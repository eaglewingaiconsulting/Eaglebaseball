import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { Toaster as SonnerToaster } from 'sonner';

// Layout
import AppLayout from './components/layout/AppLayout';

// Pages
import Dashboard from './pages/Dashboard';
import Teams from './pages/Teams';
import CreateTeam from './pages/CreateTeam';
import TeamDetail from './pages/TeamDetail';
import Games from './pages/Games';
import CreateGame from './pages/CreateGame';
import GameDetail from './pages/GameDetail';
import LineupSetup from './pages/LineupSetup.jsx';
import ScoringView from './pages/ScoringView';
import PublicGameView from './pages/PublicGameView';
import StreamSetup from './pages/StreamSetup';
import Standings from './pages/Standings';
import Stats from './pages/Stats';
import AdminPanel from './pages/AdminPanel';
import ImportTeam from './pages/ImportTeam';
import PlayerDetail from './pages/PlayerDetail';
import Onboarding from './pages/Onboarding';
import RSVPPage from './pages/RSVPPage';
import FanView from './pages/FanView';
import Landing from './pages/Landing';
import Settings from './pages/Settings';
import DemoRoleSelect from './pages/DemoRoleSelect';
import GetStarted from './pages/GetStarted';
import AcceptInvite from './pages/AcceptInvite';
import OrgDashboard from './pages/OrgDashboard';
import TeamStore from './pages/TeamStore';
import LineupTemplates from './pages/LineupTemplates';
import CoachDashboard from './pages/CoachDashboard';
import LiveGames from './pages/LiveGames';
import TeamMessages from './pages/TeamMessages';
import FeedbackButton from './components/FeedbackButton';
import { ThemeProvider } from '@/lib/ThemeContext';
import { BrandingProvider } from '@/lib/BrandingContext';
import { RoleSwitcherProvider } from '@/lib/RoleSwitcherContext';
import { DemoProvider } from '@/lib/DemoContext';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin, isAuthenticated } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
          <div className="text-sm text-muted-foreground font-medium">Loading EagleBaseball...</div>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      const isDemoMode = sessionStorage.getItem('demoMode') === '1';
      // Demo mode bypasses auth requirement — fall through to full app
      if (!isDemoMode) {
        return (
          <Routes>
            <Route path="/games/:id/public" element={<PublicGameView />} />
            <Route path="/teams/import/:code" element={<ImportTeam />} />
            <Route path="/teams/fan/:code" element={<FanView />} />
            <Route path="/invite/:token" element={<AcceptInvite />} />
            <Route path="/demo/role-select" element={<DemoRoleSelect />} />
            <Route path="*" element={<Landing />} />
          </Routes>
        );
      }
    }
  }

  // If not authenticated and no error, check for demo mode
  if (!isAuthenticated && !isLoadingAuth && !authError) {
    const isDemoMode = sessionStorage.getItem('demoMode') === '1';
    if (!isDemoMode) {
      return (
        <Routes>
          <Route path="/games/:id/public" element={<PublicGameView />} />
          <Route path="/teams/import/:code" element={<ImportTeam />} />
          <Route path="/teams/fan/:code" element={<FanView />} />
          <Route path="/invite/:token" element={<AcceptInvite />} />
          <Route path="/demo/role-select" element={<DemoRoleSelect />} />
          <Route path="*" element={<Landing />} />
        </Routes>
      );
    }
    // Demo mode — fall through to full app routes below
  }

  return (
    <Routes>
      {/* Public routes (no layout) */}
      <Route path="/games/:id/public" element={<PublicGameView />} />
      <Route path="/teams/import/:code" element={<ImportTeam />} />
      <Route path="/teams/fan/:code" element={<FanView />} />
      <Route path="/invite/:token" element={<AcceptInvite />} />
      <Route path="/onboarding" element={<Onboarding />} />
      <Route path="/get-started" element={<GetStarted />} />
      <Route path="/demo/role-select" element={<DemoRoleSelect />} />

      {/* App routes with sidebar layout */}
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/teams" element={<Teams />} />
        <Route path="/teams/create" element={<CreateTeam />} />
        <Route path="/teams/:id" element={<TeamDetail />} />
        <Route path="/games" element={<Games />} />
        <Route path="/games/create" element={<CreateGame />} />
        <Route path="/games/:id" element={<GameDetail />} />
        <Route path="/games/:id/lineup" element={<LineupSetup />} />
        <Route path="/games/:id/score" element={<ScoringView />} />
        <Route path="/games/:id/stream" element={<StreamSetup />} />
        <Route path="/games/:id/live" element={<GameDetail />} />
        <Route path="/standings" element={<Standings />} />
        <Route path="/stats" element={<Stats />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="/players/:id" element={<PlayerDetail />} />
        <Route path="/games/:gameId/rsvp" element={<RSVPPage />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/org" element={<OrgDashboard />} />
        <Route path="/teams/:id/store" element={<TeamStore />} />
        <Route path="/teams/:id/lineups" element={<LineupTemplates />} />
        <Route path="/games/:id/coach" element={<CoachDashboard />} />
        <Route path="/games/live" element={<LiveGames />} />
        <Route path="/teams/:id/messages" element={<TeamMessages />} />
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <ThemeProvider>
    <BrandingProvider>
    <DemoProvider>
    <RoleSwitcherProvider>
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <FeedbackButton />
        <Toaster />
        <SonnerToaster position="top-right" richColors />
      </QueryClientProvider>
    </AuthProvider>
    </RoleSwitcherProvider>
    </DemoProvider>
    </BrandingProvider>
    </ThemeProvider>
  );
}

export default App;