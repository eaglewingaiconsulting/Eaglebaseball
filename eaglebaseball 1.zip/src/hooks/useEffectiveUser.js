import { useAuth } from '@/lib/AuthContext';
import { useRoleSwitcher, getEffectiveUser, isMasterAccount } from '@/lib/RoleSwitcherContext';

/**
 * Returns a user object with the role overridden for the master/QA account
 * based on the active role in the Role Switcher panel.
 * For all other accounts, returns the real user unchanged.
 */
export default function useEffectiveUser() {
  const auth = useAuth();
  const roleSwitcher = useRoleSwitcher();

  const user = auth.user;

  if (!user || !isMasterAccount(user.email) || !roleSwitcher) {
    return auth;
  }

  const effectiveUser = getEffectiveUser(user, roleSwitcher.activeRole);
  return { ...auth, user: effectiveUser };
}