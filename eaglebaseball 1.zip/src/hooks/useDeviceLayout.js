import { useState, useEffect } from 'react';

export default function useDeviceLayout() {
  const [width, setWidth] = useState(window.innerWidth);

  useEffect(() => {
    const handler = () => setWidth(window.innerWidth);
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);

  const isPhone = width < 768;
  const isTablet = width >= 768;

  return { isPhone, isTablet, width };
}