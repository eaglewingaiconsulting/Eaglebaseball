import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

/**
 * Resolves the user's effective app-level role:
 *   'org_owner'  — owns or admins an Organization
 *   'coach'      — coach_email or admin_emails on any Team
 *   'parent'     — has a Player with matching parent_email (player/payer)
 *   'fan'        — in fan_emails on any Team or Player
 *   null         — not yet resolved / unauthenticated
 *
 * Priority: org_owner > coach > parent > fan
 *
 * Also exposes:
 *   myTeams      — teams the user is affiliated with
 *   myOrg        — the org they own/admin (if any)
 *   myPlayers    — players where parent_email === user.email
 *   appRole      — the resolved role string
 *   isCoach      — shorthand boolean
 *   isParent     — shorthand boolean
 *   isFan        — shorthand boolean
 *   isOrgOwner   — shorthand boolean
 */
export default function useAppRole() {
  const { user, isAuthenticated } = useAuth();
  const [appRole, setAppRole] = useState(null);
  const [myTeams, setMyTeams] = useState([]);
  const [myOrg, setMyOrg] = useState(null);
  const [myPlayers, setMyPlayers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated || !user?.email) {
      setLoading(false);
      return;
    }

    // Platform admins are always org_owner level
    if (user.role === 'admin') {
      setAppRole('org_owner');
      setLoading(false);
      return;
    }

    const email = user.email;

    (async () => {
      try {
        const [allTeams, orgs, players] = await Promise.all([
          base44.entities.Team.list('-created_date', 200),
          base44.entities.Organization.list(),
          base44.entities.Player.filter({ parent_email: email }),
        ]);

        // Org owner / admin
        const ownedOrg = orgs.find(o =>
          o.owner_email === email || (o.admin_emails || []).includes(email)
        );

        // Teams the user is affiliated with
        const coachTeams = allTeams.filter(t =>
          t.coach_email === email || (t.admin_emails || []).includes(email)
        );
        const fanTeams = allTeams.filter(t => (t.fan_emails || []).includes(email));

        setMyOrg(ownedOrg || null);
        setMyTeams([...new Map([...coachTeams, ...fanTeams].map(t => [t.id, t])).values()]);
        setMyPlayers(players || []);

        // Resolve role by priority
        if (ownedOrg) {
          setAppRole('org_owner');
        } else if (coachTeams.length > 0) {
          setAppRole('coach');
        } else if (players && players.length > 0) {
          setAppRole('parent');
        } else if (fanTeams.length > 0) {
          setAppRole('fan');
        } else {
          // Default: if logged in but no affiliation found, treat as fan
          setAppRole('fan');
        }
      } catch (e) {
        console.error('useAppRole error:', e);
        setAppRole('fan');
      } finally {
        setLoading(false);
      }
    })();
  }, [user?.email, user?.role, isAuthenticated]);

  return {
    appRole,
    loading,
    myTeams,
    myOrg,
    myPlayers,
    isOrgOwner: appRole === 'org_owner',
    isCoach: appRole === 'org_owner' || appRole === 'coach',
    isParent: appRole === 'parent',
    isFan: appRole === 'fan',
  };
}