/**
 * TeamMessages — Feature 5: Native in-app team communication.
 * Team channel + DM threads, coach emphasis, pinning, quick templates.
 * Text-only v1, real-time via subscribe().
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import TeamChannel from '@/components/messaging/TeamChannel';
import DMInbox from '@/components/messaging/DMInbox';
import DMThread from '@/components/messaging/DMThread';
import { ArrowLeft, MessageSquare, Inbox } from 'lucide-react';

export default function TeamMessages() {
  const { id: teamId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('channel'); // 'channel' | 'dms'
  const [dmPartner, setDmPartner] = useState(null); // { email, name }

  const isCoach = team && user && (
    team.coach_email === user.email ||
    (team.admin_emails || []).includes(user.email) ||
    user.role === 'admin'
  );

  useEffect(() => {
    if (!teamId || !user) return;
    Promise.all([
      base44.entities.Team.filter({ id: teamId }),
      base44.entities.Player.filter({ team_id: teamId }),
    ]).then(([teams, ps]) => {
      setTeam(teams[0] || null);
      setPlayers(ps);
      setLoading(false);
    });
  }, [teamId, user?.email]);

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      <div className="w-7 h-7 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  if (!team) return <div className="p-6 text-center text-muted-foreground">Team not found</div>;

  // ── DM thread open ────────────────────────────────────────────────────────
  if (dmPartner) {
    return (
      <DMThread
        team={team}
        user={user}
        partner={dmPartner}
        isCoach={isCoach}
        onBack={() => setDmPartner(null)}
      />
    );
  }

  return (
    <div className="flex flex-col h-full min-h-screen bg-background">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card/95 backdrop-blur-sm sticky top-0 z-20">
        <button onClick={() => navigate(`/teams/${teamId}`)} className="p-1.5 rounded-lg hover:bg-muted">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="flex-1 min-w-0">
          <div className="font-bold text-base truncate">{team.name}</div>
          <div className="text-xs text-muted-foreground">Messages</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border bg-card sticky top-[57px] z-10">
        <button onClick={() => setTab('channel')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-semibold transition-colors relative ${tab === 'channel' ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}>
          <MessageSquare className="w-4 h-4" />
          Team Channel
          {tab === 'channel' && <span className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-primary rounded-full" />}
        </button>
        <button onClick={() => setTab('dms')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-semibold transition-colors relative ${tab === 'dms' ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}>
          <Inbox className="w-4 h-4" />
          Direct Messages
          {tab === 'dms' && <span className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-primary rounded-full" />}
        </button>
      </div>

      <div className="flex-1 min-h-0">
        {tab === 'channel' && (
          <TeamChannel team={team} user={user} players={players} isCoach={isCoach} />
        )}
        {tab === 'dms' && (
          <DMInbox team={team} user={user} players={players} isCoach={isCoach} onOpenDM={setDmPartner} />
        )}
      </div>
    </div>
  );
}