import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Plus, Search, Play, Clock, CheckCircle, Calendar, List, RefreshCw, Trophy } from 'lucide-react';
import GamesCalendarView from '@/components/games/GamesCalendarView';
import usePullToRefresh from '@/hooks/usePullToRefresh';

const STATUS_CONFIG = {
  scheduled:  { label: 'Scheduled', color: 'rgba(255,255,255,0.55)', bg: 'rgba(255,255,255,0.08)' },
  in_progress:{ label: 'Live',      color: '#4ADE80',               bg: 'rgba(74,222,128,0.12)' },
  completed:  { label: 'Final',     color: 'rgba(255,255,255,0.4)', bg: 'rgba(255,255,255,0.06)' },
  final:      { label: 'Final',     color: 'rgba(255,255,255,0.4)', bg: 'rgba(255,255,255,0.06)' },
  postponed:  { label: 'Postponed', color: '#F59E0B',               bg: 'rgba(245,158,11,0.12)' },
  cancelled:  { label: 'Cancelled', color: '#F87171',               bg: 'rgba(248,113,113,0.12)' },
};

export default function Games() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [viewMode, setViewMode] = useState('list');

  const fetchGames = useCallback(async () => {
    const g = await base44.entities.Game.list('-scheduled_date', 100);
    const isDemoMode = sessionStorage.getItem('demoMode') === '1';
    // Only show demo games if in demo mode
    setGames(isDemoMode ? g : g.filter(game => !game.is_demo));
    setLoading(false);
  }, []);

  useEffect(() => { fetchGames(); }, [fetchGames]);
  const { refreshing } = usePullToRefresh(fetchGames);

  const filtered = games.filter(g => {
    const matchSearch = (g.home_team_name || '').toLowerCase().includes(search.toLowerCase()) ||
      (g.away_team_name || '').toLowerCase().includes(search.toLowerCase()) ||
      (g.location || '').toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || g.status === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
      {refreshing && (
        <div className="flex items-center justify-center gap-2 py-2 text-sm" style={{ backgroundColor: '#0F1729', color: '#F59E0B' }}>
          <RefreshCw className="w-4 h-4 animate-spin" /> Refreshing...
        </div>
      )}

      {/* Header */}
      <div className="px-4 pt-6 pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
          <div>
            <h1 className="font-bebas tracking-widest" style={{ fontSize: 40, letterSpacing: '0.08em', color: '#fff' }}>Games</h1>
            <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>{filtered.length === games.length ? games.length : filtered.length} game{games.length !== 1 ? 's' : ''} total</p>
          </div>
          <div className="flex items-center gap-2">
            {/* View toggle */}
            <div className="flex overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
              {[['list', <List className="w-3.5 h-3.5" />, 'List'], ['calendar', <Calendar className="w-3.5 h-3.5" />, 'Calendar']].map(([mode, icon, label]) => (
                <button key={mode} onClick={() => setViewMode(mode)}
                  className="flex items-center gap-1.5 px-3 py-2 text-sm transition-colors select-none"
                  style={{ backgroundColor: viewMode === mode ? '#F59E0B' : 'transparent', color: viewMode === mode ? '#0B1120' : 'rgba(255,255,255,0.6)', fontWeight: viewMode === mode ? 700 : 400 }}>
                  {icon} {label}
                </button>
              ))}
            </div>
            <Link to="/games/create">
              <button className="flex items-center gap-2 px-4 py-2 font-bold text-sm select-none touch-manipulation"
                style={{ backgroundColor: '#F59E0B', color: '#0B1120', borderRadius: 8 }}>
                <Plus className="w-4 h-4" /> Schedule
              </button>
            </Link>
          </div>
        </div>

        {/* Search + filters */}
        <div className="flex flex-wrap gap-2 mb-4">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'rgba(255,255,255,0.35)' }} />
            <input
              placeholder="Search games..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm outline-none"
              style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#fff' }}
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {[['all','All'],['in_progress','Live'],['scheduled','Upcoming'],['completed','Final']].map(([f, label]) => (
              <button key={f} onClick={() => setFilter(f)}
                className="px-3 py-2 rounded-lg text-sm font-medium transition-colors select-none"
                style={{ backgroundColor: filter === f ? '#F59E0B' : 'rgba(255,255,255,0.06)', color: filter === f ? '#0B1120' : 'rgba(255,255,255,0.6)', fontWeight: filter === f ? 700 : 400 }}>
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {viewMode === 'calendar' && !loading && (
        <div className="px-4"><GamesCalendarView games={filtered} /></div>
      )}

      {viewMode === 'list' && loading && (
        <div className="px-4 space-y-2">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-20 rounded-xl animate-pulse" style={{ backgroundColor: '#131929' }} />
          ))}
        </div>
      )}

      {viewMode === 'list' && !loading && filtered.length === 0 && (
        <div className="px-4">
          <div className="rounded-xl p-12 text-center" style={{ border: '1px dashed rgba(245,158,11,0.3)' }}>
            <Calendar className="w-10 h-10 mx-auto mb-3" style={{ color: 'rgba(255,255,255,0.25)' }} />
            <div className="font-semibold text-white">No games found</div>
            <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: 13 }} className="mt-1 mb-4">Schedule your first game</p>
            <Link to="/games/create">
              <button className="px-5 py-2 font-bold text-sm" style={{ backgroundColor: '#F59E0B', color: '#0B1120', borderRadius: 8 }}>
                Schedule Game
              </button>
            </Link>
          </div>
        </div>
      )}

      {viewMode === 'list' && !loading && filtered.length > 0 && (
        <div className="px-4 space-y-2">
          {filtered.map(game => {
            const cfg = STATUS_CONFIG[game.status] || STATUS_CONFIG.scheduled;
            const isLive = game.status === 'in_progress';
            return (
              <Link key={game.id} to={isLive ? `/games/${game.id}/live` : `/games/${game.id}`}
                className="flex flex-col sm:flex-row sm:items-center gap-3 px-4 py-4 active:opacity-80 transition-all select-none touch-manipulation"
                style={{ backgroundColor: '#131929', border: `1px solid ${isLive ? 'rgba(74,222,128,0.25)' : 'rgba(255,255,255,0.07)'}`, borderRadius: 10 }}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ color: cfg.color, backgroundColor: cfg.bg }}>
                      {cfg.label}
                    </span>
                    {isLive && <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />}
                    {game.tournament_name && (
                      <span className="flex items-center gap-1 text-xs font-medium" style={{ color: '#F59E0B' }}>
                        <Trophy className="w-3 h-3" /> {game.tournament_name}
                      </span>
                    )}
                  </div>
                  <div className="font-semibold text-white" style={{ fontSize: 15 }}>
                    {game.away_team_name || 'Away'} @ {game.home_team_name || 'Home'}
                  </div>
                  <div className="flex items-center gap-1 mt-0.5" style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12 }}>
                    <Clock className="w-3 h-3 flex-shrink-0" />
                    {game.scheduled_date}{game.scheduled_time && ` · ${game.scheduled_time}`}
                    {game.location && ` · ${game.location}`}
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  {game.status !== 'scheduled' ? (
                    <div className="font-bebas" style={{ fontSize: 30, color: '#F59E0B', letterSpacing: '0.08em', textShadow: isLive ? '0 0 10px rgba(245,158,11,0.6)' : 'none' }}>
                      {game.away_score ?? 0}–{game.home_score ?? 0}
                    </div>
                  ) : (
                    <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 12 }}>{game.league || ''}</span>
                  )}
                  {isLive && (
                    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11 }}>
                      Inn. {game.inning} {game.inning_half === 'top' ? '▲' : '▼'}
                    </div>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}