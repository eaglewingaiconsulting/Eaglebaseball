import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building2, Users, UserCircle, Star, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DEMO_ROLES } from '@/lib/DemoContext';

const ROLE_META = {
  coach:     { icon: Users,      color: 'bg-amber-500' },
  parent:    { icon: UserCircle, color: 'bg-green-600' },
  fan:       { icon: Star,       color: 'bg-purple-600' },
  org_owner: { icon: Building2,  color: 'bg-blue-600' },
};

export default function DemoRoleSelect() {
  const navigate = useNavigate();
  const [selectedRole, setSelectedRole] = useState(DEMO_ROLES[0]);

  const handleContinue = () => {
    sessionStorage.setItem('demoMode', '1');
    sessionStorage.setItem('demoRole', selectedRole.id);
    window.location.href = '/';
  };

  return (
    <div className="h-screen bg-gradient-to-br from-[hsl(214,90%,10%)] to-[hsl(214,90%,20%)] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-2xl flex flex-col gap-4">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 bg-amber-500/20 text-amber-400 text-xs font-semibold px-3 py-1.5 rounded-full mb-3 border border-amber-500/30 uppercase tracking-widest">
            Demo Mode
          </div>
          <h1 className="font-bebas text-4xl sm:text-5xl text-white tracking-wider leading-none mb-1">
            Choose Your Role
          </h1>
          <p className="text-white/50 text-sm">Pick the perspective you'd like to explore. Uses real live app data.</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {DEMO_ROLES.map(role => {
            const meta = ROLE_META[role.id] || { icon: Users, color: 'bg-primary' };
            const RoleIcon = meta.icon;
            return (
              <button
                key={role.id}
                onClick={() => setSelectedRole(role)}
                className={`relative text-left rounded-2xl border-2 p-4 transition-all ${
                  selectedRole?.id === role.id
                    ? 'border-amber-400 bg-white/10'
                    : 'border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                {selectedRole?.id === role.id && (
                  <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-amber-400 flex items-center justify-center">
                    <ChevronRight className="w-3 h-3 text-black" />
                  </div>
                )}
                <div className={`w-9 h-9 rounded-xl ${meta.color} flex items-center justify-center mb-2`}>
                  <RoleIcon className="w-4 h-4 text-white" />
                </div>
                <div className="font-semibold text-white text-sm mb-0.5">{role.label}</div>
                <div className="text-xs text-white/50 leading-snug">{role.description}</div>
              </button>
            );
          })}
        </div>

        <Button
          onClick={handleContinue}
          size="lg"
          className="w-full bg-amber-500 hover:bg-amber-400 text-black font-bold text-base py-5 rounded-xl gap-2"
        >
          Enter Demo <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}