/**
 * TeamStore — public-facing store page for a team.
 * Queries unified StoreItem (scope=team + scope=org for this team's org).
 * Shows Org badge on org-scoped items.
 * Uses default type-based image when no custom image uploaded.
 */
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { ShoppingBag, Settings, ClipboardList, Loader2, CheckCircle, Building2 } from 'lucide-react';
import { toast } from 'sonner';
import UniformSizeModal from '@/components/store/UniformSizeModal';
import TeamStoreManager from '@/components/store/TeamStoreManager';
import TeamStoreOrders from '@/components/store/TeamStoreOrders';

// Default images shown when item has no image_url
const DEFAULT_IMAGE = {
  gear: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&q=80',
  dues: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&q=80',
};

export default function TeamStore() {
  const { id: teamId } = useParams();
  const { user } = useAuth();
  const [team, setTeam] = useState(null);
  const [items, setItems] = useState([]);
  const [orders, setOrders] = useState([]);
  const [player, setPlayer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showSizeModal, setShowSizeModal] = useState(false);
  const [pendingItem, setPendingItem] = useState(null);
  const [activeTab, setActiveTab] = useState('store');

  const isCoachOrAdmin = team && user && (
    team.coach_email === user.email ||
    (team.admin_emails || []).includes(user.email) ||
    user.role === 'admin'
  );

  useEffect(() => {
    const load = async () => {
      const [teams] = await Promise.all([base44.entities.Team.filter({ id: teamId })]);
      const t = teams[0] || null;
      setTeam(t);

      if (!t) { setLoading(false); return; }

      // Fetch team items + org items (if team belongs to an org)
      const queries = [
        base44.entities.StoreItem.filter({ team_id: teamId, scope: 'team', status: 'active' }),
      ];
      if (t.org_id) {
        queries.push(base44.entities.StoreItem.filter({ org_id: t.org_id, scope: 'org', status: 'active' }));
      }
      const results = await Promise.all(queries);
      const allItems = results.flat();
      // Sort: org items first, then by name
      allItems.sort((a, b) => {
        if (a.scope === 'org' && b.scope !== 'org') return -1;
        if (a.scope !== 'org' && b.scope === 'org') return 1;
        return (a.name || '').localeCompare(b.name || '');
      });
      setItems(allItems);

      if (user) {
        const [players, myOrders] = await Promise.all([
          base44.entities.Player.filter({ team_id: teamId }),
          base44.entities.StoreOrder.filter({ team_id: teamId, created_by: user.email }),
        ]);
        const myPlayer = players.find(p => p.parent_email === user.email);
        if (myPlayer) setPlayer(myPlayer);
        setOrders(myOrders.filter(o => o.payment_status === 'paid'));
      }

      setLoading(false);
    };
    load();
  }, [teamId, user?.email]);

  const handleBuy = (item) => {
    if (!user) { base44.auth.redirectToLogin(); return; }
    if (player && (!player.shirt_size || !player.hat_size || !player.pants_size) && item.item_type === 'gear') {
      setPendingItem(item);
      setShowSizeModal(true);
      return;
    }
    initiatePurchase(item);
  };

  const initiatePurchase = async (item) => {
    const newOrder = await base44.entities.StoreOrder.create({
      store_item_id: item.id,
      team_id: teamId,
      org_id: team?.org_id || null,
      scope: item.scope || 'team',
      item_type: item.item_type,
      item_name: item.name,
      parent_name: user.full_name || user.email,
      player_id: player?.id || null,
      player_name: player?.name || null,
      amount_paid: item.price,
      payment_status: 'paid',
      payment_date: new Date().toISOString().split('T')[0],
    });
    setOrders(prev => [...prev, newOrder]);
    toast.success(`Payment recorded for ${item.name}`);
  };

  const hasPaid = (itemId) => orders.some(o => o.store_item_id === itemId);

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
    </div>
  );
  if (!team) return <div className="p-6 text-center text-muted-foreground">Team not found</div>;

  const tabs = [
    { id: 'store', label: 'STORE', icon: ShoppingBag },
    ...(isCoachOrAdmin ? [
      { id: 'manage', label: 'MANAGE ITEMS', icon: Settings },
      { id: 'orders', label: 'ORDERS', icon: ClipboardList },
    ] : []),
  ];

  return (
    <div className="min-h-screen bg-white flex flex-col max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-center gap-3 px-4 py-3 border-b border-gray-100 bg-white">
        {team.logo_url ? (
          <img src={team.logo_url} alt={team.name} className="h-8 object-contain" />
        ) : (
          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-xs"
            style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>
            {(team.name || '').slice(0, 2).toUpperCase()}
          </div>
        )}
        <span className="text-base font-bold text-gray-900">{team.name}</span>
      </div>

      {/* Tab Bar */}
      <div className="bg-white border-b border-gray-100 flex sticky top-0 z-40">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 transition-colors select-none text-sm font-semibold relative">
              <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-gray-400'}`} />
              <span className={isActive ? 'text-blue-600' : 'text-gray-400'}>{tab.label}</span>
              {isActive && <div className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-blue-600 rounded-full" />}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="flex-1">
        {activeTab === 'store' && (
          <>
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 px-6 text-center gap-4">
                <ShoppingBag className="w-16 h-16 text-gray-200" />
                <p className="text-lg font-bold text-gray-900">No Items</p>
                <p className="text-sm text-gray-500">No store items published yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3 p-3">
                {items.map(item => {
                  const imgSrc = item.image_url || DEFAULT_IMAGE[item.item_type] || DEFAULT_IMAGE.gear;
                  const isOrg = item.scope === 'org';
                  return (
                    <div key={item.id} className="relative rounded-2xl overflow-hidden aspect-[3/4] bg-gray-200 shadow-md">
                      {/* Full-bleed image */}
                      <img src={imgSrc} alt={item.name} className="absolute inset-0 w-full h-full object-cover" />

                      {/* Org badge */}
                      {isOrg && (
                        <div className="absolute top-2 left-2 flex items-center gap-1 bg-blue-600/90 backdrop-blur-sm px-2 py-0.5 rounded-full">
                          <Building2 className="w-2.5 h-2.5 text-white" />
                          <span className="text-white text-xs font-bold">ORG</span>
                        </div>
                      )}

                      {/* Dark gradient overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                      {/* Content */}
                      <div className="absolute bottom-0 left-0 right-0 p-3">
                        <p className="text-white font-black text-sm uppercase leading-tight tracking-wide line-clamp-1">
                          {item.name}
                        </p>
                        {item.description && (
                          <p className="text-white/70 text-xs mt-0.5 line-clamp-2 leading-tight">{item.description}</p>
                        )}
                        <div className="flex items-center justify-between gap-2 mt-2">
                          <div className="bg-white rounded-lg px-2 py-1 flex-shrink-0">
                            <span className="text-gray-900 font-black text-sm">${(item.price || 0).toFixed(2)}</span>
                          </div>
                          {hasPaid(item.id) ? (
                            <div className="bg-green-500 rounded-lg px-2 py-1 flex items-center gap-1">
                              <CheckCircle className="w-3 h-3 text-white" />
                              <span className="text-white font-bold text-xs">PAID</span>
                            </div>
                          ) : (
                            <button onClick={() => handleBuy(item)}
                              className="bg-blue-600 hover:bg-blue-700 active:scale-95 transition-all rounded-lg px-2.5 py-1 flex-shrink-0">
                              <span className="text-white font-black text-xs tracking-wide">BUY NOW</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {activeTab === 'manage' && isCoachOrAdmin && (
          <div className="p-4">
            <TeamStoreManager team={team} />
          </div>
        )}
        {activeTab === 'orders' && isCoachOrAdmin && (
          <div className="p-4">
            <TeamStoreOrders teamId={teamId} />
          </div>
        )}
      </div>

      {showSizeModal && player && (
        <UniformSizeModal
          player={player}
          onSaved={(updated) => {
            setPlayer(updated);
            setShowSizeModal(false);
            if (pendingItem) { initiatePurchase(pendingItem); setPendingItem(null); }
          }}
          onClose={() => { setShowSizeModal(false); setPendingItem(null); }}
        />
      )}
    </div>
  );
}