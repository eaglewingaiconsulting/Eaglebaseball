import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building2, Users, ChevronRight, Zap, Heart, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function GetStarted() {
  const navigate = useNavigate();
  const [fanCode, setFanCode] = useState('');
  const [findingTeam, setFindingTeam] = useState(false);
  const [showFanInput, setShowFanInput] = useState(false);

  const handleFanJoin = async () => {
    const code = fanCode.trim().toUpperCase();
    if (!code) { toast.error('Enter a team code'); return; }
    setFindingTeam(true);
    const teams = await base44.entities.Team.filter({ share_code: code });
    setFindingTeam(false);
    if (!teams[0]) { toast.error('Team not found — check the code and try again'); return; }
    navigate(`/teams/fan/${code}`);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center mx-auto mb-4">
            <Zap className="w-6 h-6 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Welcome to EagleBaseball</h1>
          <p className="text-muted-foreground text-sm max-w-xs mx-auto">
            Tell us how you're involved so we can set up the right experience.
          </p>
        </div>

        {/* Options */}
        <div className="space-y-3">

          {/* Org Owner */}
          <button
            onClick={() => navigate('/onboarding')}
            className="w-full text-left bg-card border border-border rounded-2xl p-5 hover:border-primary/50 hover:shadow-md transition-all group active:scale-[0.99] touch-manipulation"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center flex-shrink-0">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-semibold text-base">Organization Owner</span>
                  <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">Multiple teams</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">You run a travel ball club, league, or org with multiple teams across age groups or seasons.</p>
                <div className="flex items-center gap-1 mt-3 text-sm font-medium text-primary">
                  Set up organization <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            </div>
          </button>

          {/* Coach */}
          <button
            onClick={() => navigate('/teams/create')}
            className="w-full text-left bg-card border border-border rounded-2xl p-5 hover:border-primary/50 hover:shadow-md transition-all group active:scale-[0.99] touch-manipulation"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center flex-shrink-0">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-semibold text-base">Coach / Team Admin</span>
                  <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">Single team</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">You manage one team. Jump straight to building your roster and scheduling games.</p>
                <div className="flex items-center gap-1 mt-3 text-sm font-medium text-primary">
                  Create my team <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            </div>
          </button>

          {/* Fan / Parent */}
          <div className="bg-card border border-border rounded-2xl p-5 transition-all">
            <button
              onClick={() => setShowFanInput(v => !v)}
              className="w-full text-left group active:scale-[0.99] touch-manipulation"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-green-600 flex items-center justify-center flex-shrink-0">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="font-semibold text-base">Parent / Fan</span>
                    <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">Follow a team</span>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">You were invited or have a team share code. Enter it below to follow your team.</p>
                  <div className="flex items-center gap-1 mt-3 text-sm font-medium text-primary">
                    Enter team code <ChevronRight className={`w-4 h-4 transition-transform ${showFanInput ? 'rotate-90' : 'group-hover:translate-x-0.5'}`} />
                  </div>
                </div>
              </div>
            </button>

            {showFanInput && (
              <div className="mt-4 flex gap-2 border-t border-border pt-4">
                <Input
                  placeholder="Team code (e.g. EAGLE24)"
                  value={fanCode}
                  onChange={e => setFanCode(e.target.value.toUpperCase())}
                  onKeyDown={e => e.key === 'Enter' && handleFanJoin()}
                  className="uppercase font-mono tracking-widest"
                  autoFocus
                />
                <Button onClick={handleFanJoin} disabled={findingTeam} className="flex-shrink-0 gap-1.5">
                  {findingTeam ? <Loader2 className="w-4 h-4 animate-spin" /> : <ChevronRight className="w-4 h-4" />}
                  Join
                </Button>
              </div>
            )}
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6">
          Invited by a coach?{' '}
          <span className="text-foreground">Check your email for a direct link</span> — no code needed.
        </p>
      </div>
    </div>
  );
}