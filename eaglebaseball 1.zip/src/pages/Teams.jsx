import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Plus, Search, Users, Trophy } from 'lucide-react';

export default function Teams() {
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;
    const loadTeams = async () => {
      if (user.role === 'admin') {
        const all = await base44.entities.Team.list('-created_date', 100);
        setTeams(all);
        setLoading(false);
        return;
      }
      const all = await base44.entities.Team.list('-created_date', 200);
      const myPlayers = await base44.entities.Player.filter({ parent_email: user.email });
      const playerTeamIds = new Set(myPlayers.map(p => p.team_id));
      const visible = all.filter(t =>
        t.coach_email === user.email ||
        (t.admin_emails || []).includes(user.email) ||
        (t.fan_emails || []).includes(user.email) ||
        playerTeamIds.has(t.id)
      );
      setTeams(visible);
      setLoading(false);
    };
    loadTeams();
  }, [user]);

  const filtered = teams.filter(t =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    (t.city || '').toLowerCase().includes(search.toLowerCase()) ||
    (t.league || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
      <div className="px-4 pt-6 pb-4 max-w-5xl mx-auto space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="font-bebas tracking-widest" style={{ fontSize: 40, letterSpacing: '0.08em' }}>Teams</h1>
            <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>{teams.length} teams registered</p>
          </div>
          <Link to="/teams/create">
            <button className="flex items-center gap-2 px-4 py-2 font-bold text-sm select-none touch-manipulation"
              style={{ backgroundColor: '#F59E0B', color: '#0B1120', borderRadius: 8 }}>
              <Plus className="w-4 h-4" /> Create
            </button>
          </Link>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'rgba(255,255,255,0.35)' }} />
          <input
            placeholder="Search teams..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm outline-none"
            style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#fff' }}
          />
        </div>

        {/* List */}
        {loading ? (
          <div className="space-y-2">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-20 rounded-xl animate-pulse" style={{ backgroundColor: '#131929' }} />
            ))}
          </div>
        ) : filtered.length === 0 && teams.length === 0 ? (
          <div className="rounded-xl p-12 text-center" style={{ border: '1px dashed rgba(245,158,11,0.3)' }}>
            <span className="text-4xl block mb-3">⚾</span>
            <div className="font-semibold text-lg text-white">No Teams Yet</div>
            <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }} className="mt-2 mb-5 max-w-xs mx-auto">
              You haven't been added to a team. Ask your coach or org admin to add you, or create a new team.
            </p>
            <Link to="/teams/create">
              <button className="px-5 py-2 font-bold text-sm" style={{ backgroundColor: '#F59E0B', color: '#0B1120', borderRadius: 8 }}>
                Create Team
              </button>
            </Link>
          </div>
        ) : filtered.length === 0 ? (
          <div className="rounded-xl p-12 text-center" style={{ border: '1px dashed rgba(245,158,11,0.3)' }}>
            <Users className="w-10 h-10 mx-auto mb-3" style={{ color: 'rgba(255,255,255,0.25)' }} />
            <div className="font-semibold text-white">No teams match your search</div>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
            {filtered.map(team => (
              <Link
                key={team.id}
                to={`/teams/${team.id}`}
                className="flex items-center gap-4 p-4 active:scale-[0.98] transition-all select-none touch-manipulation"
                style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 12 }}
              >
                <div className="w-14 h-14 rounded-xl flex items-center justify-center text-white text-sm font-bold flex-shrink-0 overflow-hidden"
                  style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>
                  {team.logo_url
                    ? <img src={team.logo_url} alt={team.name} className="w-full h-full object-cover" />
                    : team.name.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-white truncate">{team.name}</div>
                  <div className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.4)' }}>{team.city || ''}{team.league ? ` · ${team.league}` : ''}</div>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="font-bold text-xs px-2 py-0.5 rounded-full"
                      style={{ backgroundColor: 'rgba(245,158,11,0.15)', color: '#F59E0B' }}>
                      {team.wins || 0}W–{team.losses || 0}L
                    </span>
                    {team.season && <span className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>{team.season}</span>}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}