import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { toast } from 'sonner';
import ActionPanel from '@/components/scoring/ActionPanel';
import Scoreboard from '@/components/scoring/Scoreboard';
import ScoringHeader from '@/components/scoring/ScoringHeader';
import PitcherDisplay from '@/components/scoring/PitcherDisplay';
import DropThirdStrikeModal from '@/components/scoring/DropThirdStrikeModal';
import PickoffModal from '@/components/scoring/PickoffModal';
import InningEndModal from '@/components/scoring/InningEndModal';
import EndGameModal from '@/components/scoring/EndGameModal';
import RunnerDiamond from '@/components/scoring/RunnerDiamond';
import RunnerActionSheet from '@/components/scoring/RunnerActionSheet';
import CurrentBatterDisplay from '@/components/scoring/CurrentBatterDisplay';
import StealModal from '@/components/scoring/StealModal';
import HalfInningBanner from '@/components/scoring/HalfInningBanner';
import InningsScoreboard from '@/components/scoring/InningsScoreboard';
import RosterPanel from '@/components/scoring/RosterPanel';
import SendBackModal from '@/components/scoring/SendBackModal';
import LineupGate from '@/components/scoring/LineupGate';
import GameTimerDisplay from '@/components/scoring/GameTimerDisplay';
import useDeviceLayout from '@/hooks/useDeviceLayout';

const MAX_UNDO = 3;

function gameSnapshot(g) {
  return {
    home_score: g.home_score ?? 0,
    away_score: g.away_score ?? 0,
    balls: g.balls ?? 0,
    strikes: g.strikes ?? 0,
    outs: g.outs ?? 0,
    runner_first: g.runner_first ?? false,
    runner_second: g.runner_second ?? false,
    runner_third: g.runner_third ?? false,
    current_batter_id: g.current_batter_id ?? null,
    home_batting_order_idx: g.home_batting_order_idx ?? 0,
    away_batting_order_idx: g.away_batting_order_idx ?? 0,
    home_hits: g.home_hits ?? 0,
    away_hits: g.away_hits ?? 0,
    home_errors: g.home_errors ?? 0,
    away_errors: g.away_errors ?? 0,
    current_pitcher_pitch_count: g.current_pitcher_pitch_count ?? 0,
  };
}

export default function ScoringView() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { isPhone } = useDeviceLayout();

  const [game, setGame] = useState(null);
  const [homeTeam, setHomeTeam] = useState(null);
  const [awayTeam, setAwayTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  // Modal states
  const [showDropThird, setShowDropThird] = useState(false);
  const [showPickoff, setShowPickoff] = useState(false);
  const [showInningEnd, setShowInningEnd] = useState(false);
  const [showEndGame, setShowEndGame] = useState(false);
  const [endingGame, setEndingGame] = useState(false);
  const [isFinalInningEnd, setIsFinalInningEnd] = useState(false);
  const [showStealModal, setShowStealModal] = useState(false);
  const [showScoreboard, setShowScoreboard] = useState(false);
  const [showRosterPanel, setShowRosterPanel] = useState(false);
  const [showSendBack, setShowSendBack] = useState(null); // { base, runnerId }

  // Runner action sheet
  const [runnerActionBase, setRunnerActionBase] = useState(null);

  // Undo stack — stores { snapshot, playLogId }
  const [undoStack, setUndoStack] = useState([]);

  // Inning-level stat tracking
  const [inningStats, setInningStats] = useState({ pitches: 0, runs: 0, hits: 0, errors: 0, strikeouts: 0, walks: 0 });
  const [recentEvents, setRecentEvents] = useState([]);
  const inningStartScoreRef = useRef({ home: 0, away: 0 });

  // Keep a ref to game for use in callbacks without stale closures
  const gameRef = useRef(game);
  useEffect(() => { gameRef.current = game; }, [game]);

  const loadGame = async () => {
    if (!id || id === ':id') return;
    const [games] = await Promise.all([base44.entities.Game.filter({ id })]);
    if (!games[0]) return;
    const g = games[0];
    setGame(g);
    const [ht, at, hp, ap] = await Promise.all([
      g.home_team_id ? base44.entities.Team.filter({ id: g.home_team_id }) : Promise.resolve([]),
      g.away_team_id ? base44.entities.Team.filter({ id: g.away_team_id }) : Promise.resolve([]),
      g.home_team_id ? base44.entities.Player.filter({ team_id: g.home_team_id }) : Promise.resolve([]),
      g.away_team_id ? base44.entities.Player.filter({ team_id: g.away_team_id }) : Promise.resolve([]),
    ]);
    setHomeTeam(ht[0] || null);
    setAwayTeam(at[0] || null);
    setPlayers([...hp, ...ap]);
    setLoading(false);
  };

  useEffect(() => { loadGame(); }, [id]);

  useEffect(() => {
    const unsub = base44.entities.Game.subscribe(evt => {
      if (evt.id === id && evt.type !== 'delete') setGame(evt.data);
    });
    return unsub;
  }, [id]);

  const updateGame = async (updates) => {
    setUpdating(true);
    setGame(prev => prev ? { ...prev, ...updates } : prev);
    try {
      await base44.entities.Game.update(id, updates);
    } catch {
      toast.error('Sync error — refreshing…');
      loadGame();
    } finally {
      setUpdating(false);
    }
  };

  const logEvent = async (eventType, description, metadata = {}) => {
    const g = gameRef.current;
    const evt = await base44.entities.GameEvent.create({
      game_id: id,
      inning: g.inning,
      inning_half: g.inning_half,
      event_type: eventType,
      description,
      team_id: g.inning_half === 'top' ? g.away_team_id : g.home_team_id,
      metadata,
      timestamp: new Date().toISOString(),
    });
    setRecentEvents(prev => [evt, ...prev].slice(0, 10));
    return evt;
  };

  // Push a snapshot before an action (for undo)
  const pushUndo = (playLogId = null) => {
    const g = gameRef.current;
    if (!g) return;
    setUndoStack(prev => [{ snapshot: gameSnapshot(g), playLogId }, ...prev].slice(0, MAX_UNDO));
  };

  const handleUndo = () => {
    if (!undoStack.length) return;
    const entry = undoStack[0];
    toast('Undo last action?', {
      action: {
        label: 'Confirm Undo',
        onClick: async () => {
          // Delete play log if exists
          if (entry.playLogId) {
            try { await base44.entities.PlayLog.delete(entry.playLogId); } catch {}
          }
          // Restore game state
          await updateGame(entry.snapshot);
          setUndoStack(prev => prev.slice(1));
        },
      },
      duration: 4000,
    });
  };

  const incrementPitch = () => {
    const g = gameRef.current;
    const newPitchCount = (g.current_pitcher_pitch_count || 0) + 1;
    setInningStats(prev => ({ ...prev, pitches: prev.pitches + 1 }));
    return { current_pitcher_pitch_count: newPitchCount };
  };

  const countRunners = (g) => (g.runner_first ? 1 : 0) + (g.runner_second ? 1 : 0) + (g.runner_third ? 1 : 0);

  // applyRunnerAdvancements: applies the runner movement selections from RunnerAdvancementModal
  const applyRunnerAdvancements = (g, selections, updates, isTopInning) => {
    const scoreTeam = (isTopInning ? 'away' : 'home') + '_score';
    let score = g[isTopInning ? 'away_score' : 'home_score'] || 0;

    // Process in reverse base order to avoid overwriting
    const bases = ['third', 'second', 'first'];
    const newState = {
      runner_first: g.runner_first,
      runner_second: g.runner_second,
      runner_third: g.runner_third,
    };

    // First clear all bases that have runners advancing
    for (const base of bases) {
      if (!selections[base]) continue;
      newState[`runner_${base}`] = false;
    }

    // Then place runners at their new positions
    for (const base of bases) {
      const sel = selections[base];
      if (!sel || sel === 'stayed') {
        newState[`runner_${base}`] = g[`runner_${base}`];
        continue;
      }
      if (sel === 'scored') {
        score++;
      } else if (sel === 'next') {
        const dest = base === 'first' ? 'second' : base === 'second' ? 'third' : null;
        if (dest) newState[`runner_${dest}`] = true;
        else score++; // runner on 3rd "next" = score
      } else if (sel === 'two') {
        const dest = base === 'first' ? 'third' : null;
        if (dest) newState[`runner_${dest}`] = true;
        else score++;
      }
    }

    updates.runner_first = newState.runner_first;
    updates.runner_second = newState.runner_second;
    updates.runner_third = newState.runner_third;
    updates[scoreTeam] = score;
  };

  // advanceRunners: moves all runners forward by `bases` bases (hit logic — everyone advances)
  const advanceRunners = (g, updates, bases) => {
    const isTop = g.inning_half === 'top';
    const scoreTeam = (isTop ? 'away' : 'home') + '_score';
    let score = g[isTop ? 'away_score' : 'home_score'] || 0;
    const r1 = g.runner_first; // may be a player ID or true
    const r2 = g.runner_second;
    const r3 = g.runner_third;
    const batterId = g.current_batter_id || true; // store batter ID so diamond can show number
    if (bases === 1) {
      // Single: everyone advances one base; runner on 3rd scores
      if (r3) score++;
      updates.runner_third = r2 || false;
      updates.runner_second = r1 || false;
      updates.runner_first = batterId;
    } else if (bases === 2) {
      // Double: r3 scores, r2 scores, r1 → 3rd, batter → 2nd
      if (r3) score++;
      if (r2) score++;
      updates.runner_third = r1 || false;
      updates.runner_second = batterId;
      updates.runner_first = false;
    } else if (bases === 3) {
      // Triple: all runners score, batter → 3rd
      if (r3) score++;
      if (r2) score++;
      if (r1) score++;
      updates.runner_third = batterId;
      updates.runner_second = false;
      updates.runner_first = false;
    }
    updates[scoreTeam] = score;
  };

  // forceAdvanceRunners: walk/HBP force-advance — only runners forced by the chain advance
  const forceAdvanceRunners = (g, updates) => {
    const isTop = g.inning_half === 'top';
    const scoreTeam = (isTop ? 'away' : 'home') + '_score';
    let score = g[isTop ? 'away_score' : 'home_score'] || 0;
    const r1 = g.runner_first;
    const r2 = g.runner_second;
    const r3 = g.runner_third;
    const batterId = g.current_batter_id || true;
    // Bases-loaded: r3 scores, everyone else advances one
    if (r1 && r2 && r3) {
      score++;
      updates.runner_third = r2;
      updates.runner_second = r1;
      updates.runner_first = batterId;
    } else if (r1 && r2) {
      updates.runner_third = r2;
      updates.runner_second = r1;
      updates.runner_first = batterId;
    } else if (r1) {
      updates.runner_second = r1;
      updates.runner_first = batterId;
    } else {
      updates.runner_first = batterId;
    }
    updates[scoreTeam] = score;
  };

  const advanceBatter = (updates) => {
    const g = gameRef.current;
    const isTop = g.inning_half === 'top';
    const lineup = isTop ? (g.away_lineup || []) : (g.home_lineup || []);
    if (!lineup.length) return;
    const idxField = isTop ? 'away_batting_order_idx' : 'home_batting_order_idx';
    const curIdx = isTop ? (g.away_batting_order_idx || 0) : (g.home_batting_order_idx || 0);
    const nextIdx = (curIdx + 1) % lineup.length;
    updates[idxField] = nextIdx;
    updates.current_batter_id = lineup[nextIdx];
  };

  const doOut = async (extraUpdates = {}) => {
    const g = gameRef.current;
    const newOuts = (g.outs || 0) + 1;
    if (newOuts >= 3) {
      const isTop = g.inning_half === 'top';
      const curScore = isTop ? (g.away_score || 0) : (g.home_score || 0);
      const startScore = isTop ? inningStartScoreRef.current.away : inningStartScoreRef.current.home;
      setInningStats(prev => ({ ...prev, runs: Math.max(0, curScore - startScore) }));
      const totalInnings = g.total_innings || 9;
      const isLastHalf = !isTop && g.inning >= totalInnings;
      setIsFinalInningEnd(isLastHalf);
      setShowInningEnd(true);
      await updateGame({ outs: newOuts, ...extraUpdates });
    } else {
      const extras = { outs: newOuts, balls: 0, strikes: 0, ...extraUpdates };
      advanceBatter(extras);
      await updateGame(extras);
    }
  };

  const handleEndGameConfirm = async () => {
    setEndingGame(true);
    try {
      const g = gameRef.current;
      await base44.entities.Game.update(id, { status: 'final', ended_early: true, final_inning: g.inning });
      await logEvent('game_end', 'Game ended');
      setShowEndGame(false);
      setShowInningEnd(false);
      navigate(`/games/${id}`);
    } finally {
      setEndingGame(false);
    }
  };

  const handleInningContinue = async () => {
    if (isFinalInningEnd) { await handleEndGameConfirm(); return; }
    setShowInningEnd(false);
    const g = gameRef.current;
    const isTop = g.inning_half === 'top';
    const updates = { outs: 0, balls: 0, strikes: 0, runner_first: false, runner_second: false, runner_third: false };
    if (isTop) {
      updates.inning_half = 'bottom';
      // Record away team's runs for the top of this inning
      const awayInningRuns = Math.max(0, (g.away_score || 0) - inningStartScoreRef.current.away);
      const inningScoresTop = [...(g.inning_scores || [])];
      // Remove any existing entry for this inning/team to avoid duplicates
      const filteredTop = inningScoresTop.filter(e => !(e.inning === g.inning && e.team === 'away'));
      filteredTop.push({ inning: g.inning, team: 'away', runs: awayInningRuns });
      updates.inning_scores = filteredTop;
    } else {
      updates.inning_half = 'top';
      updates.inning = (g.inning || 1) + 1;
      // Record home team's runs for the bottom of this inning
      const homeInningRuns = Math.max(0, (g.home_score || 0) - inningStartScoreRef.current.home);
      const inningScoresBottom = [...(g.inning_scores || [])];
      const filteredBottom = inningScoresBottom.filter(e => !(e.inning === g.inning && e.team === 'home'));
      filteredBottom.push({ inning: g.inning, team: 'home', runs: homeInningRuns });
      updates.inning_scores = filteredBottom;
    }
    await logEvent('inning_end', `End of ${isTop ? 'top' : 'bottom'} ${g.inning}`);
    await updateGame(updates);
    // After top half: home score hasn't changed yet, away half is done. Reset away start for next inning.
    // After bottom half: both halves done for this inning. Reset both for next inning.
    if (isTop) {
      inningStartScoreRef.current = { ...inningStartScoreRef.current, home: g.home_score || 0 };
    } else {
      inningStartScoreRef.current = { home: g.home_score || 0, away: g.away_score || 0 };
    }
    setInningStats({ pitches: 0, runs: 0, hits: 0, errors: 0, strikeouts: 0, walks: 0 });
    // Clear undo stack on inning change (not undoable)
    setUndoStack([]);
  };

  // Steal modal result handler (Bug #1 & #2)
  const handleStealResult = async ({ base, dest, playerId, outcome }) => {
    setShowStealModal(false);
    pushUndo();
    const g = gameRef.current;
    const isTop = g.inning_half === 'top';
    const runnerKey = `runner_${base}`;

    if (outcome === 'safe') {
      const updates = { [runnerKey]: false };
      if (dest === 'second') updates.runner_second = true;
      else if (dest === 'third') updates.runner_third = true;
      else if (dest === 'home') {
        const scoreTeam = (isTop ? 'away' : 'home') + '_score';
        updates[scoreTeam] = (g[isTop ? 'away_score' : 'home_score'] || 0) + 1;
        toast.success('Steal of home — Run scored!');
      }
      // Update player stat
      if (playerId) {
        const p = players.find(pl => pl.id === playerId);
        if (p) base44.entities.Player.update(playerId, { stolen_bases: (p.stolen_bases || 0) + 1 });
      }
      await logEvent('stolen_base', `Stolen base — safe at ${dest}`, { play_type: 'Stolen Base', player_id: playerId, base_from: base, base_to: dest });
      await updateGame(updates);
      toast.success(`Stolen base — safe at ${dest === 'second' ? '2nd' : dest === 'third' ? '3rd' : 'home'}!`);
    } else {
      // Caught stealing
      const updates = { [runnerKey]: false };
      if (playerId) {
        const p = players.find(pl => pl.id === playerId);
        if (p) base44.entities.Player.update(playerId, { caught_stealing: (p.caught_stealing || 0) + 1 });
      }
      await logEvent('out', `Caught stealing at ${dest}`, { play_type: 'Caught Stealing', player_id: playerId, base_from: base, base_to: dest });
      await updateGame(updates);
      await doOut();
      toast.info('Caught stealing — out!');
    }
  };

  const handleRunnerAction = async ({ base, runnerId, actionId }) => {
    setRunnerActionBase(null);
    // Steal actions now handled by StealModal — these are for other runner moves
    if (actionId === 'steal_safe' || actionId === 'steal_caught') {
      // Use the steal modal for proper flow
      setShowStealModal(true);
      return;
    }
    pushUndo();
    const g = gameRef.current;
    const isTop = g.inning_half === 'top';
    const scoreTeam = (isTop ? 'away' : 'home') + '_score';
    const runnerKey = `runner_${base}`;
    const updates = {};

    if (actionId === 'advance_2b') {
      if (g.runner_second) {
        if (!window.confirm('2nd base is occupied. Advance both runners?')) return;
        updates.runner_third = true;
      }
      updates.runner_second = true;
      updates.runner_first = false;
      await logEvent('hit', 'Runner advanced to 2nd', { play_type: 'Runner Advance' });
    } else if (actionId === 'advance_3b') {
      if (g.runner_third) {
        // 3rd occupied — that runner scores
        updates[scoreTeam] = (g[isTop ? 'away_score' : 'home_score'] || 0) + 1;
        updates.runner_third = false;
        toast.info('Runner on 3rd scored on the play');
      }
      updates.runner_third = true;
      updates[`runner_${base}`] = false;
      // Only clear 2nd if the runner came from 1st (not from 2nd)
      if (base === 'second') updates.runner_second = false;
      await logEvent('hit', 'Runner advanced to 3rd', { play_type: 'Runner Advance' });
    } else if (actionId === 'score') {
      updates[runnerKey] = false;
      updates[scoreTeam] = (g[isTop ? 'away_score' : 'home_score'] || 0) + 1;
      await logEvent('run', 'Runner scored', { play_type: 'Run Scored', player_id: runnerId });
      toast.success('Run scored!');
    } else if (actionId === 'advance_home') {
      // Runner scores from any base
      updates[runnerKey] = false;
      updates[scoreTeam] = (g[isTop ? 'away_score' : 'home_score'] || 0) + 1;
      await logEvent('run', `Runner scored from ${base}`, { play_type: 'Run Scored', player_id: runnerId, base_from: base, base_to: 'home' });
      toast.success('Run scored!');
    } else if (actionId === 'score_throw' || actionId === 'score_passed_ball' || actionId === 'score_wild_pitch' || actionId === 'score_balk') {
      const reasonMap = { score_throw: 'Advance on Throw', score_passed_ball: 'Passed Ball', score_wild_pitch: 'Wild Pitch', score_balk: 'Balk' };
      updates[runnerKey] = false;
      updates[scoreTeam] = (g[isTop ? 'away_score' : 'home_score'] || 0) + 1;
      await logEvent('run', `Runner scored — ${reasonMap[actionId]}`, { play_type: 'Run Scored', player_id: runnerId, base_from: base, base_to: 'home', advance_reason: reasonMap[actionId] });
      toast.success(`Run scored! (${reasonMap[actionId]})`);
    } else if (actionId === 'send_back') {
      setShowSendBack({ base, runnerId });
      return;
    } else if (actionId === 'advance_throw_safe') {
      // For 3rd base, advance_throw means scoring
      if (base === 'third') {
        updates[runnerKey] = false;
        updates[scoreTeam] = (g[isTop ? 'away_score' : 'home_score'] || 0) + 1;
        await logEvent('run', 'Runner scored — Advance on Throw', { play_type: 'Run Scored', player_id: runnerId, base_from: '3B', advance_reason: 'Advance on Throw' });
        toast.success('Run scored! (Advance on Throw)');
        await updateGame(updates);
        return;
      }
      const dest = base === 'first' ? 'second' : 'third';
      updates[runnerKey] = false;
      updates[`runner_${dest}`] = true;
      await logEvent('hit', 'Runner advanced on throw', { play_type: 'Runner Advance' });
    } else if (actionId === 'advance_throw_out') {
      updates[runnerKey] = false;
      await logEvent('out', 'Runner out on throw', { play_type: 'Runner Out' });
      await updateGame(updates);
      await doOut();
      return;
    } else if (actionId === 'runner_out') {
      updates[runnerKey] = false;
      await logEvent('out', 'Runner out', { play_type: 'Runner Out' });
      await updateGame(updates);
      await doOut();
      return;
    }

    await updateGame(updates);
  };

  const handleAction = async (action) => {
    const g = gameRef.current;
    if (!g || updating) return;
    const isTop = g.inning_half === 'top';
    const battingTeam = isTop ? 'away' : 'home';

    // Passed ball / Wild pitch from ActionPanel come as type: 'passed_ball' or 'wild_pitch'
    if (action.type === 'passed_ball') {
      action = { type: 'misc', event: 'passed_ball', runnerAdvancements: action.runnerAdvancements };
    }

    // Steal via misc panel — open modal
    if (action.type === 'misc' && action.event === 'stolen_base') {
      const hasRunners = g.runner_first || g.runner_second || g.runner_third;
      if (!hasRunners) { toast.info('No runners on base'); return; }
      const canSteal = (g.runner_first && !g.runner_second) || (g.runner_second && !g.runner_third) || g.runner_third;
      if (!canSteal) { toast.info('No steal available — bases ahead are occupied'); return; }
      setShowStealModal(true);
      return;
    }

    // Push undo snapshot before action (not for end_game/pickoff modals)
    if (!['end_game', 'pickoff'].includes(action.type)) {
      pushUndo();
    }

    switch (action.type) {
      case 'ball': {
        const pitchUpdates = incrementPitch();
        if (action.pitch_type) pitchUpdates.last_pitch_type = action.pitch_type;
        const balls = (g.balls || 0) + 1;
        if (balls >= 4) {
          await logEvent('pitch', 'Walk (BB)', { pitch_type: action.pitch_type });
          const walkUpdates = { balls: 0, strikes: 0, ...pitchUpdates };
          forceAdvanceRunners(g, walkUpdates);
          advanceBatter(walkUpdates);
          await updateGame(walkUpdates);
          setInningStats(prev => ({ ...prev, walks: prev.walks + 1 }));
          // Log AtBat + update player stats
          const battingTeamId = isTop ? g.away_team_id : g.home_team_id;
          base44.entities.AtBat.create({ game_id: id, inning: g.inning, inning_half: g.inning_half, batter_id: g.current_batter_id || '', batter_name: players.find(p => p.id === g.current_batter_id)?.name || '', pitcher_id: g.current_pitcher_id || '', pitcher_name: g.current_pitcher_name || '', batting_team_id: battingTeamId, result: 'walk', balls: 4, strikes: g.strikes ?? 0, pitch_count: g.current_pitcher_pitch_count ?? 0 }).catch(() => {});
          updateBatterStats(g.current_batter_id, 'walk');
          updatePitcherStats(g.current_pitcher_id, 'walk');
          toast.info('Walk — batter takes first');
        } else {
          await updateGame({ balls, ...pitchUpdates });
        }
        break;
      }
      case 'walk': {
        await logEvent('pitch', 'Walk (BB)');
        const walkUpdates = { balls: 0, strikes: 0 };
        forceAdvanceRunners(g, walkUpdates);
        advanceBatter(walkUpdates);
        await updateGame(walkUpdates);
        setInningStats(prev => ({ ...prev, walks: prev.walks + 1 }));
        // Log AtBat + update player stats
        const walkBattingTeamId = isTop ? g.away_team_id : g.home_team_id;
        base44.entities.AtBat.create({ game_id: id, inning: g.inning, inning_half: g.inning_half, batter_id: g.current_batter_id || '', batter_name: players.find(p => p.id === g.current_batter_id)?.name || '', pitcher_id: g.current_pitcher_id || '', pitcher_name: g.current_pitcher_name || '', batting_team_id: walkBattingTeamId, result: 'walk', balls: g.balls ?? 0, strikes: g.strikes ?? 0, pitch_count: g.current_pitcher_pitch_count ?? 0 }).catch(() => {});
        updateBatterStats(g.current_batter_id, 'walk');
        updatePitcherStats(g.current_pitcher_id, 'walk');
        toast.info('Walk recorded');
        break;
      }
      case 'strike': {
        const pitchUpdates = incrementPitch();
        if (action.pitch_type) pitchUpdates.last_pitch_type = action.pitch_type;
        const strikes = (g.strikes || 0) + 1;
        // called=true means "Called Strike" (looking); false/undefined = swinging
        const kResult = action.called ? 'strikeout_looking' : 'strikeout_swinging';
        if (strikes >= 3) {
          const canDropThird = (g.outs || 0) < 2 ? !g.runner_first : true;
          await updateGame({ strikes: 3, ...pitchUpdates });
          if (canDropThird && !action.called) {
            // Drop-third only possible on swinging strike
            setShowDropThird(true);
          } else {
            const kLabel = action.called ? 'Strikeout — looking (Kc)' : 'Strikeout (K)';
            await logEvent('out', kLabel);
            setInningStats(prev => ({ ...prev, strikeouts: prev.strikeouts + 1 }));
            const kBattingTeamId = isTop ? g.away_team_id : g.home_team_id;
            base44.entities.AtBat.create({ game_id: id, inning: g.inning, inning_half: g.inning_half, batter_id: g.current_batter_id || '', batter_name: players.find(p => p.id === g.current_batter_id)?.name || '', pitcher_id: g.current_pitcher_id || '', pitcher_name: g.current_pitcher_name || '', batting_team_id: kBattingTeamId, result: kResult, balls: g.balls ?? 0, strikes: 3, pitch_count: g.current_pitcher_pitch_count ?? 0 }).catch(() => {});
            updateBatterStats(g.current_batter_id, kResult);
            updatePitcherStats(g.current_pitcher_id, kResult);
            toast.info(action.called ? 'Called Strike 3!' : 'Strikeout!');
            await doOut();
          }
        } else {
          await updateGame({ strikes, ...pitchUpdates });
        }
        break;
      }
      case 'foul': {
        const pitchUpdates = incrementPitch();
        if (action.pitch_type) pitchUpdates.last_pitch_type = action.pitch_type;
        const strikes = Math.min((g.strikes || 0) + 1, 2);
        await updateGame({ strikes, ...pitchUpdates });
        toast.info('Foul ball');
        break;
      }
      case 'wild_pitch': {
        const pitchUpdates = incrementPitch();
        await logEvent('pitch', 'Wild pitch', { pitch_type: 'wild_pitch' });
        const balls = (g.balls || 0) + 1;
        if (balls >= 4) {
          const wu = { balls: 0, strikes: 0, ...pitchUpdates };
          forceAdvanceRunners(g, wu);
          advanceBatter(wu);
          await updateGame(wu);
          toast.info('Wild Pitch — Walk');
        } else {
          const baseUpdates = { balls, ...pitchUpdates };
          // Apply runner advancements if provided
          if (action.runnerAdvancements) {
            applyRunnerAdvancements(g, action.runnerAdvancements, baseUpdates, isTop);
          }
          await updateGame(baseUpdates);
          toast.info('Wild Pitch');
        }
        break;
      }
      case 'pitch_out': {
        const pitchUpdates = incrementPitch();
        const balls = (g.balls || 0) + 1;
        if (balls >= 4) {
          const pu = { balls: 0, strikes: 0, ...pitchUpdates };
          forceAdvanceRunners(g, pu);
          advanceBatter(pu);
          await updateGame(pu);
          toast.info('Pitch Out — Walk');
        } else {
          await updateGame({ balls, ...pitchUpdates });
          toast.info('Pitch Out');
        }
        break;
      }
      case 'hit': {
        const updates = { balls: 0, strikes: 0 };
        const scoreTeam = battingTeam + '_score';
        const hitTeam = battingTeam + '_hits';
        updates[hitTeam] = (g[hitTeam] || 0) + 1;
        setInningStats(prev => ({ ...prev, hits: prev.hits + 1 }));
        const battingTeamId = isTop ? g.away_team_id : g.home_team_id;
        if (action.hit_type === 'home_run') {
          updates[scoreTeam] = (g[battingTeam + '_score'] || 0) + 1 + countRunners(g);
          updates.runner_first = false; updates.runner_second = false; updates.runner_third = false;
          await logEvent('hit', 'Home Run! 🚀', { hit_type: 'home_run' });
          toast.success('HOME RUN! 🎉');
        } else if (action.hit_type === 'single') {
          advanceRunners(g, updates, 1);
          await logEvent('hit', 'Single', { hit_type: 'single' });
          toast.success('Single!');
        } else if (action.hit_type === 'double') {
          advanceRunners(g, updates, 2);
          await logEvent('hit', 'Double', { hit_type: 'double' });
          toast.success('Double!');
        } else if (action.hit_type === 'triple') {
          advanceRunners(g, updates, 3);
          await logEvent('hit', 'Triple', { hit_type: 'triple' });
          toast.success('Triple!');
        } else if (action.hit_type === 'hit_by_pitch') {
          forceAdvanceRunners(g, updates);
          await logEvent('hit', 'Hit by pitch', { hit_type: 'hbp' });
          toast.info('Hit by pitch');
        }
        advanceBatter(updates);
        await updateGame(updates);
        // Save AtBat record (all hit types incl. HBP)
        base44.entities.AtBat.create({
          game_id: id,
          inning: g.inning,
          inning_half: g.inning_half,
          batter_id: g.current_batter_id || '',
          batter_name: players.find(p => p.id === g.current_batter_id)?.name || '',
          pitcher_id: g.current_pitcher_id || '',
          pitcher_name: g.current_pitcher_name || '',
          batting_team_id: battingTeamId,
          result: action.hit_type,
          balls: g.balls ?? 0,
          strikes: g.strikes ?? 0,
          pitch_count: g.current_pitcher_pitch_count ?? 0,
          hit_zone: action.hitZone || null,
          rbis: action.rbis || 0,
        }).catch(() => {});
        // Update player stats
        updateBatterStats(g.current_batter_id, action.hit_type, action.rbis || 0);
        if (action.hit_type !== 'hit_by_pitch') {
          updatePitcherStats(g.current_pitcher_id, action.hit_type);
        }
        break;
      }
      case 'out': {
        if (action.description === 'double_play') {
          // fielder info attached to action
          const dpFielder1 = action.fielder1 || null;
          const dpFielder2 = action.fielder2 || null;
          // Log AtBat for the batter who hit into the double play
          const dpBattingTeamId = isTop ? g.away_team_id : g.home_team_id;
          base44.entities.AtBat.create({ game_id: id, inning: g.inning, inning_half: g.inning_half, batter_id: g.current_batter_id || '', batter_name: players.find(p => p.id === g.current_batter_id)?.name || '', pitcher_id: g.current_pitcher_id || '', pitcher_name: g.current_pitcher_name || '', batting_team_id: dpBattingTeamId, result: 'double_play', balls: g.balls ?? 0, strikes: g.strikes ?? 0, pitch_count: g.current_pitcher_pitch_count ?? 0 }).catch(() => {});
          updateBatterStats(g.current_batter_id, 'double_play');
          updatePitcherStats(g.current_pitcher_id, 'double_play');
          // Double play = 2 outs; remove batter + one base runner
          const dpSeq = action.sequence || dpFielder1;
          await logEvent('out', `Double Play — out 1${dpSeq ? ` (${dpSeq})` : ''}`, { fielder1: dpFielder1, sequence: dpSeq });
          // Clear the lead occupied runner
          const dpUpdates = { balls: 0, strikes: 0 };
          if (gameRef.current.runner_third) dpUpdates.runner_third = false;
          else if (gameRef.current.runner_second) dpUpdates.runner_second = false;
          else if (gameRef.current.runner_first) dpUpdates.runner_first = false;
          await updateGame(dpUpdates);
          await logEvent('out', `Double Play — out 2${dpFielder2 ? ` (${dpFielder2})` : ''}`, { fielder2: dpFielder2 });
          // Apply first out, then check if second out ends inning
          const newOuts1 = (gameRef.current.outs || 0) + 1;
          if (newOuts1 >= 3) {
            // First out ends inning
            await updateGame({ outs: newOuts1 });
            const g3 = gameRef.current;
            const isTop3 = g3.inning_half === 'top';
            const curScore3 = isTop3 ? (g3.away_score || 0) : (g3.home_score || 0);
            const startScore3 = isTop3 ? inningStartScoreRef.current.away : inningStartScoreRef.current.home;
            setInningStats(prev => ({ ...prev, runs: Math.max(0, curScore3 - startScore3) }));
            const totalInnings3 = g3.total_innings || 9;
            setIsFinalInningEnd(!isTop3 && g3.inning >= totalInnings3);
            setShowInningEnd(true);
            toast.info('Double Play — 3 outs! Inning over.');
          } else {
            // First out didn't end inning, apply second out
            const newOuts2 = newOuts1 + 1;
            if (newOuts2 >= 3) {
              // Second out ends inning
              await updateGame({ outs: newOuts2 });
              const g4 = gameRef.current;
              const isTop4 = g4.inning_half === 'top';
              const curScore4 = isTop4 ? (g4.away_score || 0) : (g4.home_score || 0);
              const startScore4 = isTop4 ? inningStartScoreRef.current.away : inningStartScoreRef.current.home;
              setInningStats(prev => ({ ...prev, runs: Math.max(0, curScore4 - startScore4) }));
              const totalInnings4 = g4.total_innings || 9;
              setIsFinalInningEnd(!isTop4 && g4.inning >= totalInnings4);
              setShowInningEnd(true);
              toast.info('Double Play — 3 outs! Inning over.');
            } else {
              // Both outs don't end inning, advance batter
              const extras2 = { outs: newOuts2, balls: 0, strikes: 0 };
              advanceBatter(extras2);
              await updateGame(extras2);
              toast.info('Double Play — 2 outs recorded');
            }
          }
        } else {
          const fielderNote = action.fielder1 ? ` (${action.fielder1})` : '';
          await logEvent('out', (action.description || 'Out') + fielderNote, { fielder1: action.fielder1 || null });
          // Map human-readable description to AtBat result enum
          const outDescMap = {
            'Ground out': 'ground_out', 'Fly out': 'fly_out', 'Line drive out': 'line_out',
            'Sacrifice fly': 'sacrifice_fly', 'Sacrifice bunt': 'sacrifice_bunt',
            "Fielder's choice": 'fielders_choice',
          };
          const outBattingTeamId = isTop ? g.away_team_id : g.home_team_id;
          const outResult = outDescMap[action.description] || 'ground_out';
          base44.entities.AtBat.create({ game_id: id, inning: g.inning, inning_half: g.inning_half, batter_id: g.current_batter_id || '', batter_name: players.find(p => p.id === g.current_batter_id)?.name || '', pitcher_id: g.current_pitcher_id || '', pitcher_name: g.current_pitcher_name || '', batting_team_id: outBattingTeamId, result: outResult, balls: g.balls ?? 0, strikes: g.strikes ?? 0, pitch_count: g.current_pitcher_pitch_count ?? 0 }).catch(() => {});
          updateBatterStats(g.current_batter_id, outResult);
          updatePitcherStats(g.current_pitcher_id, outResult);
          await doOut();
          toast.info((action.description || 'Out recorded') + fielderNote);
        }
        break;
      }
      case 'pickoff': {
        setShowPickoff(true);
        break;
      }
      case 'run': {
        const scoreTeam = battingTeam + '_score';
        await updateGame({ [scoreTeam]: (g[battingTeam + '_score'] || 0) + 1 });
        await logEvent('run', 'Run scored');
        toast.success('Run scored!');
        break;
      }
      case 'error': {
        const errTeam = (isTop ? 'home' : 'away') + '_errors';
        await updateGame({ [errTeam]: (g[errTeam] || 0) + 1 });
        await logEvent('error', 'Fielding error');
        setInningStats(prev => ({ ...prev, errors: prev.errors + 1 }));
        toast.info('Error recorded');
        break;
      }
      case 'misc': {
        if ((action.event === 'passed_ball' || action.event === 'wild_pitch') && action.runnerAdvancements) {
          const pbUpdates = {};
          applyRunnerAdvancements(g, action.runnerAdvancements, pbUpdates, isTop);
          await logEvent(action.event, action.event.replace(/_/g, ' '), { play_type: action.event });
          await updateGame(pbUpdates);
          toast.info(action.event.replace(/_/g, ' '));
        } else {
          await logEvent(action.event, action.event.replace(/_/g, ' '));
          toast.info(action.event.replace(/_/g, ' '));
        }
        break;
      }
      case 'end_game': {
        setShowEndGame(true);
        break;
      }
      default: break;
    }
  };

  const handleDropThirdCaught = async () => {
    setShowDropThird(false);
    const g = gameRef.current;
    await logEvent('out', 'Strikeout — caught (K)');
    setInningStats(prev => ({ ...prev, strikeouts: prev.strikeouts + 1 }));
    const kBattingTeamId = g.inning_half === 'top' ? g.away_team_id : g.home_team_id;
    base44.entities.AtBat.create({ game_id: id, inning: g.inning, inning_half: g.inning_half, batter_id: g.current_batter_id || '', batter_name: players.find(p => p.id === g.current_batter_id)?.name || '', pitcher_id: g.current_pitcher_id || '', pitcher_name: g.current_pitcher_name || '', batting_team_id: kBattingTeamId, result: 'strikeout_swinging', balls: g.balls ?? 0, strikes: 3, pitch_count: g.current_pitcher_pitch_count ?? 0 }).catch(() => {});
    updateBatterStats(g.current_batter_id, 'strikeout_swinging');
    updatePitcherStats(g.current_pitcher_id, 'strikeout_swinging');
    toast.info('Strikeout!');
    await doOut();
  };

  const handleDropThirdDropped = async () => {
    setShowDropThird(false);
    const g = gameRef.current;
    await logEvent('out', 'Strikeout — dropped 3rd, batter runs');
    // Dropped third still counts as a strikeout for pitcher, but batter reaches — no AB out for batter
    updatePitcherStats(g.current_pitcher_id, 'strikeout_swinging');
    toast.info('Dropped 3rd strike — batter runs!');
    await updateGame({ balls: 0, strikes: 0 });
  };

  const handlePickoffResult = async ({ base, result }) => {
    setShowPickoff(false);
    pushUndo();
    const runnerKey = `runner_${base}`;
    if (result === 'out') {
      await logEvent('out', `Pickoff out at ${base}`, { play_type: 'pickoff_out', base });
      toast.info(`Pickoff — out at ${base}!`);
      await doOut({ [runnerKey]: false });
    } else {
      await logEvent('pickoff', `Pickoff attempt at ${base} — safe`, { play_type: 'pickoff_safe', base });
      toast.info(`Pickoff — safe at ${base}`);
    }
  };

  const handleSendBack = async (reason) => {
    const { base, runnerId } = showSendBack;
    setShowSendBack(null);
    pushUndo();
    const g = gameRef.current;
    const destBase = base === 'third' ? 'second' : 'first';
    const currentKey = `runner_${base}`;
    const destKey = `runner_${destBase}`;
    const updates = { [currentKey]: false };

    // Check if destination is occupied
    const destOccupied = base === 'third' ? g.runner_second : g.runner_first;
    if (destOccupied) {
      // Swap the two runners
      updates[destKey] = runnerId;
      updates[currentKey] = destOccupied;
      toast.info(`Runners swapped — ${destBase} and ${base}`);
    } else {
      updates[destKey] = runnerId;
    }

    const reasonLabel = reason === 'retreated' ? 'Retreated on Line Drive' : 'Correction / Error';
    await logEvent('hit', `Runner sent back to ${destBase}`, { play_type: 'Runner Sent Back', player_id: runnerId, base_from: base, base_to: destBase, advance_reason: reasonLabel });
    await updateGame(updates);
  };

  // Update batter's cumulative stats on the Player entity after each plate appearance
  const updateBatterStats = (batterId, result, rbis = 0) => {
    // Use functional setter to always get fresh player state (avoids stale closure)
    setPlayers(prev => {
      const p = prev.find(pl => pl.id === batterId);
      if (!p) return prev;

      // Results that do NOT count as official at-bats (per baseball rules)
      const noAB = ['walk', 'intentional_walk', 'hit_by_pitch', 'sacrifice_fly', 'sacrifice_bunt'];
      const isOfficialAB = !noAB.includes(result);

      const statDelta = {
        at_bats: isOfficialAB ? (p.at_bats || 0) + 1 : (p.at_bats || 0),
      };

      if (['single', 'double', 'triple', 'home_run'].includes(result)) {
        statDelta.hits = (p.hits || 0) + 1;
      }
      if (result === 'home_run') {
        statDelta.home_runs = (p.home_runs || 0) + 1;
      }
      if (result === 'strikeout_looking' || result === 'strikeout_swinging') {
        statDelta.strikeouts_batting = (p.strikeouts_batting || 0) + 1;
      }
      if (result === 'walk' || result === 'intentional_walk') {
        statDelta.walks = (p.walks || 0) + 1;
      }
      if (rbis > 0) {
        statDelta.rbis = (p.rbis || 0) + rbis;
      }
      // Recalculate batting average (only when there are official ABs)
      if (statDelta.at_bats > 0) {
        const hits = statDelta.hits ?? p.hits ?? 0;
        statDelta.batting_avg = Math.round((hits / statDelta.at_bats) * 1000) / 1000;
      }

      base44.entities.Player.update(batterId, statDelta).catch(() => {});
      return prev.map(pl => pl.id === batterId ? { ...pl, ...statDelta } : pl);
    });
  };

  // Update pitcher's cumulative stats on the Player entity
  const updatePitcherStats = (pitcherId, result) => {
    setPlayers(prev => {
      const p = prev.find(pl => pl.id === pitcherId);
      if (!p) return prev;
      const delta = {};
      if (result === 'strikeout_looking' || result === 'strikeout_swinging') {
        delta.strikeouts_pitching = (p.strikeouts_pitching || 0) + 1;
      }
      if (result === 'walk' || result === 'intentional_walk') {
        delta.walks_allowed = (p.walks_allowed || 0) + 1;
      }
      if (['single', 'double', 'triple', 'home_run'].includes(result)) {
        delta.hits_allowed = (p.hits_allowed || 0) + 1;
      }
      if (Object.keys(delta).length === 0) return prev;
      base44.entities.Player.update(pitcherId, delta).catch(() => {});
      return prev.map(pl => pl.id === pitcherId ? { ...pl, ...delta } : pl);
    });
  };

  const handleChangePitcher = async (player) => {
    // This is called from PitcherDisplay's quick-change selector.
    // PitcherManagementPanel in RosterPanel handles its own GamePitcher records directly.
    // Here we just close any open GamePitcher record and create a new one, then update game fields.
    const g = gameRef.current;
    const currentBatterName = players.find(p => p.id === g.current_batter_id)?.name || '';

    if (g.current_pitcher_id) {
      // Find the open GamePitcher record and close it
      const openRecords = await base44.entities.GamePitcher.filter({ game_id: id });
      const openRecord = openRecords
        .filter(r => !r.is_opponent && r.exit_inning == null)
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
      if (openRecord) {
        await base44.entities.GamePitcher.update(openRecord.id, {
          exit_inning: g.inning,
          exit_batter: currentBatterName,
          pitch_count: g.current_pitcher_pitch_count || 0,
        });
      }
    }

    await base44.entities.GamePitcher.create({
      game_id: id,
      player_id: player.id,
      player_name: player.name,
      team_id: g.home_team_id,
      entry_inning: g.inning,
      pitch_count: 0,
      is_opponent: false,
    });

    await updateGame({ current_pitcher_id: player.id, current_pitcher_name: player.name, current_pitcher_pitch_count: 0 });
    toast.success(`Pitcher changed to ${player.name}`);
  };

  const isAdmin = user && (
    user.role === 'admin' ||
    homeTeam?.coach_email === user.email ||
    (homeTeam?.admin_emails || []).includes(user.email) ||
    awayTeam?.coach_email === user.email ||
    (awayTeam?.admin_emails || []).includes(user.email)
  );

  // Whether both lineups are confirmed (gate check)
  const lineupsReady = (
    (game?.home_lineup_confirmed && (game?.home_lineup || []).length > 0) &&
    (game?.opponent_lineup_confirmed && (game?.away_lineup || []).length > 0)
  );

  const handleLineupGateComplete = async () => {
    // Mark game as in_progress and set first batter, then reload
    const freshGames = await base44.entities.Game.filter({ id });
    const g = freshGames[0];
    if (!g) return;
    const updates = { status: 'in_progress', game_start_timestamp: new Date().toISOString() };
    // Set first batter from home lineup if not already set
    if (!g.current_batter_id && (g.home_lineup || []).length > 0) {
      updates.current_batter_id = g.home_lineup[0];
      updates.home_batting_order_idx = 0;
    }
    // Set first away batter too if away lineup exists
    if ((g.away_lineup || []).length > 0 && !g.away_batting_order_idx) {
      updates.away_batting_order_idx = 0;
    }
    await base44.entities.Game.update(id, updates);
    await loadGame();
  };

  if (loading) return (
    <div className="min-h-screen bg-[hsl(220,25%,6%)] flex items-center justify-center text-white">
      <div className="w-8 h-8 border-4 border-accent border-t-transparent rounded-full animate-spin" />
    </div>
  );
  if (!game) return <div className="p-6 text-center text-white">Game not found</div>;

  const isGameOver = ['final', 'completed', 'postponed', 'cancelled'].includes(game.status);
  if (!isAdmin) return <div className="p-6 text-center text-white">Admin access required to score this game</div>;
  // Lineup gate — show before scoring begins
  if (!lineupsReady && !isGameOver && isAdmin) return (
    <LineupGate
      game={game}
      homePlayers={players.filter(p => p.team_id === game.home_team_id)}
      allPlayers={players}
      onComplete={handleLineupGateComplete}
    />
  );

  if (isGameOver) return (
    <div className="min-h-screen bg-[hsl(220,25%,6%)] flex flex-col items-center justify-center text-white gap-4 p-6">
      <div className="text-5xl">🏁</div>
      <div className="font-bebas text-5xl tracking-wider">{game.away_score ?? 0} – {game.home_score ?? 0}</div>
      <div className="text-white/60">{game.away_team_name} vs {game.home_team_name}</div>
      <div className="text-white/40 text-sm">Game Over · Final</div>
      <button onClick={() => navigate(`/games/${id}`)} className="mt-4 px-6 py-3 rounded-xl bg-primary text-white font-semibold select-none touch-manipulation">
        Back to Game
      </button>
    </div>
  );

  const runnerOnBase = (base) => {
    if (base === 'first') return game.runner_first;
    if (base === 'second') return game.runner_second;
    if (base === 'third') return game.runner_third;
    return null;
  };

  const battingTeamName = game.inning_half === 'top' ? game.away_team_name : game.home_team_name;

  return (
    <div className="bg-[hsl(220,25%,6%)] text-white flex flex-col" style={{ height: '100dvh', overflow: 'hidden' }}>
      {/* Half-inning transition banner */}
      <HalfInningBanner game={game} homeTeam={homeTeam} awayTeam={awayTeam} />

      {/* Fixed Header */}
      <ScoringHeader
        game={game}
        homeTeam={homeTeam}
        awayTeam={awayTeam}
        onBack={() => navigate(`/games/${id}`)}
        onRefresh={loadGame}
        updating={updating}
        onUndo={handleUndo}
        canUndo={undoStack.length > 0}
        onRoster={() => setShowRosterPanel(true)}
      />

      {/* ── PHONE LAYOUT ── stacked single column */}
      {isPhone && (
        <>
          <PitcherDisplay game={game} players={players} onChangePitcher={handleChangePitcher} />
          {game.time_limit_minutes > 0 && (
            <div className="px-3 pt-2">
              <GameTimerDisplay game={game} />
            </div>
          )}
          <div className="flex-1 overflow-y-auto overscroll-contain">
            <div className="p-3 space-y-2 pb-4">
              <div className="rounded-2xl px-2 py-1" style={{ backgroundColor: '#0a1628', border: '1px solid rgba(255,255,255,0.07)' }}>
                <RunnerDiamond
                  game={game}
                  players={players}
                  isPhone={isPhone}
                  onBaseClick={(base) => { if (runnerOnBase(base)) setRunnerActionBase(base); }}
                />
              </div>
              <CurrentBatterDisplay
                game={game}
                players={players}
                isPhone={isPhone}
                teamName={battingTeamName}
                onBatterChange={(updates) => updateGame(updates)}
                onPlayerAdded={(newPlayer) => setPlayers(prev => [...prev, newPlayer])}
              />
              <ActionPanel game={game} players={players} onAction={handleAction} onGameUpdate={(u) => setGame(prev => prev ? { ...prev, ...u } : prev)} updating={updating} />
            </div>
          </div>
          <div className="flex-shrink-0 px-3 pb-3 pt-2 flex gap-2">
            <button
              onClick={() => setShowScoreboard(v => !v)}
              className="flex-1 py-3.5 rounded-2xl font-bold text-sm select-none touch-manipulation active:scale-[0.97] transition-all flex items-center justify-center gap-2"
              style={{ background: 'linear-gradient(135deg, #0a1628, #0d1f3c)', border: '1px solid rgba(255,184,28,0.2)', color: 'white' }}>
              📊 Scoreboard
              <span className="font-bebas text-base leading-none" style={{ color: '#FFB81C' }}>{game.away_score ?? 0}–{game.home_score ?? 0}</span>
            </button>
            <Link to={`/games/${id}/coach`}
              className="py-3.5 px-4 rounded-2xl font-bold text-sm select-none touch-manipulation active:scale-[0.97] transition-all flex items-center justify-center gap-1.5 whitespace-nowrap"
              style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.7)' }}>
              📋 Coach
            </Link>
          </div>
        </>
      )}

      {/* ── TABLET / DESKTOP LAYOUT ── two-column side-by-side */}
      {!isPhone && (
        <div className="flex-1 flex min-h-0 overflow-hidden">
          {/* LEFT COLUMN — status info */}
          <div className="flex flex-col border-r border-white/10 overflow-y-auto overscroll-contain" style={{ width: '38%', minWidth: 300, maxWidth: 440 }}>
            <PitcherDisplay game={game} players={players} onChangePitcher={handleChangePitcher} />
            {game.time_limit_minutes > 0 && (
              <div className="px-3 pt-2">
                <GameTimerDisplay game={game} />
              </div>
            )}
            <div className="p-3 space-y-3 flex-1">
              <div className="rounded-2xl px-2 py-2" style={{ backgroundColor: '#0a1628', border: '1px solid rgba(255,255,255,0.07)' }}>
                <RunnerDiamond
                  game={game}
                  players={players}
                  isPhone={false}
                  onBaseClick={(base) => { if (runnerOnBase(base)) setRunnerActionBase(base); }}
                />
              </div>
              <CurrentBatterDisplay
                game={game}
                players={players}
                isPhone={false}
                teamName={battingTeamName}
                onBatterChange={(updates) => updateGame(updates)}
                onPlayerAdded={(newPlayer) => setPlayers(prev => [...prev, newPlayer])}
              />
              {/* Scoreboard + Coach View links in left column on tablet */}
              <div className="flex gap-2">
                <button
                  onClick={() => setShowScoreboard(v => !v)}
                  className="flex-1 py-3 rounded-2xl font-bold text-sm select-none touch-manipulation active:scale-[0.97] transition-all flex items-center justify-center gap-2"
                  style={{ background: 'linear-gradient(135deg, #0a1628, #0d1f3c)', border: '1px solid rgba(255,184,28,0.2)', color: 'white' }}>
                  📊 Score
                  <span className="font-bebas text-base leading-none" style={{ color: '#FFB81C' }}>{game.away_score ?? 0}–{game.home_score ?? 0}</span>
                </button>
                <Link to={`/games/${id}/coach`}
                  className="py-3 px-4 rounded-2xl font-bold text-sm select-none touch-manipulation active:scale-[0.97] transition-all flex items-center justify-center gap-1.5 whitespace-nowrap"
                  style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.7)' }}>
                  📋 Coach
                </Link>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN — action panel, fills remaining width */}
          <div className="flex-1 overflow-y-auto overscroll-contain p-3">
            <ActionPanel game={game} players={players} onAction={handleAction} onGameUpdate={(u) => setGame(prev => prev ? { ...prev, ...u } : prev)} updating={updating} isTablet />
          </div>
        </div>
      )}

      {/* Runner Action Sheet */}
      {runnerActionBase && (
        <RunnerActionSheet
          base={runnerActionBase}
          runner={runnerOnBase(runnerActionBase)}
          players={players}
          game={game}
          onAction={handleRunnerAction}
          onClose={() => setRunnerActionBase(null)}
        />
      )}

      {/* Steal Modal */}
      {showStealModal && (
        <StealModal
          game={game}
          players={players}
          onResult={handleStealResult}
          onClose={() => setShowStealModal(false)}
        />
      )}

      {showDropThird && (
        <DropThirdStrikeModal
          onCaught={handleDropThirdCaught}
          onDropped={handleDropThirdDropped}
          onClose={() => setShowDropThird(false)}
        />
      )}
      {showPickoff && (
        <PickoffModal game={game} onResult={handlePickoffResult} onClose={() => setShowPickoff(false)} />
      )}
      {showInningEnd && (
        <InningEndModal
          game={game}
          players={players}
          inningStats={inningStats}
          recentEvents={recentEvents}
          onContinue={handleInningContinue}
          isFinal={isFinalInningEnd}
        />
      )}
      {showEndGame && (
        <EndGameModal game={game} onConfirm={handleEndGameConfirm} onCancel={() => setShowEndGame(false)} confirming={endingGame} />
      )}

      {/* Innings Scoreboard panel */}
      {showScoreboard && (
        <InningsScoreboard game={game} onClose={() => setShowScoreboard(false)} />
      )}

      {/* Roster panel */}
      {showRosterPanel && (
        <RosterPanel
          game={game}
          players={players}
          onClose={() => setShowRosterPanel(false)}
          onGameUpdate={(updates) => setGame(prev => prev ? { ...prev, ...updates } : prev)}
        />
      )}

      {/* Send Back reason modal */}
      {showSendBack && (
        <SendBackModal
          runner={showSendBack.runnerId}
          base={showSendBack.base}
          players={players}
          onConfirm={handleSendBack}
          onClose={() => setShowSendBack(null)}
        />
      )}
    </div>
  );
}