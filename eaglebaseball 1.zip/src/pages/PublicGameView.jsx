import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ChevronDown, ChevronUp } from 'lucide-react';

const fmt = (avg) => (avg && avg > 0) ? '.' + String(Math.round(avg * 1000)).padStart(3, '0') : null;

// ── Animated Field SVG ───────────────────────────────────────────────────────
function AnimatedField({ game, pitchAnim, lastPlay }) {
  const r1 = game.runner_first;
  const r2 = game.runner_second;
  const r3 = game.runner_third;

  // Pitcher mound coords and home plate coords in SVG space
  const MOUND = { x: 100, y: 110 };
  const PLATE = { x: 100, y: 165 };

  return (
    <div className="relative w-full flex flex-col items-center">
      {/* Stadium background */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <div className="w-full h-full" style={{ background: 'radial-gradient(ellipse at 50% 70%, #1a4a2e 0%, #0d2918 50%, #0B1120 100%)' }} />
      </div>

      <svg viewBox="0 0 200 200" width="100%" style={{ maxWidth: 340, position: 'relative', zIndex: 1 }} className="py-4">
        {/* Outfield arc */}
        <path d="M 20 170 Q 100 20 180 170" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="1.5" />
        {/* Foul lines */}
        <line x1="100" y1="165" x2="20" y2="85" stroke="rgba(255,255,255,0.2)" strokeWidth="1" />
        <line x1="100" y1="165" x2="180" y2="85" stroke="rgba(255,255,255,0.2)" strokeWidth="1" />
        {/* Infield dirt */}
        <polygon points="100,55 155,110 100,165 45,110" fill="rgba(180,120,60,0.22)" stroke="rgba(255,255,255,0.12)" strokeWidth="1" />
        {/* Grass inside diamond */}
        <polygon points="100,60 150,110 100,160 50,110" fill="rgba(34,197,94,0.08)" />

        {/* Pitch animation line */}
        {pitchAnim && (
          <line
            x1={MOUND.x} y1={MOUND.y}
            x2={PLATE.x} y2={PLATE.y}
            stroke="#F59E0B"
            strokeWidth="2.5"
            strokeLinecap="round"
            opacity="0.9"
            style={{ animation: 'none' }}
          />
        )}

        {/* Bases */}
        {/* 2nd base */}
        <rect x="93" y="48" width="14" height="14" rx="2"
          fill={r2 ? '#3B82F6' : 'rgba(255,255,255,0.12)'}
          stroke={r2 ? '#60A5FA' : 'rgba(255,255,255,0.35)'}
          strokeWidth={r2 ? 1 : 1.5}
          transform="rotate(45, 100, 55)" />
        {r2 && <circle cx="100" cy="55" r="13" fill="#3B82F6" opacity="0.3" />}

        {/* 1st base */}
        <rect x="148" y="103" width="14" height="14" rx="2"
          fill={r1 ? '#3B82F6' : 'rgba(255,255,255,0.12)'}
          stroke={r1 ? '#60A5FA' : 'rgba(255,255,255,0.35)'}
          strokeWidth={r1 ? 1 : 1.5}
          transform="rotate(45, 155, 110)" />
        {r1 && <circle cx="155" cy="110" r="13" fill="#3B82F6" opacity="0.3" />}

        {/* 3rd base */}
        <rect x="38" y="103" width="14" height="14" rx="2"
          fill={r3 ? '#3B82F6' : 'rgba(255,255,255,0.12)'}
          stroke={r3 ? '#60A5FA' : 'rgba(255,255,255,0.35)'}
          strokeWidth={r3 ? 1 : 1.5}
          transform="rotate(45, 45, 110)" />
        {r3 && <circle cx="45" cy="110" r="13" fill="#3B82F6" opacity="0.3" />}

        {/* Pitcher mound */}
        <circle cx="100" cy="110" r="8" fill="rgba(180,120,60,0.55)" stroke="rgba(255,255,255,0.2)" strokeWidth="1" />

        {/* Home plate */}
        <rect x="93" y="158" width="14" height="14" rx="2" fill="rgba(255,255,255,0.8)" transform="rotate(45, 100, 165)" />

        {/* Batter indicator */}
        <circle cx="100" cy="165" r="5" fill="#F59E0B" opacity="0.9" />
      </svg>

      {/* Pitch overlay — shown after animation */}
      {lastPlay && (
        <div className="absolute bottom-6 left-0 right-0 flex flex-col items-center gap-1 z-10 px-4 pointer-events-none">
          {lastPlay.pitchType && (
            <div className="text-xs font-bold px-3 py-1 rounded-full" style={{ backgroundColor: 'rgba(245,158,11,0.2)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.4)' }}>
              {lastPlay.pitchType}
            </div>
          )}
          <div className="text-lg font-black text-white" style={{ textShadow: '0 0 20px rgba(0,0,0,0.8)' }}>
            {lastPlay.description}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Top Nav Bar ──────────────────────────────────────────────────────────────
function LiveNavBar({ game }) {
  const isTop = game.inning_half === 'top';
  const battingTeam = isTop ? game.away_team_name : game.home_team_name;
  const balls = game.balls ?? 0;
  const strikes = game.strikes ?? 0;
  const outs = game.outs ?? 0;

  return (
    <div className="fixed top-0 left-0 right-0 z-30 px-3 py-2 flex items-center gap-2 text-white text-xs"
      style={{ backgroundColor: 'rgba(11,17,32,0.96)', borderBottom: '1px solid rgba(255,255,255,0.08)', backdropFilter: 'blur(8px)' }}>
      {/* Batting team */}
      <div className="flex-1 min-w-0">
        <div className="font-bold truncate text-sm" style={{ color: '#F59E0B' }}>{battingTeam}</div>
        <div className="text-white/40 text-[10px]">Batting</div>
      </div>

      {/* Score */}
      <div className="text-center px-2">
        <div className="font-black text-xl leading-none" style={{ fontFamily: 'Bebas Neue, sans-serif', letterSpacing: '0.05em' }}>
          {game.away_score ?? 0}–{game.home_score ?? 0}
        </div>
        <div className="text-[10px] text-white/40">{game.away_team_name?.slice(0,3)} — {game.home_team_name?.slice(0,3)}</div>
      </div>

      {/* Inning */}
      <div className="text-center px-1">
        <div className="font-bold text-sm">{isTop ? '▲' : '▼'} {game.inning}</div>
        <div className="text-[10px] text-white/40">Inning</div>
      </div>

      {/* Outs */}
      <div className="text-center px-1">
        <div className="flex gap-0.5 justify-center">
          {[0, 1, 2].map(i => (
            <div key={i} className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: i < outs ? '#EF4444' : 'rgba(255,255,255,0.2)' }} />
          ))}
        </div>
        <div className="text-[10px] text-white/40 mt-0.5">Outs</div>
      </div>

      {/* Count */}
      <div className="text-center px-1">
        <div className="font-bold text-sm">{balls}-{strikes}</div>
        <div className="text-[10px] text-white/40">Count</div>
      </div>
    </div>
  );
}

// ── Play by Play Log ─────────────────────────────────────────────────────────
function PlayByPlayLog({ events }) {
  const [expanded, setExpanded] = useState(false);
  if (!events.length) return null;

  const latest = events[0];

  // Group by half-inning
  const groups = {};
  events.forEach(evt => {
    const key = `${evt.inning_half === 'top' ? 'Top' : 'Bot'} ${evt.inning}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(evt);
  });

  const dotColor = (type) => {
    if (type === 'run') return '#F59E0B';
    if (type === 'hit') return '#22C55E';
    if (type === 'out') return '#EF4444';
    return 'rgba(255,255,255,0.3)';
  };

  return (
    <div className="mx-3 mb-3 rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.04)' }}>
      {/* Toggle header */}
      <button
        className="w-full flex items-center justify-between px-4 py-3 text-left touch-manipulation"
        onClick={() => setExpanded(v => !v)}>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-semibold uppercase tracking-wider mb-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>Play by Play</div>
          {!expanded && (
            <div className="text-sm font-medium text-white truncate">
              {latest.inning_half === 'top' ? '▲' : '▼'}{latest.inning} · {latest.description}
            </div>
          )}
        </div>
        {expanded
          ? <ChevronUp className="w-4 h-4 flex-shrink-0 ml-2" style={{ color: 'rgba(255,255,255,0.4)' }} />
          : <ChevronDown className="w-4 h-4 flex-shrink-0 ml-2" style={{ color: 'rgba(255,255,255,0.4)' }} />}
      </button>

      {expanded && (
        <div className="max-h-72 overflow-y-auto" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          {Object.entries(groups).map(([label, evts]) => (
            <div key={label}>
              <div className="px-4 py-1.5 text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(255,255,255,0.3)', backgroundColor: 'rgba(255,255,255,0.03)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                {label}
              </div>
              {evts.map((evt, i) => (
                <div key={evt.id || i} className="flex items-start gap-2.5 px-4 py-2.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <div className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: dotColor(evt.event_type) }} />
                  <span className="text-sm text-white flex-1">{evt.description}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Line Score ───────────────────────────────────────────────────────────────
function LineScoreCard({ game }) {
  const innings = game.inning_scores || [];
  const total = Math.max(game.total_innings || 9, game.inning || 1);
  const inningNums = Array.from({ length: total }, (_, i) => i + 1);
  const getScore = (team, inning) => {
    const e = innings.find(e => e.inning === inning && e.team === team);
    return e != null ? e.runs : '-';
  };

  return (
    <div className="mx-3 mb-3 rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.04)' }}>
      <div className="px-4 py-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.4)' }}>Line Score</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
              <th className="text-left px-3 py-2 w-20" style={{ color: 'transparent' }}>·</th>
              {inningNums.map(i => (
                <th key={i} className="px-2 py-2 text-center font-bold text-xs"
                  style={{ color: game.status === 'in_progress' && game.inning === i ? '#F59E0B' : 'rgba(255,255,255,0.4)' }}>{i}</th>
              ))}
              <th className="px-2 py-2 text-center font-bold text-xs" style={{ color: '#F59E0B' }}>R</th>
              <th className="px-2 py-2 text-center font-bold text-xs" style={{ color: '#F59E0B' }}>H</th>
              <th className="px-2 py-2 text-center font-bold text-xs" style={{ color: '#F59E0B' }}>E</th>
            </tr>
          </thead>
          <tbody>
            {[
              { key: 'away', name: game.away_team_name, score: game.away_score, hits: game.away_hits, errors: game.away_errors },
              { key: 'home', name: game.home_team_name, score: game.home_score, hits: game.home_hits, errors: game.home_errors },
            ].map((row, ri) => (
              <tr key={row.key} style={{ borderTop: ri > 0 ? '1px solid rgba(255,255,255,0.06)' : 'none' }}>
                <td className="px-3 py-2.5 font-bold text-sm text-white truncate max-w-[80px]">{row.name}</td>
                {inningNums.map(i => (
                  <td key={i} className="px-2 py-2.5 text-center text-sm font-bold" style={{ color: 'rgba(255,255,255,0.65)' }}>{getScore(row.key, i)}</td>
                ))}
                <td className="px-2 py-2.5 text-center text-sm font-black" style={{ color: '#F59E0B' }}>{row.score ?? 0}</td>
                <td className="px-2 py-2.5 text-center text-sm font-bold" style={{ color: 'rgba(255,255,255,0.6)' }}>{row.hits ?? 0}</td>
                <td className="px-2 py-2.5 text-center text-sm font-bold" style={{ color: 'rgba(255,255,255,0.6)' }}>{row.errors ?? 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Main Page ────────────────────────────────────────────────────────────────
export default function PublicGameView() {
  const { id } = useParams();
  const [game, setGame] = useState(null);
  const [events, setEvents] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pitchAnim, setPitchAnim] = useState(false);
  const [lastPlay, setLastPlay] = useState(null);
  const prevEventCountRef = useRef(0);
  const animTimerRef = useRef(null);

  useEffect(() => {
    if (!id || id === ':id') { setLoading(false); return; }
    const loadGame = async () => {
      // Try by ID first, then fall back to public_token lookup
      let [byId, byToken] = await Promise.all([
        base44.entities.Game.filter({ id }),
        base44.entities.Game.filter({ public_token: id }),
      ]);
      const g = byId[0] || byToken[0] || null;
      const gameId = g?.id || id;
      const evts = await base44.entities.GameEvent.filter({ game_id: gameId });
      setGame(g);
      const sorted = (evts || []).sort((a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0)).slice(0, 40);
      setEvents(sorted);
      prevEventCountRef.current = sorted.length;
      if (sorted[0]) setLastPlay({ description: sorted[0].description, pitchType: g?.last_pitch_type });
      setLoading(false);
      if (g) {
        const teamIds = [g.home_team_id, g.away_team_id].filter(Boolean);
        Promise.all(teamIds.map(tid => base44.entities.Player.filter({ team_id: tid })))
          .then(results => setPlayers(results.flat()))
          .catch(() => {});
      }
    };
    loadGame().catch(() => setLoading(false));
  }, [id]);

  const gameId = game?.id || id;

  // Real-time game updates
  useEffect(() => {
    const unsub = base44.entities.Game.subscribe(evt => {
      if ((evt.id === id || evt.id === gameId) && evt.type !== 'delete' && evt.data) setGame(evt.data);
    });
    return unsub;
  }, [id, gameId]);

  // Real-time event updates — trigger pitch animation on new event
  useEffect(() => {
    const unsub = base44.entities.GameEvent.subscribe(evt => {
      if (evt.data?.game_id === gameId && evt.type === 'create') {
        const newEvt = evt.data;
        setEvents(prev => [newEvt, ...prev].slice(0, 40));
        setLastPlay({ description: newEvt.description, pitchType: newEvt.metadata?.pitch_type });

        // Trigger pitch animation
        setPitchAnim(true);
        clearTimeout(animTimerRef.current);
        animTimerRef.current = setTimeout(() => setPitchAnim(false), 600);
      }
    });
    return unsub;
  }, [gameId]);

  useEffect(() => () => clearTimeout(animTimerRef.current), []);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0B1120' }}>
      <div className="w-8 h-8 border-4 border-t-transparent rounded-full animate-spin" style={{ borderColor: '#F59E0B', borderTopColor: 'transparent' }} />
    </div>
  );

  if (!game) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0B1120' }}>
      <div className="text-center px-6">
        <div className="text-4xl mb-3">⚾</div>
        <div className="font-bold text-white text-lg mb-2">Game not found</div>
        <div className="text-sm" style={{ color: 'rgba(255,255,255,0.45)' }}>
          This link may be invalid, or the game hasn't been set up yet.<br />Check with your coach for the correct link.
        </div>
      </div>
    </div>
  );

  const isLive = game.status === 'in_progress';
  const isFinal = game.status === 'completed' || game.status === 'final';
  const currentBatter = game.current_batter_id ? players.find(p => p.id === game.current_batter_id) : null;

  return (
    <div className="min-h-screen pb-16" style={{ backgroundColor: '#0B1120', fontFamily: 'Inter, sans-serif' }}>

      {/* Sticky live nav bar */}
      {isLive && <LiveNavBar game={game} />}

      {/* Top spacing for nav bar */}
      {isLive && <div style={{ height: 56 }} />}

      {/* Score hero (non-live or final) */}
      {!isLive && (
        <div className="pt-10 pb-5 px-4 text-center" style={{ background: 'linear-gradient(180deg, #0F1729 0%, #0B1120 100%)' }}>
          {/* Status badge */}
          <div className="flex justify-center mb-3">
            {isFinal && <div className="px-3 py-1 rounded-full text-sm font-bold" style={{ backgroundColor: 'rgba(255,255,255,0.12)', color: 'rgba(255,255,255,0.7)' }}>FINAL</div>}
            {game.status === 'scheduled' && <div className="px-3 py-1 rounded-full text-sm font-bold" style={{ backgroundColor: 'rgba(59,130,246,0.25)', color: '#93C5FD' }}>UPCOMING</div>}
          </div>
          <div className="flex items-center justify-center gap-2" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            <div className="text-right flex-1">
              <div className="text-base leading-tight" style={{ color: 'rgba(255,255,255,0.6)' }}>{game.away_team_name}</div>
              <div className="text-5xl font-black leading-none" style={{ color: '#F59E0B' }}>{game.away_score ?? 0}</div>
            </div>
            <div className="text-3xl px-2" style={{ color: 'rgba(255,255,255,0.3)' }}>–</div>
            <div className="text-left flex-1">
              <div className="text-base leading-tight" style={{ color: 'rgba(255,255,255,0.6)' }}>{game.home_team_name}</div>
              <div className="text-5xl font-black leading-none" style={{ color: '#F59E0B' }}>{game.home_score ?? 0}</div>
            </div>
          </div>
          {!isLive && game.scheduled_date && (
            <div className="mt-2 text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>{game.scheduled_date}{game.scheduled_time ? ` · ${game.scheduled_time}` : ''}</div>
          )}
        </div>
      )}

      {/* Live score in field area */}
      {isLive && (
        <div className="text-center pt-3 pb-1">
          <div className="flex items-center justify-center gap-4" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            <div>
              <div className="text-xs text-white/40 mb-0.5">{game.away_team_name}</div>
              <div className="text-4xl font-black" style={{ color: '#F59E0B' }}>{game.away_score ?? 0}</div>
            </div>
            <div className="text-2xl text-white/30">–</div>
            <div>
              <div className="text-xs text-white/40 mb-0.5">{game.home_team_name}</div>
              <div className="text-4xl font-black" style={{ color: '#F59E0B' }}>{game.home_score ?? 0}</div>
            </div>
          </div>
        </div>
      )}

      {/* Animated field — live only */}
      {isLive && (
        <div className="px-3 mb-2">
          <AnimatedField game={game} pitchAnim={pitchAnim} lastPlay={lastPlay} />
        </div>
      )}

      {/* Current batter strip — live only */}
      {isLive && currentBatter && (
        <div className="mx-3 mb-3 flex items-center gap-3 px-4 py-3 rounded-xl" style={{ backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 font-black text-white text-sm" style={{ backgroundColor: 'rgba(245,158,11,0.2)', border: '1px solid rgba(245,158,11,0.3)' }}>
            #{currentBatter.number}
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-white text-sm truncate">{currentBatter.name}</div>
            <div className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
              At Bat{fmt(currentBatter.batting_avg) ? ` · ${fmt(currentBatter.batting_avg)} AVG` : ''}
            </div>
          </div>
          {game.current_pitcher_name && (
            <div className="text-right text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
              vs <span className="text-white font-semibold">{game.current_pitcher_name}</span>
              {game.current_pitcher_pitch_count > 0 && <div>{game.current_pitcher_pitch_count}p</div>}
            </div>
          )}
        </div>
      )}

      {/* Scheduled — show field + waiting message */}
      {game.status === 'scheduled' && (
        <>
          <div className="px-3 mb-2">
            <AnimatedField game={game} pitchAnim={false} lastPlay={null} />
          </div>
          <div className="mx-3 mb-3 rounded-xl p-5 text-center" style={{ border: '1px solid rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.04)' }}>
            <div className="font-bold text-white text-base">Game hasn't started yet</div>
            <div className="mt-1 text-sm" style={{ color: 'rgba(255,255,255,0.45)' }}>This page will update automatically when scoring begins</div>
            {game.arrival_time && (
              <div className="mt-2 text-sm font-medium" style={{ color: '#F59E0B' }}>Arrive by {game.arrival_time}</div>
            )}
            {game.location && (
              <div className="mt-1 text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>📍 {game.location}</div>
            )}
          </div>
        </>
      )}

      {/* Line Score */}
      {game.status !== 'scheduled' && game.status !== 'postponed' && <LineScoreCard game={game} />}

      {/* Play by Play (collapsible) */}
      {events.length > 0 && <PlayByPlayLog events={events} />}

      {/* Stream embeds */}
      {game.home_stream_url && (
        <div className="mx-3 mb-3 rounded-xl overflow-hidden aspect-video">
          <iframe src={game.home_stream_url} className="w-full h-full" allowFullScreen title="Home Stream" />
        </div>
      )}
      {game.away_stream_url && (
        <div className="mx-3 mb-3 rounded-xl overflow-hidden aspect-video">
          <iframe src={game.away_stream_url} className="w-full h-full" allowFullScreen title="Away Stream" />
        </div>
      )}
      {game.video_url && (
        <div className="mx-3 mb-3 rounded-xl overflow-hidden aspect-video">
          <iframe src={game.video_url} className="w-full h-full" allowFullScreen title="Game Video" />
        </div>
      )}

      {/* Footer */}
      <div className="text-center pt-6 pb-4">
        <div className="font-bold" style={{ fontFamily: 'Bebas Neue, sans-serif', letterSpacing: '0.08em', fontSize: 22, color: 'rgba(255,255,255,0.6)' }}>EagleBaseball</div>
      </div>
    </div>
  );
}