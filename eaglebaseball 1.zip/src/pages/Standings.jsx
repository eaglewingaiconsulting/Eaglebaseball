import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Trophy } from 'lucide-react';

export default function Standings() {
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [season, setSeason] = useState('all');

  useEffect(() => {
    base44.entities.Team.list('-wins', 100).then(t => {
      setTeams(t);
      setLoading(false);
    });
  }, []);

  const seasons = ['all', ...new Set(teams.map(t => t.season).filter(Boolean))];
  const filtered = season === 'all' ? teams : teams.filter(t => t.season === season);
  const sorted = [...filtered].sort((a, b) => {
    const wpA = (a.wins || 0) / Math.max(1, (a.wins || 0) + (a.losses || 0));
    const wpB = (b.wins || 0) / Math.max(1, (b.wins || 0) + (b.losses || 0));
    return wpB - wpA;
  });

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
      <div className="px-4 pt-6 pb-4 max-w-4xl mx-auto space-y-5">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-bebas tracking-widest" style={{ fontSize: 40, letterSpacing: '0.08em' }}>Standings</h1>
            <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>League standings by win percentage</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            {seasons.map(s => (
              <button key={s} onClick={() => setSeason(s)}
                className="px-3 py-1.5 text-sm font-medium transition-colors select-none"
                style={{ borderRadius: 8, backgroundColor: season === s ? '#F59E0B' : 'rgba(255,255,255,0.07)', color: season === s ? '#0B1120' : 'rgba(255,255,255,0.6)', fontWeight: season === s ? 700 : 400 }}>
                {s === 'all' ? 'All' : s}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 12 }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: 'rgba(255,255,255,0.04)', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                <th className="text-left px-4 py-3 w-10 font-semibold" style={{ color: 'rgba(255,255,255,0.4)' }}>#</th>
                <th className="text-left px-4 py-3 font-semibold text-white">Team</th>
                <th className="text-center px-3 py-3 font-semibold text-white">W</th>
                <th className="text-center px-3 py-3 font-semibold text-white">L</th>
                <th className="text-center px-3 py-3 font-semibold text-white">T</th>
                <th className="text-center px-3 py-3 font-semibold" style={{ color: '#F59E0B' }}>PCT</th>
                <th className="text-left px-3 py-3 font-semibold hidden md:table-cell" style={{ color: 'rgba(255,255,255,0.4)' }}>League</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="px-4 py-8 text-center" style={{ color: 'rgba(255,255,255,0.35)' }}>Loading...</td></tr>
              ) : sorted.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-8 text-center" style={{ color: 'rgba(255,255,255,0.35)' }}>No teams found</td></tr>
              ) : sorted.map((team, i) => {
                const g = (team.wins || 0) + (team.losses || 0);
                const pct = g > 0 ? ((team.wins || 0) / g).toFixed(3) : '.000';
                return (
                  <tr key={team.id} className="transition-colors"
                    style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.04)'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center">
                        {i === 0
                          ? <Trophy className="w-4 h-4" style={{ color: '#F59E0B' }} />
                          : <span style={{ color: 'rgba(255,255,255,0.35)' }}>{i + 1}</span>}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Link to={`/teams/${team.id}`} className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold overflow-hidden"
                          style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>
                          {team.logo_url
                            ? <img src={team.logo_url} alt={team.name} className="w-full h-full object-cover" />
                            : team.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-semibold text-white">{team.name}</div>
                          <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>{team.city}</div>
                        </div>
                      </Link>
                    </td>
                    <td className="px-3 py-3 text-center font-bold" style={{ color: '#4ADE80' }}>{team.wins || 0}</td>
                    <td className="px-3 py-3 text-center font-bold" style={{ color: '#F87171' }}>{team.losses || 0}</td>
                    <td className="px-3 py-3 text-center" style={{ color: 'rgba(255,255,255,0.4)' }}>{team.ties || 0}</td>
                    <td className="px-3 py-3 text-center font-bebas font-bold" style={{ color: '#F59E0B', fontSize: 16 }}>{pct}</td>
                    <td className="px-3 py-3 hidden md:table-cell" style={{ color: 'rgba(255,255,255,0.35)' }}>{team.league || '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}