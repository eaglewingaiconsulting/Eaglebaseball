import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { QrCode, Users, Calendar, Plus, ArrowLeft, Shield, Copy, UserPlus, FileDown, Star, CreditCard, Play, ChevronDown, ChevronUp, X, ShoppingBag, Palette, Pencil } from 'lucide-react';
import PlayerFormModal from '@/components/teams/PlayerFormModal';
import TeamSummary from '@/components/dashboard/TeamSummary';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import QRCodeModal from '@/components/teams/QRCodeModal';
import PlayerCard from '@/components/teams/PlayerCard';
import InvitePanel from '@/components/teams/InvitePanel';
import GameChangerExport from '@/components/teams/GameChangerExport';
import LogoBrandingEditor from '@/components/teams/LogoBrandingEditor';
import PaymentQRManager from '@/components/payments/PaymentQRManager';
import PaymentQRDisplay from '@/components/payments/PaymentQRDisplay';
import RosterPhotoImporter from '@/components/teams/RosterPhotoImporter';

export default function TeamDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showQR, setShowQR] = useState(false);
  const [showInvite, setShowInvite] = useState(false);
  const [showGCExport, setShowGCExport] = useState(false);
  const [showPayments, setShowPayments] = useState(false);
  const [showGames, setShowGames] = useState(false);
  const [showBranding, setShowBranding] = useState(false);
  const [brandingDraft, setBrandingDraft] = useState({});
  const [savingBranding, setSavingBranding] = useState(false);
  const [showAddPlayer, setShowAddPlayer] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState(null); // Player record to edit
  const [showRosterImporter, setShowRosterImporter] = useState(false);

  useEffect(() => {
    Promise.all([
      base44.entities.Team.filter({ id }),
      base44.entities.Player.filter({ team_id: id }),
      base44.entities.Game.list('-scheduled_date', 20),
    ]).then(([teams, players, allGames]) => {
      setTeam(teams[0] || null);
      setPlayers(players);
      setGames(allGames.filter(g => g.home_team_id === id || g.away_team_id === id));
      setLoading(false);
    });
  }, [id]);

  const isAdmin = user && team && (
    team.coach_email === user.email ||
    (team.admin_emails || []).includes(user.email) ||
    user.role === 'admin'
  );

  const handlePlayerSaved = (saved) => {
    setPlayers(prev => {
      const idx = prev.findIndex(p => p.id === saved.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = saved;
        return next;
      }
      return [...prev, saved];
    });
    setShowAddPlayer(false);
    setEditingPlayer(null);
  };

  const handlePlayerDeleted = (deletedId) => {
    setPlayers(prev => prev.filter(p => p.id !== deletedId));
    setEditingPlayer(null);
  };

  const copyShareCode = () => {
    navigator.clipboard.writeText(team.share_code);
    toast.success('Share code copied!');
  };

  const openBranding = () => {
    setBrandingDraft({ logo_url: team.logo_url || '', primary_color: team.primary_color || '#1e3a8a', secondary_color: team.secondary_color || '#f59e0b' });
    setShowBranding(true);
  };

  const saveBranding = async () => {
    setSavingBranding(true);
    await base44.entities.Team.update(id, brandingDraft);
    setTeam(t => ({ ...t, ...brandingDraft }));
    setShowBranding(false);
    setSavingBranding(false);
    toast.success('Branding updated!');
  };

  if (loading) return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh' }} className="flex items-center justify-center">
      <div className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>Loading...</div>
    </div>
  );
  if (!team) return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh' }} className="flex items-center justify-center">
      <div className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>Team not found</div>
    </div>
  );

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
      {/* Team Banner Header */}
      <div className="relative">
        <div className="h-28" style={{ backgroundColor: team.primary_color || '#1e3a8a' }} />
        <button
          onClick={() => navigate(-1)}
          className="absolute top-3 left-3 p-2 rounded-full select-none touch-manipulation"
          style={{ backgroundColor: 'rgba(0,0,0,0.4)' }}
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="px-4 pb-4" style={{ backgroundColor: '#0B1120', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div className="flex items-end gap-4 -mt-10 mb-3">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-white text-2xl font-bold flex-shrink-0 overflow-hidden"
              style={{ backgroundColor: team.primary_color || '#1e3a8a', border: '3px solid #0B1120' }}>
              {team.logo_url
                ? <img src={team.logo_url} alt={team.name} className="w-full h-full object-contain" />
                : team.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="pb-1 min-w-0">
              <h1 className="text-xl font-bebas tracking-wide text-white truncate" style={{ fontSize: 26 }}>{team.name}</h1>
              <p className="text-sm truncate" style={{ color: 'rgba(255,255,255,0.45)' }}>{[team.city, team.league, team.season].filter(Boolean).join(' · ')}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold px-2.5 py-1 rounded-full" style={{ backgroundColor: 'rgba(245,158,11,0.15)', color: '#F59E0B' }}>
              {team.wins || 0}W – {team.losses || 0}L
            </span>
            {team.share_code && (
              <button onClick={copyShareCode} className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full select-none touch-manipulation transition-colors"
                style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.55)' }}>
                <Copy className="w-3 h-3" /> {team.share_code}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="px-4 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
        <div className="flex gap-2 overflow-x-auto pb-1">
          <Link to={`/teams/${id}/messages`} className="flex-shrink-0">
            <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium select-none touch-manipulation"
              style={{ backgroundColor: 'rgba(245,158,11,0.15)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.3)', borderRadius: 8 }}>
              💬 Messages
            </button>
          </Link>
          {isAdmin && (
            <>
              <Link to={`/teams/${id}/lineups`} className="flex-shrink-0">
                <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium select-none touch-manipulation"
                  style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
                  📋 Lineups
                </button>
              </Link>
              <Link to={`/teams/${id}/store`} className="flex-shrink-0">
                <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium select-none touch-manipulation"
                  style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
                  <ShoppingBag className="w-3.5 h-3.5" /> Store
                </button>
              </Link>
              <button onClick={() => setShowInvite(!showInvite)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium flex-shrink-0 select-none touch-manipulation"
                style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
                <UserPlus className="w-3.5 h-3.5" /> Invite
              </button>
              <Link to={`/games/create?team=${id}`} className="flex-shrink-0">
                <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium select-none touch-manipulation"
                  style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
                  <Play className="w-3.5 h-3.5" /> Schedule
                </button>
              </Link>
              <button onClick={() => setShowPayments(!showPayments)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium flex-shrink-0 select-none touch-manipulation"
                style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
                <CreditCard className="w-3.5 h-3.5" /> Payments
              </button>
              <button onClick={openBranding}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium flex-shrink-0 select-none touch-manipulation"
                style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
                <Palette className="w-3.5 h-3.5" /> Branding
              </button>
              <button onClick={() => setShowGCExport(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium flex-shrink-0 select-none touch-manipulation"
                style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
                <FileDown className="w-3.5 h-3.5" /> Export
              </button>
            </>
          )}
          <button onClick={() => setShowQR(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium flex-shrink-0 select-none touch-manipulation"
            style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8 }}>
            <QrCode className="w-3.5 h-3.5" /> QR Code
          </button>
        </div>
      </div>

      <div className="p-4 space-y-4 max-w-4xl mx-auto">
        {/* Team Summary for coaches */}
        {isAdmin && (
          <div className="rounded-xl p-4" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <TeamSummary team={team} />
          </div>
        )}



        {/* Payment QR Manager (admin) */}
        {showPayments && isAdmin && (
          <div className="rounded-xl p-4" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <h3 className="font-semibold mb-4 flex items-center gap-2 text-sm text-white"><CreditCard className="w-4 h-4" /> Payment Options</h3>
            <PaymentQRManager entity={team} entityType="Team" onSave={updated => setTeam(updated)} />
          </div>
        )}

        {/* Payment QR Display (fans) */}
        {!isAdmin && (team?.payment_qr_codes || []).length > 0 && (
          <div className="rounded-xl p-4" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <PaymentQRDisplay qrCodes={team.payment_qr_codes} title="Pay Team Fees" />
          </div>
        )}

        {/* Invite Panel */}
        {showInvite && isAdmin && (
          <div className="rounded-xl p-4" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <h3 className="font-semibold mb-4 flex items-center gap-2 text-sm text-white"><UserPlus className="w-4 h-4" /> Invite to Team</h3>
            <InvitePanel team={team} players={players} />
          </div>
        )}

        {/* Roster */}
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h2 className="font-semibold flex items-center gap-2 text-sm text-white"><Users className="w-4 h-4" /> Roster ({players.length})</h2>
            {isAdmin && (
              <div className="flex gap-2">
                <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium select-none touch-manipulation"
                  style={{ backgroundColor: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8, color: 'rgba(255,255,255,0.7)' }}
                  onClick={() => setShowRosterImporter(true)}>
                  📸 Import Roster
                </button>
                <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium select-none touch-manipulation"
                  style={{ backgroundColor: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8, color: 'rgba(255,255,255,0.7)' }}
                  onClick={() => setShowAddPlayer(true)}>
                  <Plus className="w-3.5 h-3.5" /> Add Player
                </button>
              </div>
            )}
          </div>
          {players.length === 0 ? (
            <div className="rounded-xl p-8 text-center text-sm" style={{ border: '1px dashed rgba(245,158,11,0.3)', color: 'rgba(255,255,255,0.35)' }}>
              No players added yet
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-2">
              {players.map(player => (
                <div key={player.id} className="relative group">
                  <PlayerCard player={player} />
                  {isAdmin && (
                    <button
                      onClick={e => { e.stopPropagation(); setEditingPlayer(player); }}
                      className="absolute top-2 right-2 p-1.5 rounded-lg transition-all touch-manipulation sm:opacity-0 sm:group-hover:opacity-100"
                      style={{ backgroundColor: 'rgba(11,17,32,0.8)', border: '1px solid rgba(255,255,255,0.12)' }}
                    >
                      <Pencil className="w-3.5 h-3.5" style={{ color: 'rgba(255,255,255,0.6)' }} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
          {isAdmin && players.some(p => p.shirt_size) && (
            <button
              onClick={() => {
                const sized = players.filter(p => p.shirt_size && p.hat_size && p.pants_size);
                const csv = ['Name,Shirt,Hat,Pants', ...sized.map(p => `${p.name},${p.shirt_size},${p.hat_size},${p.pants_size}`)].join('\n');
                const blob = new Blob([csv], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = `${team.name}-sizing.csv`; a.click();
                URL.revokeObjectURL(url);
              }}
              className="text-xs flex items-center gap-1 hover:underline mt-1 select-none"
              style={{ color: '#F59E0B' }}
            >
              <FileDown className="w-3 h-3" /> Export Uniform Sizes (CSV)
            </button>
          )}
        </div>

        {/* Staff */}
        <div className="rounded-xl p-4" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
          <h3 className="font-semibold text-sm flex items-center gap-2 mb-3 text-white"><Shield className="w-4 h-4" /> Team Staff</h3>
          <div className="space-y-1.5">
            <div className="text-sm"><span style={{ color: 'rgba(255,255,255,0.4)' }}>Head Coach: </span><span className="font-medium text-white">{team.coach_email}</span></div>
            {(team.admin_emails || []).filter(e => e).map((email, i) => (
              <div key={i} className="text-sm"><span style={{ color: 'rgba(255,255,255,0.4)' }}>Admin {i+1}: </span><span className="font-medium text-white">{email}</span></div>
            ))}
          </div>
        </div>

        {/* Games collapsible */}
        <div className="rounded-xl overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
          <button
            onClick={() => setShowGames(v => !v)}
            className="w-full p-4 flex items-center justify-between select-none touch-manipulation"
          >
            <h3 className="font-semibold text-sm flex items-center gap-2 text-white"><Calendar className="w-4 h-4" /> Recent Games ({games.length})</h3>
            {showGames ? <ChevronUp className="w-4 h-4" style={{ color: 'rgba(255,255,255,0.4)' }} /> : <ChevronDown className="w-4 h-4" style={{ color: 'rgba(255,255,255,0.4)' }} />}
          </button>
          {showGames && (
            <div className="px-4 pb-4 space-y-2 pt-3" style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}>
              {games.length === 0 ? (
                <p className="text-sm" style={{ color: 'rgba(255,255,255,0.35)' }}>No games yet</p>
              ) : games.slice(0, 8).map(game => (
                <Link key={game.id} to={`/games/${game.id}`} className="flex items-center justify-between py-2.5 transition-colors"
                  style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                  <div>
                    <div className="text-sm font-medium text-white">{game.away_team_name} @ {game.home_team_name}</div>
                    <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>{game.scheduled_date} · {game.status}</div>
                  </div>
                  {game.status !== 'scheduled' && (
                    <div className="font-bebas" style={{ fontSize: 18, color: '#F59E0B' }}>{game.away_score}–{game.home_score}</div>
                  )}
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>

      {showQR && <QRCodeModal team={team} onClose={() => setShowQR(false)} />}
      {showGCExport && <GameChangerExport team={team} players={players} onClose={() => setShowGCExport(false)} />}

      {/* Branding Modal */}
      {showBranding && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-lg flex items-center gap-2"><Palette className="w-5 h-5" /> Team Branding</h2>
              <button onClick={() => setShowBranding(false)} className="p-1.5 rounded-lg hover:bg-muted"><X className="w-4 h-4" /></button>
            </div>
            <LogoBrandingEditor
              logoUrl={brandingDraft.logo_url}
              primaryColor={brandingDraft.primary_color}
              secondaryColor={brandingDraft.secondary_color}
              name={team.name}
              onChange={updates => setBrandingDraft(d => ({ ...d, ...updates }))}
            />
            <div className="flex gap-2 pt-1">
              <button onClick={() => setShowBranding(false)} className="flex-1 py-2 rounded-lg border border-border bg-muted hover:bg-secondary text-sm font-medium select-none">Cancel</button>
              <button onClick={saveBranding} disabled={savingBranding} className="flex-1 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium select-none disabled:opacity-60">
                {savingBranding ? 'Saving…' : 'Save Branding'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Player Modal */}
      {(showAddPlayer || editingPlayer) && (
        <PlayerFormModal
          teamId={id}
          players={players}
          player={editingPlayer || null}
          onSave={handlePlayerSaved}
          onDelete={handlePlayerDeleted}
          onClose={() => { setShowAddPlayer(false); setEditingPlayer(null); }}
        />
      )}

      {/* Roster Photo Importer Modal */}
      {showRosterImporter && (
        <RosterPhotoImporter
          teamId={id}
          onConfirm={async ({ players: rosterPlayers }) => {
            try {
              // Batch create players from the roster
              const created = await base44.entities.Player.bulkCreate(
                rosterPlayers.map(p => ({
                  team_id: id,
                  name: p.name,
                  number: p.number,
                  position: p.position,
                  bats: 'R',
                  throws: 'R',
                }))
              );
              setPlayers(prev => [...prev, ...created]);
              toast.success(`Added ${created.length} players!`);
              setShowRosterImporter(false);
            } catch (err) {
              toast.error('Failed to create players');
            }
          }}
          onClose={() => setShowRosterImporter(false)}
        />
      )}
    </div>
  );
}