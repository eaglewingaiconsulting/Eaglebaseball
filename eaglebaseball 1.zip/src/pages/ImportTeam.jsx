import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Check, Users, Zap } from 'lucide-react';
import { toast } from 'sonner';
import PlayerCard from '@/components/teams/PlayerCard';

export default function ImportTeam() {
  const { code } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [importing, setImporting] = useState(false);

  useEffect(() => {
    base44.entities.Team.filter({ share_code: code }).then(async (teams) => {
      const found = teams[0] || null;
      if (!found) { setLoading(false); return; }
      setTeam(found);
      const ps = await base44.entities.Player.filter({ team_id: found.id });
      setPlayers(ps);
      setLoading(false);
    });
  }, [code]);

  const handleImport = async () => {
    if (!user) {
      toast.error('Please sign in to import a team');
      return;
    }
    setImporting(true);
    try {
      // Clone the team with the current user as coach
      const newTeam = await base44.entities.Team.create({
        name: `${team.name} (Imported)`,
        city: team.city,
        league: team.league,
        season: team.season,
        primary_color: team.primary_color,
        secondary_color: team.secondary_color,
        coach_email: user.email,
        admin_emails: [],
        share_code: Math.random().toString(36).substring(2, 8).toUpperCase(),
        wins: 0, losses: 0, ties: 0,
      });
      await Promise.all(
        players.map(p => base44.entities.Player.create({
          team_id: newTeam.id,
          name: p.name,
          number: p.number,
          position: p.position,
          bats: p.bats,
          throws: p.throws,
        }))
      );
      toast.success('Team imported successfully!');
      navigate(`/teams/${newTeam.id}`);
    } catch {
      toast.error('Failed to import team');
    } finally {
      setImporting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (!team) return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="text-center">
        <div className="text-6xl mb-4">🔍</div>
        <h1 className="text-2xl font-bold">Team Not Found</h1>
        <p className="text-muted-foreground mt-2">The share code <strong>{code}</strong> doesn't match any team.</p>
        <Button onClick={() => navigate('/')} className="mt-4">Go Home</Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-accent flex items-center justify-center">
            <Zap className="w-5 h-5 text-accent-foreground" />
          </div>
          <span className="font-bebas text-xl tracking-wider">EagleBaseball</span>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
          <div className="text-center">
            <div className="w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center text-white text-2xl font-bold shadow-lg"
              style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>
              {team.name.slice(0, 2).toUpperCase()}
            </div>
            <h1 className="text-2xl font-bold">{team.name}</h1>
            <p className="text-muted-foreground">{team.city} • {team.league} • {team.season}</p>
          </div>

          <div>
            <h2 className="font-semibold flex items-center gap-2 mb-3">
              <Users className="w-4 h-4" /> Roster ({players.length} players)
            </h2>
            <div className="grid sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto">
              {players.map(player => <PlayerCard key={player.id} player={player} />)}
            </div>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={() => navigate('/')}>Cancel</Button>
            <Button className="flex-1 gap-2" onClick={handleImport} disabled={importing}>
              <Check className="w-4 h-4" />
              {importing ? 'Importing...' : 'Import Team to My Account'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}