import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { CheckCircle, XCircle, HelpCircle, ArrowLeft, MapPin, Clock, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function RSVPPage() {
  const { gameId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [game, setGame] = useState(null);
  const [players, setPlayers] = useState([]);
  const [rsvps, setRsvps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(null);

  useEffect(() => {
    base44.entities.Game.filter({ id: gameId }).then(async ([g]) => {
      if (!g) { setLoading(false); return; }
      setGame(g);
      // Get players whose parent_email matches current user
      const [myPlayers, existingRsvps] = await Promise.all([
        base44.entities.Player.filter({ parent_email: user?.email }),
        base44.entities.RSVP.filter({ game_id: gameId })
      ]);
      // Only show players from the user's own team (home team) — never expose opponent RSVP data
      const gamePlayers = myPlayers.filter(p => p.team_id === g.home_team_id);
      // Also filter loaded RSVPs to only show own team
      const filteredRsvps = existingRsvps.filter(r => r.team_id === g.home_team_id);
      setPlayers(gamePlayers);
      setRsvps(filteredRsvps);
      setLoading(false);
    });
  }, [gameId, user]);

  const getRsvp = (playerId) => rsvps.find(r => r.player_id === playerId);

  const submitRsvp = async (player, status) => {
    setSaving(player.id);
    const existing = getRsvp(player.id);

    // Optimistic update — apply immediately
    const optimisticId = existing?.id || `optimistic-${player.id}`;
    if (existing) {
      setRsvps(prev => prev.map(r => r.id === existing.id ? { ...r, status } : r));
    } else {
      setRsvps(prev => [...prev, {
        id: optimisticId, game_id: gameId, player_id: player.id,
        player_name: player.name, parent_email: user.email,
        team_id: player.team_id, status
      }]);
    }

    try {
      let updated;
      if (existing) {
        updated = await base44.entities.RSVP.update(existing.id, { status });
        setRsvps(prev => prev.map(r => r.id === existing.id ? updated : r));
      } else {
        updated = await base44.entities.RSVP.create({
          game_id: gameId, player_id: player.id, player_name: player.name,
          parent_email: user.email, team_id: player.team_id, status
        });
        // Replace optimistic placeholder with real record
        setRsvps(prev => prev.map(r => r.id === optimisticId ? updated : r));
      }
      toast.success(`RSVP updated: ${status}`);
    } catch {
      // Rollback on failure
      if (existing) {
        setRsvps(prev => prev.map(r => r.id === existing.id ? existing : r));
      } else {
        setRsvps(prev => prev.filter(r => r.id !== optimisticId));
      }
      toast.error('Failed to update RSVP');
    } finally {
      setSaving(null);
    }
  };

  if (loading) return <div className="p-6 text-center text-muted-foreground">Loading...</div>;
  if (!game) return <div className="p-6 text-center text-muted-foreground">Game not found</div>;

  const mapsUrl = game.field_address ? `https://www.google.com/maps/search/${encodeURIComponent(game.field_address)}` : null;

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="w-4 h-4" /> Back
      </button>

      <div className="bg-card border border-border rounded-2xl p-6">
        <h1 className="text-xl font-bold mb-1">{game.away_team_name} @ {game.home_team_name}</h1>
        <div className="space-y-2 mt-3 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span>{game.scheduled_date} {game.scheduled_time && `at ${game.scheduled_time}`}</span>
          </div>
          {game.arrival_time && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Arrive by: <span className="font-medium text-foreground">{game.arrival_time}</span></span>
            </div>
          )}
          {game.location && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="w-4 h-4" />
              {mapsUrl ? (
                <a href={mapsUrl} target="_blank" rel="noopener noreferrer" className="text-primary underline">{game.location}</a>
              ) : <span>{game.location}</span>}
            </div>
          )}
        </div>
      </div>

      {players.length === 0 ? (
        <div className="bg-card border border-border rounded-xl p-6 text-center text-muted-foreground">
          No players linked to your account for this game
        </div>
      ) : (
        <div className="space-y-4">
          <h2 className="font-semibold">RSVP for Your Players</h2>
          {players.map(player => {
            const rsvp = getRsvp(player.id);
            return (
              <div key={player.id} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="font-semibold">{player.name}</div>
                    <div className="text-xs text-muted-foreground">#{player.number} · {player.position}</div>
                  </div>
                  {rsvp && (
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                      rsvp.status === 'attending' ? 'bg-green-100 text-green-700' :
                      rsvp.status === 'not_attending' ? 'bg-red-100 text-red-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>{rsvp.status.replace('_', ' ')}</span>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant={rsvp?.status === 'attending' ? 'default' : 'outline'}
                    className="flex-1 gap-1.5" onClick={() => submitRsvp(player, 'attending')} disabled={saving === player.id}>
                    <CheckCircle className="w-3.5 h-3.5" /> Attending
                  </Button>
                  <Button size="sm" variant={rsvp?.status === 'maybe' ? 'default' : 'outline'}
                    className="flex-1 gap-1.5" onClick={() => submitRsvp(player, 'maybe')} disabled={saving === player.id}>
                    <HelpCircle className="w-3.5 h-3.5" /> Maybe
                  </Button>
                  <Button size="sm" variant={rsvp?.status === 'not_attending' ? 'destructive' : 'outline'}
                    className="flex-1 gap-1.5" onClick={() => submitRsvp(player, 'not_attending')} disabled={saving === player.id}>
                    <XCircle className="w-3.5 h-3.5" /> Can't Go
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}