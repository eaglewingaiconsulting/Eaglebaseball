/**
 * LiveGames — dedicated listing of all in-progress games across every team
 * the current user follows (all orgs, all roles).
 * Polls every 45 seconds — intentionally not aggressive.
 */
import { useState, useEffect, useCallback, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import useEffectiveUser from '@/hooks/useEffectiveUser';
import useAppRole from '@/hooks/useAppRole';
import { ArrowLeft, Radio, RefreshCw, Play, Clock } from 'lucide-react';

const POLL_INTERVAL_MS = 45_000; // 45 seconds

function LiveGameCard({ game }) {
  const isTop = game.inning_half === 'top';
  return (
    <Link
      to={`/games/${game.id}/live`}
      className="block select-none touch-manipulation active:opacity-80 transition-opacity"
    >
      <div style={{
        backgroundColor: '#12180A',
        border: '1.5px solid #3D5A00',
        borderRadius: 12,
        overflow: 'hidden',
      }}>
        {/* Live indicator bar */}
        <div className="flex items-center gap-2 px-4 py-2" style={{ backgroundColor: '#1A2210', borderBottom: '1px solid #2A3800' }}>
          <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse flex-shrink-0" />
          <span className="font-bebas tracking-widest text-yellow-400" style={{ fontSize: 13, letterSpacing: '0.1em' }}>
            LIVE
          </span>
          <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: 12, marginLeft: 4 }}>
            Inn. {game.inning} {isTop ? '▲ Top' : '▼ Bot'} · {game.outs} out{game.outs !== 1 ? 's' : ''}
          </span>
          {game.location && (
            <span className="ml-auto text-xs" style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11 }}>
              {game.location}
            </span>
          )}
        </div>

        {/* Score section */}
        <div className="px-4 py-4">
          {/* Away row */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 min-w-0">
              <div
                className="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold"
                style={{ backgroundColor: 'rgba(245,158,11,0.15)', color: '#F59E0B' }}>
                A
              </div>
              <span className="font-semibold text-white truncate" style={{ fontSize: 15 }}>
                {game.away_team_name}
              </span>
              {isTop && (
                <span className="text-xs font-bold px-1.5 py-0.5 rounded flex-shrink-0"
                  style={{ backgroundColor: 'rgba(245,158,11,0.2)', color: '#F59E0B', fontSize: 10 }}>
                  ▲ BAT
                </span>
              )}
            </div>
            <span className="font-bebas flex-shrink-0" style={{ fontSize: 38, color: '#F59E0B', lineHeight: 1, textShadow: '0 0 14px rgba(245,158,11,0.6)', letterSpacing: '0.05em' }}>
              {game.away_score ?? 0}
            </span>
          </div>

          {/* Divider */}
          <div style={{ height: 1, backgroundColor: 'rgba(255,255,255,0.07)', marginBottom: 12 }} />

          {/* Home row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0">
              <div
                className="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold"
                style={{ backgroundColor: 'rgba(59,130,246,0.15)', color: '#93C5FD' }}>
                H
              </div>
              <span className="font-semibold text-white truncate" style={{ fontSize: 15 }}>
                {game.home_team_name}
              </span>
              {!isTop && (
                <span className="text-xs font-bold px-1.5 py-0.5 rounded flex-shrink-0"
                  style={{ backgroundColor: 'rgba(245,158,11,0.2)', color: '#F59E0B', fontSize: 10 }}>
                  ▼ BAT
                </span>
              )}
            </div>
            <span className="font-bebas flex-shrink-0" style={{ fontSize: 38, color: '#F59E0B', lineHeight: 1, textShadow: '0 0 14px rgba(245,158,11,0.6)', letterSpacing: '0.05em' }}>
              {game.home_score ?? 0}
            </span>
          </div>

          {/* BSO + runners mini row */}
          <div className="flex items-center gap-4 mt-3 pt-3" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <div className="flex items-center gap-1">
              <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: 11 }}>B</span>
              {[0,1,2,3].map(i => (
                <div key={i} className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: i < (game.balls ?? 0) ? '#4ADE80' : 'rgba(255,255,255,0.12)' }} />
              ))}
            </div>
            <div className="flex items-center gap-1">
              <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: 11 }}>S</span>
              {[0,1,2].map(i => (
                <div key={i} className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: i < (game.strikes ?? 0) ? '#F59E0B' : 'rgba(255,255,255,0.12)' }} />
              ))}
            </div>
            <div className="flex items-center gap-1">
              <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: 11 }}>O</span>
              {[0,1,2].map(i => (
                <div key={i} className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: i < (game.outs ?? 0) ? '#F87171' : 'rgba(255,255,255,0.12)' }} />
              ))}
            </div>
            {/* Runners */}
            <div className="ml-auto flex items-center gap-0.5">
              {/* Diamond: 2B top, 3B left, 1B right */}
              <div className="relative" style={{ width: 28, height: 28 }}>
                <div className="absolute" style={{ top: 2, left: '50%', transform: 'translateX(-50%) rotate(45deg)', width: 9, height: 9, backgroundColor: game.runner_second ? '#F59E0B' : 'rgba(255,255,255,0.12)', borderRadius: 2 }} />
                <div className="absolute" style={{ top: '50%', left: 1, transform: 'translateY(-50%) rotate(45deg)', width: 9, height: 9, backgroundColor: game.runner_third ? '#F59E0B' : 'rgba(255,255,255,0.12)', borderRadius: 2 }} />
                <div className="absolute" style={{ top: '50%', right: 1, transform: 'translateY(-50%) rotate(45deg)', width: 9, height: 9, backgroundColor: game.runner_first ? '#F59E0B' : 'rgba(255,255,255,0.12)', borderRadius: 2 }} />
              </div>
            </div>
          </div>
        </div>

        {/* Tap hint */}
        <div className="flex items-center justify-end gap-1 px-4 pb-2.5" style={{ color: 'rgba(245,158,11,0.5)', fontSize: 11 }}>
          <Play className="w-2.5 h-2.5" /> View Live
        </div>
      </div>
    </Link>
  );
}

export default function LiveGames() {
  const navigate = useNavigate();
  const { user } = useEffectiveUser();
  const { isOrgOwner, roleLoading } = useAppRole();
  const [liveGames, setLiveGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const pollRef = useRef(null);

  const fetchLiveGames = useCallback(async (silent = false) => {
    if (!user || roleLoading) return;
    if (!silent) setRefreshing(true);

    // Step 1: get all teams this user follows
    const allTeams = await base44.entities.Team.list('-created_date', 200);
    const myTeams = isOrgOwner
      ? allTeams
      : allTeams.filter(t =>
          t.coach_email === user.email ||
          (t.admin_emails || []).includes(user.email) ||
          (t.fan_emails || []).includes(user.email)
        );
    const myTeamIds = new Set(myTeams.map(t => t.id));

    // Step 2: fetch only in_progress games
    const inProgress = await base44.entities.Game.filter({ status: 'in_progress' });
    const relevant = isOrgOwner
      ? inProgress
      : inProgress.filter(g => myTeamIds.has(g.home_team_id) || myTeamIds.has(g.away_team_id));

    // Sort by most recently updated
    relevant.sort((a, b) => new Date(b.updated_date || 0) - new Date(a.updated_date || 0));

    setLiveGames(relevant);
    setLastUpdated(new Date());
    setLoading(false);
    setRefreshing(false);
  }, [user?.email, isOrgOwner, roleLoading]);

  // Initial load
  useEffect(() => {
    fetchLiveGames(false);
  }, [fetchLiveGames]);

  // Poll every 45 seconds
  useEffect(() => {
    pollRef.current = setInterval(() => fetchLiveGames(true), POLL_INTERVAL_MS);
    return () => clearInterval(pollRef.current);
  }, [fetchLiveGames]);

  const timeAgo = lastUpdated
    ? `Updated ${Math.round((Date.now() - lastUpdated.getTime()) / 1000)}s ago`
    : '';

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">

      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center gap-3 px-4 py-3" style={{ backgroundColor: '#0B1120', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
        <button onClick={() => navigate(-1)} className="p-2 rounded-lg touch-manipulation hover:bg-white/10 flex-shrink-0" style={{ color: 'rgba(255,255,255,0.6)' }}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2 flex-1">
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 animate-pulse flex-shrink-0" />
          <h1 className="font-bebas tracking-widest" style={{ fontSize: 22, color: '#F59E0B', letterSpacing: '0.1em' }}>
            Live Games
          </h1>
        </div>
        <button
          onClick={() => fetchLiveGames(false)}
          disabled={refreshing}
          className="p-2 rounded-lg touch-manipulation hover:bg-white/10 flex-shrink-0"
          style={{ color: refreshing ? '#F59E0B' : 'rgba(255,255,255,0.4)' }}
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Last updated */}
      {lastUpdated && (
        <div className="px-4 pt-2 pb-0">
          <span style={{ color: 'rgba(255,255,255,0.25)', fontSize: 11 }}>
            <Clock className="w-3 h-3 inline mr-1 -mt-px" />{timeAgo} · auto-refreshes every 45s
          </span>
        </div>
      )}

      <div className="px-4 pt-4 space-y-3">
        {loading && (
          <div className="flex items-center justify-center py-20 gap-3" style={{ color: 'rgba(255,255,255,0.4)' }}>
            <div className="w-6 h-6 rounded-full border-2 border-yellow-400/30 border-t-yellow-400 animate-spin" />
            <span className="text-sm">Loading live games…</span>
          </div>
        )}

        {!loading && liveGames.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
            <Radio className="w-12 h-12" style={{ color: 'rgba(255,255,255,0.1)' }} />
            <div>
              <p className="font-semibold text-white mb-1">No live games right now</p>
              <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: 13 }}>
                Games in progress across your teams will appear here automatically.
              </p>
            </div>
            <Link to="/games"
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm touch-manipulation"
              style={{ backgroundColor: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.3)', color: '#F59E0B' }}>
              View All Games
            </Link>
          </div>
        )}

        {!loading && liveGames.map(game => (
          <LiveGameCard key={game.id} game={game} />
        ))}

        {!loading && liveGames.length > 0 && (
          <p className="text-center pt-2 pb-4" style={{ color: 'rgba(255,255,255,0.2)', fontSize: 11 }}>
            Showing {liveGames.length} live game{liveGames.length !== 1 ? 's' : ''} across all your teams
          </p>
        )}
      </div>
    </div>
  );
}