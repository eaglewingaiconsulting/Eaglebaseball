import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Calendar, ArrowUpDown, ChevronDown, ChevronUp, Trophy, Users, MapPin, Clock, Zap } from 'lucide-react';
import { toast } from 'sonner';

function generateToken() {
  return Math.random().toString(36).substring(2, 12);
}

function SectionCard({ title, icon: Icon, children }) {
  return (
    <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
      <div className="flex items-center gap-2.5 px-5 py-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        {Icon && <Icon className="w-4 h-4" style={{ color: '#F59E0B' }} />}
        <span className="font-semibold text-white text-sm tracking-wide">{title}</span>
      </div>
      <div className="px-5 py-4 space-y-4">{children}</div>
    </div>
  );
}

function FieldLabel({ children, hint }) {
  return (
    <div className="flex items-baseline justify-between mb-1.5">
      <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.45)' }}>{children}</label>
      {hint && <span className="text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>{hint}</span>}
    </div>
  );
}

function DarkInput({ value, onChange, placeholder, type = 'text', required }) {
  return (
    <input
      type={type}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      required={required}
      className="w-full px-3 py-2.5 rounded-xl text-sm text-white placeholder:text-white/25 outline-none transition-all"
      style={{
        backgroundColor: 'rgba(255,255,255,0.05)',
        border: '1px solid rgba(255,255,255,0.1)',
        fontSize: 14,
      }}
      onFocus={e => { e.target.style.border = '1px solid rgba(245,158,11,0.5)'; e.target.style.backgroundColor = 'rgba(245,158,11,0.05)'; }}
      onBlur={e => { e.target.style.border = '1px solid rgba(255,255,255,0.1)'; e.target.style.backgroundColor = 'rgba(255,255,255,0.05)'; }}
    />
  );
}

function DarkSelect({ value, onValueChange, placeholder, children }) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger className="w-full px-3 py-2.5 rounded-xl text-sm text-white outline-none transition-all h-auto"
        style={{ backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: value ? '#fff' : 'rgba(255,255,255,0.25)' }}>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent style={{ backgroundColor: '#1A2235', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12 }}>
        {children}
      </SelectContent>
    </Select>
  );
}

export default function CreateGame() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [teams, setTeams] = useState([]);
  const [lineupTemplates, setLineupTemplates] = useState([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [showTemplatePreview, setShowTemplatePreview] = useState(false);
  const [saving, setSaving] = useState(false);
  const [opponentMode, setOpponentMode] = useState('text');
  const [leagueTeams, setLeagueTeams] = useState([]);
  const [showTournament, setShowTournament] = useState(false);
  const [homePlayers, setHomePlayers] = useState([]);
  const [probablePitcherId, setProbablePitcherId] = useState('');

  const preselectedTeamId = new URLSearchParams(window.location.search).get('team') || '';

  const [game, setGame] = useState({
    home_team_id: preselectedTeamId, away_team_id: '', away_team_name: '',
    opponent_team_id: '',
    scheduled_date: '', scheduled_time: '',
    location: '', field_address: '', arrival_time: '',
    tournament_name: '', tournament_link: '',
    total_innings: 9,
    time_limit_minutes: 0,
  });

  useEffect(() => {
    base44.entities.Team.list('-created_date', 100).then(setTeams);
  }, []);

  useEffect(() => {
    if (!game.home_team_id) { setLineupTemplates([]); setSelectedTemplateId(''); setLeagueTeams([]); return; }
    base44.entities.LineupTemplate.filter({ team_id: game.home_team_id }).then(tmpl => {
      setLineupTemplates(tmpl);
      const def = tmpl.find(t => t.is_default);
      if (def) setSelectedTemplateId(def.id);
    });
    base44.entities.Player.filter({ team_id: game.home_team_id }).then(setHomePlayers);
    setProbablePitcherId('');
    const homeTeam = teams.find(t => t.id === game.home_team_id);
    if (homeTeam?.age_group) {
      setLeagueTeams(teams.filter(t => t.id !== game.home_team_id && t.age_group === homeTeam.age_group));
    } else {
      setLeagueTeams([]);
    }
    setOpponentMode('text');
  }, [game.home_team_id, teams]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!game.home_team_id) return toast.error('Select a home team');
    if (!game.away_team_name) return toast.error('Enter the away team name');
    if (!game.scheduled_date) return toast.error('Select a date');

    const homeTeam = teams.find(t => t.id === game.home_team_id);
    setSaving(true);
    try {
      let homeLineup = [];
      let templateId = null;
      if (selectedTemplateId) {
        const tmpl = lineupTemplates.find(t => t.id === selectedTemplateId);
        if (tmpl?.batting_order?.length) {
          homeLineup = tmpl.batting_order
            .sort((a, b) => a.batting_position - b.batting_position)
            .map(e => e.player_id)
            .filter(Boolean);
          templateId = tmpl.id;
          base44.entities.LineupTemplate.update(tmpl.id, { last_used: new Date().toISOString() });
        }
      }

      const probablePitcher = homePlayers.find(p => p.id === probablePitcherId);
      const created = await base44.entities.Game.create({
        ...game,
        home_team_name: homeTeam?.name,
        ...(game.opponent_team_id ? { away_team_id: game.opponent_team_id } : {}),
        status: 'scheduled',
        inning: 1, inning_half: 'top', outs: 0, balls: 0, strikes: 0,
        total_innings: game.total_innings || 9,
        home_score: 0, away_score: 0,
        home_hits: 0, away_hits: 0,
        home_errors: 0, away_errors: 0,
        runner_first: false, runner_second: false, runner_third: false,
        home_batting_order_idx: 0, away_batting_order_idx: 0,
        inning_scores: [],
        public_token: generateToken(),
        ...(homeLineup.length ? { home_lineup: homeLineup } : {}),
        ...(templateId ? { lineup_template_id: templateId } : {}),
        ...(probablePitcherId ? { probable_pitcher_id: probablePitcherId, probable_pitcher_name: probablePitcher?.name || '' } : {}),
        ...(game.time_limit_minutes > 0 ? { time_limit_minutes: game.time_limit_minutes } : {}),
      });
      toast.success('Game scheduled!');
      navigate(`/games/${created.id}/lineup`);
    } catch {
      toast.error('Failed to schedule game');
    } finally {
      setSaving(false);
    }
  };

  const myTeams = teams.filter(t =>
    t.coach_email === user?.email ||
    (t.admin_emails || []).includes(user?.email) ||
    user?.role === 'admin'
  );

  const homeTeamName = teams.find(t => t.id === game.home_team_id)?.name;

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">

      {/* Hero header */}
      <div className="px-5 pt-6 pb-5" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 rounded-xl flex items-center justify-center transition-colors select-none flex-shrink-0"
            style={{ backgroundColor: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.3)' }}>
              <Zap className="w-5 h-5" style={{ color: '#F59E0B' }} />
            </div>
            <div>
              <h1 className="font-bebas tracking-widest text-white" style={{ fontSize: 28, letterSpacing: '0.06em', lineHeight: 1 }}>
                Schedule Game
              </h1>
              <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>Set up the matchup details</p>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="max-w-2xl mx-auto px-4 py-5 space-y-4">

          {/* Teams section */}
          <SectionCard title="Matchup" icon={Users}>
            {/* Opponent */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <FieldLabel>Opponent (bats first) *</FieldLabel>
                {leagueTeams.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setOpponentMode(m => m === 'text' ? 'pick' : 'text')}
                    className="flex items-center gap-1 text-xs font-medium select-none"
                    style={{ color: '#F59E0B' }}
                  >
                    <Users className="w-3 h-3" />
                    {opponentMode === 'text' ? 'Pick from league' : 'Enter manually'}
                  </button>
                )}
              </div>
              {opponentMode === 'text' ? (
                <DarkInput
                  value={game.away_team_name || ''}
                  onChange={e => setGame(g => ({ ...g, away_team_name: e.target.value, away_team_id: '', opponent_team_id: '' }))}
                  placeholder="Opponent team name"
                />
              ) : (
                <DarkSelect
                  value={game.opponent_team_id || ''}
                  onValueChange={v => {
                    const picked = leagueTeams.find(t => t.id === v);
                    setGame(g => ({ ...g, opponent_team_id: v, away_team_name: picked?.name || '', away_team_id: v }));
                  }}
                  placeholder="Choose opponent from league"
                >
                  {leagueTeams.map(t => (
                    <SelectItem key={t.id} value={t.id}>{t.name}{t.age_group ? ` · ${t.age_group}` : ''}</SelectItem>
                  ))}
                </DarkSelect>
              )}
            </div>

            {/* VS divider with swap */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px" style={{ backgroundColor: 'rgba(255,255,255,0.07)' }} />
              <button
                type="button"
                onClick={() => {
                  if (!game.home_team_id || !game.away_team_name) { toast.error('Select both teams before swapping'); return; }
                  const prevHomeName = teams.find(t => t.id === game.home_team_id)?.name || '';
                  const prevAwayName = game.away_team_name;
                  setGame(g => ({ ...g, home_team_id: '', away_team_name: prevHomeName, away_team_id: '', opponent_team_id: '' }));
                  setOpponentMode('text');
                  toast.success('Teams swapped');
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold select-none transition-colors"
                style={{ backgroundColor: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.25)', color: '#F59E0B' }}
              >
                <ArrowUpDown className="w-3 h-3" /> Swap
              </button>
              <div className="flex-1 h-px" style={{ backgroundColor: 'rgba(255,255,255,0.07)' }} />
            </div>

            {/* Home team */}
            <div>
              <FieldLabel>Home Team (bats second) *</FieldLabel>
              <DarkSelect
                value={game.home_team_id}
                onValueChange={v => setGame(g => ({ ...g, home_team_id: v }))}
                placeholder="Select your team"
              >
                {myTeams.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
              </DarkSelect>
            </div>
          </SectionCard>

          {/* Game Details */}
          <SectionCard title="Game Details" icon={Calendar}>
            {/* Innings */}
            <div>
              <FieldLabel>Number of Innings</FieldLabel>
              <div className="flex items-center gap-3">
                <button type="button" onClick={() => setGame(g => ({ ...g, total_innings: Math.max(3, (g.total_innings || 9) - 1) }))}
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-lg font-bold select-none touch-manipulation transition-colors"
                  style={{ backgroundColor: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#fff' }}>−</button>
                <span className="font-bebas text-3xl w-8 text-center" style={{ color: '#F59E0B' }}>{game.total_innings}</span>
                <button type="button" onClick={() => setGame(g => ({ ...g, total_innings: Math.min(9, (g.total_innings || 9) + 1) }))}
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-lg font-bold select-none touch-manipulation transition-colors"
                  style={{ backgroundColor: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#fff' }}>+</button>
                <div className="flex gap-2 ml-1">
                  {[6, 7, 9].map(n => (
                    <button key={n} type="button" onClick={() => setGame(g => ({ ...g, total_innings: n }))}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold select-none touch-manipulation transition-all"
                      style={{
                        backgroundColor: game.total_innings === n ? '#F59E0B' : 'rgba(255,255,255,0.06)',
                        border: game.total_innings === n ? '1px solid #F59E0B' : '1px solid rgba(255,255,255,0.1)',
                        color: game.total_innings === n ? '#0B1120' : 'rgba(255,255,255,0.6)',
                      }}>
                      {n}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Time Limit */}
            <div>
              <FieldLabel hint="optional">Game Time Limit</FieldLabel>
              <div className="flex items-center gap-2 flex-wrap">
                {[0, 75, 90, 105].map(mins => (
                  <button key={mins} type="button"
                    onClick={() => setGame(g => ({ ...g, time_limit_minutes: mins }))}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold select-none touch-manipulation transition-all"
                    style={{
                      backgroundColor: game.time_limit_minutes === mins ? '#F59E0B' : 'rgba(255,255,255,0.06)',
                      border: game.time_limit_minutes === mins ? '1px solid #F59E0B' : '1px solid rgba(255,255,255,0.1)',
                      color: game.time_limit_minutes === mins ? '#0B1120' : 'rgba(255,255,255,0.6)',
                    }}>
                    {mins === 0 ? 'No limit' : `${Math.floor(mins/60)}h${mins%60 ? ` ${mins%60}m` : ''}`}
                  </button>
                ))}
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min={1}
                    max={300}
                    placeholder="custom"
                    value={![0, 75, 90, 105].includes(game.time_limit_minutes) && game.time_limit_minutes > 0 ? game.time_limit_minutes : ''}
                    onChange={e => {
                      const val = parseInt(e.target.value);
                      setGame(g => ({ ...g, time_limit_minutes: isNaN(val) ? 0 : val }));
                    }}
                    className="w-20 px-2 py-1.5 rounded-lg text-xs text-white outline-none transition-all"
                    style={{
                      backgroundColor: 'rgba(255,255,255,0.05)',
                      border: `1px solid ${![0, 75, 90, 105].includes(game.time_limit_minutes) && game.time_limit_minutes > 0 ? 'rgba(245,158,11,0.5)' : 'rgba(255,255,255,0.1)'}`,
                      fontSize: 13,
                    }}
                  />
                  <span className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>min</span>
                </div>
              </div>
              {game.time_limit_minutes > 0 && (
                <div className="text-xs mt-1.5" style={{ color: 'rgba(255,255,255,0.4)' }}>
                  Scorer and coach will see a countdown with alerts at 15, 10, 5 &amp; 2 min
                </div>
              )}
            </div>

            {/* Date / Time / Arrival */}
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 sm:col-span-1">
                <FieldLabel>Date *</FieldLabel>
                <DarkInput type="date" value={game.scheduled_date} onChange={e => setGame(g => ({ ...g, scheduled_date: e.target.value }))} required />
              </div>
              <div>
                <FieldLabel>Game Time</FieldLabel>
                <DarkInput type="time" value={game.scheduled_time} onChange={e => {
                  const time = e.target.value;
                  setGame(g => {
                    const updates = { ...g, scheduled_time: time };
                    if (time) {
                      const [h, m] = time.split(':').map(Number);
                      const total = h * 60 + m - 60;
                      const arrH = Math.floor(((total % 1440) + 1440) % 1440 / 60);
                      const arrM = ((total % 1440) + 1440) % 1440 % 60;
                      updates.arrival_time = `${String(arrH).padStart(2,'0')}:${String(arrM).padStart(2,'0')}`;
                    }
                    return updates;
                  });
                }} />
              </div>
              <div>
                <FieldLabel>Arrive By</FieldLabel>
                <DarkInput type="time" value={game.arrival_time} onChange={e => setGame(g => ({ ...g, arrival_time: e.target.value }))} />
              </div>
            </div>

            {/* Location */}
            <div>
              <FieldLabel>Field Name</FieldLabel>
              <DarkInput value={game.location} onChange={e => setGame(g => ({ ...g, location: e.target.value }))} placeholder="Eagle Field" />
            </div>
            <div>
              <FieldLabel hint="for Google Maps link">Field Address</FieldLabel>
              <DarkInput value={game.field_address} onChange={e => setGame(g => ({ ...g, field_address: e.target.value }))} placeholder="123 Main St, City, State" />
            </div>
          </SectionCard>

          {/* Probable Pitcher */}
          {game.home_team_id && homePlayers.length > 0 && (
            <SectionCard title="Probable Pitcher" icon={Zap}>
              <div>
                <FieldLabel hint="optional">Starting Pitcher — {teams.find(t => t.id === game.home_team_id)?.name}</FieldLabel>
                <DarkSelect
                  value={probablePitcherId}
                  onValueChange={v => setProbablePitcherId(v === '' ? '' : v)}
                  placeholder="Select probable pitcher (optional)"
                >
                  <SelectItem value={null}>None / TBD</SelectItem>
                  {homePlayers.map(p => (
                    <SelectItem key={p.id} value={p.id}>#{p.number} {p.name}{p.position === 'P' ? ' · P' : ''}</SelectItem>
                  ))}
                </DarkSelect>
                {probablePitcherId && (
                  <div className="text-xs mt-1.5" style={{ color: 'rgba(255,255,255,0.4)' }}>
                    Will pre-fill the pitcher slot when scoring begins
                  </div>
                )}
              </div>
            </SectionCard>
          )}

          {/* Lineup Template */}
          {game.home_team_id && (
            <SectionCard title={`Lineup Template`} icon={Users}>
              {lineupTemplates.length === 0 ? (
                <div className="text-sm py-2" style={{ color: 'rgba(255,255,255,0.4)' }}>
                  No saved lineups for this team.{' '}
                  <button type="button" className="font-medium underline" style={{ color: '#F59E0B' }}
                    onClick={() => navigate(`/teams/${game.home_team_id}/lineups`)}>
                    Create one →
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <FieldLabel hint="optional">Select Template</FieldLabel>
                    <DarkSelect value={selectedTemplateId} onValueChange={setSelectedTemplateId} placeholder="Build manually in next step">
                      <SelectItem value={null}>Build manually in next step</SelectItem>
                      {lineupTemplates.map(t => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.is_default ? '★ ' : ''}{t.name} ({(t.batting_order || []).length} players)
                        </SelectItem>
                      ))}
                    </DarkSelect>
                  </div>
                  {selectedTemplateId && (() => {
                    const tmpl = lineupTemplates.find(t => t.id === selectedTemplateId);
                    if (!tmpl?.batting_order?.length) return null;
                    const preview = tmpl.batting_order
                      .sort((a, b) => a.batting_position - b.batting_position)
                      .slice(0, showTemplatePreview ? undefined : 3);
                    return (
                      <div className="rounded-xl p-3 space-y-2" style={{ backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
                        {preview.map((entry, i) => (
                          <div key={i} className="flex items-center gap-2.5 text-sm">
                            <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                              style={{ backgroundColor: '#F59E0B', color: '#0B1120' }}>
                              {entry.batting_position}
                            </span>
                            <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: 12 }}>#{entry.jersey_number}</span>
                            <span className="font-medium text-white">{entry.name}</span>
                          </div>
                        ))}
                        {tmpl.batting_order.length > 3 && (
                          <button type="button" onClick={() => setShowTemplatePreview(v => !v)}
                            className="flex items-center gap-1 text-xs mt-1 select-none" style={{ color: '#F59E0B' }}>
                            {showTemplatePreview ? <><ChevronUp className="w-3 h-3" /> Show less</> : <><ChevronDown className="w-3 h-3" /> Show all {tmpl.batting_order.length}</>}
                          </button>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}
            </SectionCard>
          )}

          {/* Tournament — collapsible */}
          <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <button
              type="button"
              onClick={() => setShowTournament(v => !v)}
              className="w-full flex items-center justify-between px-5 py-4 select-none touch-manipulation"
            >
              <span className="flex items-center gap-2.5 font-semibold text-sm text-white">
                <Trophy className="w-4 h-4" style={{ color: '#F59E0B' }} /> Tournament Game?
              </span>
              {showTournament
                ? <ChevronUp className="w-4 h-4" style={{ color: 'rgba(255,255,255,0.4)' }} />
                : <ChevronDown className="w-4 h-4" style={{ color: 'rgba(255,255,255,0.4)' }} />}
            </button>
            {showTournament && (
              <div className="px-5 pb-5 space-y-4" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="pt-4">
                  <FieldLabel>Tournament Name</FieldLabel>
                  <DarkInput value={game.tournament_name} onChange={e => setGame(g => ({ ...g, tournament_name: e.target.value }))} placeholder="Spring Invitational" />
                </div>
                <div>
                  <FieldLabel>Tournament Link</FieldLabel>
                  <DarkInput value={game.tournament_link} onChange={e => setGame(g => ({ ...g, tournament_link: e.target.value }))} placeholder="https://..." />
                </div>
              </div>
            )}
          </div>

          {/* Submit */}
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={() => navigate(-1)}
              className="flex-1 py-3 rounded-xl text-sm font-semibold select-none transition-colors"
              style={{ backgroundColor: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.7)' }}>
              Cancel
            </button>
            <button type="submit" disabled={saving}
              className="flex-1 py-3 rounded-xl text-sm font-bold select-none transition-all flex items-center justify-center gap-2 disabled:opacity-60"
              style={{
                backgroundColor: '#F59E0B',
                color: '#0B1120',
                boxShadow: saving ? 'none' : '0 0 20px rgba(245,158,11,0.4)',
              }}>
              <Calendar className="w-4 h-4" />
              {saving ? 'Scheduling…' : 'Schedule & Set Lineup'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}