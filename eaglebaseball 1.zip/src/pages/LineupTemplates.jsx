import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Plus, Star, MoreVertical, Pencil, Copy, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import LineupTemplateEditor from '@/components/game/LineupTemplateEditor';

export default function LineupTemplates() {
  const { id: teamId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [templates, setTemplates] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingTemplate, setEditingTemplate] = useState(null); // null=closed, 'new'=new, template obj=edit
  const [menuOpen, setMenuOpen] = useState(null); // template id with open menu
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [selectedTemplateId, setSelectedTemplateId] = useState(null);
  const [starConfirm, setStarConfirm] = useState(null); // template to confirm starring

  const load = async () => {
    const [tmpl, plrs] = await Promise.all([
      base44.entities.LineupTemplate.filter({ team_id: teamId }),
      base44.entities.Player.filter({ team_id: teamId }),
    ]);
    const sorted = tmpl.sort((a, b) => (b.is_default ? 1 : 0) - (a.is_default ? 1 : 0));
    setTemplates(sorted);
    setPlayers(plrs);
    // Default select: last used or first (starred)
    const defaultTemplate = sorted.find(t => t.is_default) || sorted[0];
    if (defaultTemplate) setSelectedTemplateId(defaultTemplate.id);
    setLoading(false);
  };

  useEffect(() => { load(); }, [teamId]);

  const handleSave = async (templateData) => {
    // If setting as default, clear default from others
    if (templateData.is_default) {
      await Promise.all(
        templates
          .filter(t => t.is_default && t.id !== templateData.id)
          .map(t => base44.entities.LineupTemplate.update(t.id, { is_default: false }))
      );
    }

    if (templateData.id) {
      await base44.entities.LineupTemplate.update(templateData.id, templateData);
      toast.success('Lineup saved');
    } else {
      await base44.entities.LineupTemplate.create({ ...templateData, team_id: teamId });
      toast.success('Lineup created');
    }
    setEditingTemplate(null);
    load();
  };

  const handleDuplicate = async (template) => {
    setMenuOpen(null);
    await base44.entities.LineupTemplate.create({
      team_id: teamId,
      name: template.name + ' (Copy)',
      batting_order: template.batting_order || [],
      is_default: false,
    });
    toast.success('Lineup duplicated');
    load();
  };

  const handleSetDefault = async (template) => {
    setMenuOpen(null);
    const currentDefault = templates.find(t => t.is_default);
    if (currentDefault && currentDefault.id !== template.id) {
      setStarConfirm(template);
    } else {
      await Promise.all([
        ...templates.filter(t => t.is_default && t.id !== template.id)
          .map(t => base44.entities.LineupTemplate.update(t.id, { is_default: false })),
        base44.entities.LineupTemplate.update(template.id, { is_default: true }),
      ]);
      toast.success(`"${template.name}" set as default`);
      load();
    }
  };

  const confirmSetDefault = async () => {
    if (!starConfirm) return;
    await Promise.all([
      ...templates.filter(t => t.is_default && t.id !== starConfirm.id)
        .map(t => base44.entities.LineupTemplate.update(t.id, { is_default: false })),
      base44.entities.LineupTemplate.update(starConfirm.id, { is_default: true }),
    ]);
    toast.success(`"${starConfirm.name}" set as default`);
    setStarConfirm(null);
    load();
  };

  const handleDelete = async (template) => {
    setDeleteConfirm(null);
    await base44.entities.LineupTemplate.delete(template.id);
    toast.success('Lineup deleted');
    load();
  };

  if (loading) return <div className="p-6 text-center text-muted-foreground">Loading...</div>;

  if (editingTemplate !== null) {
    return (
      <LineupTemplateEditor
        template={editingTemplate === 'new' ? null : editingTemplate}
        players={players}
        onSave={handleSave}
        onClose={() => setEditingTemplate(null)}
      />
    );
  }

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-muted transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-2xl font-bold">Lineups</h1>
          <p className="text-sm text-muted-foreground">Save batting orders to reuse across games</p>
        </div>
      </div>

      {templates.length === 0 ? (
        <div className="text-center py-12 space-y-4">
          <div className="text-4xl">📋</div>
          <div className="text-muted-foreground">
            <p className="font-medium">No lineups saved yet</p>
            <p className="text-sm mt-1">Create your first lineup template</p>
          </div>
          <Button className="gap-2 mx-auto" onClick={() => setEditingTemplate('new')}>
            <Plus className="w-4 h-4" /> Create Lineup
          </Button>
        </div>
      ) : (
        <>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {templates.map(t => (
              <button
                key={t.id}
                onClick={() => setSelectedTemplateId(t.id)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 flex-shrink-0 ${
                  selectedTemplateId === t.id
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted hover:bg-secondary text-muted-foreground'
                }`}
              >
                {t.is_default && <Star className="w-3.5 h-3.5 fill-current" />}
                {t.name}
              </button>
            ))}
          </div>

          <Button className="w-full gap-2" onClick={() => setEditingTemplate('new')}>
            <Plus className="w-4 h-4" /> New Lineup
          </Button>
        </>
      )}

      {templates.length > 0 && (
        <div className="space-y-3">
          {templates.map(template => (
            <div key={template.id} className={`bg-card border rounded-xl p-4 flex items-center gap-3 cursor-pointer transition-colors ${
              selectedTemplateId === template.id ? 'border-primary bg-primary/5' : 'border-border'
            }`} onClick={() => setEditingTemplate(template)}>
              {template.is_default && <Star className="w-4 h-4 text-accent flex-shrink-0 fill-current" />}
              <div className="flex-1 min-w-0">
                <div className="font-semibold flex items-center gap-2">
                  {template.name}
                  {template.is_default && <span className="text-xs text-accent font-normal">Default</span>}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {(template.batting_order || []).length} players
                  {template.last_used ? ` • Last used: ${new Date(template.last_used).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}` : ' • Never used'}
                </div>
              </div>
              <div className="relative" onClick={e => e.stopPropagation()}>
                <button
                  onClick={() => setMenuOpen(menuOpen === template.id ? null : template.id)}
                  className="p-1.5 rounded-lg hover:bg-muted touch-manipulation"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>
                {menuOpen === template.id && (
                  <div className="absolute right-0 top-8 z-20 bg-popover border border-border rounded-xl shadow-xl w-44 py-1 text-sm">
                    {!template.is_default && (
                      <button className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted text-left"
                        onClick={(e) => { e.stopPropagation(); handleSetDefault(template); }}>
                        <Star className="w-4 h-4" /> Set as Default
                      </button>
                    )}
                    <button className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted text-left"
                      onClick={(e) => { e.stopPropagation(); handleDuplicate(template); }}>
                      <Copy className="w-4 h-4" /> Duplicate
                    </button>
                    <button className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted text-left text-destructive"
                      onClick={(e) => { e.stopPropagation(); setMenuOpen(null); setDeleteConfirm(template); }}>
                      <Trash2 className="w-4 h-4" /> Delete
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Click-away for menus */}
      {menuOpen && (
        <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(null)} />
      )}

      {/* Delete confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-6">
          <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-sm space-y-4">
            <h3 className="font-semibold">Delete "{deleteConfirm.name}"?</h3>
            <p className="text-sm text-muted-foreground">This cannot be undone.</p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setDeleteConfirm(null)}>Cancel</Button>
              <Button variant="destructive" className="flex-1" onClick={() => handleDelete(deleteConfirm)}>Delete</Button>
            </div>
          </div>
        </div>
      )}

      {/* Star/Default confirmation */}
      {starConfirm && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-6">
          <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-sm space-y-4">
            <h3 className="font-semibold">Update default lineup?</h3>
            <p className="text-sm text-muted-foreground">Set "{starConfirm.name}" as your default lineup? This will replace the current default.</p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setStarConfirm(null)}>Cancel</Button>
              <Button className="flex-1" onClick={confirmSetDefault}>Update</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}