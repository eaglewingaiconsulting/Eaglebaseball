import { useState } from 'react';
import { useTheme } from '@/lib/ThemeContext';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Trash2, LogOut, AlertTriangle, Sun, Moon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function Settings() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { theme, setTheme } = useTheme();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);

  const handleLogout = () => {
    base44.auth.logout('/');
  };

  const handleDeleteAccount = async () => {
    if (confirmText !== 'DELETE') {
      toast.error('Please type DELETE to confirm');
      return;
    }
    setDeleting(true);
    try {
      await base44.auth.updateMe({ is_deleted: true, email: `deleted_${Date.now()}@deleted.invalid` });
      toast.success('Account deleted. Signing you out...');
      setTimeout(() => base44.auth.logout('/'), 1500);
    } catch {
      toast.error('Failed to delete account. Please contact support.');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6 pb-24 lg:pb-6">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-muted transition-colors select-none">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-2xl font-bold">Settings</h1>
          <p className="text-sm text-muted-foreground">Manage your account</p>
        </div>
      </div>

      {/* Account Info */}
      <div className="bg-card border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">Account</h2>
        <div className="text-sm">
          <span className="text-muted-foreground">Email: </span>
          <span className="font-medium">{user?.email}</span>
        </div>
        <div className="text-sm">
          <span className="text-muted-foreground">Name: </span>
          <span className="font-medium">{user?.full_name || '—'}</span>
        </div>
        <div className="text-sm">
          <span className="text-muted-foreground">Role: </span>
          <span className="font-medium capitalize">{user?.role || 'user'}</span>
        </div>
      </div>

      {/* Appearance */}
      <div className="bg-card border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">Appearance</h2>
        <p className="text-sm text-muted-foreground">Choose your preferred color theme.</p>
        <div className="flex gap-3">
          <button
            onClick={() => setTheme('dark')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-medium transition-colors select-none ${
              theme === 'dark'
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-background border-border hover:bg-muted'
            }`}
          >
            <Moon className="w-4 h-4" /> Dark
          </button>
          <button
            onClick={() => setTheme('light')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-medium transition-colors select-none ${
              theme === 'light'
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-background border-border hover:bg-muted'
            }`}
          >
            <Sun className="w-4 h-4" /> Light
          </button>
        </div>
      </div>

      {/* Sign Out */}
      <div className="bg-card border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">Session</h2>
        <p className="text-sm text-muted-foreground">Sign out of your account on this device.</p>
        <Button variant="outline" className="gap-2 select-none" onClick={handleLogout}>
          <LogOut className="w-4 h-4" /> Sign Out
        </Button>
      </div>

      {/* Delete Account */}
      <div className="bg-card border border-destructive/30 rounded-xl p-5 space-y-3">
        <h2 className="font-semibold text-destructive flex items-center gap-2">
          <Trash2 className="w-4 h-4" /> Delete Account
        </h2>
        <p className="text-sm text-muted-foreground">
          Permanently delete your account and all associated data. This action cannot be undone.
        </p>
        {!showDeleteConfirm ? (
          <Button
            variant="outline"
            className="gap-2 border-destructive/50 text-destructive hover:bg-destructive/10 select-none"
            onClick={() => setShowDeleteConfirm(true)}
          >
            <Trash2 className="w-4 h-4" /> Delete My Account
          </Button>
        ) : (
          <div className="space-y-4 p-4 bg-destructive/5 border border-destructive/20 rounded-lg">
            <div className="flex items-start gap-2 text-sm text-destructive">
              <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>This will permanently delete all your data including teams, players, and game history.</span>
            </div>
            <div className="space-y-1.5">
              <Label>Type <strong>DELETE</strong> to confirm</Label>
              <Input
                value={confirmText}
                onChange={e => setConfirmText(e.target.value)}
                placeholder="DELETE"
                className="border-destructive/40 focus-visible:ring-destructive"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="select-none"
                onClick={() => { setShowDeleteConfirm(false); setConfirmText(''); }}
              >
                Cancel
              </Button>
              <Button
                size="sm"
                variant="destructive"
                disabled={deleting || confirmText !== 'DELETE'}
                className="gap-2 select-none"
                onClick={handleDeleteAccount}
              >
                <Trash2 className="w-4 h-4" />
                {deleting ? 'Deleting...' : 'Permanently Delete'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}