import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Users, Calendar, Trophy, Trash2, Shield, BarChart3, RefreshCw, FlaskConical, Loader2, SwitchCamera, UserCog, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useRoleSwitcher, ROLES, isMasterAccount } from '@/lib/RoleSwitcherContext';

export default function AdminPanel() {
  const { user } = useAuth();
  const roleSwitcher = useRoleSwitcher();
  const activeRole = roleSwitcher?.activeRole;
  const setActiveRole = roleSwitcher?.setActiveRoleId;
  const isMaster = isMasterAccount(user?.email);
  const navigate = useNavigate();
  const [tab, setTab] = useState('overview');

  // Set default tab to 'roles' for master account once user is known
  useEffect(() => {
    if (isMasterAccount(user?.email)) setTab('roles');
  }, [user?.email]);
  const [teams, setTeams] = useState([]);
  const [games, setGames] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [enhancingLogos, setEnhancingLogos] = useState(false);
  const [enhanceResult, setEnhanceResult] = useState(null);
  const [allUsers, setAllUsers] = useState([]);
  const [savingRole, setSavingRole] = useState({});

  useEffect(() => {
    if (user?.role !== 'admin') { navigate('/'); return; }
    loadData();
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    const [t, g, p, u] = await Promise.all([
      base44.entities.Team.list('-created_date', 100),
      base44.entities.Game.list('-scheduled_date', 100),
      base44.entities.Player.list('-created_date', 200),
      base44.entities.User.list('-created_date', 100),
    ]);
    setTeams(t);
    setGames(g);
    setPlayers(p);
    setAllUsers(u);
    setLoading(false);
  };

  const saveUserRole = async (userId, newRole, prevRole) => {
    setSavingRole(s => ({ ...s, [userId]: true }));
    try {
      await base44.entities.User.update(userId, { role: newRole });
      setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
      toast.success('Role updated');
    } catch {
      setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, role: prevRole } : u));
      toast.error('Failed to save role');
    } finally {
      setSavingRole(s => ({ ...s, [userId]: false }));
    }
  };

  const deleteTeam = async (teamId, teamName) => {
    if (!confirm(`Delete team "${teamName}"? This cannot be undone.`)) return;
    await base44.entities.Team.delete(teamId);
    setTeams(prev => prev.filter(t => t.id !== teamId));
    toast.success('Team deleted');
  };

  const deleteGame = async (gameId) => {
    if (!confirm('Delete this game?')) return;
    await base44.entities.Game.delete(gameId);
    setGames(prev => prev.filter(g => g.id !== gameId));
    toast.success('Game deleted');
  };

  const enhanceAllLogos = async () => {
    if (!confirm('This will AI-enhance all team and org logos. It may take a few minutes. Continue?')) return;
    setEnhancingLogos(true);
    setEnhanceResult(null);
    const res = await base44.functions.invoke('enhanceLogos', {});
    setEnhanceResult(res.data);
    setEnhancingLogos(false);
    loadData();
    toast.success(`Enhanced ${res.data?.enhanced || 0} logos`);
  };

  const updateGameStatus = async (gameId, status) => {
    await base44.entities.Game.update(gameId, { status });
    setGames(prev => prev.map(g => g.id === gameId ? { ...g, status } : g));
    toast.success('Status updated');
  };

  if (user?.role !== 'admin') return null;

  const liveGames = games.filter(g => g.status === 'in_progress');
  const completedGames = games.filter(g => g.status === 'completed');

  const tabs = [
    ...(isMaster ? [{ id: 'roles', label: 'Role Switcher', icon: SwitchCamera }] : []),
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'users', label: 'Users', icon: UserCog },
    { id: 'teams', label: 'Teams', icon: Users },
    { id: 'games', label: 'Games', icon: Calendar },
    { id: 'demo', label: 'Demo', icon: FlaskConical },
  ];

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
    <div className="p-4 max-w-7xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(245,158,11,0.15)' }}>
            <Shield className="w-5 h-5" style={{ color: '#F59E0B' }} />
          </div>
          <div>
            <h1 className="font-bebas tracking-widest text-white" style={{ fontSize: 32, letterSpacing: '0.08em' }}>Admin Panel</h1>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.45)' }}>Full platform management</p>
          </div>
        </div>
        <button onClick={loadData} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium select-none touch-manipulation transition-colors"
          style={{ border: '1px solid rgba(255,255,255,0.12)', color: 'rgba(255,255,255,0.7)', backgroundColor: 'rgba(255,255,255,0.04)' }}>
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors select-none"
            style={{
              backgroundColor: tab === t.id ? '#F59E0B' : 'rgba(255,255,255,0.05)',
              color: tab === t.id ? '#0B1120' : 'rgba(255,255,255,0.65)',
              border: tab === t.id ? 'none' : '1px solid rgba(255,255,255,0.1)',
              fontWeight: tab === t.id ? 700 : 400,
            }}>
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'roles' && isMaster && (
        <div className="max-w-sm space-y-3">
          <div className="rounded-xl p-5 space-y-4" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div className="flex items-center gap-3 pb-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(245,158,11,0.12)' }}>
                <SwitchCamera className="w-4 h-4" style={{ color: '#F59E0B' }} />
              </div>
              <div>
                <h2 className="font-semibold text-white">Role Switcher</h2>
                <p className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>Testing only — visible only to master account</p>
              </div>
            </div>
            <div className="space-y-1.5">
              {ROLES.map(role => (
                <button
                  key={role.id}
                  onClick={() => {
                    if (role.navigateTo) { window.location.replace(role.navigateTo); return; }
                    setActiveRole(role.id); window.location.replace('/');
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-colors select-none touch-manipulation"
                  style={{
                    backgroundColor: activeRole?.id === role.id ? 'rgba(245,158,11,0.12)' : 'rgba(255,255,255,0.03)',
                    border: activeRole?.id === role.id ? '1px solid rgba(245,158,11,0.4)' : '1px solid transparent',
                    color: activeRole?.id === role.id ? '#F59E0B' : 'rgba(255,255,255,0.75)',
                    fontWeight: activeRole?.id === role.id ? 600 : 400,
                  }}
                >
                  <span className="text-xl leading-none w-7 text-center">{role.icon}</span>
                  <div className="flex-1 text-left">
                    <div className="font-medium">{role.label}</div>
                    <div className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>{role.description}</div>
                  </div>
                  {activeRole?.id === role.id && (
                    <span className="text-xs font-bold" style={{ color: '#F59E0B' }}>Active ✓</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'overview' && (
        <div className="space-y-6">
          {/* Enhance All Logos */}
          <div className="rounded-xl p-4 flex items-center justify-between gap-4" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div>
              <div className="font-semibold text-white text-sm flex items-center gap-2"><Sparkles className="w-4 h-4" style={{ color: '#F59E0B' }} /> AI Logo Enhancement</div>
              <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>
                {enhanceResult ? `Last run: ${enhanceResult.enhanced} enhanced, ${enhanceResult.failed} failed` : 'Crop, sharpen & polish all team and org logos using AI'}
              </div>
            </div>
            <Button size="sm" onClick={enhanceAllLogos} disabled={enhancingLogos}
              className="gap-1.5 bg-amber-500 hover:bg-amber-400 text-black font-bold flex-shrink-0">
              {enhancingLogos ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              {enhancingLogos ? 'Enhancing…' : 'Enhance All'}
            </Button>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { label: 'Total Teams', value: teams.length, icon: Users },
              { label: 'Total Players', value: players.length, icon: Trophy },
              { label: 'Live Games', value: liveGames.length, icon: Calendar },
              { label: 'Games Played', value: completedGames.length, icon: BarChart3 },
            ].map(stat => (
              <div key={stat.label} className="flex flex-col items-center justify-center py-4 px-2" style={{
                backgroundColor: '#0F1729',
                border: '2px solid #F59E0B',
                borderRadius: 8,
                boxShadow: '0 0 14px rgba(245,158,11,0.2)',
              }}>
                <stat.icon style={{ width: 18, height: 18, color: '#F59E0B', marginBottom: 6 }} />
                <div className="font-bebas" style={{ fontSize: 36, color: '#F59E0B', lineHeight: 1, textShadow: '0 0 10px rgba(245,158,11,0.6)' }}>
                  {loading ? '—' : stat.value}
                </div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 4 }}>{stat.label}</div>
              </div>
            ))}
          </div>

          {liveGames.length > 0 && (
            <div>
              <h2 className="font-bebas tracking-widest mb-3 flex items-center gap-2" style={{ fontSize: 22, color: '#fff', letterSpacing: '0.08em' }}>
                <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 animate-pulse" /> Live Games
              </h2>
              <div className="space-y-2">
                {liveGames.map(g => (
                  <div key={g.id} className="flex items-center justify-between p-4 rounded-xl" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
                    <div>
                      <div className="font-semibold text-white">{g.away_team_name} @ {g.home_team_name}</div>
                      <div className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>Inn. {g.inning} • Score: {g.away_score}-{g.home_score}</div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => navigate(`/games/${g.id}/live`)}>View</Button>
                      <Button size="sm" variant="outline" onClick={() => updateGameStatus(g.id, 'completed')}>End Game</Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {tab === 'users' && (
        <div className="rounded-xl overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: 'rgba(255,255,255,0.04)', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                <th className="text-left px-4 py-3 font-semibold text-white">User</th>
                <th className="text-left px-4 py-3 font-semibold text-white">Email</th>
                <th className="text-right px-4 py-3 font-semibold text-white">Role</th>
              </tr>
            </thead>
            <tbody>
              {allUsers.map(u => (
                <tr key={u.id} style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }} className="hover:bg-white/5 transition-colors">
                  <td className="px-4 py-3 font-medium text-white">{u.full_name || '—'}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'rgba(255,255,255,0.45)' }}>{u.email}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {savingRole[u.id] && <Loader2 className="w-3.5 h-3.5 animate-spin" style={{ color: '#F59E0B' }} />}
                      <select
                        className="text-sm rounded-lg px-2 py-1.5"
                        style={{ border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#0B1120', color: '#fff' }}
                        value={u.role || 'user'}
                        onChange={e => saveUserRole(u.id, e.target.value, u.role)}
                        disabled={savingRole[u.id]}
                      >
                        {['admin', 'coach', 'parent', 'fan', 'game_manager', 'user'].map(r => (
                          <option key={r} value={r}>{r}</option>
                        ))}
                      </select>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'teams' && (
        <div className="rounded-xl overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: 'rgba(255,255,255,0.04)', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                <th className="text-left px-4 py-3 font-semibold text-white">Team</th>
                <th className="text-left px-4 py-3 font-semibold text-white hidden md:table-cell">Coach</th>
                <th className="text-left px-4 py-3 font-semibold text-white hidden lg:table-cell">League/Season</th>
                <th className="text-center px-3 py-3 font-semibold text-white">Record</th>
                <th className="text-right px-4 py-3 font-semibold text-white">Actions</th>
              </tr>
            </thead>
            <tbody>
              {teams.map(team => (
                <tr key={team.id} style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }} className="hover:bg-white/5 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded flex items-center justify-center text-white text-xs font-bold"
                        style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>
                        {team.name.slice(0,2).toUpperCase()}
                      </div>
                      <span className="font-medium text-white">{team.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs hidden md:table-cell" style={{ color: 'rgba(255,255,255,0.45)' }}>{team.coach_email}</td>
                  <td className="px-4 py-3 text-xs hidden lg:table-cell" style={{ color: 'rgba(255,255,255,0.45)' }}>{team.league} {team.season}</td>
                  <td className="px-3 py-3 text-center text-white">{team.wins || 0}W-{team.losses || 0}L</td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex gap-1.5 justify-end">
                      <Button size="sm" variant="outline" onClick={() => navigate(`/teams/${team.id}`)}>View</Button>
                      <Button size="sm" variant="outline" className="text-destructive hover:text-destructive" onClick={() => deleteTeam(team.id, team.name)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'games' && (
        <div className="rounded-xl overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: 'rgba(255,255,255,0.04)', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                <th className="text-left px-4 py-3 font-semibold text-white">Game</th>
                <th className="text-left px-4 py-3 font-semibold text-white hidden md:table-cell">Date</th>
                <th className="text-center px-3 py-3 font-semibold text-white">Score</th>
                <th className="text-center px-3 py-3 font-semibold text-white">Status</th>
                <th className="text-right px-4 py-3 font-semibold text-white">Actions</th>
              </tr>
            </thead>
            <tbody>
              {games.map(game => (
                <tr key={game.id} style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }} className="hover:bg-white/5 transition-colors">
                  <td className="px-4 py-3 font-medium text-white">{game.away_team_name} @ {game.home_team_name}</td>
                  <td className="px-4 py-3 hidden md:table-cell" style={{ color: 'rgba(255,255,255,0.45)' }}>{game.scheduled_date}</td>
                  <td className="px-3 py-3 text-center font-bold text-white">{game.away_score ?? 0}-{game.home_score ?? 0}</td>
                  <td className="px-3 py-3 text-center">
                    <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                      style={{
                        backgroundColor: game.status === 'in_progress' ? 'rgba(74,222,128,0.15)' : 'rgba(255,255,255,0.08)',
                        color: game.status === 'in_progress' ? '#4ADE80' : 'rgba(255,255,255,0.6)',
                      }}>
                      {game.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex gap-1.5 justify-end">
                      <Button size="sm" variant="outline" onClick={() => navigate(`/games/${game.id}`)}>View</Button>
                      <Button size="sm" variant="outline" className="text-destructive" onClick={() => deleteGame(game.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'demo' && (
        <div className="max-w-lg">
          <div className="rounded-xl p-8 flex flex-col items-center text-center gap-5" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl" style={{ backgroundColor: 'rgba(245,158,11,0.12)' }}>
              🎭
            </div>
            <div>
              <h2 className="font-bebas tracking-widest text-white mb-1" style={{ fontSize: 28 }}>Demo Mode</h2>
              <p className="text-sm" style={{ color: 'rgba(255,255,255,0.45)' }}>Experience the app as a Coach, Parent, Fan, or Org Owner using live sample data.</p>
            </div>
            <Button
              className="gap-2 bg-amber-500 hover:bg-amber-400 text-black font-bold px-8 py-5 text-base rounded-xl"
              onClick={() => navigate('/demo/role-select')}
            >
              <FlaskConical className="w-5 h-5" /> Launch Demo
            </Button>
          </div>
        </div>
      )}
    </div>
    </div>
  );
}