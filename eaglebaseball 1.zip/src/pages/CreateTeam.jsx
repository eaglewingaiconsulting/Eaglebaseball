import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { ArrowLeft, Upload, ChevronDown } from 'lucide-react';
import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

function generateShareCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

// Dark-themed input
function DarkInput({ value, onChange, placeholder, type = 'text', required, maxLength, className = '' }) {
  return (
    <input
      type={type}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      required={required}
      maxLength={maxLength}
      className={`w-full px-3 py-2.5 rounded-lg text-sm text-white placeholder-gray-500 outline-none focus:ring-2 focus:ring-amber-500 transition-all ${className}`}
      style={{ backgroundColor: '#0B1120', border: '1px solid rgba(255,255,255,0.12)' }}
    />
  );
}

// Dark-themed select wrapper
function DarkSelect({ value, onValueChange, children, placeholder }) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger
        className="w-full text-sm text-white outline-none focus:ring-2 focus:ring-amber-500"
        style={{ backgroundColor: '#0B1120', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8, height: 42, color: '#fff' }}
      >
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.12)', color: '#fff' }}>
        {children}
      </SelectContent>
    </Select>
  );
}

function SectionCard({ title, subtitle, children }) {
  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}
    >
      {/* Gold left-border header */}
      <div className="flex items-stretch">
        <div className="w-1 flex-shrink-0" style={{ backgroundColor: '#F59E0B' }} />
        <div className="flex-1 px-6 pt-5 pb-4">
          <h2 className="font-bebas tracking-widest text-white" style={{ fontSize: 26, letterSpacing: '0.08em' }}>{title}</h2>
          {subtitle && <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>{subtitle}</p>}
        </div>
      </div>
      <div className="px-6 pb-6 space-y-4">
        {children}
      </div>
    </div>
  );
}

function CollapsibleSectionCard({ title, subtitle, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}
    >
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-stretch text-left select-none touch-manipulation"
      >
        <div className="w-1 flex-shrink-0" style={{ backgroundColor: '#F59E0B' }} />
        <div className="flex-1 px-6 pt-5 pb-4">
          <h2 className="font-bebas tracking-widest text-white" style={{ fontSize: 26, letterSpacing: '0.08em' }}>{title}</h2>
          {subtitle && <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>{subtitle}</p>}
        </div>
        <div className="flex items-center pr-5">
          <ChevronDown
            className="w-5 h-5 transition-transform duration-200"
            style={{ color: 'rgba(255,255,255,0.4)', transform: open ? 'rotate(180deg)' : 'rotate(0deg)' }}
          />
        </div>
      </button>
      {open && (
        <div className="px-6 pb-6 space-y-4">
          {children}
        </div>
      )}
    </div>
  );
}

export default function CreateTeam() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [team, setTeam] = useState({
    name: '', city: '', season: new Date().getFullYear().toString(),
    primary_color: '#1e3a8a', secondary_color: '#f59e0b',
    logo_url: '',
    age_group: '13U',
    admin_emails: ['', '', '', '']
  });
  const handleLogoUpload = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setTeam(t => ({ ...t, logo_url: file_url }));
      toast.success('Logo uploaded! Analyzing colors & enhancing…');
      setUploading(false);
      setEnhancing(true);

      const [colorResult, enhancedResult] = await Promise.all([
        base44.integrations.Core.InvokeLLM({
          prompt: `Look at this sports team logo. Identify the two most prominent non-white, non-black colors.
Return primary_color (most dominant color, e.g. navy, red, green) and secondary_color (accent, e.g. gold, orange).
Return valid hex codes only. Do NOT return #000000 or #ffffff unless purely monochrome.`,
          file_urls: [file_url],
          model: 'claude_sonnet_4_6',
          response_json_schema: {
            type: 'object',
            properties: {
              primary_color: { type: 'string' },
              secondary_color: { type: 'string' },
            },
          },
        }),
        base44.integrations.Core.GenerateImage({
          prompt: `Recreate this sports team logo as a clean, sharp, professional vector-style emblem. Preserve all original colors, text, mascot, and design elements exactly. Make it crisp, high-resolution, with clean edges and vivid colors. Transparent-friendly white or transparent background.`,
          existing_image_urls: [file_url],
        }),
      ]);

      const normalizeHex = (val) => {
        if (!val) return null;
        const hex = val.trim().startsWith('#') ? val.trim() : `#${val.trim()}`;
        return /^#[0-9a-fA-F]{6}$/.test(hex) ? hex.toLowerCase() : null;
      };
      const primary = normalizeHex(colorResult?.primary_color);
      const secondary = normalizeHex(colorResult?.secondary_color);

      const { file_url: enhanced_url } = await base44.integrations.Core.UploadFile({ file: enhancedResult.url });
      setTeam(t => ({
        ...t,
        logo_url: enhanced_url,
        ...(primary && { primary_color: primary }),
        ...(secondary && { secondary_color: secondary }),
      }));
      toast.success(primary ? 'Logo enhanced & colors detected!' : 'Logo enhanced!');
    } catch {
      toast.error('Upload failed — try again');
    } finally {
      setUploading(false);
      setEnhancing(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!team.name.trim()) return toast.error('Team name is required');
    setSaving(true);
    try {
      let orgId = null;
      const orgs = await base44.entities.Organization.filter({ owner_email: user.email });
      if (orgs[0]) orgId = orgs[0].id;

      const created = await base44.entities.Team.create({
        ...team,
        coach_email: user.email,
        admin_emails: team.admin_emails.filter(e => e.trim()),
        share_code: generateShareCode(),
        wins: 0, losses: 0, ties: 0,
        ...(orgId && { org_id: orgId }),
      });
      toast.success('Team created!');
      navigate(`/teams/${created.id}`);
    } catch {
      toast.error('Failed to create team');
    } finally {
      setSaving(false);
    }
  };

  const isProcessing = uploading || enhancing;

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <div>
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-1.5 text-sm mb-4 select-none touch-manipulation transition-opacity hover:opacity-70"
            style={{ color: 'rgba(255,255,255,0.55)' }}
          >
            <ArrowLeft className="w-4 h-4" /> back
          </button>
          <h1 className="font-bebas tracking-widest text-white" style={{ fontSize: 44, letterSpacing: '0.08em', lineHeight: 1 }}>
            Create Team
          </h1>
          <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.45)' }}>You'll become the head coach & admin</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Team Information */}
          <SectionCard title="Team Information">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>Team Name *</label>
                <DarkInput
                  value={team.name}
                  onChange={e => setTeam(t => ({...t, name: e.target.value}))}
                  placeholder="Eagles"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>Age Group *</label>
                <DarkSelect value={team.age_group} onValueChange={v => setTeam(t => ({...t, age_group: v}))}>
                  {['6U','8U','10U','12U','13U','14U','15U','16U','18U'].map(ag => (
                    <SelectItem key={ag} value={ag} style={{ color: '#fff' }}>{ag}</SelectItem>
                  ))}
                </DarkSelect>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>City</label>
                <DarkInput
                  value={team.city}
                  onChange={e => setTeam(t => ({...t, city: e.target.value}))}
                  placeholder="Springfield"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>Season</label>
                <DarkInput
                  value={team.season}
                  onChange={e => setTeam(t => ({...t, season: e.target.value}))}
                  placeholder="2026"
                />
              </div>
            </div>

            {/* Logo */}
            <div className="space-y-2">
              <label className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>Logo</label>
              <div className="flex items-center gap-4">
                {/* Logo preview box */}
                <div
                  className="w-20 h-20 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden"
                  style={{ border: '2px dashed rgba(255,255,255,0.2)', backgroundColor: 'rgba(255,255,255,0.04)' }}
                >
                  {team.logo_url ? (
                    <img src={team.logo_url} alt="Logo" className="w-full h-full object-contain" />
                  ) : (
                    <span className="font-bebas text-3xl" style={{ color: 'rgba(255,255,255,0.2)' }}>??</span>
                  )}
                </div>
                {/* Upload button + hint */}
                <div className="space-y-1.5">
                  <label className="cursor-pointer select-none">
                    <div
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold transition-opacity hover:opacity-90"
                      style={{ backgroundColor: '#fff', color: '#0B1120' }}
                    >
                      {isProcessing ? (
                        <span className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4" />
                      )}
                      {uploading ? 'Uploading…' : enhancing ? 'Enhancing…' : 'Upload Logo'}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      disabled={isProcessing}
                      onChange={e => { handleLogoUpload(e.target.files?.[0]); e.target.value = ''; }}
                    />
                  </label>
                  <p className="text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>PNG, JPG, SVG — max 5 MB</p>
                </div>
              </div>
            </div>

            {/* Colors */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>Primary Color</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={team.primary_color}
                    onChange={e => setTeam(t => ({...t, primary_color: e.target.value}))}
                    className="w-10 h-10 rounded-lg cursor-pointer flex-shrink-0"
                    style={{ border: '1px solid rgba(255,255,255,0.15)', backgroundColor: 'transparent' }}
                  />
                  <DarkInput
                    value={team.primary_color}
                    onChange={e => setTeam(t => ({...t, primary_color: e.target.value}))}
                    maxLength={7}
                    className="font-mono"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>Secondary Color</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={team.secondary_color}
                    onChange={e => setTeam(t => ({...t, secondary_color: e.target.value}))}
                    className="w-10 h-10 rounded-lg cursor-pointer flex-shrink-0"
                    style={{ border: '1px solid rgba(255,255,255,0.15)', backgroundColor: 'transparent' }}
                  />
                  <DarkInput
                    value={team.secondary_color}
                    onChange={e => setTeam(t => ({...t, secondary_color: e.target.value}))}
                    maxLength={7}
                    className="font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Preview swatch */}
            <div>
              <label className="text-xs font-medium block mb-2" style={{ color: 'rgba(255,255,255,0.6)' }}>Preview</label>
              <div className="flex items-center gap-3 p-3 rounded-lg" style={{ backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white text-xs font-bold overflow-hidden flex-shrink-0"
                  style={{ backgroundColor: team.primary_color }}>
                  {team.logo_url
                    ? <img src={team.logo_url} alt="" className="w-full h-full object-contain" />
                    : (team.name ? team.name.slice(0,2).toUpperCase() : '??')}
                </div>
                <div>
                  <div className="text-sm font-semibold" style={{ color: team.primary_color }}>{team.name || 'Team Name'}</div>
                  <div className="text-xs" style={{ color: team.secondary_color }}>{team.age_group} · {team.season}</div>
                </div>
              </div>
            </div>
          </SectionCard>

          {/* Coaching Staff & Admin */}
          <CollapsibleSectionCard
            title="Coaching Staff & Admin"
            subtitle="Add up to 4 assistant coaches or admins — they'll have full team access"
          >
            <div className="grid grid-cols-2 gap-3">
              {team.admin_emails.map((email, i) => (
                <div key={i} className="space-y-1.5">
                  <label className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>Staff {i + 1}</label>
                  <DarkInput
                    type="email"
                    value={email}
                    onChange={e => setTeam(t => ({...t, admin_emails: t.admin_emails.map((em, idx) => idx === i ? e.target.value : em)}))}
                    placeholder="coach@example.com"
                  />
                </div>
              ))}
            </div>
          </CollapsibleSectionCard>

          {/* Footer actions */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="py-3 rounded-xl text-sm font-bold transition-opacity hover:opacity-80 select-none"
              style={{ border: '1px solid rgba(255,255,255,0.15)', color: 'rgba(255,255,255,0.7)', backgroundColor: 'transparent' }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="py-3 rounded-xl text-sm font-bold transition-opacity hover:opacity-90 select-none disabled:opacity-60"
              style={{ backgroundColor: '#F59E0B', color: '#0B1120' }}
            >
              {saving ? 'Creating...' : 'Create Team'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}