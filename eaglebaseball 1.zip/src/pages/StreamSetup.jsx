import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Camera, Video, StopCircle, Save, FlipHorizontal } from 'lucide-react';
import { toast } from 'sonner';

export default function StreamSetup() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [game, setGame] = useState(null);
  const [teams, setTeams] = useState({ home: null, away: null });
  const [streamUrls, setStreamUrls] = useState({ home: '', away: '' });
  const [streaming, setStreaming] = useState(false);
  const [saving, setSaving] = useState(false);
  const [facingMode, setFacingMode] = useState('environment'); // BUG #1: default to rear camera
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  useEffect(() => {
    base44.entities.Game.filter({ id }).then(async ([g]) => {
      if (!g) return;
      setGame(g);
      setStreamUrls({ home: g.home_stream_url || '', away: g.away_stream_url || '' });
      const [ht, at] = await Promise.all([
        g.home_team_id ? base44.entities.Team.filter({ id: g.home_team_id }) : Promise.resolve([]),
        g.away_team_id ? base44.entities.Team.filter({ id: g.away_team_id }) : Promise.resolve([]),
      ]);
      setTeams({ home: ht[0] || null, away: at[0] || null });
      // Auto-start rear camera on mount
      startCamera('environment');
    });
  }, [id]);

  const startCamera = async (facing = facingMode) => {
    // Stop existing stream first
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing },
        audio: true,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setStreaming(true);
      if (!streaming) toast.success('Camera started!');
    } catch (err) {
      toast.error('Could not access camera. Check permissions.');
    }
  };

  const flipCamera = async () => {
    const newFacing = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(newFacing);
    if (streaming) await startCamera(newFacing);
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
    setStreaming(false);
  };

  const saveStreamUrls = async () => {
    setSaving(true);
    try {
      await base44.entities.Game.update(id, {
        home_stream_url: streamUrls.home,
        away_stream_url: streamUrls.away,
      });
      toast.success('Stream URLs saved!');
    } catch {
      toast.error('Failed to save');
    } finally {
      setSaving(false);
    }
  };

  if (!game) return <div className="p-6 text-center text-muted-foreground">Loading...</div>;

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-muted">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-2xl font-bold">Stream Setup</h1>
          <p className="text-sm text-muted-foreground">{game.away_team_name} @ {game.home_team_name}</p>
        </div>
      </div>

      {/* Camera preview */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="font-semibold flex items-center gap-2"><Camera className="w-4 h-4" /> Camera Stream</h2>
          {!streaming ? (
            <Button onClick={() => startCamera()} size="sm" className="gap-1.5 bg-red-600 hover:bg-red-700">
              <Video className="w-4 h-4" /> Start Camera
            </Button>
          ) : (
            <Button onClick={stopCamera} variant="outline" size="sm" className="gap-1.5">
              <StopCircle className="w-4 h-4" /> Stop
            </Button>
          )}
        </div>

        {/* BUG #1: always render video element so it never collapses to 0 height */}
        <div className="relative bg-black" style={{ minHeight: 220 }}>
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full object-contain"
            style={{ display: streaming ? 'block' : 'none', minHeight: 220 }}
          />
          {!streaming && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white/40">
              <Camera className="w-12 h-12 mx-auto mb-2" />
              <p className="text-sm">Click "Start Camera" to preview your stream</p>
              <p className="text-xs mt-1">Use a service like YouTube Live, Twitch, or Streamyard to broadcast</p>
            </div>
          )}
          {/* Camera flip button — always visible when streaming */}
          {streaming && (
            <button
              onClick={flipCamera}
              className="absolute bottom-3 right-3 bg-black/60 hover:bg-black/80 text-white rounded-full p-2.5 transition-colors"
              title="Flip camera"
            >
              <FlipHorizontal className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Stream URLs */}
      <div className="bg-card border border-border rounded-xl p-5 space-y-4">
        <div>
          <h2 className="font-semibold">Embed Stream URLs</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Enter YouTube Live, Twitch, or other embeddable stream URLs for each team</p>
        </div>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>{teams.home?.name || 'Home Team'} Stream URL</Label>
            <Input
              value={streamUrls.home}
              onChange={e => setStreamUrls(s => ({...s, home: e.target.value}))}
              placeholder="https://www.youtube.com/embed/..."
            />
          </div>
          <div className="space-y-1.5">
            <Label>{teams.away?.name || 'Away Team'} Stream URL</Label>
            <Input
              value={streamUrls.away}
              onChange={e => setStreamUrls(s => ({...s, away: e.target.value}))}
              placeholder="https://www.youtube.com/embed/..."
            />
          </div>
        </div>
        <Button onClick={saveStreamUrls} disabled={saving} className="gap-2">
          <Save className="w-4 h-4" />
          {saving ? 'Saving...' : 'Save Stream URLs'}
        </Button>
      </div>

      {/* Instructions */}
      <div className="bg-card border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">📡 How to Stream Live</h2>
        <ol className="space-y-2 text-sm text-muted-foreground list-decimal list-inside">
          <li>Use a streaming app like <strong className="text-foreground">OBS Studio</strong>, <strong className="text-foreground">Streamyard</strong>, or your phone's camera app</li>
          <li>Connect to <strong className="text-foreground">YouTube Live</strong> or <strong className="text-foreground">Twitch</strong> as your broadcast destination</li>
          <li>Copy the embed URL (e.g. <code className="text-xs bg-muted px-1 py-0.5 rounded">youtube.com/embed/LIVE_ID</code>)</li>
          <li>Paste the embed URL above and save</li>
          <li>Fans viewing the public game page will see your live stream</li>
        </ol>
      </div>
    </div>
  );
}