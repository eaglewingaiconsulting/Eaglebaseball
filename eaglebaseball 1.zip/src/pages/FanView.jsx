import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Star, Calendar, MapPin, Trophy, ArrowLeft, Loader2, X } from 'lucide-react';
import PaymentQRDisplay from '@/components/payments/PaymentQRDisplay';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

const STATUS_COLORS = {
  scheduled: 'bg-blue-100 text-blue-700',
  in_progress: 'bg-green-100 text-green-700',
  completed: 'bg-gray-100 text-gray-700',
  postponed: 'bg-amber-100 text-amber-700',
  cancelled: 'bg-red-100 text-red-700',
};

export default function FanView() {
  const { code } = useParams(); // team share code
  const { user } = useAuth();
  const navigate = useNavigate();
  const [team, setTeam] = useState(null);
  const [games, setGames] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);

  useEffect(() => {
    base44.entities.Team.filter({ share_code: code }).then(async ([t]) => {
      if (!t) { setLoading(false); return; }
      setTeam(t);
      const [allGames, teamPlayers] = await Promise.all([
        base44.entities.Game.list('-scheduled_date', 20),
        base44.entities.Player.filter({ team_id: t.id })
      ]);
      setGames(allGames.filter(g => g.home_team_id === t.id || g.away_team_id === t.id));
      setPlayers(teamPlayers);
      if (user) setIsFollowing((t.fan_emails || []).includes(user.email));
      setLoading(false);
    });
  }, [code, user]);

  const followTeam = async () => {
    if (!user) { base44.auth.redirectToLogin(); return; }
    setJoining(true);
    const updated = await base44.entities.Team.update(team.id, {
      fan_emails: [...(team.fan_emails || []), user.email]
    });
    setTeam(updated);
    setIsFollowing(true);
    setJoining(false);
    toast.success(`You're now following ${team.name}!`);
  };

  const unfollowTeam = async () => {
    setJoining(true);
    const updated = await base44.entities.Team.update(team.id, {
      fan_emails: (team.fan_emails || []).filter(e => e !== user.email)
    });
    setTeam(updated);
    setIsFollowing(false);
    setJoining(false);
    toast.success('Unfollowed');
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  if (!team) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Team not found</div>;

  const upcomingGames = games.filter(g => g.status === 'scheduled' || g.status === 'in_progress');
  const recentGames = games.filter(g => g.status === 'completed' || g.status === 'final').slice(0, 5);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="h-32 w-full" style={{ backgroundColor: team.primary_color || '#1e3a8a' }} />
      <div className="max-w-4xl mx-auto px-4 -mt-12 pb-12 space-y-6">
        <div className="flex items-end justify-between">
          <div className="flex items-end gap-4">
            <div className="w-20 h-20 rounded-2xl border-4 border-background shadow-lg flex items-center justify-center text-white text-2xl font-bold"
              style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>
              {team.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="pb-2">
              <h1 className="text-2xl font-bold">{team.name}</h1>
              <p className="text-sm text-muted-foreground">{team.city} · {team.league}</p>
            </div>
          </div>
          <div className="pb-2">
            {isFollowing ? (
              <Button variant="outline" size="sm" className="gap-1.5" onClick={unfollowTeam} disabled={joining}>
                <X className="w-4 h-4" /> Unfollow
              </Button>
            ) : (
              <Button size="sm" className="gap-1.5" onClick={followTeam} disabled={joining}>
                {joining ? <Loader2 className="w-4 h-4 animate-spin" /> : <Star className="w-4 h-4" />}
                Follow Team
              </Button>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4 text-center">
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="text-2xl font-bold text-green-600">{team.wins || 0}</div>
            <div className="text-xs text-muted-foreground">Wins</div>
          </div>
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="text-2xl font-bold text-red-600">{team.losses || 0}</div>
            <div className="text-xs text-muted-foreground">Losses</div>
          </div>
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="text-2xl font-bold">{(team.fan_emails || []).length}</div>
            <div className="text-xs text-muted-foreground">Fans</div>
          </div>
        </div>

        {/* Upcoming Games */}
        {upcomingGames.length > 0 && (
          <div>
            <h2 className="font-semibold mb-3 flex items-center gap-2"><Calendar className="w-4 h-4" /> Upcoming Games</h2>
            <div className="space-y-3">
              {upcomingGames.map(game => (
                <Link key={game.id} to={`/games/${game.id}/public`}
                  className="block bg-card border border-border rounded-xl p-4 hover:border-primary/40 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{game.away_team_name} @ {game.home_team_name}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-3 mt-1">
                        <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{game.scheduled_date} {game.scheduled_time}</span>
                        {game.location && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{game.location}</span>}
                      </div>
                      {game.arrival_time && <div className="text-xs text-amber-600 mt-1">Arrive: {game.arrival_time}</div>}
                    </div>
                    <Badge className={STATUS_COLORS[game.status]}>{game.status.replace('_', ' ')}</Badge>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Roster */}
        {players.length > 0 && (
          <div>
            <h2 className="font-semibold mb-3">Roster</h2>
            <div className="grid sm:grid-cols-2 gap-2">
              {players.map(p => (
                <Link key={p.id} to={`/players/${p.id}`}
                  className="flex items-center gap-3 bg-card border border-border rounded-lg p-3 hover:border-primary/40 transition-colors">
                  <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center text-primary text-xs font-bold">
                    #{p.number}
                  </div>
                  <div>
                    <div className="text-sm font-medium">{p.name}</div>
                    <div className="text-xs text-muted-foreground">{p.position}</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Payment Options */}
        {(team.payment_qr_codes || []).length > 0 && (
          <div className="bg-card border border-border rounded-xl p-5">
            <PaymentQRDisplay qrCodes={team.payment_qr_codes} title="Pay Team Fees" />
          </div>
        )}

        {/* Recent Results */}
        {recentGames.length > 0 && (
          <div>
            <h2 className="font-semibold mb-3 flex items-center gap-2"><Trophy className="w-4 h-4" /> Recent Results</h2>
            <div className="space-y-2">
              {recentGames.map(game => (
                <Link key={game.id} to={`/games/${game.id}/public`}
                  className="flex items-center justify-between bg-card border border-border rounded-lg p-3 hover:border-primary/40 transition-colors">
                  <span className="text-sm">{game.away_team_name} @ {game.home_team_name}</span>
                  <span className="text-sm font-bold">{game.away_score} - {game.home_score}</span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}