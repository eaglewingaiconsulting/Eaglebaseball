import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Zap, Building2, Users, UserCircle, Star, ChevronRight, FlaskConical } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ROLES = [
  {
    icon: Building2,
    title: 'Org Owner',
    color: 'bg-blue-600',
    description: 'Create & manage your baseball organization, multiple teams, and seasons.',
  },
  {
    icon: Users,
    title: 'Coach / Admin',
    color: 'bg-amber-500',
    description: 'Manage rosters, schedule games, set lineups, and track live scoring.',
  },
  {
    icon: UserCircle,
    title: 'Player / Parent',
    color: 'bg-green-600',
    description: 'View your schedule, RSVP to games, and follow your player stats.',
  },
  {
    icon: Star,
    title: 'Fan',
    color: 'bg-purple-600',
    description: 'Follow teams and players, watch live scores, and cheer from anywhere.',
  },
];

function getInitials(name) {
  return (name || '?').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
}

export default function Landing() {
  const { isAuthenticated, isLoadingAuth } = useAuth();
  const navigate = useNavigate();
  const [teams, setTeams] = useState([]);

  useEffect(() => {
    if (!isLoadingAuth && isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, isLoadingAuth, navigate]);

  useEffect(() => {
    base44.entities.Team.list('-created_date', 12).then(t => setTeams(t.filter(tm => !tm.is_demo)));
  }, []);

  const handleTryDemo = () => {
    navigate('/demo/role-select');
  };

  const handleLogin = () => {
    base44.auth.redirectToLogin(window.location.origin + '/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(214,90%,10%)] to-[hsl(214,90%,20%)] flex flex-col">
      {/* Nav */}
      <header className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-amber-500 flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-bebas text-xl text-amber-400 tracking-wider leading-none">Eagle</div>
            <div className="font-bebas text-[10px] text-white/50 tracking-widest leading-none">BASEBALL</div>
          </div>
        </div>
        <Button onClick={handleLogin} variant="outline" className="border-white/20 text-white bg-white/10 hover:bg-white/20 hover:text-white">
          Sign In
        </Button>
      </header>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 py-12 text-center">
        <div className="inline-flex items-center gap-2 bg-amber-500/20 text-amber-400 text-xs font-semibold px-3 py-1.5 rounded-full mb-6 border border-amber-500/30 uppercase tracking-widest">
          Youth Baseball Platform
        </div>

        <h1 className="font-bebas text-5xl sm:text-7xl text-white tracking-wider mb-4 leading-none">
          EagleBaseball
        </h1>
        <p className="text-white/60 text-lg max-w-md mb-10">
          Live scoring, roster management, RSVP tracking, and stats — all in one place for your whole baseball community.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <Button
            onClick={handleLogin}
            size="lg"
            className="bg-amber-500 hover:bg-amber-400 text-black font-bold text-base px-8 py-6 rounded-xl gap-2 shadow-xl shadow-amber-500/20"
          >
            Get Started <ChevronRight className="w-5 h-5" />
          </Button>
          <Button
            onClick={handleTryDemo}
            size="lg"
            variant="outline"
            className="border-white/20 text-white bg-white/5 hover:bg-white/15 hover:text-white px-8 py-6 rounded-xl gap-2"
          >
            <FlaskConical className="w-5 h-5" />
            Try Demo
          </Button>
        </div>

        <p className="text-white/30 text-xs mt-4">Sign in or create a free account</p>

        {/* Teams on EagleBaseball */}
        <div className="mt-16 w-full max-w-4xl">
          <div className="text-center mb-6">
            <h2 className="font-bebas text-2xl text-white/80 tracking-wider">Teams Using EagleBaseball</h2>
            <p className="text-white/40 text-sm mt-1">Join the growing community of teams on the platform</p>
          </div>
          {teams.length === 0 ? (
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8 text-center text-white/40 text-sm">
              Be one of the first teams on EagleBaseball!
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {teams.slice(0, 12).map(team => (
                <div key={team.id} className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center gap-2 text-center">
                  {team.logo_url ? (
                    <img src={team.logo_url} alt={team.name} className="w-12 h-12 rounded-xl object-contain bg-white/10" />
                  ) : (
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white text-sm font-bold"
                      style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>
                      {getInitials(team.name)}
                    </div>
                  )}
                  <div>
                    <div className="text-white text-sm font-semibold leading-tight">{team.name}</div>
                    {team.city && <div className="text-white/40 text-xs mt-0.5">{team.city}</div>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <footer className="text-center py-4 text-white/20 text-xs space-y-1">
        <div>© {new Date().getFullYear()} EagleBaseball</div>
        <div>Built by <a href="https://eaglewingai.com" target="_blank" rel="noopener noreferrer" className="text-amber-400/60 hover:text-amber-400 transition-colors underline underline-offset-2">EagleWing AI</a></div>
      </footer>
    </div>
  );
}