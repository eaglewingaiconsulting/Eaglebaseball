import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Building2, Calendar, ChevronRight, Loader2, Upload, Users, CheckCircle } from 'lucide-react';

export default function Onboarding() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(0); // 0=multi-team check, 1=org, 2=season
  const [saving, setSaving] = useState(false);
  const [org, setOrg] = useState(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);

  const [orgForm, setOrgForm] = useState({
    name: '', primary_color: '#1e3a8a', secondary_color: '#f59e0b', logo_url: ''
  });
  const [seasonForm, setSeasonForm] = useState({
    name: '', year: new Date().getFullYear().toString(), start_date: '', end_date: ''
  });

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingLogo(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setOrgForm(f => ({ ...f, logo_url: file_url }));
    setUploadingLogo(false);
    toast.success('Logo uploaded!');
  };

  const createOrg = async () => {
    if (!orgForm.name.trim()) { toast.error('Organization name required'); return; }
    setSaving(true);
    const created = await base44.entities.Organization.create({
      ...orgForm,
      owner_email: user.email,
      admin_emails: [user.email]
    });
    setOrg(created);
    setSaving(false);
    setStep(2);
  };

  const createSeason = async () => {
    if (!seasonForm.name.trim()) { toast.error('Season name required'); return; }
    setSaving(true);
    await base44.entities.Season.create({ ...seasonForm, org_id: org.id, status: 'active' });
    setSaving(false);
    toast.success('Organization & Season created!');
    navigate('/teams/create');
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-lg">

        {/* Step 0 — Multi-team check */}
        {step === 0 && (
          <div className="bg-card border border-border rounded-2xl p-6 space-y-6">
            <div>
              <h1 className="text-2xl font-bold">Do you manage multiple teams?</h1>
              <p className="text-muted-foreground text-sm mt-1">This helps us set up the right structure for you.</p>
            </div>
            <div className="space-y-3">
              <button
                onClick={() => setStep(1)}
                className="w-full text-left bg-background border-2 border-border hover:border-primary/60 rounded-xl p-4 transition-all group active:scale-[0.99] touch-manipulation"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center flex-shrink-0">
                    <Building2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="font-semibold">Yes — I run multiple teams</div>
                    <div className="text-sm text-muted-foreground">Create an organization to manage teams, seasons, and fees together.</div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground ml-auto group-hover:text-primary transition-colors" />
                </div>
              </button>
              <button
                onClick={() => navigate('/teams/create')}
                className="w-full text-left bg-background border-2 border-border hover:border-primary/60 rounded-xl p-4 transition-all group active:scale-[0.99] touch-manipulation"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-500 flex items-center justify-center flex-shrink-0">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="font-semibold">No — just one team</div>
                    <div className="text-sm text-muted-foreground">Skip the org setup and go straight to building your roster.</div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground ml-auto group-hover:text-primary transition-colors" />
                </div>
              </button>
            </div>
          </div>
        )}

        {/* Progress bar — only show for steps 1+ */}
        {step >= 1 && (
          <div className="flex items-center gap-3 mb-8">
            {[{ n: 1, label: 'Organization', StepIcon: Building2 }, { n: 2, label: 'Season', StepIcon: Calendar }].map(({ n, label, StepIcon }) => (
              <div key={n} className={`flex items-center gap-2 flex-1 pb-3 border-b-2 transition-colors ${step >= n ? 'border-primary text-primary' : 'border-border text-muted-foreground'}`}>
                <StepIcon className="w-4 h-4" />
                <span className="text-sm font-medium">{label}</span>
              </div>
            ))}
          </div>
        )}

        {step === 1 && (
          <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
            <div>
              <h1 className="text-2xl font-bold">Create Your Organization</h1>
              <p className="text-muted-foreground text-sm mt-1">Set up your travel ball org branding</p>
            </div>

            <div className="space-y-2">
              <Label>Organization Name *</Label>
              <Input placeholder="e.g. Eagles Travel Baseball" value={orgForm.name} onChange={e => setOrgForm(f => ({ ...f, name: e.target.value }))} />
            </div>

            <div className="space-y-2">
              <Label>Logo</Label>
              <div className="flex items-center gap-3">
                {orgForm.logo_url && <img src={orgForm.logo_url} alt="logo" className="w-12 h-12 rounded-lg object-cover" />}
                <label className="flex items-center gap-2 cursor-pointer border border-border rounded-lg px-3 py-2 text-sm hover:bg-muted transition-colors">
                  {uploadingLogo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  {uploadingLogo ? 'Uploading...' : 'Upload Logo'}
                  <input type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
                </label>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Primary Color</Label>
                <div className="flex items-center gap-2">
                  <input type="color" value={orgForm.primary_color} onChange={e => setOrgForm(f => ({ ...f, primary_color: e.target.value }))} className="w-10 h-9 rounded border border-border cursor-pointer" />
                  <Input value={orgForm.primary_color} onChange={e => setOrgForm(f => ({ ...f, primary_color: e.target.value }))} className="font-mono text-sm" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Secondary Color</Label>
                <div className="flex items-center gap-2">
                  <input type="color" value={orgForm.secondary_color} onChange={e => setOrgForm(f => ({ ...f, secondary_color: e.target.value }))} className="w-10 h-9 rounded border border-border cursor-pointer" />
                  <Input value={orgForm.secondary_color} onChange={e => setOrgForm(f => ({ ...f, secondary_color: e.target.value }))} className="font-mono text-sm" />
                </div>
              </div>
            </div>

            <Button className="w-full gap-2" onClick={createOrg} disabled={saving}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <ChevronRight className="w-4 h-4" />}
              Continue to Season Setup
            </Button>
          </div>
        )}

        {step === 2 && (
          <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
            <div>
              <h1 className="text-2xl font-bold">Create Your First Season</h1>
              <p className="text-muted-foreground text-sm mt-1">Teams will be organized under this season</p>
            </div>

            <div className="space-y-2">
              <Label>Season Name *</Label>
              <Input placeholder="e.g. Summer 2026" value={seasonForm.name} onChange={e => setSeasonForm(f => ({ ...f, name: e.target.value }))} />
            </div>

            <div className="space-y-2">
              <Label>Year</Label>
              <Input placeholder="2026" value={seasonForm.year} onChange={e => setSeasonForm(f => ({ ...f, year: e.target.value }))} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date</Label>
                <Input type="date" value={seasonForm.start_date} onChange={e => setSeasonForm(f => ({ ...f, start_date: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>End Date</Label>
                <Input type="date" value={seasonForm.end_date} onChange={e => setSeasonForm(f => ({ ...f, end_date: e.target.value }))} />
              </div>
            </div>

            <Button className="w-full gap-2" onClick={createSeason} disabled={saving}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <ChevronRight className="w-4 h-4" />}
              Create Season & Go to Teams
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}