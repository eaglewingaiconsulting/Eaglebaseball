/**
 * CoachDashboard — Feature 6
 * Coach & Org Admin access only.
 * Polls every 30s. Opponent scouting only when prior game data exists.
 */
import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { ArrowLeft, RefreshCw, Zap } from 'lucide-react';
import CoachGameBar from '@/components/coach/CoachGameBar';
import CoachPitcherPanel from '@/components/coach/CoachPitcherPanel';
import CoachBatterPanel from '@/components/coach/CoachBatterPanel';
import CoachLineupPanel from '@/components/coach/CoachLineupPanel';
import CoachAnalysisPanel from '@/components/coach/CoachAnalysisPanel';
import CoachScoutingPanel from '@/components/coach/CoachScoutingPanel';
import LineupChangeSheet from '@/components/scoring/LineupChangeSheet';

const POLL_INTERVAL = 30_000; // 30s

export default function CoachDashboard() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [game, setGame]       = useState(null);
  const [players, setPlayers] = useState([]);
  const [atBats, setAtBats]   = useState([]);
  const [pitchers, setPitchers] = useState([]);
  const [playLogs, setPlayLogs] = useState([]);
  const [scoutAtBats, setScoutAtBats] = useState([]); // prior game at-bats for opponent
  const [myTeamId, setMyTeamId] = useState(null);
  const [oppTeamId, setOppTeamId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [accessDenied, setAccessDenied] = useState(false);
  const [showLineupSheet, setShowLineupSheet] = useState(false);
  const pollRef = useRef(null);

  // ── Load everything ─────────────────────────────────────────────────────
  const loadAll = useCallback(async (silent = false) => {
    if (!silent) setLoading(true); else setRefreshing(true);
    const games = await base44.entities.Game.filter({ id });
    const g = games[0];
    if (!g) { setLoading(false); setRefreshing(false); return; }
    setGame(g);

    const [hp, ap, ht, at] = await Promise.all([
      g.home_team_id ? base44.entities.Player.filter({ team_id: g.home_team_id }) : [],
      g.away_team_id ? base44.entities.Player.filter({ team_id: g.away_team_id }) : [],
      g.home_team_id ? base44.entities.Team.filter({ id: g.home_team_id }) : [],
      g.away_team_id ? base44.entities.Team.filter({ id: g.away_team_id }) : [],
    ]);
    setPlayers([...hp, ...ap]);

    // Determine which side "my team" is and verify access
    const homeTeam = ht[0];
    const awayTeam = at[0];
    const isHomeCoach = user && homeTeam &&
      (homeTeam.coach_email === user.email || (homeTeam.admin_emails || []).includes(user.email));
    const isAwayCoach = user && awayTeam &&
      (awayTeam.coach_email === user.email || (awayTeam.admin_emails || []).includes(user.email));
    const isAppAdmin = user?.role === 'admin';

    if (!isAppAdmin && !isHomeCoach && !isAwayCoach) {
      setAccessDenied(true);
      setLoading(false);
      setRefreshing(false);
      return;
    }

    let myId = isAwayCoach && !isHomeCoach ? g.away_team_id : g.home_team_id;
    let oppId = myId === g.home_team_id ? g.away_team_id : g.home_team_id;
    setMyTeamId(myId);
    setOppTeamId(oppId);

    // Game-specific data
    const [abs, gp, pl] = await Promise.all([
      base44.entities.AtBat.filter({ game_id: id }),
      base44.entities.GamePitcher.filter({ game_id: id }),
      base44.entities.PlayLog.filter({ game_id: id }),
    ]);
    setAtBats(abs);
    setPitchers(gp);
    setPlayLogs(pl);

    // ── Scouting: prior games vs this opponent ─────────────────────────────
    // Look for completed games where opponent appeared as home or away
    if (oppId) {
      const [prevAsHome, prevAsAway] = await Promise.all([
        base44.entities.Game.filter({ home_team_id: oppId }),
        base44.entities.Game.filter({ away_team_id: oppId }),
      ]);
      const priorGames = [...prevAsHome, ...prevAsAway]
        .filter(pg => (pg.status === 'completed' || pg.status === 'final') && pg.id !== id);

      if (priorGames.length > 0) {
        // Load at-bats from up to 3 most recent prior games
        const recentIds = priorGames
          .sort((a, b) => new Date(b.scheduled_date) - new Date(a.scheduled_date))
          .slice(0, 3)
          .map(pg => pg.id);
        const scoutResults = await Promise.all(
          recentIds.map(gid => base44.entities.AtBat.filter({ game_id: gid }))
        );
        const flat = scoutResults.flat();
        // Keep at-bats where the opponent was batting
        const oppScout = flat.filter(ab => {
          const isPrevAsHome = prevAsHome.some(pg => pg.id === ab.game_id);
          return isPrevAsHome
            ? ab.batting_team_id === oppId
            : ab.batting_team_id === oppId;
        });
        setScoutAtBats(oppScout);
      } else {
        setScoutAtBats([]);
      }
    }

    setLoading(false);
    setRefreshing(false);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, user?.email]);

  useEffect(() => {
    loadAll(false);
  }, [loadAll]);

  // Poll every 30s
  useEffect(() => {
    pollRef.current = setInterval(() => loadAll(true), POLL_INTERVAL);
    return () => clearInterval(pollRef.current);
  }, [loadAll]);

  // Real-time game subscription
  useEffect(() => {
    const unsub = base44.entities.Game.subscribe(evt => {
      if (evt.id === id && evt.type !== 'delete' && evt.data) setGame(evt.data);
    });
    return unsub;
  }, [id]);

  // Real-time AtBat subscription
  useEffect(() => {
    const unsub = base44.entities.AtBat.subscribe(evt => {
      if (evt.data?.game_id !== id) return;
      if (evt.type === 'create') setAtBats(prev => [...prev, evt.data]);
      if (evt.type === 'update') setAtBats(prev => prev.map(ab => ab.id === evt.id ? evt.data : ab));
    });
    return unsub;
  }, [id]);

  // ── Access gate ──────────────────────────────────────────────────────────
  if (loading) return (
    <div className="min-h-screen bg-[hsl(220,25%,6%)] flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-accent border-t-transparent rounded-full animate-spin" />
    </div>
  );
  if (!game) return (
    <div className="min-h-screen bg-[hsl(220,25%,6%)] flex flex-col items-center justify-center text-white gap-3">
      <div className="text-white/40">Game not found</div>
      <button onClick={() => navigate(-1)} className="text-sm text-primary underline">Go back</button>
    </div>
  );

  if (accessDenied) return (
    <div className="min-h-screen bg-[hsl(220,25%,6%)] flex flex-col items-center justify-center text-white gap-3 p-6">
      <div className="text-4xl">🔒</div>
      <div className="font-bold text-lg">Coach Access Only</div>
      <div className="text-white/40 text-sm text-center">This dashboard is restricted to coaches and team admins.</div>
      <button onClick={() => navigate(-1)} className="mt-2 text-sm text-primary underline">Go back</button>
    </div>
  );

  const isLive = game.status === 'in_progress';

  return (
    <div className="bg-[hsl(220,25%,6%)] text-white flex flex-col" style={{ minHeight: '100dvh' }}>

      {/* App bar */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-white/10 flex-shrink-0 bg-[hsl(220,25%,8%)]">
        <button onClick={() => navigate(-1)} className="p-1.5 rounded-lg bg-white/5 select-none touch-manipulation">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="flex-1 min-w-0">
          <div className="font-bold text-sm flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-accent" />
            Coach Dashboard
          </div>
          <div className="text-white/40 text-xs truncate">{game.away_team_name} @ {game.home_team_name}</div>
        </div>
        <div className="flex items-center gap-2">
          {isLive && (
            <div className="flex items-center gap-1 bg-red-500/80 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> LIVE
            </div>
          )}
          <button
            onClick={() => loadAll(true)}
            disabled={refreshing}
            className="p-1.5 rounded-lg bg-white/5 select-none touch-manipulation disabled:opacity-40"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setShowLineupSheet(true)}
            className="text-xs bg-violet-600 hover:bg-violet-500 text-white font-bold px-3 py-1.5 rounded-lg select-none touch-manipulation">
            📋 Lineup
          </button>
          <Link to={`/games/${id}/score`} className="text-xs bg-accent text-accent-foreground font-bold px-3 py-1.5 rounded-lg select-none touch-manipulation">
            Score
          </Link>
        </div>
      </div>

      {/* Scoreboard bar */}
      <CoachGameBar game={game} />

      {/* Scrollable body */}
      <div className="flex-1 overflow-y-auto overscroll-contain px-3 pt-3 pb-24 space-y-3">

        {/* 1 — Current Batter */}
        <CoachBatterPanel game={game} players={players} atBats={atBats} />

        {/* 2 — My team's lineup order + on-deck */}
        <CoachLineupPanel game={game} players={players} myTeamId={myTeamId} />

        {/* 3 — Pitching analysis (both teams) */}
        <CoachAnalysisPanel
          game={game}
          atBats={atBats}
          players={players}
          myTeamId={myTeamId}
          oppTeamId={oppTeamId}
        />

        {/* 4 — Opponent scouting (only when prior data exists) */}
        {scoutAtBats.length > 0 && (
          <CoachScoutingPanel
            scoutAtBats={scoutAtBats}
            oppTeamId={oppTeamId}
            oppTeamName={myTeamId === game.home_team_id ? game.away_team_name : game.home_team_name}
            players={players}
          />
        )}

      </div>

      {/* Sticky bottom: pitcher workload */}
      <div className="relative flex-shrink-0">
        <CoachPitcherPanel game={game} players={players} pitchers={pitchers} />
      </div>

      {showLineupSheet && (
        <LineupChangeSheet
          game={game}
          players={players}
          onClose={() => setShowLineupSheet(false)}
          onGameUpdate={(updates) => {
            setGame(prev => prev ? { ...prev, ...updates } : prev);
            setShowLineupSheet(false);
          }}
        />
      )}
    </div>
  );
}