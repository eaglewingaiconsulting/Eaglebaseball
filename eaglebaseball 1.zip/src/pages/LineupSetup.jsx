import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { ArrowLeft, Check, Camera, X, Plus, Trash2, ChevronDown, GripVertical } from 'lucide-react';
import { toast } from 'sonner';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

const POSITIONS = ['P', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH', 'UT'];

function PositionPicker({ value, onChange }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen(v => !v)}
        className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold select-none touch-manipulation"
        style={{
          backgroundColor: value ? 'rgba(245,158,11,0.2)' : 'rgba(255,255,255,0.08)',
          border: `1px solid ${value ? 'rgba(245,158,11,0.5)' : 'rgba(255,255,255,0.15)'}`,
          color: value ? '#FCD34D' : 'rgba(255,255,255,0.4)',
          minWidth: 44,
        }}
      >
        {value || 'POS'} <ChevronDown className="w-3 h-3 flex-shrink-0" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute z-50 top-full mt-1 left-0 rounded-xl shadow-2xl p-2 grid grid-cols-3 gap-1"
            style={{ backgroundColor: '#1A2235', border: '1px solid rgba(255,255,255,0.15)', minWidth: 120 }}>
            {POSITIONS.map(pos => (
              <button key={pos} type="button"
                onClick={() => { onChange(pos); setOpen(false); }}
                className="px-2 py-1.5 rounded-lg text-xs font-bold select-none touch-manipulation transition-all"
                style={{
                  backgroundColor: value === pos ? '#F59E0B' : 'rgba(255,255,255,0.06)',
                  color: value === pos ? '#0B1120' : 'rgba(255,255,255,0.7)',
                }}>
                {pos}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function LineupRow({ player, index, positionOverride, onPositionChange, onRemove, dragHandleProps }) {
  return (
    <div className="flex items-center gap-3 px-4 py-3 rounded-xl"
      style={{ backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
      {/* Drag handle */}
      <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing touch-manipulation flex-shrink-0 p-1 -ml-1">
        <GripVertical className="w-4 h-4" style={{ color: 'rgba(255,255,255,0.25)' }} />
      </div>
      {/* Batting number */}
      <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0"
        style={{ backgroundColor: '#F59E0B', color: '#0B1120' }}>
        {index + 1}
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-semibold text-white text-sm leading-tight truncate">{player.name}</div>
        <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>#{player.number}</div>
      </div>
      <PositionPicker value={positionOverride} onChange={onPositionChange} />
      <button onClick={onRemove}
        className="p-1.5 rounded-lg touch-manipulation hover:bg-red-500/20 select-none">
        <Trash2 className="w-3.5 h-3.5 text-red-400" />
      </button>
    </div>
  );
}

function BenchRow({ player, onAdd }) {
  return (
    <button onClick={onAdd}
      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left select-none touch-manipulation"
      style={{ backgroundColor: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
        style={{ backgroundColor: 'rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.6)' }}>
        #{player.number}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-white truncate">{player.name}</div>
        <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>{player.position || 'No position'}</div>
      </div>
      <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
        style={{ backgroundColor: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.3)' }}>
        <Plus className="w-3.5 h-3.5 text-amber-400" />
      </div>
    </button>
  );
}

export default function LineupSetup() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [game, setGame] = useState(null);
  const [homePlayers, setHomePlayers] = useState([]);
  const [lineup, setLineup] = useState([]);
  const [positions, setPositions] = useState({});
  const [saving, setSaving] = useState(false);
  const [lineupPhotoUrl, setLineupPhotoUrl] = useState(null);
  const [showPhotoViewer, setShowPhotoViewer] = useState(false);

  useEffect(() => {
    base44.entities.Game.filter({ id }).then(async ([g]) => {
      if (!g) return;
      setGame(g);
      const hp = await base44.entities.Player.filter({ team_id: g.home_team_id });
      setHomePlayers(hp);
      if (g.home_lineup?.length) setLineup(g.home_lineup);
      if (g.lineup_photo_url) setLineupPhotoUrl(g.lineup_photo_url);
      const posMap = {};
      hp.forEach(p => { if (p.position) posMap[p.id] = p.position; });
      setPositions(posMap);
    });
  }, [id]);

  const orderedPlayers = lineup.map(pid => homePlayers.find(p => p.id === pid)).filter(Boolean);
  const benchPlayers = homePlayers.filter(p => !lineup.includes(p.id));

  const addToLineup = (playerId) => setLineup(prev => [...prev, playerId]);
  const removeFromLineup = (playerId) => setLineup(prev => prev.filter(id => id !== playerId));

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const src = result.source.index;
    const dst = result.destination.index;
    if (src === dst) return;
    setLineup(prev => {
      const a = [...prev];
      const [moved] = a.splice(src, 1);
      a.splice(dst, 0, moved);
      return a;
    });
  };

  const setPosition = (playerId, pos) => {
    setPositions(prev => ({ ...prev, [playerId]: pos }));
    base44.entities.Player.update(playerId, { position: pos }).catch(() => {});
  };

  const missingPositions = orderedPlayers.filter(p => !positions[p.id]);

  const handleSave = async () => {
    if (missingPositions.length > 0) {
      toast.error(`Assign positions for: ${missingPositions.map(p => p.name).join(', ')}`);
      return;
    }
    setSaving(true);
    try {
      await base44.entities.Game.update(id, {
        home_lineup: lineup,
        ...(lineupPhotoUrl ? { lineup_photo_url: lineupPhotoUrl } : {}),
      });
      toast.success('Lineup saved!');
      navigate(`/games/${id}`);
    } catch {
      toast.error('Failed to save lineup');
    } finally {
      setSaving(false);
    }
  };

  if (!game) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0B1120' }}>
      <div className="w-8 h-8 border-4 border-amber-400 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24">
      {/* Header */}
      <div className="px-4 pt-6 pb-5" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button onClick={() => navigate(-1)}
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <div>
            <h1 className="font-bebas tracking-widest text-white" style={{ fontSize: 26, letterSpacing: '0.06em', lineHeight: 1 }}>
              Set Lineup
            </h1>
            <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>
              {game.away_team_name} @ {game.home_team_name} · {game.scheduled_date}
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5 space-y-5">

        {/* Photo actions */}
        {lineupPhotoUrl && (
          <div className="flex gap-2">
            <button onClick={() => setShowPhotoViewer(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold select-none touch-manipulation"
              style={{ backgroundColor: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', color: 'rgba(255,255,255,0.7)' }}>
              <Camera className="w-4 h-4" /> View Source Photo
            </button>
          </div>
        )}

        {/* Batting Order */}
        <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
          <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            <span className="font-semibold text-white text-sm tracking-wide">Batting Order</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full"
              style={{ backgroundColor: 'rgba(245,158,11,0.15)', color: '#FCD34D', border: '1px solid rgba(245,158,11,0.3)' }}>
              {orderedPlayers.length} players
            </span>
          </div>
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="lineup">
              {(provided) => (
                <div className="px-4 py-4 space-y-2" ref={provided.innerRef} {...provided.droppableProps}>
                  {orderedPlayers.length === 0 && (
                    <div className="text-center py-8 text-sm" style={{ color: 'rgba(255,255,255,0.3)' }}>
                      Add players from the roster below
                    </div>
                  )}
                  {orderedPlayers.map((player, idx) => (
                    <Draggable key={player.id} draggableId={player.id} index={idx}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          style={{
                            ...provided.draggableProps.style,
                            opacity: snapshot.isDragging ? 0.85 : 1,
                          }}
                        >
                          <LineupRow
                            player={player}
                            index={idx}
                            positionOverride={positions[player.id]}
                            onPositionChange={(pos) => setPosition(player.id, pos)}
                            onRemove={() => removeFromLineup(player.id)}
                            dragHandleProps={provided.dragHandleProps}
                          />
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </div>

        {/* Position warning */}
        {missingPositions.length > 0 && orderedPlayers.length > 0 && (
          <div className="flex items-center gap-2 px-4 py-3 rounded-xl text-sm"
            style={{ backgroundColor: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.3)', color: '#FCD34D' }}>
            ⚠️ Assign positions for: {missingPositions.map(p => p.name).join(', ')}
          </div>
        )}

        {/* Bench / Roster */}
        {benchPlayers.length > 0 && (
          <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div className="px-5 py-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              <span className="font-semibold text-white text-sm tracking-wide">Roster — tap to add</span>
            </div>
            <div className="px-4 py-4 space-y-2">
              {benchPlayers.map(player => (
                <BenchRow key={player.id} player={player} onAdd={() => addToLineup(player.id)} />
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3 pt-1">
          <button onClick={() => navigate(-1)}
            className="flex-1 py-3 rounded-xl text-sm font-semibold select-none"
            style={{ backgroundColor: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.6)' }}>
            Skip for Now
          </button>
          <button onClick={handleSave} disabled={saving}
            className="flex-1 py-3 rounded-xl text-sm font-bold select-none flex items-center justify-center gap-2 disabled:opacity-60"
            style={{ backgroundColor: '#F59E0B', color: '#0B1120', boxShadow: saving ? 'none' : '0 0 20px rgba(245,158,11,0.35)' }}>
            <Check className="w-4 h-4" />
            {saving ? 'Saving…' : 'Save Lineup'}
          </button>
        </div>
      </div>

      {/* Photo viewer */}
      {showPhotoViewer && lineupPhotoUrl && (
        <div className="fixed inset-0 z-50 bg-black flex items-center justify-center" onClick={() => setShowPhotoViewer(false)}>
          <button className="absolute top-4 right-4 p-2 rounded-full bg-white/20 text-white z-10 touch-manipulation">
            <X className="w-5 h-5" />
          </button>
          <img src={lineupPhotoUrl} alt="Import source" className="max-w-full max-h-full object-contain"
            onClick={e => e.stopPropagation()} />
        </div>
      )}
    </div>
  );
}