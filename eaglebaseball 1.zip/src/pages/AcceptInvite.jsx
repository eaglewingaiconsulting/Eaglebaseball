import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, CheckCircle, AlertCircle, Zap } from 'lucide-react';
import { toast } from 'sonner';

const POSITIONS = ['P', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH', 'UT'];

export default function AcceptInvite() {
  const { token } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [invitation, setInvitation] = useState(null);
  const [team, setTeam] = useState(null);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const [form, setForm] = useState({
    player_name: '',
    jersey_number: '',
    position: 'UT',
    bats: 'R',
    throws: 'R',
  });

  useEffect(() => {
    const load = async () => {
      const invites = await base44.entities.Invitation.filter({ token });
      const inv = invites[0];
      if (!inv) { setError('Invitation not found or already used.'); setLoading(false); return; }
      if (inv.status !== 'pending') { setError('This invitation has already been accepted or has expired.'); setLoading(false); return; }
      if (inv.expires_at && new Date(inv.expires_at) < new Date()) { setError('This invitation has expired. Ask your coach to send a new one.'); setLoading(false); return; }

      setInvitation(inv);
      // Pre-fill player name if coach included it
      if (inv.player_id) {
        const players = await base44.entities.Player.filter({ id: inv.player_id });
        if (players[0]) setForm(f => ({ ...f, player_name: players[0].name }));
      }

      const teams = await base44.entities.Team.filter({ id: inv.team_id });
      setTeam(teams[0] || null);
      setLoading(false);
    };
    load().catch(() => { setError('Something went wrong loading your invitation.'); setLoading(false); });
  }, [token]);

  const handleSubmit = async () => {
    if (!form.player_name.trim()) { toast.error('Player name is required'); return; }
    if (!form.jersey_number.trim()) { toast.error('Jersey number is required'); return; }
    setSaving(true);

    // Create the player record
    const player = await base44.entities.Player.create({
      team_id: invitation.team_id,
      name: form.player_name.trim(),
      number: form.jersey_number.trim(),
      position: form.position,
      bats: form.bats,
      throws: form.throws,
      parent_email: invitation.email,
    });

    // Mark invitation as accepted and link player
    await base44.entities.Invitation.update(invitation.id, {
      status: 'accepted',
      player_id: player.id,
    });

    // Invite the parent as an app user (role=user)
    await base44.users.inviteUser(invitation.email, 'user');

    setDone(true);
    setSaving(false);
  };

  const Field = ({ label, children }) => (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium text-foreground">{label}</Label>
      {children}
    </div>
  );

  if (loading) return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
    </div>
  );

  if (error) return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center max-w-sm">
        <AlertCircle className="w-10 h-10 text-destructive mx-auto mb-3" />
        <h2 className="font-bold text-lg mb-1">Invitation Issue</h2>
        <p className="text-muted-foreground text-sm">{error}</p>
      </div>
    </div>
  );

  if (done) return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center max-w-sm">
        <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
        <h2 className="font-bold text-xl mb-2">You're on the team!</h2>
        <p className="text-muted-foreground text-sm mb-6">
          <strong>{form.player_name}</strong> has been added to <strong>{team?.name}</strong>.
          Check your email for a login link to access your account.
        </p>
        <Button onClick={() => navigate('/')} className="w-full">Go to EagleBaseball</Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center mx-auto mb-4">
            <Zap className="w-6 h-6 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold mb-1">Join {team?.name}</h1>
          <p className="text-muted-foreground text-sm">
            You've been invited as a <strong>parent</strong>. Fill in your child's details to complete registration.
          </p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
          <Field label="Player's Full Name *">
            <Input
              placeholder="e.g. Jake Smith"
              value={form.player_name}
              onChange={e => setForm(f => ({ ...f, player_name: e.target.value }))}
              autoFocus
            />
          </Field>

          <Field label="Jersey Number *">
            <Input
              placeholder="e.g. 24"
              inputMode="numeric"
              value={form.jersey_number}
              onChange={e => setForm(f => ({ ...f, jersey_number: e.target.value }))}
            />
          </Field>

          <Field label="Position">
            <div className="flex flex-wrap gap-1.5">
              {POSITIONS.map(pos => (
                <button
                  key={pos}
                  onClick={() => setForm(f => ({ ...f, position: pos }))}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
                    form.position === pos
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'border-border hover:bg-muted'
                  }`}
                >
                  {pos}
                </button>
              ))}
            </div>
          </Field>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Bats">
              <div className="flex gap-1.5">
                {['R', 'L', 'S'].map(v => (
                  <button key={v} onClick={() => setForm(f => ({ ...f, bats: v }))}
                    className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-colors ${
                      form.bats === v ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'
                    }`}>
                    {v === 'R' ? 'Right' : v === 'L' ? 'Left' : 'Switch'}
                  </button>
                ))}
              </div>
            </Field>
            <Field label="Throws">
              <div className="flex gap-1.5">
                {['R', 'L'].map(v => (
                  <button key={v} onClick={() => setForm(f => ({ ...f, throws: v }))}
                    className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-colors ${
                      form.throws === v ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'
                    }`}>
                    {v === 'R' ? 'Right' : 'Left'}
                  </button>
                ))}
              </div>
            </Field>
          </div>

          <div className="pt-1 space-y-2">
            <Button className="w-full gap-2" onClick={handleSubmit} disabled={saving}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
              {saving ? 'Adding player...' : 'Complete Registration'}
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              Your email <strong>{invitation?.email}</strong> will be used to create your account.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}