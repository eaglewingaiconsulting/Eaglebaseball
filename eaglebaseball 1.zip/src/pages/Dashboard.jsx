import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import useEffectiveUser from '@/hooks/useEffectiveUser';
import useAppRole from '@/hooks/useAppRole';
import { Calendar, Trophy, Activity, ArrowRight, Play, Clock, RefreshCw, Plus, Users, DollarSign, ShoppingBag, Radio } from 'lucide-react';
import usePullToRefresh from '@/hooks/usePullToRefresh';
import DemoWrapper from '@/components/demo/DemoWrapper';
import TeamGrid from '@/components/hub/TeamGrid';

const FIELD_BG = 'https://media.base44.com/images/public/69bee7c941fcc47a38cfc123/bbc2e8956_generated_image.png';

export default function Dashboard() {
  const { user } = useEffectiveUser();
  const { appRole, isOrgOwner, isCoach, myOrg, myTeams: roleTeams, loading: roleLoading } = useAppRole();
  const [teams, setTeams] = useState([]);
  const [games, setGames] = useState([]);
  const [org, setOrg] = useState(null);
  const [orgFinancials, setOrgFinancials] = useState(null);
  const [storeOrders, setStoreOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  const demoRole = sessionStorage.getItem('demoRole');
  const isDemoMode = sessionStorage.getItem('demoMode') === '1';

  const fetchData = useCallback(async () => {
    if (isDemoMode) { setLoading(false); return; }
    if (!user || roleLoading) return;

    const [allTeams, g] = await Promise.all([
      base44.entities.Team.list('-created_date', 200),
      base44.entities.Game.list('-scheduled_date', 30),
    ]);

    const myTeams = isOrgOwner ? allTeams : allTeams.filter(t =>
      t.coach_email === user.email ||
      (t.admin_emails || []).includes(user.email) ||
      (t.fan_emails || []).includes(user.email)
    );
    setTeams(myTeams);

    const myTeamIds = new Set(myTeams.map(t => t.id));
    const myGames = isOrgOwner ? g : g.filter(gm => myTeamIds.has(gm.home_team_id) || myTeamIds.has(gm.away_team_id));
    setGames(myGames);

    // Only fetch org data for org owners
    if (isOrgOwner) {
      const foundOrg = myOrg || null;
      if (foundOrg) {
        setOrg(foundOrg);
        const orgTeams = allTeams.filter(t => t.org_id === foundOrg.id);
        const allOrders = (await Promise.all(orgTeams.map(t => base44.entities.StoreOrder.filter({ team_id: t.id })))).flat();
        const paid = allOrders.filter(o => o.payment_status === 'paid');
        const pending = allOrders.filter(o => o.payment_status === 'pending');
        setOrgFinancials({ totalRevenue: paid.reduce((sum, o) => sum + (o.amount_paid || 0), 0), paidCount: paid.length, pendingCount: pending.length });
        setStoreOrders(allOrders.sort((a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0)).slice(0, 5));
      }
    }

    setLoading(false);
  }, [isDemoMode, user?.email, isOrgOwner, roleLoading, myOrg]);

  useEffect(() => { fetchData(); }, [fetchData]);
  const { refreshing } = usePullToRefresh(fetchData);

  if (isDemoMode) return <DemoWrapper />;

  const liveGames = games.filter(g => g.status === 'in_progress');
  const upcomingGames = games.filter(g => g.status === 'scheduled').slice(0, 5);
  const recentGames = games.filter(g => g.status === 'completed').slice(0, 3);

  const hubTitle = org ? 'Org Hub' : isCoach ? 'Coach Hub' : 'Player Hub';
  const groupBy = (org || isCoach) ? 'age_season' : 'season';
  const hubSubtitle = org ? 'Organization overview' : isCoach ? 'Team management & scoring' : 'Your teams & games';

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
      {refreshing && (
        <div className="flex items-center justify-center gap-2 py-2 text-sm" style={{ backgroundColor: '#0F1729', color: '#F59E0B' }}>
          <RefreshCw className="w-4 h-4 animate-spin" /> Refreshing...
        </div>
      )}

      {/* ── HERO: Baseball Field ── */}
      <div className="relative overflow-hidden" style={{ minHeight: 220 }}>
        <img
          src={FIELD_BG}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
          style={{ opacity: 0.55 }}
        />
        {/* Dark overlay gradient */}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(11,17,32,0.3) 0%, rgba(11,17,32,0.55) 60%, rgba(11,17,32,1) 100%)' }} />

        <div className="relative z-10 flex flex-col items-center justify-center text-center px-5 py-10">
          <h1 className="font-bebas tracking-widest text-white" style={{ fontSize: 56, lineHeight: 1, letterSpacing: '0.08em', textShadow: '0 2px 20px rgba(0,0,0,0.8)' }}>
            {loading ? 'Hub' : hubTitle}
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: 14, marginTop: 6 }}>{hubSubtitle}</p>

          {/* CTA Buttons — marquee bulb style */}
          {isCoach && (
            <div className="flex gap-3 mt-6">
              <Link to="/teams/create"
                className="flex items-center gap-2 font-bold tracking-wide select-none touch-manipulation"
                style={{
                  border: '2px solid #F59E0B',
                  color: '#F59E0B',
                  backgroundColor: 'rgba(245,158,11,0.08)',
                  padding: '10px 22px',
                  borderRadius: 8,
                  fontSize: 14,
                  boxShadow: '0 0 12px rgba(245,158,11,0.35), inset 0 0 8px rgba(245,158,11,0.05)',
                  letterSpacing: '0.05em',
                }}
              >
                <Plus className="w-4 h-4" /> New Team
              </Link>
              <Link to="/games/create"
                className="flex items-center gap-2 font-bold tracking-wide select-none touch-manipulation"
                style={{
                  border: '2px solid #F59E0B',
                  color: '#F59E0B',
                  backgroundColor: 'rgba(245,158,11,0.08)',
                  padding: '10px 22px',
                  borderRadius: 8,
                  fontSize: 14,
                  boxShadow: '0 0 12px rgba(245,158,11,0.35), inset 0 0 8px rgba(245,158,11,0.05)',
                  letterSpacing: '0.05em',
                }}
              >
                <Calendar className="w-4 h-4" /> Schedule
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* ── STAT SCOREBOARD CARDS ── */}
      <div className="grid grid-cols-4 gap-2.5 px-4 py-4">
        {[
          { label: 'Teams', value: teams.length, icon: Users, to: '/teams' },
          { label: 'Played', value: games.filter(g => g.status === 'completed').length, icon: Trophy, to: '/games' },
          { label: 'Live', value: liveGames.length, icon: Radio, to: '/games/live', pulse: liveGames.length > 0 },
          { label: 'Soon', value: upcomingGames.length, icon: Calendar, to: '/games' },
        ].map(stat => (
          <Link key={stat.label} to={stat.to}
            className="flex flex-col items-center justify-center py-3 px-1 select-none touch-manipulation active:brightness-110 transition-all"
            style={{
              backgroundColor: '#0F1729',
              border: stat.pulse ? '2px solid #FACC15' : '2px solid #F59E0B',
              borderRadius: 8,
              boxShadow: stat.pulse ? '0 0 18px rgba(250,204,21,0.45)' : '0 0 14px rgba(245,158,11,0.25)',
            }}>
            <div className="relative">
              <stat.icon style={{ width: 18, height: 18, color: '#F59E0B', marginBottom: 6 }} />
              {stat.pulse && <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />}
            </div>
            <div className="font-bebas" style={{ fontSize: 36, lineHeight: 1, color: '#F59E0B', textShadow: '0 0 10px rgba(245,158,11,0.6)' }}>
              {loading ? '—' : stat.value}
            </div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 3, letterSpacing: '0.05em' }}>{stat.label}</div>
          </Link>
        ))}
      </div>

      <div className="px-4 space-y-6">

        {/* ── LIVE GAMES ── */}
        {liveGames.length > 0 && (
          <div>
            {/* Scoreboard header bar */}
            <Link to="/games/live" className="flex items-center gap-2 px-4 py-2.5 rounded-t-lg touch-manipulation active:opacity-80" style={{ backgroundColor: '#1A1F0E', border: '1px solid #3D3D00' }}>
              <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 animate-pulse" />
              <span className="font-bebas tracking-widest" style={{ color: '#F59E0B', fontSize: 18 }}>Live Now</span>
              <ArrowRight className="w-3.5 h-3.5 ml-auto" style={{ color: 'rgba(245,158,11,0.5)' }} />
            </Link>
            <div className="space-y-0">
              {liveGames.map(game => (
                <Link key={game.id} to={`/games/${game.id}/live`}
                  className="flex items-center justify-between px-4 py-4 active:opacity-80 transition-all select-none touch-manipulation"
                  style={{ backgroundColor: '#12180A', border: '1px solid #2A2A00', borderTop: 'none' }}>
                  <div>
                    <div className="font-semibold text-white" style={{ fontSize: 15 }}>{game.away_team_name} @ {game.home_team_name}</div>
                    <div style={{ color: 'rgba(255,255,255,0.45)', fontSize: 13 }}>
                      Inn. {game.inning} {game.inning_half === 'top' ? '▲' : '▼'} • {game.outs} outs
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bebas" style={{ fontSize: 32, color: '#F59E0B', letterSpacing: '0.1em', textShadow: '0 0 12px rgba(245,158,11,0.7)' }}>
                      {game.away_score}-{game.home_score}
                    </div>
                    <div className="flex items-center gap-1 justify-end" style={{ color: '#F59E0B', fontSize: 12 }}>
                      <Play className="w-3 h-3" /> Live
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* ── UPCOMING ── */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bebas tracking-widest" style={{ fontSize: 24, color: '#fff', letterSpacing: '0.08em' }}>Upcoming</h2>
            <Link to="/games" className="flex items-center gap-1" style={{ color: '#F59E0B', fontSize: 13 }}>
              All games <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          {upcomingGames.length === 0 && !loading ? (
            <div className="text-center py-6 rounded-xl" style={{ border: '1px dashed rgba(245,158,11,0.3)', color: 'rgba(255,255,255,0.35)', fontSize: 14 }}>
              No upcoming games
              {isCoach && <> — <Link to="/games/create" style={{ color: '#F59E0B' }}>schedule one</Link></>}
            </div>
          ) : (
            <div className="space-y-2">
              {upcomingGames.map(game => (
                <Link key={game.id} to={`/games/${game.id}`}
                  className="flex items-center justify-between px-4 py-3.5 active:opacity-80 transition-all select-none touch-manipulation"
                  style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10 }}>
                  <div className="min-w-0">
                    <div className="font-semibold text-white truncate" style={{ fontSize: 14 }}>{game.away_team_name} @ {game.home_team_name}</div>
                    <div className="flex items-center gap-1 mt-0.5" style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12 }}>
                      <Clock className="w-3 h-3 flex-shrink-0" />
                      {game.scheduled_date}{game.scheduled_time && ` · ${game.scheduled_time}`}
                    </div>
                  </div>
                  {game.location && (
                    <span className="ml-3 flex-shrink-0 px-2.5 py-1 rounded-full" style={{ backgroundColor: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.6)', fontSize: 11 }}>
                      {game.location}
                    </span>
                  )}
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* ── RECENT RESULTS ── */}
        {recentGames.length > 0 && (
          <div>
            <h2 className="font-bebas tracking-widest mb-3" style={{ fontSize: 24, color: '#fff', letterSpacing: '0.08em' }}>Recent Results</h2>
            <div className="space-y-2">
              {recentGames.map(game => (
                <Link key={game.id} to={`/games/${game.id}`}
                  className="flex items-center justify-between px-4 py-3.5 active:opacity-80 transition-all select-none touch-manipulation"
                  style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10 }}>
                  <div className="font-semibold text-white truncate min-w-0 pr-4" style={{ fontSize: 14 }}>
                    {game.away_team_name} @ {game.home_team_name}
                  </div>
                  <div className="font-bebas flex-shrink-0" style={{ fontSize: 22, color: '#F59E0B', letterSpacing: '0.08em' }}>
                    {game.away_score}–{game.home_score}
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* ── MY TEAMS ── */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bebas tracking-widest" style={{ fontSize: 24, color: '#fff', letterSpacing: '0.08em' }}>My Teams</h2>
            {isCoach && (
              <Link to="/teams/create" className="flex items-center gap-1 select-none" style={{ color: '#F59E0B', fontSize: 13 }}>
                <Plus className="w-3.5 h-3.5" /> New
              </Link>
            )}
          </div>
          <TeamGrid
            teams={teams}
            groupBy={groupBy}
            emptyLabel={isCoach ? 'No teams yet — create one above' : 'No teams associated with your account'}
          />
        </div>

        {/* ── ORG FINANCIALS ── */}
        {org && orgFinancials && (
          <div>
            <h2 className="font-bebas tracking-widest mb-3" style={{ fontSize: 24, color: '#fff', letterSpacing: '0.08em' }}>Org Financials</h2>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Revenue', value: `$${orgFinancials.totalRevenue.toFixed(0)}`, icon: DollarSign },
                { label: 'Paid Orders', value: orgFinancials.paidCount, icon: Trophy },
                { label: 'Pending', value: orgFinancials.pendingCount, icon: Clock },
              ].map(stat => (
                <div key={stat.label} className="flex flex-col items-center justify-center py-4 px-2" style={{
                  backgroundColor: '#0F1729',
                  border: '2px solid #F59E0B',
                  borderRadius: 8,
                  boxShadow: '0 0 14px rgba(245,158,11,0.2)',
                }}>
                  <stat.icon style={{ width: 18, height: 18, color: '#F59E0B', marginBottom: 6 }} />
                  <div className="font-bebas" style={{ fontSize: 28, color: '#F59E0B', lineHeight: 1, textShadow: '0 0 8px rgba(245,158,11,0.5)' }}>
                    {stat.value}
                  </div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', marginTop: 4 }}>{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── STORE ACTIVITY ── */}
        {org && storeOrders.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bebas tracking-widest" style={{ fontSize: 24, color: '#fff', letterSpacing: '0.08em' }}>Store Activity</h2>
              <Link to="/org" className="flex items-center gap-1 select-none" style={{ color: '#F59E0B', fontSize: 13 }}>
                View all <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
            <div className="overflow-hidden" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10 }}>
              {storeOrders.slice(0, 5).map((order, i) => (
                <div key={order.id} className="flex items-center gap-3 px-4 py-3"
                  style={{ borderTop: i > 0 ? '1px solid rgba(255,255,255,0.06)' : 'none' }}>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: 'rgba(245,158,11,0.12)' }}>
                    <ShoppingBag style={{ width: 16, height: 16, color: '#F59E0B' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white truncate" style={{ fontSize: 13, fontWeight: 500 }}>{order.item_name || 'Store Item'}</div>
                    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11 }}>{order.parent_name || order.parent_email}</div>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: order.payment_status === 'Paid' ? '#4ADE80' : '#F59E0B', flexShrink: 0 }}>
                    {order.payment_status === 'Paid' ? `$${(order.amount_paid || 0).toFixed(2)}` : 'Pending'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}