import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { ArrowLeft, UserPlus, X, Star, Shield, TrendingUp, Film, Ruler } from 'lucide-react';
import PlayerPhotoUpload, { PlayerAvatar } from '@/components/player/PlayerPhotoUpload';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

const STAT_ROWS = [
  { label: 'Games Played', key: 'games_played' },
  { label: 'At Bats', key: 'at_bats' },
  { label: 'Batting Avg', key: 'batting_avg', format: v => v?.toFixed(3) || '.000' },
  { label: 'Hits', key: 'hits' },
  { label: 'Runs', key: 'runs' },
  { label: 'RBIs', key: 'rbis' },
  { label: 'Home Runs', key: 'home_runs' },
  { label: 'Stolen Bases', key: 'stolen_bases' },
  { label: 'Walks', key: 'walks' },
];

const PITCH_ROWS = [
  { label: 'Innings Pitched', key: 'innings_pitched' },
  { label: 'ERA', key: 'era', format: v => v?.toFixed(2) || '0.00' },
  { label: 'Strikeouts (P)', key: 'strikeouts_pitching' },
  { label: 'Hits Allowed', key: 'hits_allowed' },
  { label: 'Walks Allowed', key: 'walks_allowed' },
  { label: 'Earned Runs', key: 'earned_runs' },
];

export default function PlayerDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [player, setPlayer] = useState(null);
  const [team, setTeam] = useState(null);
  const [playLogs, setPlayLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newFanEmail, setNewFanEmail] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.entities.Player.filter({ id }).then(async ([p]) => {
      if (!p) { setLoading(false); return; }
      setPlayer(p);
      const [teams, logs] = await Promise.all([
        base44.entities.Team.filter({ id: p.team_id }),
        base44.entities.PlayLog.filter({ player_id: p.id })
      ]);
      setTeam(teams[0] || null);
      setPlayLogs(logs.sort((a, b) => (b.inning || 0) - (a.inning || 0)));
      setLoading(false);
    });
  }, [id]);

  const canManage = user && player && (
    player.parent_email === user.email ||
    (team && (team.coach_email === user.email || (team.admin_emails || []).includes(user.email))) ||
    user.role === 'admin'
  );

  const isFan = user && player && (player.fan_emails || []).includes(user.email);

  const addFan = async () => {
    if (!newFanEmail.trim()) return;
    const fans = [...(player.fan_emails || [])];
    if (fans.includes(newFanEmail.trim())) { toast.error('Already a fan'); return; }
    fans.push(newFanEmail.trim());
    setSaving(true);
    const updated = await base44.entities.Player.update(player.id, { fan_emails: fans });
    setPlayer(updated);
    setNewFanEmail('');
    setSaving(false);
    toast.success('Fan invited!');
  };

  const removeFan = async (email) => {
    const fans = (player.fan_emails || []).filter(e => e !== email);
    setSaving(true);
    const updated = await base44.entities.Player.update(player.id, { fan_emails: fans });
    setPlayer(updated);
    setSaving(false);
    toast.success('Fan removed');
  };

  const followAsMyself = async () => {
    if (!user) return;
    const fans = [...(player.fan_emails || []), user.email];
    setSaving(true);
    const updated = await base44.entities.Player.update(player.id, { fan_emails: fans });
    setPlayer(updated);
    setSaving(false);
    toast.success("You're now following this player!");
  };

  const unfollowMyself = async () => {
    const fans = (player.fan_emails || []).filter(e => e !== user.email);
    setSaving(true);
    const updated = await base44.entities.Player.update(player.id, { fan_emails: fans });
    setPlayer(updated);
    setSaving(false);
    toast.success('Unfollowed');
  };

  if (loading) return <div className="p-6 text-center text-muted-foreground">Loading...</div>;
  if (!player) return <div className="p-6 text-center text-muted-foreground">Player not found</div>;

  const isPitcher = player.position === 'P';

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back
      </button>

      {/* Header */}
      <div className="bg-card border border-border rounded-2xl p-6 flex flex-wrap gap-4 items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-center gap-1">
            {canManage ? (
              <PlayerPhotoUpload player={player} onUpdated={setPlayer} />
            ) : (
              <PlayerAvatar player={player} size="xl" />
            )}
            <span className="text-xs font-bold text-muted-foreground">#{player.number}</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold">{player.name}</h1>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge>{player.position}</Badge>
              {team && <Link to={`/teams/${team.id}`} className="text-sm text-muted-foreground hover:text-primary">{team.name}</Link>}
              <span className="text-xs text-muted-foreground">Bats {player.bats} / Throws {player.throws}</span>
            </div>
            {player.parent_email && (
              <div className="flex items-center gap-1.5 mt-1 text-xs text-muted-foreground">
                <Shield className="w-3 h-3" /> Parent: <span className="font-medium text-foreground">{player.parent_email}</span>
              </div>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          {user && !isFan && !canManage && (
            <Button size="sm" variant="outline" className="gap-1.5" onClick={followAsMyself} disabled={saving}>
              <Star className="w-4 h-4" /> Follow
            </Button>
          )}
          {isFan && (
            <Button size="sm" variant="ghost" className="gap-1.5 text-muted-foreground" onClick={unfollowMyself} disabled={saving}>
              <X className="w-4 h-4" /> Unfollow
            </Button>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Stats */}
        <div className="bg-card border border-border rounded-2xl p-5">
          <h2 className="font-semibold flex items-center gap-2 mb-4"><TrendingUp className="w-4 h-4" /> Batting Stats</h2>
          <div className="space-y-2">
            {STAT_ROWS.map(({ label, key, format }) => (
              <div key={key} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{label}</span>
                <span className="font-medium">{format ? format(player[key]) : (player[key] ?? 0)}</span>
              </div>
            ))}
          </div>
          {isPitcher && (
            <>
              <hr className="my-4 border-border" />
              <h3 className="font-semibold text-sm mb-3">Pitching Stats</h3>
              <div className="space-y-2">
                {PITCH_ROWS.map(({ label, key, format }) => (
                  <div key={key} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{label}</span>
                    <span className="font-medium">{format ? format(player[key]) : (player[key] ?? 0)}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Fans & Parent */}
        <div className="space-y-4">
          {canManage && (
            <div className="bg-card border border-border rounded-2xl p-5">
              <h2 className="font-semibold flex items-center gap-2 mb-4"><UserPlus className="w-4 h-4" /> Invite Fans</h2>
              <div className="flex gap-2 mb-4">
                <Input
                  placeholder="fan@email.com"
                  value={newFanEmail}
                  onChange={e => setNewFanEmail(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addFan()}
                  className="text-sm"
                />
                <Button size="sm" onClick={addFan} disabled={saving || !newFanEmail.trim()}>Invite</Button>
              </div>
              <div className="space-y-2">
                {(player.fan_emails || []).length === 0 ? (
                  <p className="text-sm text-muted-foreground">No fans yet. Invite some!</p>
                ) : (
                  (player.fan_emails || []).map(email => (
                    <div key={email} className="flex items-center justify-between bg-muted rounded-lg px-3 py-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Star className="w-3.5 h-3.5 text-accent" />
                        <span>{email}</span>
                      </div>
                      <button onClick={() => removeFan(email)} className="text-muted-foreground hover:text-destructive transition-colors">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {!canManage && (
            <div className="bg-card border border-border rounded-2xl p-5">
              <h2 className="font-semibold flex items-center gap-2 mb-3"><Star className="w-4 h-4" /> Fans</h2>
              <p className="text-sm text-muted-foreground">
                {(player.fan_emails || []).length > 0
                  ? `${player.fan_emails.length} fan(s) following this player`
                  : 'No fans yet.'}
              </p>
              {isFan && <p className="text-sm text-primary font-medium mt-2">⭐ You're following this player!</p>}
            </div>
          )}
        </div>
      </div>
      {/* Uniform Sizing */}
      {(player.shirt_size || player.hat_size || player.pants_size || canManage) && (
        <div className="bg-card border border-border rounded-2xl p-5">
          <h2 className="font-semibold flex items-center gap-2 mb-4"><Ruler className="w-4 h-4" /> Uniform Sizes</h2>
          {player.shirt_size || player.hat_size || player.pants_size ? (
            <div className="grid grid-cols-3 gap-3">
              {[['Shirt', player.shirt_size], ['Hat', player.hat_size], ['Pants', player.pants_size]].map(([label, val]) => (
                <div key={label} className="bg-muted rounded-lg p-3 text-center">
                  <div className="text-xs text-muted-foreground mb-1">{label}</div>
                  <div className="font-bold">{val || '—'}</div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No sizes on file yet. Player will be prompted at checkout.</p>
          )}
        </div>
      )}

      {/* Play Highlights */}
      {playLogs.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-5">
          <h2 className="font-semibold flex items-center gap-2 mb-4"><Film className="w-4 h-4" /> Play Highlights</h2>
          <div className="space-y-2 max-h-72 overflow-y-auto">
            {playLogs.map(log => (
              <div key={log.id} className="flex items-center justify-between text-sm border-b border-border pb-2 last:border-0">
                <div>
                  <span className="font-medium capitalize">{log.play_type?.replace(/_/g, ' ')}</span>
                  <span className="text-muted-foreground ml-2">Inn. {log.inning} {log.inning_half === 'top' ? '▲' : '▼'}</span>
                  {log.rbis > 0 && <span className="text-green-600 ml-2">{log.rbis} RBI</span>}
                </div>
                <div className="flex items-center gap-2">
                  {log.timestamp_seconds != null && (
                    <span className="text-xs text-muted-foreground">T+{Math.floor(log.timestamp_seconds / 60)}:{String(log.timestamp_seconds % 60).padStart(2, '0')}</span>
                  )}
                  {log.video_clip_url && (
                    <a href={log.video_clip_url} target="_blank" rel="noopener noreferrer" className="text-primary text-xs underline">Watch</a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}