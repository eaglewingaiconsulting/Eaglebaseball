import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Play, QrCode, ArrowLeft, Users, Clock, MapPin, Calendar, CheckSquare, Navigation, Video, ArrowLeftRight, Trophy, Activity, User, Camera, Flame } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import QRCodeModal from '@/components/teams/QRCodeModal';
import Scoreboard from '@/components/scoring/Scoreboard';
import RSVPSummary from '@/components/game/RSVPSummary';
import InlineRSVP from '@/components/game/InlineRSVP';
import GameHighlights from '@/components/game/GameHighlights';
import OpponentLineupImporter from '@/components/scoring/OpponentLineupImporter';
import { toast } from 'sonner';

export default function GameDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [game, setGame] = useState(null);
  const [homeTeam, setHomeTeam] = useState(null);
  const [awayTeam, setAwayTeam] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showQR, setShowQR] = useState(false);
  const [showSwapConfirm, setShowSwapConfirm] = useState(false);
  const [swapping, setSwapping] = useState(false);
  const [showOpponentImporter, setShowOpponentImporter] = useState(false);
  const [showPitcherPicker, setShowPitcherPicker] = useState(false);
  const [savingPitcher, setSavingPitcher] = useState(false);
  const [players, setPlayers] = useState([]);
  const [events, setEvents] = useState([]);

  useEffect(() => {
    const load = async () => {
      if (!id || id === ':id') { setLoading(false); return; }
      const [games] = await Promise.all([base44.entities.Game.filter({ id })]);
      if (!games[0]) { setLoading(false); return; }
      const g = games[0];
      setGame(g);
      const [ht, at] = await Promise.all([
        g.home_team_id ? base44.entities.Team.filter({ id: g.home_team_id }) : Promise.resolve([]),
        g.away_team_id ? base44.entities.Team.filter({ id: g.away_team_id }) : Promise.resolve([]),
      ]);
      setHomeTeam(ht[0] || null);
      setAwayTeam(at[0] || null);
      setLoading(false);
      // Load players for pitcher picker and live view
      const teamIds = [g.home_team_id, g.away_team_id].filter(Boolean);
      if (g.status === 'in_progress') {
        Promise.all([
          ...teamIds.map(tid => base44.entities.Player.filter({ team_id: tid })),
          base44.entities.GameEvent.filter({ game_id: id }),
        ]).then(results => {
          const evts = results.pop();
          setPlayers(results.flat());
          setEvents(evts.sort((a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0)).slice(0, 20));
        }).catch(() => {});
      } else if (teamIds.length) {
        Promise.all(teamIds.map(tid => base44.entities.Player.filter({ team_id: tid })))
          .then(results => setPlayers(results.flat()))
          .catch(() => {});
      }
    };
    load();
  }, [id]);

  // Subscribe to new game events for live play-by-play
  useEffect(() => {
    const unsub = base44.entities.GameEvent.subscribe(evt => {
      if (evt.data?.game_id === id && evt.type === 'create') {
        setEvents(prev => [evt.data, ...prev].slice(0, 20));
      }
    });
    return unsub;
  }, [id]);

  useEffect(() => {
    if (!id) return;
    const unsub = base44.entities.Game.subscribe(evt => {
      if (evt.id === id && evt.type !== 'delete' && evt.data) setGame(evt.data);
    });
    return unsub;
  }, [id]);

  const isAdmin = user && game && (
    user.role === 'admin' ||
    homeTeam?.coach_email === user.email ||
    (homeTeam?.admin_emails || []).includes(user.email) ||
    awayTeam?.coach_email === user.email ||
    (awayTeam?.admin_emails || []).includes(user.email)
  );

  // The team this user actually manages — independent of home/away assignment
  const managedTeam = user && game ? (
    (homeTeam?.coach_email === user.email || (homeTeam?.admin_emails || []).includes(user.email)) ? homeTeam :
    (awayTeam?.coach_email === user.email || (awayTeam?.admin_emails || []).includes(user.email)) ? awayTeam :
    homeTeam // super admin fallback
  ) : null;
  const managedTeamId = managedTeam?.id;

  const swapTeams = async () => {
    setSwapping(true);
    try {
      // Swap inning_scores team labels too
      const swappedInningScores = (game.inning_scores || []).map(entry => ({
        ...entry,
        team: entry.team === 'home' ? 'away' : 'home',
      }));

      await base44.entities.Game.update(id, {
        home_team_id: game.away_team_id,
        away_team_id: game.home_team_id,
        home_team_name: game.away_team_name,
        away_team_name: game.home_team_name,
        home_game_manager_email: game.away_game_manager_email,
        away_game_manager_email: game.home_game_manager_email,
        home_stream_url: game.away_stream_url,
        away_stream_url: game.home_stream_url,
        home_lineup: game.away_lineup,
        away_lineup: game.home_lineup,
        home_score: game.away_score ?? 0,
        away_score: game.home_score ?? 0,
        home_hits: game.away_hits ?? 0,
        away_hits: game.home_hits ?? 0,
        home_errors: game.away_errors ?? 0,
        away_errors: game.home_errors ?? 0,
        home_batting_order_idx: game.away_batting_order_idx ?? 0,
        away_batting_order_idx: game.home_batting_order_idx ?? 0,
        inning_scores: swappedInningScores,
      });
      toast.success('Home and away teams switched.');
    } catch {
      toast.error('Failed to switch teams');
    } finally {
      setSwapping(false);
      setShowSwapConfirm(false);
    }
  };

  const startGame = async () => {
    await base44.entities.Game.update(id, { status: 'in_progress' });
    navigate(`/games/${id}/score`);
    toast.success('Game started!');
  };

  const handleSetPitcher = async (player) => {
    setSavingPitcher(true);
    try {
      const updates = {
        current_pitcher_id: player.id,
        current_pitcher_name: player.name,
        current_pitcher_pitch_count: 0,
      };
      await base44.entities.Game.update(id, updates);
      setGame(prev => ({ ...prev, ...updates }));
      toast.success(`${player.name} set as pitcher`);
      setShowPitcherPicker(false);
    } catch {
      toast.error('Failed to set pitcher');
    } finally {
      setSavingPitcher(false);
    }
  };

  if (!id || id === ':id') return <div className="p-6 text-center text-muted-foreground">Invalid game link.</div>;
  if (loading) return <div className="p-6 text-center text-muted-foreground">Loading...</div>;
  if (!game) return <div className="p-6 text-center text-muted-foreground">Game not found</div>;

  return (
    <div className="pb-24 lg:pb-8">
      {/* Hero score card */}
      <div className="bg-gradient-to-br from-[hsl(214,90%,18%)] to-[hsl(214,90%,28%)] text-white relative">
        <div className="px-4 pt-4 pb-6">
          <div className="flex items-center gap-3 mb-4">
            <button onClick={() => navigate(-1)} className="p-2 rounded-full bg-white/10 select-none touch-manipulation">
              <ArrowLeft className="w-4 h-4" />
            </button>
            <Badge className={game.status === 'in_progress' ? 'bg-green-500/80 text-white border-0' : (game.status === 'completed' || game.status === 'final') ? 'bg-white/20 text-white border-0' : 'bg-blue-500/80 text-white border-0'}>
              {game.status === 'in_progress' ? '🔴 Live' : (game.status === 'completed' || game.status === 'final') ? 'Final' : 'Scheduled'}
            </Badge>
          </div>

          {/* Teams & Score */}
          <div className="flex items-center justify-between gap-2 mb-4">
            <div className="text-center flex-1">
              <div className="w-14 h-14 rounded-xl mx-auto mb-2 flex items-center justify-center text-lg font-bold"
                style={{ backgroundColor: awayTeam?.primary_color || '#374151' }}>
                {(game.away_team_name || '?').slice(0, 2).toUpperCase()}
              </div>
              <div className="font-semibold text-sm leading-tight">{game.away_team_name}</div>
              <div className="text-white/60 text-xs">Away</div>
            </div>

            <div className="text-center px-2">
              <div className="font-bebas text-6xl tracking-wider leading-none">
                {game.away_score ?? 0}–{game.home_score ?? 0}
              </div>
              {game.status === 'in_progress' && (
                <div className="text-white/70 text-xs mt-1">
                  Inn. {game.inning} {game.inning_half === 'top' ? '▲' : '▼'} • {game.outs} out{game.outs !== 1 ? 's' : ''}
                </div>
              )}
            </div>

            <div className="text-center flex-1">
              <div className="w-14 h-14 rounded-xl mx-auto mb-2 flex items-center justify-center text-lg font-bold"
                style={{ backgroundColor: homeTeam?.primary_color || '#1e3a8a' }}>
                {(game.home_team_name || '?').slice(0, 2).toUpperCase()}
              </div>
              <div className="font-semibold text-sm leading-tight">{game.home_team_name}</div>
              <div className="text-white/60 text-xs">Home</div>
            </div>
          </div>

          {/* Game meta */}
          <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-sm text-white/70">
            <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {game.scheduled_date}</span>
            {game.scheduled_time && <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {game.scheduled_time}</span>}
            {game.arrival_time && <span className="flex items-center gap-1 text-amber-300"><Clock className="w-3.5 h-3.5" /> Arrive: {game.arrival_time}</span>}
            {game.location && (
              game.field_address
                ? <a href={`https://www.google.com/maps/search/${encodeURIComponent(game.field_address)}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-white/70 hover:text-white">
                    <Navigation className="w-3.5 h-3.5" /> {game.location}
                  </a>
                : <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {game.location}</span>
            )}
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4 max-w-3xl mx-auto">
        {/* Scoreboard */}
        {game.status !== 'scheduled' && game.status !== 'postponed' && game.status !== 'cancelled' && <Scoreboard game={game} />}

        {/* Game Highlights — completed games only */}
        {(game.status === 'final' || game.status === 'completed') && <GameHighlights game={game} />}

        {/* Admin Actions — prominent on mobile */}
        {isAdmin && (
          <div className="bg-card border border-border rounded-2xl p-4">
            <h3 className="font-semibold text-xs text-muted-foreground uppercase tracking-wide mb-3">Game Management</h3>
            <div className="grid grid-cols-2 gap-2">
              {game.status === 'scheduled' && (
                <Button onClick={startGame} className="gap-2 bg-green-600 hover:bg-green-700 text-white col-span-2 h-12 text-base select-none touch-manipulation">
                  <Play className="w-5 h-5" /> Start Game & Score
                </Button>
              )}
              {game.status === 'in_progress' && (
                <Link to={`/games/${id}/score`} className="col-span-2">
                  <Button className="gap-2 bg-green-600 hover:bg-green-700 text-white w-full h-12 text-base select-none touch-manipulation">
                    <Play className="w-5 h-5" /> Continue Scoring
                  </Button>
                </Link>
              )}
              <Link to={`/games/${id}/lineup`}>
                <Button variant="outline" className="gap-2 w-full select-none touch-manipulation"><Users className="w-4 h-4" /> Lineup</Button>
              </Link>
              <Button variant="outline" className="gap-2 select-none touch-manipulation" onClick={() => setShowOpponentImporter(true)}>
                <Camera className="w-4 h-4" /> Opponent Lineup
              </Button>
              <Button variant="outline" className="gap-2 select-none touch-manipulation" onClick={() => setShowPitcherPicker(true)}>
                <Flame className="w-4 h-4" />
                {game.current_pitcher_name ? `P: ${game.current_pitcher_name}` : 'Set Pitcher'}
              </Button>
              {game.status === 'scheduled' && (
                <Button variant="outline" className="gap-2 select-none touch-manipulation" onClick={() => setShowSwapConfirm(true)}>
                  <ArrowLeftRight className="w-4 h-4" /> Switch Home/Away
                </Button>
              )}
              <Link to={`/games/${id}/stream`}>
                <Button variant="outline" className="gap-2 w-full select-none touch-manipulation"><Video className="w-4 h-4" /> Watch the Stream</Button>
              </Link>
              <Button variant="outline" className="gap-2 select-none touch-manipulation" onClick={() => setShowQR(true)}>
                <QrCode className="w-4 h-4" /> Share
              </Button>
              <Link to={`/games/${id}/public`} target="_blank">
                <Button variant="outline" className="gap-2 w-full select-none touch-manipulation">📺 Watch Game</Button>
              </Link>
              {game.status === 'in_progress' && (
                <Link to={`/games/${id}/coach`} className="col-span-2">
                  <Button variant="outline" className="gap-2 w-full select-none touch-manipulation">📋 Coach Dashboard</Button>
                </Link>
              )}
            </div>
          </div>
        )}

        {/* RSVP Summary — only show for the admin's managed team */}
        {isAdmin && game.status === 'scheduled' && managedTeamId && (
          <div className="bg-card border border-border rounded-2xl p-4">
            <h3 className="font-semibold mb-4 flex items-center gap-2 text-sm"><CheckSquare className="w-4 h-4" /> RSVP Summary — {managedTeam?.name}</h3>
            <RSVPSummary gameId={id} teamId={managedTeamId} />
          </div>
        )}

        {/* Tournament info */}
        {game.tournament_name && (
          <div className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-50 flex items-center justify-center flex-shrink-0">
              <Trophy className="w-4 h-4 text-amber-500" />
            </div>
            <div className="min-w-0">
              <div className="text-xs text-muted-foreground uppercase tracking-wide font-medium">Tournament</div>
              {game.tournament_link ? (
                <a href={game.tournament_link} target="_blank" rel="noopener noreferrer" className="font-semibold text-primary hover:underline truncate block">{game.tournament_name}</a>
              ) : (
                <div className="font-semibold truncate">{game.tournament_name}</div>
              )}
            </div>
          </div>
        )}

        {/* Notes */}
        {game.notes && (
          <div className="bg-card border border-border rounded-2xl p-4">
            <div className="text-xs text-muted-foreground uppercase tracking-wide font-medium mb-1">Notes</div>
            <p className="text-sm text-foreground whitespace-pre-line">{game.notes}</p>
          </div>
        )}

        {/* Inline RSVP — for parents of players on the managed team */}
        {game.status === 'scheduled' && <InlineRSVP game={game} managedTeamId={managedTeamId} />}

        {/* Live fan view — field, batter, play-by-play */}
        {!isAdmin && game.status === 'in_progress' && (() => {
          const r1 = game.runner_first, r2 = game.runner_second, r3 = game.runner_third;
          const balls = game.balls ?? 0, strikes = game.strikes ?? 0, outs = game.outs ?? 0;
          const batter = game.current_batter_id ? players.find(p => p.id === game.current_batter_id) : null;
          const fmt = avg => avg > 0 ? '.' + String(Math.round(avg * 1000)).padStart(3, '0') : null;

          return (
            <>
              {/* Field + Count */}
              <div className="bg-card border border-border rounded-2xl p-4">
                <div className="flex items-center gap-4">
                  <div className="flex-shrink-0">
                    <svg viewBox="0 0 160 160" width="130" height="130">
                      <path d="M 80 140 L 20 80 Q 80 10 140 80 Z" fill="#86EFAC" opacity="0.3" />
                      <polygon points="80,40 130,90 80,140 30,90" fill="#D4A064" opacity="0.35" />
                      <line x1="80" y1="140" x2="20" y2="80" stroke="#94A3B8" strokeWidth="0.8" opacity="0.5" />
                      <line x1="80" y1="140" x2="140" y2="80" stroke="#94A3B8" strokeWidth="0.8" opacity="0.5" />
                      {[
                        { filled: false, cx: 80, cy: 140 },
                        { filled: r1, cx: 130, cy: 90 },
                        { filled: r2, cx: 80, cy: 40 },
                        { filled: r3, cx: 30, cy: 90 },
                      ].map(({ filled, cx, cy }, i) => (
                        <g key={i}>
                          <rect x={cx - 9} y={cy - 9} width={18} height={18} rx={2}
                            fill={filled ? '#1D4ED8' : 'white'}
                            stroke={filled ? '#1D4ED8' : '#CBD5E1'}
                            strokeWidth={filled ? 0 : 1.5}
                            transform={`rotate(45, ${cx}, ${cy})`} />
                          {filled && <circle cx={cx} cy={cy} r={16} fill="#3B82F6" opacity="0.2" />}
                        </g>
                      ))}
                      <circle cx={80} cy={95} r={5} fill="#C8935A" opacity="0.6" />
                    </svg>
                  </div>
                  <div className="flex-1 space-y-2.5">
                    {[
                      { label: 'Balls', count: balls, max: 4, color: 'bg-green-500 border-green-500' },
                      { label: 'Strikes', count: strikes, max: 3, color: 'bg-yellow-400 border-yellow-400' },
                      { label: 'Outs', count: outs, max: 3, color: 'bg-red-500 border-red-500' },
                    ].map(({ label, count, max, color }) => (
                      <div key={label}>
                        <div className="text-xs text-muted-foreground font-semibold uppercase tracking-wider mb-1">{label}</div>
                        <div className="flex gap-1.5">
                          {Array.from({ length: max }, (_, i) => (
                            <div key={i} className={`w-4 h-4 rounded-full border-2 transition-all ${i < count ? color : 'border-border bg-muted'}`} />
                          ))}
                        </div>
                      </div>
                    ))}
                    <div className="text-xs text-muted-foreground pt-0.5 border-t border-border">
                      {r1 || r2 || r3
                        ? <span className="text-primary font-medium">On: {[r1 && '1st', r2 && '2nd', r3 && '3rd'].filter(Boolean).join(', ')}</span>
                        : <span>Bases empty</span>}
                    </div>
                  </div>
                </div>
              </div>

              {/* Current Batter */}
              <div className="bg-gradient-to-br from-[hsl(214,90%,22%)] to-[hsl(214,90%,32%)] rounded-2xl p-4 text-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-blue-200">At Bat</div>
                  {game.current_pitcher_name && (
                    <div className="text-xs text-blue-200">
                      vs <span className="font-semibold text-white">{game.current_pitcher_name}</span>
                      {game.current_pitcher_pitch_count > 0 && <span className="text-blue-300 ml-1">({game.current_pitcher_pitch_count}p)</span>}
                    </div>
                  )}
                </div>
                {batter ? (
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center flex-shrink-0">
                      {batter.photo_thumb_url
                        ? <img src={batter.photo_thumb_url} alt={batter.name} className="w-full h-full object-cover rounded-xl" />
                        : <span className="text-lg font-black">#{batter.number}</span>}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-base leading-tight truncate">{batter.name}</div>
                      <div className="text-blue-200 text-xs">{batter.position} · {batter.bats === 'L' ? 'Bats Left' : batter.bats === 'S' ? 'Switch' : 'Bats Right'}</div>
                      {fmt(batter.batting_avg) && (
                        <div className="mt-1 flex gap-2 text-xs">
                          <span className="bg-white/10 px-2 py-0.5 rounded-full font-semibold">{fmt(batter.batting_avg)} AVG</span>
                          {batter.home_runs > 0 && <span className="bg-white/10 px-2 py-0.5 rounded-full font-semibold">{batter.home_runs} HR</span>}
                          {batter.rbis > 0 && <span className="bg-white/10 px-2 py-0.5 rounded-full font-semibold">{batter.rbis} RBI</span>}
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-blue-300 text-sm">
                    <User className="w-4 h-4" /> No batter info
                  </div>
                )}
              </div>

              {/* Play by Play */}
              {events.length > 0 && (
                <div className="bg-card border border-border rounded-2xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-border flex items-center gap-2">
                    <Activity className="w-3.5 h-3.5 text-primary" />
                    <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Play by Play</h3>
                  </div>
                  <div className="divide-y divide-border max-h-64 overflow-y-auto">
                    {events.map((evt, i) => {
                      const dotColor = evt.event_type === 'run' ? 'bg-green-500' : evt.event_type === 'out' ? 'bg-red-400' : evt.event_type === 'hit' ? 'bg-amber-400' : 'bg-muted-foreground/30';
                      const textColor = evt.event_type === 'run' ? 'text-green-600' : evt.event_type === 'out' ? 'text-red-500' : evt.event_type === 'hit' ? 'text-amber-600' : 'text-foreground';
                      return (
                        <div key={evt.id || i} className="flex items-start gap-3 px-4 py-2.5">
                          <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${dotColor}`} />
                          <span className={`text-sm font-medium flex-1 ${textColor}`}>{evt.description}</span>
                          <span className="text-xs text-muted-foreground flex-shrink-0 mt-0.5">{evt.inning}{evt.inning_half === 'top' ? '▲' : '▼'}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          );
        })()}

        {/* Non-admin quick actions */}
        {!isAdmin && (
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" className="gap-2 select-none touch-manipulation" onClick={() => setShowQR(true)}>
              <QrCode className="w-4 h-4" /> Share Live
            </Button>
            <Link to={`/games/${id}/public`} target="_blank">
              <Button variant="outline" className="gap-2 w-full select-none touch-manipulation">📺 Watch Game</Button>
            </Link>
          </div>
        )}
      </div>

      {showQR && <QRCodeModal team={{ name: `Game ${id}`, share_code: game.public_token }} onClose={() => setShowQR(false)} />}

      {showOpponentImporter && (() => {
        // Determine opponent team — the team the admin does NOT belong to
        const isHomeAdmin = homeTeam?.coach_email === user?.email || (homeTeam?.admin_emails || []).includes(user?.email) || user?.role === 'admin';
        const opponentTeamId = isHomeAdmin ? game.away_team_id : game.home_team_id;
        const opponentIsHome = isHomeAdmin ? false : true;
        const lineupField = opponentIsHome ? 'home_lineup' : 'away_lineup';
        return (
          <OpponentLineupImporter
            game={game}
            opponentTeamId={opponentTeamId}
            isOpponentHome={opponentIsHome}
            existingPlayers={players}
            onConfirm={async (lineupIds) => {
              await base44.entities.Game.update(id, { [lineupField]: lineupIds });
              setGame(prev => ({ ...prev, [lineupField]: lineupIds }));
              setShowOpponentImporter(false);
              toast.success('Opponent lineup saved!');
            }}
            onClose={() => setShowOpponentImporter(false)}
          />
        );
      })()}

      {/* Pitcher Picker Modal */}
      {showPitcherPicker && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0">
          <div className="bg-card border border-border rounded-t-2xl w-full max-w-lg shadow-xl flex flex-col max-h-[75vh]">
            <div className="px-5 pt-4 pb-3 border-b border-border flex items-center justify-between flex-shrink-0">
              <div>
                <h2 className="font-bold text-base">Set Pitcher</h2>
                {game.current_pitcher_name && (
                  <p className="text-xs text-muted-foreground mt-0.5">Current: {game.current_pitcher_name} ({game.current_pitcher_pitch_count || 0} pitches)</p>
                )}
              </div>
              <Button variant="ghost" size="sm" onClick={() => setShowPitcherPicker(false)}>✕</Button>
            </div>
            <div className="overflow-y-auto flex-1 p-3 space-y-1.5">
              {/* Pitching team — fielding team is opposite of who's batting */}
              {(() => {
                const isTop = game.inning_half === 'top';
                // Fielding team pitches — home pitches in top, away pitches in bottom
                const pitchingTeamId = isTop ? game.home_team_id : game.away_team_id;
                const pitchingTeamName = isTop ? game.home_team_name : game.away_team_name;
                // For scheduled games, let admin pick from either team
                const eligible = players.filter(p => p.team_id === pitchingTeamId);
                if (eligible.length === 0) return (
                  <p className="text-sm text-muted-foreground text-center py-6">No players loaded yet. Start the game first to load rosters.</p>
                );
                return (
                  <>
                    {game.status !== 'scheduled' && (
                      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide px-1 mb-2">{pitchingTeamName} — Pitching</p>
                    )}
                    {eligible.map(p => (
                      <button
                        key={p.id}
                        disabled={savingPitcher}
                        onClick={() => handleSetPitcher(p)}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border transition-all select-none touch-manipulation text-left ${
                          p.id === game.current_pitcher_id
                            ? 'border-primary bg-primary/5 text-primary font-semibold'
                            : 'border-border hover:bg-muted'
                        }`}>
                        <span className="font-bold text-sm w-8 flex-shrink-0">#{p.number}</span>
                        <span className="flex-1 text-sm">{p.name}</span>
                        <span className="text-xs text-muted-foreground">{p.position}</span>
                        {p.id === game.current_pitcher_id && <span className="text-xs font-bold text-primary ml-1">● Current</span>}
                      </button>
                    ))}
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {showSwapConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-card border border-border rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-xl">
            <h2 className="font-bold text-lg">Switch Home and Away?</h2>
            <p className="text-sm text-muted-foreground">
              This will swap <strong>{game.home_team_name}</strong> and <strong>{game.away_team_name}</strong>. All lineup and game manager assignments will also be switched.
            </p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setShowSwapConfirm(false)}>Cancel</Button>
              <Button className="flex-1 gap-2" disabled={swapping} onClick={swapTeams}>
                <ArrowLeftRight className="w-4 h-4" />
                {swapping ? 'Switching...' : 'Switch Teams'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}