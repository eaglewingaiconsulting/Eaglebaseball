import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Building2, Users, Store, Loader2, UserMinus, UserPlus, X, Palette, CheckCircle, AlertTriangle, ChevronRight } from 'lucide-react';
import LogoBrandingEditor from '@/components/teams/LogoBrandingEditor';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import OrgStoreManager from '@/components/org/OrgStoreManager';
import OrgTeamDetail from '@/components/org/OrgTeamDetail';
import TeamGrid from '@/components/hub/TeamGrid';

function hslFromHex(hex) {
  let r = parseInt(hex.slice(1, 3), 16) / 255;
  let g = parseInt(hex.slice(3, 5), 16) / 255;
  let b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

export default function OrgDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [org, setOrg] = useState(null);
  const [teams, setTeams] = useState([]);
  const [playerCounts, setPlayerCounts] = useState({});
  const [duesStatus, setDuesStatus] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('teams'); // 'teams' | 'store'
  const [selectedTeamId, setSelectedTeamId] = useState(null);
  const [showRemoveCoach, setShowRemoveCoach] = useState(null);
  const [showAssignCoach, setShowAssignCoach] = useState(null);
  const [newCoachEmail, setNewCoachEmail] = useState('');
  const [saving, setSaving] = useState(false);
  const [showBranding, setShowBranding] = useState(false);
  const [brandingDraft, setBrandingDraft] = useState({});
  const [savingBranding, setSavingBranding] = useState(false);

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    const orgs = await base44.entities.Organization.filter({ owner_email: user.email });
    const myOrg = orgs[0];
    if (!myOrg) { setLoading(false); return; }
    setOrg(myOrg);

    const orgTeams = await base44.entities.Team.filter({ org_id: myOrg.id });
    const sorted = [...orgTeams].sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    setTeams(sorted);

    // Fetch player counts and dues status per team
    const counts = {};
    const dues = {};
    await Promise.all(sorted.map(async (team) => {
      const players = await base44.entities.Player.filter({ team_id: team.id });
      counts[team.id] = players.length;

      if (players.length > 0) {
        const paidOrders = await base44.entities.TeamStoreOrder.filter({
          team_id: team.id,
          item_name: 'Organization Dues',
          payment_status: 'Paid',
        });
        dues[team.id] = paidOrders.length >= players.length ? 'green' : 'yellow';
      } else {
        dues[team.id] = 'none';
      }
    }));
    setPlayerCounts(counts);
    setDuesStatus(dues);
    setLoading(false);
  };

  const handleRemoveCoach = async (team) => {
    setSaving(true);
    await base44.entities.Team.update(team.id, { coach_email: null });
    setTeams(prev => prev.map(t => t.id === team.id ? { ...t, coach_email: null } : t));
    setShowRemoveCoach(null);
    setSaving(false);
    toast.success('Coach removed');
  };

  const openOrgBranding = () => {
    setBrandingDraft({ logo_url: org.logo_url || '', primary_color: org.primary_color || '#1e3a8a', secondary_color: org.secondary_color || '#f59e0b' });
    setShowBranding(true);
  };

  const saveOrgBranding = async () => {
    setSavingBranding(true);
    await base44.entities.Organization.update(org.id, brandingDraft);
    setOrg(o => ({ ...o, ...brandingDraft }));
    
    // Apply colors to CSS immediately
    const root = document.documentElement;
    if (brandingDraft.primary_color?.startsWith('#')) {
      root.style.setProperty('--primary', hslFromHex(brandingDraft.primary_color));
    }
    if (brandingDraft.secondary_color?.startsWith('#')) {
      root.style.setProperty('--accent', hslFromHex(brandingDraft.secondary_color));
    }
    
    setShowBranding(false);
    setSavingBranding(false);
    toast.success('Org branding updated!');
  };

  const handleAssignCoach = async (team) => {
    if (!newCoachEmail.trim()) { toast.error('Enter an email'); return; }
    setSaving(true);
    await base44.entities.Team.update(team.id, { coach_email: newCoachEmail.trim() });
    setTeams(prev => prev.map(t => t.id === team.id ? { ...t, coach_email: newCoachEmail.trim() } : t));
    setShowAssignCoach(null);
    setNewCoachEmail('');
    setSaving(false);
    toast.success('Coach assigned');
  };

  if (loading) return (
    <div className="flex items-center justify-center min-h-64">
      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
    </div>
  );

  if (!org) return (
    <div className="p-6 text-center space-y-3">
      <Building2 className="w-10 h-10 mx-auto text-muted-foreground" />
      <p className="text-muted-foreground">No organization found. Set one up first.</p>
      <Button onClick={() => navigate('/onboarding')}>Create Organization</Button>
    </div>
  );

  if (selectedTeamId) {
    return (
      <OrgTeamDetail
        teamId={selectedTeamId}
        orgId={org.id}
        onBack={() => setSelectedTeamId(null)}
      />
    );
  }

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
    <div className="p-4 max-w-4xl mx-auto space-y-5">
      {/* Org Header */}
      <div className="bg-gradient-to-br from-[hsl(214,90%,18%)] to-[hsl(214,90%,30%)] rounded-2xl p-5 text-white">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-xl flex-shrink-0 overflow-hidden flex items-center justify-center bg-white/20">
            {org.logo_url
              ? <img src={org.logo_url} alt={org.name} className="w-full h-full object-contain" />
              : <Building2 className="w-6 h-6 text-white" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-semibold text-white/50 tracking-widest uppercase mb-0.5">Org Hub</div>
            <h1 className="text-xl font-bold">{org.name}</h1>
            <p className="text-white/60 text-sm">{teams.length} teams</p>
          </div>
          <button
            onClick={openOrgBranding}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-sm font-medium text-white transition-colors select-none touch-manipulation"
          >
            <Palette className="w-4 h-4" /> Branding
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12 }}>
        {[
          { id: 'teams', label: 'Teams', icon: Users },
          { id: 'store', label: 'Org Store', icon: Store },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium transition-colors select-none"
            style={{ backgroundColor: activeTab === tab.id ? '#F59E0B' : 'rgba(255,255,255,0.04)', color: activeTab === tab.id ? '#0B1120' : 'rgba(255,255,255,0.6)', fontWeight: activeTab === tab.id ? 700 : 400 }}
          >
            <tab.icon className="w-4 h-4" /> {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'teams' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">All Teams</h2>
            <Link to="/teams/create">
              <Button size="sm" className="gap-1.5"><Users className="w-3.5 h-3.5" /> New Team</Button>
            </Link>
          </div>

          {/* Team tiles grid */}
          <TeamGrid teams={teams} groupBy="age_season" emptyLabel="No teams yet. Create one above." />

          {/* Coach management per team */}
          {teams.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-widest mt-2" style={{ color: 'rgba(255,255,255,0.4)' }}>Coach Assignments</h3>
              {teams.map(team => (
                <div key={team.id} className="rounded-xl p-3 flex items-center gap-3" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm">{team.name}</span>
                      {duesStatus[team.id] === 'green' && <CheckCircle className="w-3.5 h-3.5 text-green-500" />}
                      {duesStatus[team.id] === 'yellow' && <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />}
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>
                      {team.coach_email ? team.coach_email : 'No coach assigned'} · {playerCounts[team.id] || 0} players
                    </div>
                  </div>
                  <div className="flex gap-1.5">
                    <Button size="sm" variant="outline" className="gap-1 text-xs h-7 px-2"
                      onClick={() => { setShowAssignCoach(team); setNewCoachEmail(team.coach_email || ''); }}>
                      <UserPlus className="w-3 h-3" /> {team.coach_email ? 'Reassign' : 'Assign'}
                    </Button>
                    {team.coach_email && (
                      <Button size="sm" variant="outline" className="gap-1 text-xs h-7 px-2 text-destructive border-destructive/30 hover:bg-destructive/10"
                        onClick={() => setShowRemoveCoach(team)}>
                        <UserMinus className="w-3 h-3" />
                      </Button>
                    )}
                    <button onClick={() => setSelectedTeamId(team.id)} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
                      <ChevronRight className="w-4 h-4 text-muted-foreground" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'store' && <OrgStoreManager org={org} />}
    </div>

      {/* Remove Coach Modal */}
      {showRemoveCoach && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
            <h2 className="font-bold text-lg">Remove Coach?</h2>
            <p className="text-sm text-muted-foreground">
              Remove <strong>{showRemoveCoach.coach_email}</strong> as coach of <strong>{showRemoveCoach.name}</strong>? The team data will be preserved.
            </p>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowRemoveCoach(null)}>Cancel</Button>
              <Button variant="destructive" className="flex-1 gap-1.5" onClick={() => handleRemoveCoach(showRemoveCoach)} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserMinus className="w-4 h-4" />}
                Remove
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Org Branding Modal */}
      {showBranding && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-lg flex items-center gap-2"><Palette className="w-5 h-5" /> Org Branding</h2>
              <button onClick={() => setShowBranding(false)} className="p-1.5 rounded-lg hover:bg-muted"><X className="w-4 h-4" /></button>
            </div>
            <LogoBrandingEditor
              logoUrl={brandingDraft.logo_url}
              primaryColor={brandingDraft.primary_color}
              secondaryColor={brandingDraft.secondary_color}
              name={org.name}
              onChange={updates => setBrandingDraft(d => ({ ...d, ...updates }))}
            />
            <div className="flex gap-2 pt-1">
              <button onClick={() => setShowBranding(false)} className="flex-1 py-2 rounded-lg border border-border bg-muted hover:bg-secondary text-sm font-medium select-none">Cancel</button>
              <button onClick={saveOrgBranding} disabled={savingBranding} className="flex-1 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium select-none disabled:opacity-60">
                {savingBranding ? 'Saving…' : 'Save Branding'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Assign Coach Modal */}
      {showAssignCoach && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-lg">Assign Coach</h2>
              <button onClick={() => setShowAssignCoach(null)}><X className="w-4 h-4" /></button>
            </div>
            <p className="text-sm text-muted-foreground">Enter the email of the coach for <strong>{showAssignCoach.name}</strong>.</p>
            <Input
              placeholder="coach@email.com"
              value={newCoachEmail}
              onChange={e => setNewCoachEmail(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAssignCoach(showAssignCoach)}
            />
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowAssignCoach(null)}>Cancel</Button>
              <Button className="flex-1 gap-1.5" onClick={() => handleAssignCoach(showAssignCoach)} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
                Assign
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}