import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Search } from 'lucide-react';

export default function Stats() {
  const [players, setPlayers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [view, setView] = useState('batting');
  const [teamFilter, setTeamFilter] = useState('all');

  useEffect(() => {
    Promise.all([
      base44.entities.Player.list('-batting_avg', 200),
      base44.entities.Team.list('-wins', 50),
    ]).then(([p, t]) => {
      setPlayers(p);
      setTeams(t);
      setLoading(false);
    });
  }, []);

  const teamMap = {};
  teams.forEach(t => { teamMap[t.id] = t.name; });

  const filtered = players.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchTeam = teamFilter === 'all' || p.team_id === teamFilter;
    return matchSearch && matchTeam;
  });

  const calcOBP = (p) => {
    const ab = p.at_bats || 0, h = p.hits || 0, bb = p.walks || 0;
    const denom = ab + bb;
    return denom > 0 ? (h + bb) / denom : 0;
  };

  const sorted = [...filtered].sort((a, b) => {
    if (view === 'batting') return (b.batting_avg || 0) - (a.batting_avg || 0);
    if (view === 'hr') return (b.home_runs || 0) - (a.home_runs || 0);
    if (view === 'rbi') return (b.rbis || 0) - (a.rbis || 0);
    if (view === 'era') return (a.era || 0) - (b.era || 0);
    if (view === 'k') return (b.strikeouts_pitching || 0) - (a.strikeouts_pitching || 0);
    if (view === 'obp') return calcOBP(b) - calcOBP(a);
    if (view === 'sb') return (b.stolen_bases || 0) - (a.stolen_bases || 0);
    return 0;
  });

  const STAT_TABS = [
    { id: 'batting', label: 'AVG' },
    { id: 'obp', label: 'OBP' },
    { id: 'hr', label: 'HR' },
    { id: 'rbi', label: 'RBI' },
    { id: 'sb', label: 'SB' },
    { id: 'era', label: 'ERA' },
    { id: 'k', label: 'K (P)' },
  ];

  return (
    <div style={{ backgroundColor: '#0B1120', minHeight: '100vh', color: '#fff' }} className="pb-24 lg:pb-8">
      <div className="px-4 pt-6 pb-4 max-w-6xl mx-auto space-y-5">
        {/* Header */}
        <div>
          <h1 className="font-bebas tracking-widest" style={{ fontSize: 40, letterSpacing: '0.08em' }}>Statistics</h1>
          <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>League-wide player statistics</p>
        </div>

        {/* Search + team filter */}
        <div className="flex flex-wrap gap-2">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'rgba(255,255,255,0.35)' }} />
            <input
              placeholder="Search players..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm outline-none"
              style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#fff' }}
            />
          </div>
          <select
            value={teamFilter}
            onChange={e => setTeamFilter(e.target.value)}
            className="px-3 py-2 text-sm outline-none"
            style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: 'rgba(255,255,255,0.7)' }}>
            <option value="all">All Teams</option>
            {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>

        {/* Stat type tabs */}
        <div className="flex flex-wrap gap-2">
          {STAT_TABS.map(s => (
            <button key={s.id} onClick={() => setView(s.id)}
              className="px-4 py-2 text-sm font-semibold transition-colors select-none"
              style={{ borderRadius: 8, backgroundColor: view === s.id ? '#F59E0B' : 'rgba(255,255,255,0.07)', color: view === s.id ? '#0B1120' : 'rgba(255,255,255,0.6)', fontWeight: view === s.id ? 700 : 500 }}>
              {s.label}
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="overflow-x-auto" style={{ backgroundColor: '#131929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 12 }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: 'rgba(255,255,255,0.04)', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                {['#','Player','Team','GP','AVG','OBP','HR','RBI','H','BB','SB','ERA','K'].map((col, idx) => (
                  <th key={col}
                    className={`py-3 font-semibold ${idx <= 1 ? 'text-left px-4' : 'text-center px-3'} ${idx >= 8 ? (idx >= 10 ? 'hidden lg:table-cell' : 'hidden sm:table-cell') : ''}`}
                    style={{ color: idx >= 3 ? '#F59E0B' : 'rgba(255,255,255,0.45)' }}>
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={13} className="px-4 py-8 text-center" style={{ color: 'rgba(255,255,255,0.35)' }}>Loading...</td></tr>
              ) : sorted.length === 0 ? (
                <tr><td colSpan={13} className="px-4 py-8 text-center" style={{ color: 'rgba(255,255,255,0.35)' }}>No players found</td></tr>
              ) : sorted.slice(0, 50).map((player, i) => (
                <tr key={player.id} className="transition-colors"
                  style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}
                  onMouseEnter={e => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.04)'}
                  onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}>
                  <td className="px-4 py-3" style={{ color: 'rgba(255,255,255,0.35)' }}>{i + 1}</td>
                  <td className="px-4 py-3">
                    <Link to={`/players/${player.id}`} className="font-semibold text-white hover:text-amber-400 transition-colors">{player.name}</Link>
                    <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>#{player.number} · {player.position}</div>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell" style={{ color: 'rgba(255,255,255,0.4)' }}>{teamMap[player.team_id] || '—'}</td>
                  <td className="px-3 py-3 text-center text-white">{player.games_played || 0}</td>
                  <td className="px-3 py-3 text-center font-bold" style={{ color: '#F59E0B' }}>{(player.batting_avg || 0).toFixed(3)}</td>
                  <td className="px-3 py-3 text-center hidden sm:table-cell text-white">{calcOBP(player).toFixed(3)}</td>
                  <td className="px-3 py-3 text-center text-white">{player.home_runs || 0}</td>
                  <td className="px-3 py-3 text-center text-white">{player.rbis || 0}</td>
                  <td className="px-3 py-3 text-center hidden lg:table-cell text-white">{player.hits || 0}</td>
                  <td className="px-3 py-3 text-center hidden lg:table-cell text-white">{player.walks || 0}</td>
                  <td className="px-3 py-3 text-center hidden lg:table-cell text-white">{player.stolen_bases || 0}</td>
                  <td className="px-3 py-3 text-center hidden lg:table-cell text-white">{(player.era || 0).toFixed(2)}</td>
                  <td className="px-3 py-3 text-center hidden xl:table-cell text-white">{player.strikeouts_pitching || 0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}