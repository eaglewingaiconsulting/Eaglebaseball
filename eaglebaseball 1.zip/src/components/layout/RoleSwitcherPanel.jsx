import { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { useRoleSwitcher, ROLES, isMasterAccount } from '@/lib/RoleSwitcherContext';
import { ChevronDown, ChevronUp, FlaskConical } from 'lucide-react';

export default function RoleSwitcherPanel() {
  const { user } = useAuth(); // always use real user to check master account
  const { activeRoleId, activeRole, setActiveRoleId } = useRoleSwitcher();
  const [open, setOpen] = useState(false);

  if (!user || !isMasterAccount(user.email)) return null;

  const handleSelect = (role) => {
    setActiveRoleId(role.id);
    setOpen(false);
    // Reload to flush all cached state
    window.location.replace('/');
  };

  return (
    <div className="mx-1 mb-2">
      {/* Trigger button */}
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl border text-xs font-semibold select-none touch-manipulation transition-colors"
        style={{
          backgroundColor: 'rgba(245,158,11,0.12)',
          borderColor: 'rgba(245,158,11,0.4)',
          color: '#F59E0B',
        }}
      >
        <FlaskConical className="w-3.5 h-3.5 flex-shrink-0" />
        <span className="flex-1 text-left truncate">
          QA: {activeRole.icon} {activeRole.label}
        </span>
        {open ? <ChevronUp className="w-3.5 h-3.5 flex-shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 flex-shrink-0" />}
      </button>

      {/* Dropdown */}
      {open && (
        <div
          className="mt-1 rounded-xl overflow-hidden shadow-xl z-50 relative"
          style={{ backgroundColor: '#0F1729', border: '1px solid rgba(245,158,11,0.25)' }}
        >
          <div className="px-3 py-2 border-b" style={{ borderColor: 'rgba(245,158,11,0.15)', color: 'rgba(255,255,255,0.4)', fontSize: 10, letterSpacing: '0.1em' }}>
            QA ROLE SWITCHER
          </div>
          {ROLES.map(role => {
            const isActive = activeRoleId === role.id;
            return (
              <button
                key={role.id}
                onClick={() => handleSelect(role)}
                className="w-full flex items-center gap-3 px-3 py-3 text-left transition-colors select-none touch-manipulation"
                style={{
                  backgroundColor: isActive ? 'rgba(245,158,11,0.18)' : 'transparent',
                  borderBottom: '1px solid rgba(255,255,255,0.05)',
                }}
                onMouseEnter={e => { if (!isActive) e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)'; }}
                onMouseLeave={e => { if (!isActive) e.currentTarget.style.backgroundColor = 'transparent'; }}
              >
                <span style={{ fontSize: 18, lineHeight: 1, width: 22, textAlign: 'center', flexShrink: 0 }}>{role.icon}</span>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: 13, fontWeight: 600, color: isActive ? '#F59E0B' : 'rgba(255,255,255,0.85)' }}>
                    {role.label}
                  </div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 1 }}>
                    {role.description}
                  </div>
                </div>
                {isActive && (
                  <span style={{ fontSize: 10, fontWeight: 700, color: '#F59E0B', flexShrink: 0 }}>ACTIVE</span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}