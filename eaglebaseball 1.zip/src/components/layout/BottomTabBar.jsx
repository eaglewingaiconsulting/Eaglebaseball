import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Users, Calendar, BarChart3, MessageSquare } from 'lucide-react';
import { cn } from '@/lib/utils';
import { base44 } from '@/api/base44Client';

const BASE_TABS = [
  { label: 'Dashboard', icon: Home, path: '/' },
  { label: 'Teams', icon: Users, path: '/teams' },
  { label: 'Games', icon: Calendar, path: '/games' },
  { label: 'Messages', icon: MessageSquare, path: null, dynamic: 'messages' },
  { label: 'Stats', icon: BarChart3, path: '/stats' },
];

export default function BottomTabBar() {
  const location = useLocation();
  const [messagesPath, setMessagesPath] = useState(null);
  const isScoringRoute = /\/games\/[^/]+\/score/.test(location.pathname);

  useEffect(() => {
    base44.entities.Team.list('-created_date', 50).then(teams => {
      if (teams[0]) setMessagesPath(`/teams/${teams[0].id}/messages`);
    }).catch(() => {});
  }, []);

  if (isScoringRoute) return null;

  const tabs = BASE_TABS.map(t => t.dynamic === 'messages' ? { ...t, path: messagesPath || '/teams' } : t);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-sidebar border-t border-sidebar-border pb-safe lg:hidden">
      <div className="flex">
        {tabs.map(tab => {
          const active = tab.path && (location.pathname === tab.path || (tab.path !== '/' && location.pathname.startsWith(tab.path)));
          return (
            <Link
              key={tab.label}
              to={tab.path || '/teams'}
              className={cn(
                "flex-1 flex flex-col items-center justify-center py-2 gap-0.5 text-xs font-medium transition-colors select-none",
                active
                  ? "text-sidebar-primary"
                  : "text-sidebar-foreground/60 hover:text-sidebar-foreground"
              )}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}