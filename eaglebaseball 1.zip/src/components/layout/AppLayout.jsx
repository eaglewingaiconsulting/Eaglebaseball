import { useState, useEffect, useRef } from 'react';
import { Link, useLocation, Outlet, useNavigate } from 'react-router-dom';
import { 
  Home, Users, Calendar, Trophy, BarChart3, Settings, 
  Menu, X, ChevronRight, Shield, Zap, Building2, ShoppingBag, MessageSquare
} from 'lucide-react';
import useEffectiveUser from '@/hooks/useEffectiveUser';
import { useRoleSwitcher, isMasterAccount } from '@/lib/RoleSwitcherContext';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import BottomTabBar from './BottomTabBar';
import PageTransition from './PageTransition';
import RoleSwitcherPanel from './RoleSwitcherPanel';
import FloatingDemoSwitcher from '@/components/demo/FloatingDemoSwitcher';
import { useDemo } from '@/lib/DemoContext';


function TeamLogoHeader({ storeTeamId }) {
  const [team, setTeam] = useState(null);
  useEffect(() => {
    if (!storeTeamId) return;
    base44.entities.Team.get(storeTeamId).then(t => { if (t) setTeam(t); });
  }, [storeTeamId]);

  const initials = team ? team.name.slice(0, 2).toUpperCase() : 'EB';
  return (
    <div className="flex items-center gap-2 select-none">
      {team?.logo_url ? (
        <img src={team.logo_url} alt={team.name} className="w-8 h-8 rounded-md object-contain flex-shrink-0" />
      ) : (
        <div className="w-8 h-8 rounded-md flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
          style={{ backgroundColor: team?.primary_color || 'hsl(214,90%,40%)' }}>
          {initials}
        </div>
      )}
      <span className="font-bebas text-lg tracking-wider">{team?.name || 'EagleBaseball'}</span>
    </div>
  );
}

const navItems = [
  { label: 'Dashboard', icon: Home, path: '/' },
  { label: 'Teams', icon: Users, path: '/teams' },
  { label: 'Games', icon: Calendar, path: '/games' },
  { label: 'Standings', icon: Trophy, path: '/standings' },
  { label: 'Stats', icon: BarChart3, path: '/stats' },
];

// Tab roots — these are the "stack roots" for each bottom tab
const TAB_ROOTS = ['/', '/teams', '/games', '/stats'];

function getActiveTab(pathname) {
  if (pathname === '/' || pathname === '/dashboard') return '/';
  for (const root of TAB_ROOTS) {
    if (root !== '/' && pathname.startsWith(root)) return root;
  }
  return null; // non-tab route (e.g. /settings, /admin)
}

// Routes that are OK even for brand-new users with no team/org
const SETUP_ROUTES = ['/get-started', '/onboarding', '/teams/create', '/settings'];

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isDemoMode, exitDemo } = useDemo();
  const [storeTeamId, setStoreTeamId] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  // Scoring view needs full screen — no sidebar, no topbar
  const isScoringRoute = /\/games\/[^/]+\/score/.test(location.pathname);
  const { user } = useEffectiveUser();
  const { activeRole } = useRoleSwitcher() || {};

  // Scroll preservation: map tab root → saved scrollTop
  const scrollPositions = useRef({});
  const mainRef = useRef(null);
  const prevTabRef = useRef(null);

  const activeTab = getActiveTab(location.pathname);

  useEffect(() => {
    const mainEl = mainRef.current;
    if (!mainEl) return;

    const prevTab = prevTabRef.current;

    // Save scroll of the tab we're leaving
    if (prevTab && prevTab !== activeTab) {
      scrollPositions.current[prevTab] = mainEl.scrollTop;
    }

    // Restore scroll of the tab we're entering (only for tab switches, not deep navigation)
    if (activeTab && prevTab !== activeTab) {
      const saved = scrollPositions.current[activeTab] ?? 0;
      // Use rAF so the content has rendered before we scroll
      requestAnimationFrame(() => {
        if (mainRef.current) mainRef.current.scrollTop = saved;
      });
    }

    prevTabRef.current = activeTab;
  }, [location.pathname, activeTab]);

  // Find the first team the user is a coach/admin of (for Store nav link + new-user redirect)
  const storeTeamFetched = useRef(false);
  useEffect(() => {
    if (!user || storeTeamFetched.current || isDemoMode) return;
    storeTeamFetched.current = true;
    base44.entities.Team.list('-created_date', 50).then(teams => {
      const myTeam = teams.find(t =>
        t.coach_email === user.email ||
        (t.admin_emails || []).includes(user.email)
      ) || teams[0];
      if (myTeam) {
        setStoreTeamId(myTeam.id);
      } else {
        // New user — no team found. Redirect to get-started unless already there.
        const onSetupRoute = SETUP_ROUTES.some(r => location.pathname.startsWith(r));
        if (!onSetupRoute) navigate('/get-started', { replace: true });
      }
    });
  }, [user]);

  const doExit = exitDemo;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Demo banner */}
      {isDemoMode && (
        <div className="flex items-center justify-between bg-amber-500 text-black px-4 py-2 text-sm font-semibold z-50 flex-shrink-0" style={{ zIndex: 9999 }}>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-black/40 animate-pulse" />
            Demo Mode — exploring a sample team
          </div>
          <button
            onClick={doExit}
            className="text-xs bg-black/15 hover:bg-black/25 active:bg-black/30 px-5 rounded-full transition-colors font-bold touch-manipulation select-none"
            style={{
              WebkitTapHighlightColor: 'transparent',
              minWidth: 96,
              minHeight: 48,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
              zIndex: 10000,
            }}
          >
            Exit Demo
          </button>
        </div>
      )}
      <div className="flex flex-1 min-h-0">
      {/* Mobile overlay */}
      {sidebarOpen && !isScoringRoute && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar — hidden on scoring route, otherwise desktop always visible */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-72 bg-sidebar flex flex-col transition-transform duration-300 lg:relative lg:translate-x-0 lg:w-64",
        isScoringRoute ? "hidden" : (sidebarOpen ? "translate-x-0" : "-translate-x-full")
      )}>
        {/* Logo */}
        <div className="p-6 border-b border-sidebar-border">
          <Link to="/" className="flex items-center gap-3 select-none" onClick={() => setSidebarOpen(false)}>
            <div className="w-9 h-9 rounded-lg bg-accent flex items-center justify-center">
              <Zap className="w-5 h-5 text-accent-foreground" />
            </div>
            <div>
              <div className="font-bebas text-xl text-sidebar-primary tracking-wider">Eagle</div>
              <div className="font-bebas text-xs text-sidebar-foreground/60 tracking-widest -mt-1">BASEBALL</div>
            </div>
          </Link>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map(item => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all select-none",
                location.pathname === item.path
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
              )}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {item.label}
              {location.pathname === item.path && <ChevronRight className="w-3 h-3 ml-auto" />}
            </Link>
          ))}

          {(!user || !['parent', 'fan'].includes(user.role)) && !isDemoMode && (
            <>
              <Link
                to="/get-started"
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all mt-4 select-none",
                  location.pathname === '/get-started' || location.pathname === '/onboarding'
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
                )}
              >
                <Building2 className="w-4 h-4 flex-shrink-0" />
                Get Started
              </Link>

              <Link
                to="/org"
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all mt-1 select-none",
                  location.pathname === '/org'
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
                )}
              >
                <Building2 className="w-4 h-4 flex-shrink-0" />
                Org Dashboard
              </Link>
            </>
          )}

          {storeTeamId && (
            <Link
              to={`/teams/${storeTeamId}/messages`}
              onClick={() => setSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all mt-1 select-none",
                location.pathname.includes('/messages')
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
              )}
            >
              <MessageSquare className="w-4 h-4 flex-shrink-0" />
              Team Messages
            </Link>
          )}

          {(!user || !['fan', 'game_manager'].includes(user?.role)) && (
            <Link
              to={storeTeamId ? `/teams/${storeTeamId}/store` : '/teams'}
              onClick={() => setSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all mt-1 select-none",
                location.pathname.includes('/store')
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
              )}
            >
              <ShoppingBag className="w-4 h-4 flex-shrink-0" />
              Team Store
            </Link>
          )}

          {(user?.role === 'admin' || isMasterAccount(user?.email)) && (
            <Link
              to="/admin"
              onClick={() => setSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all mt-2 select-none",
                location.pathname.startsWith('/admin')
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
              )}
            >
              <Shield className="w-4 h-4 flex-shrink-0" />
              Admin Panel
            </Link>
          )}
        </nav>

        {/* User */}
        <div className="p-4 border-t border-sidebar-border pb-safe">
          <Link to="/settings" onClick={() => setSidebarOpen(false)} className={cn(
            "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all select-none",
            location.pathname === '/settings'
              ? "bg-sidebar-accent text-sidebar-accent-foreground"
              : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
          )}>
            <Settings className="w-4 h-4" />
            Settings
          </Link>
          {user && (
            <div className="mt-3 px-3 py-2 rounded-lg bg-sidebar-accent/30">
              <div className="text-xs text-sidebar-foreground/60">Signed in as</div>
              <div className="text-sm font-medium text-sidebar-foreground truncate">{user.email}</div>
            </div>
          )}
          <div className="mt-2">
            <RoleSwitcherPanel />
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar (mobile only, hidden on scoring route) */}
        <header className={cn("h-14 border-b border-border bg-card/95 backdrop-blur-sm flex items-center px-4 gap-3 sticky top-0 z-30 pt-safe shadow-card", isScoringRoute ? "hidden" : "lg:hidden")}>
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg hover:bg-muted select-none">
            <Menu className="w-5 h-5" />
          </button>
          <TeamLogoHeader storeTeamId={storeTeamId} />
          {sidebarOpen && (
            <button onClick={() => setSidebarOpen(false)} className="ml-auto p-2 rounded-lg hover:bg-muted select-none">
              <X className="w-5 h-5" />
            </button>
          )}
        </header>

        <main ref={mainRef} className="flex-1 overflow-auto pb-16 lg:pb-0">
          <PageTransition>
            <Outlet />
          </PageTransition>
        </main>
      </div>

      {/* Bottom Tab Bar — mobile only */}
      <BottomTabBar />
      </div>

      {/* Floating demo role switcher — visible at all times during demo mode */}
      <FloatingDemoSwitcher />


    </div>
  );
}