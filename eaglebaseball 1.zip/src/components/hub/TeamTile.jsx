import { Link } from 'react-router-dom';

export default function TeamTile({ team }) {
  const initials = (team.name || '').slice(0, 2).toUpperCase();
  const record = `${team.wins || 0}W-${team.losses || 0}L`;

  return (
    <Link
      to={`/teams/${team.id}`}
      className="flex flex-col overflow-hidden active:scale-[0.97] transition-all select-none touch-manipulation"
      style={{
        backgroundColor: '#0F1420',
        border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: 12,
      }}
    >
      {/* Logo area — full-bleed team color */}
      <div
        className="w-full flex items-center justify-center relative overflow-hidden"
        style={{ height: 110, backgroundColor: team.primary_color || '#1e3a8a' }}
      >
        {team.logo_url ? (
          <img
            src={team.logo_url}
            alt={team.name}
            className="w-full h-full object-cover"
            style={{ objectPosition: 'center' }}
          />
        ) : (
          <span className="font-bebas text-white/90" style={{ fontSize: 42, letterSpacing: '0.05em' }}>{initials}</span>
        )}
      </div>

      {/* Info */}
      <div className="px-3 py-2.5">
        <div className="font-bold text-white leading-tight line-clamp-2" style={{ fontSize: 14 }}>{team.name}</div>
        {team.season && (
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 2 }}>{team.season}</div>
        )}
        <div
          className="mt-2 inline-block font-bold"
          style={{
            backgroundColor: 'var(--accent)',
            color: 'var(--accent)',
            fontSize: 11,
            padding: '2px 8px',
            borderRadius: 20,
            letterSpacing: '0.03em',
            opacity: 0.15,
          }}
        >
          {record}
        </div>
      </div>
    </Link>
  );
}