import TeamTile from './TeamTile';

/**
 * groupBy: 'age_season' (org/coach) | 'season' (player/fan)
 */
export default function TeamGrid({ teams, groupBy = 'age_season', emptyLabel = 'No teams yet' }) {
  if (teams.length === 0) {
    return (
      <div className="rounded-xl p-8 text-center text-sm" style={{ border: '1px dashed rgba(245,158,11,0.3)', color: 'rgba(255,255,255,0.35)' }}>
        {emptyLabel}
      </div>
    );
  }

  // Build groups
  const groupMap = new Map();
  teams.forEach(team => {
    const key = groupBy === 'age_season'
      ? [team.age_group || 'Unknown Age', team.season || ''].filter(Boolean).join(' · ')
      : (team.season || 'Unknown Season');
    if (!groupMap.has(key)) groupMap.set(key, []);
    groupMap.get(key).push(team);
  });

  // Sort groups: age groups numerically (e.g. 10U before 13U), then season desc
  const sortedGroups = [...groupMap.entries()].sort(([a], [b]) => {
    // Extract age number for sorting
    const ageA = parseInt((a.match(/(\d+)U/) || [])[1] || '99');
    const ageB = parseInt((b.match(/(\d+)U/) || [])[1] || '99');
    if (ageA !== ageB) return ageA - ageB;
    return a.localeCompare(b);
  });

  return (
    <div className="space-y-6">
      {sortedGroups.map(([group, groupTeams]) => (
        <div key={group}>
          <h3 className="text-xs font-bold uppercase tracking-widest mb-3 px-0.5" style={{ color: 'rgba(255,255,255,0.4)', letterSpacing: '0.1em' }}>{group}</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {groupTeams.map(team => (
              <TeamTile key={team.id} team={team} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}