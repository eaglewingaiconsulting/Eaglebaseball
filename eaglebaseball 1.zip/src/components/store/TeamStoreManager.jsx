/**
 * TeamStoreManager — manage StoreItems for a single team.
 * Now uses unified StoreItem entity (scope="team").
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, Plus, Pencil, Trash2, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import StoreItemModal from './StoreItemModal';

const ITEM_TYPE_LABEL = { gear: '⚾ Gear', dues: '💰 Dues' };

export default function TeamStoreManager({ team }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [deleting, setDeleting] = useState({});
  const [toggling, setToggling] = useState({});

  useEffect(() => {
    base44.entities.StoreItem.filter({ team_id: team.id, scope: 'team' }).then(data => {
      setItems([...data].sort((a, b) => (a.name || '').localeCompare(b.name || '')));
      setLoading(false);
    });
  }, [team.id]);

  const togglePublish = async (item) => {
    setToggling(t => ({ ...t, [item.id]: true }));
    const newStatus = item.status === 'active' ? 'archived' : 'active';
    try {
      await base44.entities.StoreItem.update(item.id, { status: newStatus });
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, status: newStatus } : i));
    } catch {
      toast.error('Failed to update status');
    } finally {
      setToggling(t => ({ ...t, [item.id]: false }));
    }
  };

  const deleteItem = async (item) => {
    if (!confirm(`Delete "${item.name}"?`)) return;
    setDeleting(d => ({ ...d, [item.id]: true }));
    try {
      await base44.entities.StoreItem.delete(item.id);
      setItems(prev => prev.filter(i => i.id !== item.id));
      toast.success('Item deleted');
    } catch {
      toast.error('Delete failed');
    } finally {
      setDeleting(d => ({ ...d, [item.id]: false }));
    }
  };

  const handleSaved = (saved, isEdit) => {
    setItems(prev => isEdit ? prev.map(i => i.id === saved.id ? saved : i) : [...prev, saved]);
    setEditingItem(null);
    setShowAdd(false);
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Store Items</h2>
        <Button size="sm" className="gap-1.5" onClick={() => setShowAdd(true)}>
          <Plus className="w-4 h-4" /> Add Item
        </Button>
      </div>

      {items.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 px-6 text-center space-y-5">
          <Plus className="w-12 h-12 text-muted-foreground/30" />
          <div>
            <p className="font-semibold text-lg">No Items Yet</p>
            <p className="text-sm text-muted-foreground mt-1">Create your first store item</p>
          </div>
          <Button className="gap-2" onClick={() => setShowAdd(true)}>
            <Plus className="w-4 h-4" /> Add Item
          </Button>
        </div>
      ) : (
        <div className="grid gap-3">
          {items.map(item => {
            const isPublished = item.status === 'active';
            return (
              <div key={item.id} className="bg-card border border-border rounded-xl overflow-hidden flex gap-0">
                <div className="w-20 h-20 flex-shrink-0 bg-muted flex items-center justify-center overflow-hidden">
                  {item.image_url
                    ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                    : <span className="text-2xl">{item.item_type === 'dues' ? '💰' : '🛍️'}</span>}
                </div>
                <div className="flex-1 p-3 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-semibold text-sm truncate">{item.name}</span>
                        <span className="text-xs px-1.5 py-0.5 rounded-full bg-secondary text-secondary-foreground">
                          {ITEM_TYPE_LABEL[item.item_type] || item.item_type}
                        </span>
                      </div>
                      {item.description && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{item.description}</p>}
                      <span className="text-sm font-bold text-primary mt-1 block">${(item.price || 0).toFixed(2)}</span>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${isPublished ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      {isPublished ? 'Live' : 'Draft'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-2">
                    <button onClick={() => togglePublish(item)} disabled={toggling[item.id]}
                      className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg border border-border hover:bg-muted transition-colors">
                      {toggling[item.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : isPublished ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      {isPublished ? 'Unpublish' : 'Publish'}
                    </button>
                    <button onClick={() => setEditingItem(item)}
                      className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg border border-border hover:bg-muted transition-colors">
                      <Pencil className="w-3 h-3" /> Edit
                    </button>
                    <button onClick={() => deleteItem(item)} disabled={deleting[item.id]}
                      className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg border border-destructive/30 text-destructive hover:bg-destructive/10 transition-colors">
                      {deleting[item.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showAdd && (
        <StoreItemModal scope="team" teamId={team.id} orgId={team.org_id}
          onSave={(saved) => handleSaved(saved, false)} onClose={() => setShowAdd(false)} />
      )}
      {editingItem && (
        <StoreItemModal scope="team" item={editingItem} teamId={team.id} orgId={team.org_id}
          onSave={(saved) => handleSaved(saved, true)} onClose={() => setEditingItem(null)} />
      )}
    </div>
  );
}