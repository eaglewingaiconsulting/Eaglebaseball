import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

const SHIRT_SIZES = ['YS', 'YM', 'YL', 'YXL', 'XS', 'S', 'M', 'L', 'XL', 'XXL'];
const HAT_SIZES = ['6½', '6⅝', '6¾', '6⅞', '7', '7⅛', '7¼', '7⅜', '7½', '7⅝', '7¾', '7⅞', '8', 'S/M', 'L/XL'];
const PANTS_SIZES = ['YS', 'YM', 'YL', 'YXL', 'XS', 'S', 'M', 'L', 'XL', 'XXL'];

export default function UniformSizeModal({ player, onSaved, onClose }) {
  const [sizes, setSizes] = useState({
    shirt_size: player.shirt_size || '',
    hat_size: player.hat_size || '',
    pants_size: player.pants_size || '',
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!sizes.shirt_size || !sizes.hat_size || !sizes.pants_size) {
      toast.error('All three sizes are required');
      return;
    }
    setSaving(true);
    const updated = await base44.entities.Player.update(player.id, sizes);
    setSaving(false);
    toast.success('Sizes saved!');
    onSaved(updated);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-lg">Uniform Sizing Required</h2>
          <button onClick={onClose}><X className="w-4 h-4" /></button>
        </div>
        <p className="text-sm text-muted-foreground">Please provide your uniform sizes before checkout. These are saved and won't be asked again.</p>

        <div className="space-y-3">
          <div>
            <Label className="text-xs mb-1 block">Shirt Size *</Label>
            <Select value={sizes.shirt_size} onValueChange={v => setSizes(s => ({ ...s, shirt_size: v }))}>
              <SelectTrigger><SelectValue placeholder="Select shirt size" /></SelectTrigger>
              <SelectContent>{SHIRT_SIZES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs mb-1 block">Hat Size *</Label>
            <Select value={sizes.hat_size} onValueChange={v => setSizes(s => ({ ...s, hat_size: v }))}>
              <SelectTrigger><SelectValue placeholder="Select hat size" /></SelectTrigger>
              <SelectContent>{HAT_SIZES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs mb-1 block">Pants Size *</Label>
            <Select value={sizes.pants_size} onValueChange={v => setSizes(s => ({ ...s, pants_size: v }))}>
              <SelectTrigger><SelectValue placeholder="Select pants size" /></SelectTrigger>
              <SelectContent>{PANTS_SIZES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
          <Button className="flex-1 gap-1.5" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            Save & Continue
          </Button>
        </div>
      </div>
    </div>
  );
}