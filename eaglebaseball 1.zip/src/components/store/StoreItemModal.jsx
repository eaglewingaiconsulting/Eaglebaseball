/**
 * StoreItemModal — unified create/edit modal for StoreItem.
 * Works for both team (scope="team") and org (scope="org") items.
 * Does NOT block publish when no image is uploaded — defaults to type-based placeholder.
 */
import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { X, Loader2, ImagePlus, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

// Default image library by item_type — used when no custom image is uploaded
const DEFAULT_IMAGES = {
  gear: [
    'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&q=80', // jersey
    'https://images.unsplash.com/photo-1566552881560-0be862a7c445?w=400&q=80', // cap
    'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=400&q=80',   // shirt
    'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&q=80',   // cleats
  ],
  dues: [
    'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&q=80',   // payment
    'https://images.unsplash.com/photo-1565372195458-9de0b320ef04?w=400&q=80', // trophy
    'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400&q=80', // baseball
    'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&q=80',   // field
  ],
};

const ITEM_TYPE_EMOJI = { gear: '⚾', dues: '💰' };

export default function StoreItemModal({ item, onSave, onClose, scope = 'team', teamId, orgId }) {
  const isEdit = !!item;
  const [form, setForm] = useState({
    name: item?.name || '',
    description: item?.description || '',
    price: item?.price ?? '',
    image_url: item?.image_url || '',
    item_type: item?.item_type || 'gear',
    status: item?.status || 'active',
  });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showDefaultImages, setShowDefaultImages] = useState(false);

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImage(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm(f => ({ ...f, image_url: file_url }));
    } catch {
      toast.error('Image upload failed');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Name is required'); return; }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description.trim(),
        price: parseFloat(form.price) || 0,
        image_url: form.image_url || '',
        item_type: form.item_type,
        status: form.status,
        scope,
        ...(scope === 'org' ? { org_id: orgId } : { team_id: teamId, org_id: orgId || undefined }),
      };
      const result = isEdit
        ? await base44.entities.StoreItem.update(item.id, payload)
        : await base44.entities.StoreItem.create(payload);
      onSave(result);
      toast.success(isEdit ? 'Item updated' : 'Item added');
    } catch {
      toast.error('Save failed');
    } finally {
      setSaving(false);
    }
  };

  const defaultImagesForType = DEFAULT_IMAGES[form.item_type] || DEFAULT_IMAGES.gear;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-card border border-border rounded-t-3xl sm:rounded-2xl w-full sm:max-w-md shadow-2xl max-h-[92dvh] flex flex-col">
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border flex-shrink-0">
          <h2 className="font-bold text-lg">{isEdit ? 'Edit Item' : 'Add Store Item'}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto flex-1">

          {/* Item type selector */}
          <div className="space-y-1.5">
            <Label>Item Type</Label>
            <div className="grid grid-cols-2 gap-2">
              {['gear', 'dues'].map(t => (
                <button key={t}
                  type="button"
                  onClick={() => setForm(f => ({ ...f, item_type: t }))}
                  className={`py-2.5 rounded-xl font-semibold text-sm capitalize transition-all ${
                    form.item_type === t
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}>
                  {ITEM_TYPE_EMOJI[t]} {t.charAt(0).toUpperCase() + t.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Image Upload */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Product Image <span className="text-muted-foreground text-xs font-normal">(optional)</span></Label>
              <button
                type="button"
                onClick={() => setShowDefaultImages(v => !v)}
                className="text-xs text-primary hover:underline">
                {showDefaultImages ? 'Hide' : 'Use default image'}
              </button>
            </div>

            {showDefaultImages ? (
              <div className="grid grid-cols-4 gap-2 mb-2">
                {defaultImagesForType.map((url, i) => (
                  <button key={i} type="button"
                    onClick={() => { setForm(f => ({ ...f, image_url: url })); setShowDefaultImages(false); }}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${form.image_url === url ? 'border-primary' : 'border-transparent hover:border-primary/50'}`}>
                    <img src={url} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            ) : (
              <label className="cursor-pointer block">
                <div className={`relative w-full h-36 rounded-xl border-2 border-dashed transition-colors overflow-hidden flex items-center justify-center ${
                  form.image_url ? 'border-border' : 'border-border hover:border-primary/50 bg-muted/30'
                }`}>
                  {form.image_url ? (
                    <>
                      <img src={form.image_url} alt="preview" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="text-white text-sm font-medium">Change Image</span>
                      </div>
                      <button
                        type="button"
                        onClick={e => { e.preventDefault(); setForm(f => ({ ...f, image_url: '' })); }}
                        className="absolute top-2 right-2 bg-black/60 rounded-full p-1 hover:bg-black/80">
                        <X className="w-3 h-3 text-white" />
                      </button>
                    </>
                  ) : uploadingImage ? (
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Loader2 className="w-6 h-6 animate-spin" />
                      <span className="text-sm">Uploading...</span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <ImagePlus className="w-8 h-8" />
                      <span className="text-sm">Tap to upload image</span>
                    </div>
                  )}
                </div>
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} disabled={uploadingImage} />
              </label>
            )}
          </div>

          <div className="space-y-1.5">
            <Label>Item Name *</Label>
            <Input
              placeholder="e.g. Team Jersey, Spring Dues"
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Description</Label>
            <Input
              placeholder="Short description (optional)"
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Price</Label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="number"
                min="0"
                step="0.01"
                className="pl-8"
                placeholder="0.00"
                value={form.price}
                onChange={e => setForm(f => ({ ...f, price: e.target.value }))}
              />
            </div>
          </div>

          {/* Publish toggle — does NOT block save */}
          <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-xl">
            <div className="flex-1">
              <div className="text-sm font-medium">Publish immediately</div>
              <div className="text-xs text-muted-foreground">Visible to members when active</div>
            </div>
            <button
              type="button"
              onClick={() => setForm(f => ({ ...f, status: f.status === 'active' ? 'archived' : 'active' }))}
              className={`relative w-11 h-6 rounded-full transition-colors ${form.status === 'active' ? 'bg-primary' : 'bg-muted-foreground/30'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${form.status === 'active' ? 'translate-x-5' : 'translate-x-0'}`} />
            </button>
          </div>
        </div>

        <div className="flex gap-3 px-5 pb-5 flex-shrink-0">
          <Button variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
          <Button className="flex-1 gap-2" onClick={handleSave} disabled={saving || uploadingImage}>
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            {isEdit ? 'Save Changes' : 'Add Item'}
          </Button>
        </div>
      </div>
    </div>
  );
}