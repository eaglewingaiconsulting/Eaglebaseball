/**
 * TeamStoreOrders — orders for a specific team, using unified StoreOrder entity.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { DollarSign, Loader2, CheckCircle, Clock, Ban } from 'lucide-react';

const STATUS_CONFIG = {
  paid:    { label: 'Paid',    icon: CheckCircle, color: 'text-green-600' },
  pending: { label: 'Pending', icon: Clock,        color: 'text-yellow-600' },
  waived:  { label: 'Waived',  icon: Ban,          color: 'text-muted-foreground' },
};

export default function TeamStoreOrders({ teamId }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.StoreOrder.filter({ team_id: teamId }).then(data => {
      setOrders([...data].sort((a, b) => new Date(b.payment_date || b.created_date || 0) - new Date(a.payment_date || a.created_date || 0)));
      setLoading(false);
    });
  }, [teamId]);

  if (loading) return <div className="flex justify-center py-6"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>;

  const totalRevenue = orders.filter(o => o.payment_status === 'paid').reduce((s, o) => s + (o.amount_paid || 0), 0);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider flex items-center gap-2">
          <DollarSign className="w-4 h-4" /> Payment History
        </h3>
        {orders.length > 0 && (
          <span className="text-sm font-bold text-primary">${totalRevenue.toFixed(2)} collected</span>
        )}
      </div>
      {orders.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-6 bg-card border border-dashed border-border rounded-xl">No payments yet</p>
      ) : (
        <div className="space-y-2">
          {orders.map(order => {
            const cfg = STATUS_CONFIG[order.payment_status] || STATUS_CONFIG.pending;
            const Icon = cfg.icon;
            return (
              <div key={order.id} className="flex items-center justify-between bg-card border border-border rounded-xl p-3.5">
                <div>
                  <div className="text-sm font-medium">{order.player_name || order.parent_name || '—'}</div>
                  <div className="text-xs text-muted-foreground">{order.item_name} · {order.payment_date || '—'}</div>
                  {order.scope === 'org' && (
                    <span className="text-xs px-1.5 py-0.5 rounded-full bg-primary/10 text-primary font-medium mt-0.5 inline-block">Org</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm">${(order.amount_paid || 0).toFixed(2)}</span>
                  <Icon className={`w-4 h-4 ${cfg.color}`} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}