/**
 * MessageBubble — renders a single message.
 * Coach messages get gold left border + badge.
 * Long-press / hover reveals action row: pin, delete, react.
 */
import { useState } from 'react';
import { Pin, Trash2, MoreHorizontal } from 'lucide-react';
import { format, isToday, isYesterday } from 'date-fns';

const QUICK_REACTIONS = ['👍', '❤️', '⚾', '🔥', '👏'];

function formatTime(dateStr) {
  const d = new Date(dateStr);
  if (isToday(d)) return format(d, 'h:mm a');
  if (isYesterday(d)) return `Yesterday ${format(d, 'h:mm a')}`;
  return format(d, 'MMM d, h:mm a');
}

function getInitials(name) {
  const parts = (name || '').split(' ');
  return parts.length >= 2
    ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
    : (name || '?').slice(0, 2).toUpperCase();
}

export default function MessageBubble({ msg, isMine, showHeader, isCoach, onPin, onDelete, onReact, currentUserEmail }) {
  const [showActions, setShowActions] = useState(false);

  const isCoachMsg = msg.is_coach_message;

  const totalReactions = Object.entries(msg.reactions || {}).filter(([, users]) => users.length > 0);

  return (
    <div className={`group relative flex gap-2 ${isMine ? 'flex-row-reverse' : 'flex-row'} items-end mb-0.5`}
      onMouseLeave={() => setShowActions(false)}>

      {/* Avatar (only for others, only on header row) */}
      {!isMine && showHeader && (
        <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 self-end mb-0.5 ${
          isCoachMsg ? 'bg-amber-500 text-white' : 'bg-secondary text-secondary-foreground'
        }`}>
          {getInitials(msg.sender_name)}
        </div>
      )}
      {!isMine && !showHeader && <div className="w-7 flex-shrink-0" />}

      <div className={`max-w-[80%] space-y-0.5`}>
        {/* Sender / time header */}
        {showHeader && (
          <div className={`flex items-center gap-2 text-xs text-muted-foreground mb-0.5 ${isMine ? 'justify-end' : 'justify-start'}`}>
            {!isMine && <span className={`font-semibold ${isCoachMsg ? 'text-amber-600' : 'text-foreground'}`}>{msg.sender_name}</span>}
            {isCoachMsg && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700">COACH</span>
            )}
            <span>{formatTime(msg.created_date)}</span>
          </div>
        )}

        {/* Reply-to snippet */}
        {msg.reply_to_body && (
          <div className={`text-xs px-2.5 py-1.5 rounded-lg bg-muted/60 border-l-2 border-primary/50 ${isMine ? 'ml-auto' : ''} max-w-full truncate`}>
            {msg.reply_to_body}
          </div>
        )}

        {/* Bubble */}
        <div
          className={`relative px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed break-words ${
            isMine
              ? 'bg-primary text-primary-foreground rounded-br-sm'
              : isCoachMsg
                ? 'bg-amber-50 text-amber-900 border border-amber-200 rounded-bl-sm'
                : 'bg-card border border-border text-foreground rounded-bl-sm'
          }`}
          style={isCoachMsg && !isMine ? { borderLeft: '3px solid #F59E0B' } : {}}
          onMouseEnter={() => setShowActions(true)}
          onTouchStart={() => setShowActions(v => !v)}
        >
          {msg.body}

          {/* Pinned indicator */}
          {msg.is_pinned && (
            <span className="ml-1.5 inline-flex items-center gap-0.5 text-xs text-amber-500">
              <Pin className="w-2.5 h-2.5" /> pinned
            </span>
          )}
        </div>

        {/* Reactions display */}
        {totalReactions.length > 0 && (
          <div className={`flex flex-wrap gap-1 ${isMine ? 'justify-end' : 'justify-start'}`}>
            {totalReactions.map(([emoji, users]) => (
              <button key={emoji}
                onClick={() => onReact(msg, emoji)}
                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border transition-colors ${
                  users.includes(currentUserEmail) ? 'bg-primary/10 border-primary/40 text-primary' : 'bg-muted border-border hover:bg-muted/80'
                }`}>
                {emoji} <span className="font-semibold">{users.length}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Action row — appears on hover/tap */}
      {showActions && (
        <div className={`absolute ${isMine ? 'right-full mr-1' : 'left-full ml-1'} top-1/2 -translate-y-1/2 flex items-center gap-0.5 bg-card border border-border rounded-xl shadow-lg px-1.5 py-1 z-10`}>
          {QUICK_REACTIONS.map(emoji => (
            <button key={emoji} onClick={() => { onReact(msg, emoji); setShowActions(false); }}
              className="w-7 h-7 hover:bg-muted rounded-lg text-sm transition-colors flex items-center justify-center">
              {emoji}
            </button>
          ))}
          {isCoach && (
            <button onClick={() => { onPin(msg); setShowActions(false); }}
              className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${msg.is_pinned ? 'text-amber-500 hover:bg-amber-50' : 'hover:bg-muted text-muted-foreground'}`}
              title={msg.is_pinned ? 'Unpin' : 'Pin'}>
              <Pin className="w-3.5 h-3.5" />
            </button>
          )}
          {(isMine || isCoach) && (
            <button onClick={() => { onDelete(msg); setShowActions(false); }}
              className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-destructive/10 text-destructive transition-colors"
              title="Delete">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}