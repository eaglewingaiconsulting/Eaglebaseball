/**
 * DMThread — private DM conversation between two users on a team.
 */
import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft } from 'lucide-react';
import MessageBubble from './MessageBubble';
import MessageComposer from './MessageComposer';

function dmThreadId(emailA, emailB) {
  return [emailA, emailB].sort().join('|');
}

export default function DMThread({ team, user, partner, isCoach, onBack }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef(null);
  const threadId = dmThreadId(user.email, partner.email);

  const load = async () => {
    const data = await base44.entities.TeamMessage.filter({
      team_id: team.id,
      channel: 'direct',
      thread_id: threadId,
    });
    const visible = data
      .filter(m => !m.is_deleted)
      .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    setMessages(visible);
    setLoading(false);
  };

  useEffect(() => { load(); }, [threadId]);

  useEffect(() => {
    const unsub = base44.entities.TeamMessage.subscribe(evt => {
      if (!evt.data || evt.data.thread_id !== threadId) return;
      if (evt.type === 'create' && !evt.data.is_deleted) {
        setMessages(prev => [...prev, evt.data]);
      } else if (evt.type === 'update') {
        setMessages(prev => prev.map(m => m.id === evt.id ? evt.data : m).filter(m => !m.is_deleted));
      } else if (evt.type === 'delete') {
        setMessages(prev => prev.filter(m => m.id !== evt.id));
      }
    });
    return unsub;
  }, [threadId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleSend = async ({ body }) => {
    if (!body.trim()) return;
    await base44.entities.TeamMessage.create({
      team_id: team.id,
      channel: 'direct',
      thread_id: threadId,
      sender_email: user.email,
      sender_name: user.full_name || user.email,
      sender_role: user.role || 'parent',
      body: body.trim(),
      is_coach_message: isCoach,
    });
  };

  const handleDelete = async (msg) => {
    if (!confirm('Delete this message?')) return;
    await base44.entities.TeamMessage.update(msg.id, { is_deleted: true });
  };

  const handleReact = async (msg, emoji) => {
    const reactions = { ...(msg.reactions || {}) };
    const current = reactions[emoji] || [];
    const hasReacted = current.includes(user.email);
    reactions[emoji] = hasReacted ? current.filter(e => e !== user.email) : [...current, user.email];
    await base44.entities.TeamMessage.update(msg.id, { reactions });
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card/95 backdrop-blur-sm sticky top-0 z-20">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-muted touch-manipulation">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold flex-shrink-0 text-sm">
          {partner.email[0].toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-bold text-sm truncate">{partner.name || partner.email}</div>
          <div className="text-xs text-muted-foreground">Private message · {team.name}</div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
        {loading && (
          <div className="flex justify-center py-10">
            <div className="w-5 h-5 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        )}
        {!loading && messages.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-3 text-muted-foreground">
            <div className="text-4xl">✉️</div>
            <p className="font-semibold">No messages yet</p>
            <p className="text-sm">Send a message to {partner.name || partner.email}</p>
          </div>
        )}
        {messages.map((msg, idx) => {
          const prev = messages[idx - 1];
          const showHeader = !prev || prev.sender_email !== msg.sender_email ||
            (new Date(msg.created_date) - new Date(prev.created_date)) > 5 * 60 * 1000;
          return (
            <MessageBubble
              key={msg.id}
              msg={msg}
              isMine={msg.sender_email === user.email}
              showHeader={showHeader}
              isCoach={isCoach}
              onPin={() => {}}
              onDelete={handleDelete}
              onReact={handleReact}
              currentUserEmail={user.email}
            />
          );
        })}
        <div ref={bottomRef} />
      </div>

      <MessageComposer onSend={handleSend} isCoach={isCoach} placeholder={`Message ${partner.name || partner.email}…`} />
    </div>
  );
}