/**
 * TeamChannel — team-wide broadcast channel.
 * Coach messages have gold emphasis. Pinned messages shown at top.
 * Quick templates for coaches. Real-time via subscribe().
 */
import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import MessageBubble from './MessageBubble';
import MessageComposer from './MessageComposer';
import PinnedBanner from './PinnedBanner';
import { Pin } from 'lucide-react';

export default function TeamChannel({ team, user, players, isCoach }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef(null);

  const load = async () => {
    const data = await base44.entities.TeamMessage.filter({
      team_id: team.id,
      channel: 'team',
    });
    const visible = data
      .filter(m => !m.is_deleted)
      .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    setMessages(visible);
    setLoading(false);
  };

  useEffect(() => { load(); }, [team.id]);

  useEffect(() => {
    const unsub = base44.entities.TeamMessage.subscribe(evt => {
      if (!evt.data || evt.data.team_id !== team.id || evt.data.channel !== 'team') return;
      if (evt.type === 'create') {
        setMessages(prev => evt.data.is_deleted ? prev : [...prev, evt.data]);
      } else if (evt.type === 'update') {
        setMessages(prev => prev
          .map(m => m.id === evt.id ? evt.data : m)
          .filter(m => !m.is_deleted));
      } else if (evt.type === 'delete') {
        setMessages(prev => prev.filter(m => m.id !== evt.id));
      }
    });
    return unsub;
  }, [team.id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleSend = async ({ body, replyTo }) => {
    if (!body.trim()) return;
    await base44.entities.TeamMessage.create({
      team_id: team.id,
      channel: 'team',
      sender_email: user.email,
      sender_name: user.full_name || user.email,
      sender_role: user.role || 'parent',
      body: body.trim(),
      is_coach_message: isCoach,
      reply_to_id: replyTo?.id || null,
      reply_to_body: replyTo?.body?.slice(0, 80) || null,
    });
  };

  const handlePin = async (msg) => {
    const wasPin = !!msg.is_pinned;
    await base44.entities.TeamMessage.update(msg.id, {
      is_pinned: !wasPin,
      pinned_by: wasPin ? null : user.email,
    });
    toast.success(wasPin ? 'Unpinned' : 'Message pinned');
  };

  const handleDelete = async (msg) => {
    if (!confirm('Delete this message?')) return;
    await base44.entities.TeamMessage.update(msg.id, { is_deleted: true });
  };

  const handleReact = async (msg, emoji) => {
    const reactions = { ...(msg.reactions || {}) };
    const current = reactions[emoji] || [];
    const hasReacted = current.includes(user.email);
    reactions[emoji] = hasReacted
      ? current.filter(e => e !== user.email)
      : [...current, user.email];
    await base44.entities.TeamMessage.update(msg.id, { reactions });
  };

  const pinned = messages.filter(m => m.is_pinned);
  const regular = messages;

  if (loading) return (
    <div className="flex items-center justify-center py-16">
      <div className="w-6 h-6 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="flex flex-col h-full" style={{ minHeight: 0 }}>
      {/* Pinned messages banner */}
      {pinned.length > 0 && <PinnedBanner messages={pinned} />}

      {/* Message list */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
        {regular.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-3 text-muted-foreground">
            <div className="text-4xl">💬</div>
            <p className="font-semibold">No messages yet</p>
            <p className="text-sm">Be the first to say something!</p>
          </div>
        )}
        {regular.map((msg, idx) => {
          const prev = regular[idx - 1];
          const showHeader = !prev || prev.sender_email !== msg.sender_email ||
            (new Date(msg.created_date) - new Date(prev.created_date)) > 5 * 60 * 1000;
          return (
            <MessageBubble
              key={msg.id}
              msg={msg}
              isMine={msg.sender_email === user.email}
              showHeader={showHeader}
              isCoach={isCoach}
              onPin={handlePin}
              onDelete={handleDelete}
              onReact={handleReact}
              currentUserEmail={user.email}
            />
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Composer */}
      <MessageComposer onSend={handleSend} isCoach={isCoach} placeholder="Message the team..." />
    </div>
  );
}