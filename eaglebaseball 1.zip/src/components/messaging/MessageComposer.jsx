/**
 * MessageComposer — text input with send button + coach quick templates.
 */
import { useState, useRef } from 'react';
import { Send, ChevronDown, ChevronUp } from 'lucide-react';

const COACH_TEMPLATES = [
  { label: '📋 Practice', body: 'Practice this week: please confirm attendance by replying here.' },
  { label: '🏟️ Game Day', body: "Game day tomorrow! Arrive by {time}. Let's bring the energy! ⚾" },
  { label: '✅ Attendance', body: 'Please reply with ✅ if your player will be at practice this week.' },
  { label: '🏆 Great Job!', body: 'Great effort today team! Proud of everyone\'s work on the field 🙌' },
  { label: '⚠️ Cancellation', body: 'CANCELLED: Today\'s practice/game has been cancelled. Watch for updates.' },
  { label: '📦 Store', body: 'Reminder: team store is open! Check the Store tab to place your order.' },
  { label: '🧢 Uniform', body: 'Please make sure your player has their full uniform for the next game.' },
  { label: '🚌 Carpool', body: 'Anyone able to help with carpool this week? Please reply if you can assist.' },
];

export default function MessageComposer({ onSend, isCoach, placeholder = 'Type a message…' }) {
  const [body, setBody] = useState('');
  const [showTemplates, setShowTemplates] = useState(false);
  const [sending, setSending] = useState(false);
  const textareaRef = useRef(null);

  const submit = async () => {
    if (!body.trim() || sending) return;
    setSending(true);
    await onSend({ body });
    setBody('');
    setSending(false);
    textareaRef.current?.focus();
  };

  const applyTemplate = (tmpl) => {
    setBody(tmpl.body);
    setShowTemplates(false);
    textareaRef.current?.focus();
  };

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div className="flex-shrink-0 border-t border-border bg-card pb-safe">
      {/* Coach templates tray */}
      {isCoach && showTemplates && (
        <div className="border-b border-border px-3 py-2 grid grid-cols-2 gap-1.5 max-h-44 overflow-y-auto">
          {COACH_TEMPLATES.map(t => (
            <button key={t.label} onClick={() => applyTemplate(t)}
              className="text-left px-3 py-2 rounded-lg bg-muted hover:bg-secondary text-xs font-medium transition-colors truncate">
              {t.label}
            </button>
          ))}
        </div>
      )}

      <div className="flex items-end gap-2 px-3 py-2">
        {/* Templates toggle for coaches */}
        {isCoach && (
          <button onClick={() => setShowTemplates(v => !v)}
            className={`flex-shrink-0 p-2 rounded-xl transition-colors touch-manipulation select-none ${showTemplates ? 'bg-amber-100 text-amber-600' : 'bg-muted text-muted-foreground hover:bg-secondary'}`}
            title="Quick templates">
            {showTemplates ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        )}

        {/* Text area */}
        <textarea
          ref={textareaRef}
          rows={1}
          value={body}
          onChange={e => setBody(e.target.value)}
          onKeyDown={handleKey}
          placeholder={placeholder}
          className="flex-1 resize-none bg-muted rounded-2xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 max-h-28 overflow-y-auto leading-relaxed"
          style={{ minHeight: 42 }}
        />

        {/* Send */}
        <button
          onClick={submit}
          disabled={!body.trim() || sending}
          className="flex-shrink-0 w-10 h-10 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center transition-all active:scale-95 disabled:opacity-40 touch-manipulation select-none">
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}