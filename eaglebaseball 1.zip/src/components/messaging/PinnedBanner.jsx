/**
 * PinnedBanner — collapsible bar showing pinned messages at the top of the channel.
 */
import { useState } from 'react';
import { Pin, ChevronDown, ChevronUp } from 'lucide-react';

export default function PinnedBanner({ messages }) {
  const [expanded, setExpanded] = useState(false);
  const latest = messages[messages.length - 1];

  return (
    <div className="flex-shrink-0 bg-amber-50 border-b border-amber-200">
      <button
        onClick={() => setExpanded(v => !v)}
        className="w-full flex items-center gap-2 px-3 py-2 text-left touch-manipulation select-none">
        <Pin className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
        <span className="flex-1 text-xs text-amber-800 font-medium truncate">{latest?.body}</span>
        <span className="text-xs text-amber-500 flex-shrink-0">{messages.length} pinned</span>
        {expanded ? <ChevronUp className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
      </button>

      {expanded && (
        <div className="px-3 pb-2 space-y-1.5 max-h-36 overflow-y-auto">
          {messages.map(m => (
            <div key={m.id} className="bg-amber-100/60 rounded-lg px-3 py-1.5">
              <div className="text-xs font-semibold text-amber-700">{m.sender_name}</div>
              <div className="text-xs text-amber-900">{m.body}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}