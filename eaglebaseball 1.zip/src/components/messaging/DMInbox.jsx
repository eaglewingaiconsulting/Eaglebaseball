/**
 * DMInbox — lists DM threads this user has had on this team.
 * Coaches can see all parent/player members to start new DMs.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, MessageSquare } from 'lucide-react';
import { format, isToday } from 'date-fns';

function dmThreadId(emailA, emailB) {
  return [emailA, emailB].sort().join('|');
}

function formatPreviewTime(dateStr) {
  const d = new Date(dateStr);
  if (isToday(d)) return format(d, 'h:mm a');
  return format(d, 'MMM d');
}

export default function DMInbox({ team, user, players, isCoach, onOpenDM }) {
  const [threads, setThreads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showNewDM, setShowNewDM] = useState(false);

  useEffect(() => {
    // Fetch all DMs on this team where the current user is involved
    base44.entities.TeamMessage.filter({
      team_id: team.id,
      channel: 'direct',
    }).then(msgs => {
      // Group by thread_id
      const myMessages = msgs.filter(m =>
        m.thread_id && m.thread_id.includes(user.email) && !m.is_deleted
      );
      const threadMap = {};
      for (const msg of myMessages) {
        const tid = msg.thread_id;
        if (!threadMap[tid] || new Date(msg.created_date) > new Date(threadMap[tid].latest.created_date)) {
          threadMap[tid] = { thread_id: tid, latest: msg };
        }
      }
      setThreads(Object.values(threadMap).sort((a, b) => new Date(b.latest.created_date) - new Date(a.latest.created_date)));
      setLoading(false);
    });
  }, [team.id, user.email]);

  // Real-time updates
  useEffect(() => {
    const unsub = base44.entities.TeamMessage.subscribe(evt => {
      if (!evt.data || evt.data.team_id !== team.id || evt.data.channel !== 'direct') return;
      if (!evt.data.thread_id?.includes(user.email)) return;
      setThreads(prev => {
        const tid = evt.data.thread_id;
        const existing = prev.find(t => t.thread_id === tid);
        if (existing) {
          return prev.map(t => t.thread_id === tid ? { ...t, latest: evt.data } : t)
            .sort((a, b) => new Date(b.latest.created_date) - new Date(a.latest.created_date));
        }
        return [{ thread_id: tid, latest: evt.data }, ...prev];
      });
    });
    return unsub;
  }, [team.id, user.email]);

  // Build the partner info from thread_id
  const getPartner = (thread_id) => {
    const emails = thread_id.split('|');
    const partnerEmail = emails.find(e => e !== user.email) || emails[0];
    return partnerEmail;
  };

  // Get display name for a partner email
  const getPartnerName = (email) => {
    // Try to find a player whose parent_email matches
    const player = players.find(p => p.parent_email === email);
    if (player) return `${player.name}'s parent`;
    // Try to get from any message sender_name
    return email.split('@')[0];
  };

  // Members available to start DM with
  const buildMemberList = () => {
    const members = new Set();
    // Parents of players
    players.forEach(p => { if (p.parent_email && p.parent_email !== user.email) members.add(p.parent_email); });
    // Coach
    if (team.coach_email && team.coach_email !== user.email) members.add(team.coach_email);
    (team.admin_emails || []).forEach(e => { if (e !== user.email) members.add(e); });
    return Array.from(members);
  };

  const startDM = (email) => {
    setShowNewDM(false);
    onOpenDM({ email, name: getPartnerName(email) });
  };

  if (loading) return (
    <div className="flex items-center justify-center py-16">
      <div className="w-6 h-6 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  const members = buildMemberList();

  return (
    <div className="flex flex-col h-full">
      {/* Header row */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border flex-shrink-0">
        <span className="text-sm font-semibold text-muted-foreground">{threads.length} conversation{threads.length !== 1 ? 's' : ''}</span>
        <button onClick={() => setShowNewDM(v => !v)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary text-primary-foreground text-xs font-semibold transition-colors hover:bg-primary/90 touch-manipulation">
          <Plus className="w-3.5 h-3.5" /> New DM
        </button>
      </div>

      {/* New DM picker */}
      {showNewDM && (
        <div className="border-b border-border bg-muted/40 px-4 py-3 space-y-2 flex-shrink-0">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Select a member to message</div>
          {members.length === 0 && <div className="text-sm text-muted-foreground">No other members found</div>}
          <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto">
            {members.map(email => (
              <button key={email} onClick={() => startDM(email)}
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-card border border-border hover:bg-secondary text-sm text-left transition-colors touch-manipulation">
                <div className="w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold flex-shrink-0">
                  {email[0].toUpperCase()}
                </div>
                <span className="truncate text-xs">{getPartnerName(email)}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Thread list */}
      <div className="flex-1 overflow-y-auto">
        {threads.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-3 text-muted-foreground">
            <MessageSquare className="w-10 h-10 opacity-30" />
            <p className="font-semibold">No direct messages yet</p>
            <p className="text-sm">Tap "New DM" to start a private conversation</p>
          </div>
        ) : (
          threads.map(thread => {
            const partnerEmail = getPartner(thread.thread_id);
            const partnerName = getPartnerName(partnerEmail);
            const isMine = thread.latest.sender_email === user.email;
            return (
              <button key={thread.thread_id}
                onClick={() => onOpenDM({ email: partnerEmail, name: partnerName })}
                className="w-full flex items-center gap-3 px-4 py-3.5 border-b border-border hover:bg-muted/40 transition-colors text-left touch-manipulation">
                <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold flex-shrink-0">
                  {partnerEmail[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-sm truncate">{partnerName}</span>
                    <span className="text-xs text-muted-foreground flex-shrink-0">
                      {formatPreviewTime(thread.latest.created_date)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate mt-0.5">
                    {isMine ? 'You: ' : ''}{thread.latest.body}
                  </p>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}