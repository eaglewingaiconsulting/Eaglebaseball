import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Camera, Loader2, X } from 'lucide-react';
import { toast } from 'sonner';

function getInitials(name) {
  return (name || '?').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
}

export function PlayerAvatar({ player, size = 'md', className = '' }) {
  const sizes = {
    xs: 'w-7 h-7 text-xs',
    sm: 'w-9 h-9 text-xs',
    md: 'w-14 h-14 text-base',
    lg: 'w-20 h-20 text-xl',
    xl: 'w-28 h-28 text-2xl',
  };
  const sz = sizes[size] || sizes.md;
  const url = size === 'xl' || size === 'lg' ? player?.photo_full_url : player?.photo_thumb_url;

  if (url) {
    return <img src={url} alt={player?.name} className={`${sz} rounded-full object-cover flex-shrink-0 ${className}`} />;
  }

  return (
    <div className={`${sz} rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold flex-shrink-0 ${className}`}>
      {getInitials(player?.name)}
    </div>
  );
}

export default function PlayerPhotoUpload({ player, onUpdated }) {
  const [uploading, setUploading] = useState(false);

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Only allow jpg/png
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
      toast.error('Only JPG and PNG files are supported');
      return;
    }

    setUploading(true);
    try {
      // Upload original to get a URL for AI processing
      const { file_url: originalUrl } = await base44.integrations.Core.UploadFile({ file });

      // Convert to avatar using AI
      toast.info('Converting to avatar…');
      const avatarResult = await base44.integrations.Core.GenerateImage({
        prompt: `Convert this person's photo into a clean, modern sports player avatar / cartoon illustration. Keep the face recognizable but stylized as a bold, vibrant sports card avatar. Use a simple solid or gradient background. Make it look great as a small circular profile picture.`,
        existing_image_urls: [originalUrl],
      });

      // Upload avatar at full and thumb sizes
      const avatarFile = await fetchImageAsFile(avatarResult.url, 'avatar.jpg');
      const [thumb, full] = await Promise.all([
        createThumbnail(avatarFile, 80),
        createThumbnail(avatarFile, 400),
      ]);
      const [{ file_url: thumbUrl }, { file_url: fullUrl }] = await Promise.all([
        base44.integrations.Core.UploadFile({ file: thumb }),
        base44.integrations.Core.UploadFile({ file: full }),
      ]);

      const updated = await base44.entities.Player.update(player.id, {
        photo_thumb_url: thumbUrl,
        photo_full_url: fullUrl,
      });
      onUpdated(updated);
      toast.success('Avatar created!');
    } catch (err) {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="relative inline-block">
      <PlayerAvatar player={player} size="xl" />
      <label className="absolute bottom-0 right-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center cursor-pointer shadow-lg hover:bg-primary/90 transition-colors" title={uploading ? 'Creating avatar…' : 'Upload photo'}>
        {uploading ? <Loader2 className="w-4 h-4 text-white animate-spin" /> : <Camera className="w-4 h-4 text-white" />}
        <input type="file" accept="image/jpeg,image/png" className="hidden" onChange={handleFileChange} disabled={uploading} />
      </label>
    </div>
  );
}

async function fetchImageAsFile(url, filename = 'image.jpg') {
  const res = await fetch(url);
  const blob = await res.blob();
  return new File([blob], filename, { type: 'image/jpeg' });
}

async function createThumbnail(file, size) {
  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');

      // Crop to square from center
      const s = Math.min(img.width, img.height);
      const sx = (img.width - s) / 2;
      const sy = (img.height - s) / 2;
      ctx.drawImage(img, sx, sy, s, s, 0, 0, size, size);

      URL.revokeObjectURL(url);
      canvas.toBlob(blob => {
        resolve(new File([blob], file.name, { type: 'image/jpeg' }));
      }, 'image/jpeg', 0.85);
    };
    img.src = url;
  });
}