import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { CheckCircle, XCircle, HelpCircle, Clock } from 'lucide-react';

export default function RSVPSummary({ gameId, teamId }) {
  const [rsvps, setRsvps] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.RSVP.filter({ game_id: gameId, team_id: teamId }),
      base44.entities.Player.filter({ team_id: teamId })
    ]).then(([r, p]) => {
      setRsvps(r);
      setPlayers(p);
      setLoading(false);
    });
  }, [gameId, teamId]);

  if (loading) return <div className="text-sm text-muted-foreground">Loading RSVP...</div>;

  const getStatus = (playerId) => rsvps.find(r => r.player_id === playerId)?.status || 'pending';

  const counts = { attending: 0, not_attending: 0, maybe: 0, pending: 0 };
  players.forEach(p => counts[getStatus(p.id)]++);

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-2 text-center">
        <div className="bg-green-50 border border-green-200 rounded-lg p-2">
          <CheckCircle className="w-4 h-4 text-green-600 mx-auto mb-1" />
          <div className="text-lg font-bold text-green-700">{counts.attending}</div>
          <div className="text-xs text-green-600">Yes</div>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-2">
          <XCircle className="w-4 h-4 text-red-600 mx-auto mb-1" />
          <div className="text-lg font-bold text-red-700">{counts.not_attending}</div>
          <div className="text-xs text-red-600">No</div>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-2">
          <HelpCircle className="w-4 h-4 text-amber-600 mx-auto mb-1" />
          <div className="text-lg font-bold text-amber-700">{counts.maybe}</div>
          <div className="text-xs text-amber-600">Maybe</div>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-2">
          <Clock className="w-4 h-4 text-gray-500 mx-auto mb-1" />
          <div className="text-lg font-bold text-gray-700">{counts.pending}</div>
          <div className="text-xs text-gray-500">Pending</div>
        </div>
      </div>

      <div className="space-y-1 max-h-48 overflow-y-auto">
        {players.map(p => {
          const status = getStatus(p.id);
          return (
            <div key={p.id} className="flex items-center justify-between text-sm py-1 border-b border-border last:border-0">
              <span>{p.name} <span className="text-muted-foreground text-xs">#{p.number}</span></span>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                status === 'attending' ? 'bg-green-100 text-green-700' :
                status === 'not_attending' ? 'bg-red-100 text-red-700' :
                status === 'maybe' ? 'bg-amber-100 text-amber-700' :
                'bg-gray-100 text-gray-600'
              }`}>{status.replace('_', ' ')}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}