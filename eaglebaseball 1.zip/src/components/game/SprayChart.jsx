import { useEffect, useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';

// Zone center positions on a 100x90 viewBox (matching HitZonePicker)
const ZONE_CENTERS = {
  deep_left:      { x: 29,  y: 27 },
  deep_center:    { x: 50,  y: 19 },
  deep_right:     { x: 71,  y: 27 },
  shallow_left:   { x: 29,  y: 44 },
  shallow_center: { x: 50,  y: 36 },
  shallow_right:  { x: 71,  y: 44 },
  gap_left:       { x: 34,  y: 34 },
  gap_right:      { x: 66,  y: 34 },
  infield_left:   { x: 31,  y: 60 },
  infield_center: { x: 50,  y: 57 },
  infield_right:  { x: 69,  y: 60 },
  line_left:      { x: 13,  y: 52 },
  line_right:     { x: 87,  y: 52 },
};

const RESULT_COLORS = {
  single:   '#10B981',
  double:   '#3B82F6',
  triple:   '#8B5CF6',
  home_run: '#F59E0B',
};

// Home plate position in viewBox coordinates
const HOME_PLATE = { x: 50, y: 82 };

export default function SprayChart({ gameId, teamId, isOpponent = false, players = [], emptyLabel = 'No hit data yet' }) {
   const [atBats, setAtBats] = useState([]);
   const [animatingHit, setAnimatingHit] = useState(null); // { zone, color, id }
   const animTimerRef = useRef(null);

   useEffect(() => {
     if (!gameId || !teamId) return;
     const filter = { game_id: gameId };
     filter[isOpponent ? 'pitching_team_id' : 'batting_team_id'] = teamId;
     base44.entities.AtBat.filter(filter)
       .then(data => {
        const hits = data.filter(ab =>
          ab.hit_zone && ['single', 'double', 'triple', 'home_run'].includes(ab.result)
        );
        setAtBats(hits);
      })
      .catch(() => {});
  }, [gameId, teamId]);

  // Subscribe to real-time updates
  useEffect(() => {
    const unsub = base44.entities.AtBat.subscribe(evt => {
      const filterMatch = isOpponent ? evt.data?.pitching_team_id === teamId : evt.data?.batting_team_id === teamId;
      if (evt.type === 'create' && evt.data?.game_id === gameId && filterMatch) {
        const ab = evt.data;
        if (ab.hit_zone && ['single', 'double', 'triple', 'home_run'].includes(ab.result)) {
          setAtBats(prev => [...prev, ab]);
          // Trigger hit animation
          const color = RESULT_COLORS[ab.result] || '#10B981';
          clearTimeout(animTimerRef.current);
          setAnimatingHit({ zone: ab.hit_zone, color, id: ab.id || Date.now() });
          animTimerRef.current = setTimeout(() => setAnimatingHit(null), 2200);
        }
      }
    });
    return () => { unsub(); clearTimeout(animTimerRef.current); };
    }, [gameId, teamId, isOpponent]);

  // Group by zone
  const byZone = {};
  atBats.forEach(ab => {
    if (!byZone[ab.hit_zone]) byZone[ab.hit_zone] = [];
    byZone[ab.hit_zone].push(ab);
  });

  const getPlayerName = (id) => {
    const p = players.find(p => p.id === id);
    return p ? p.name.split(' ').pop() : '?'; // last name only
  };

  return (
    <div className="relative w-full" style={{ paddingBottom: '85%' }}>
      <div className="absolute inset-0">
        <svg viewBox="0 0 100 90" className="absolute inset-0 w-full h-full">
          {/* Outfield grass */}
          <path d="M 50 88 L 3 42 Q 50 2 97 42 Z" fill="#14532D" opacity="0.5" />
          {/* Infield dirt */}
          <polygon points="50,42 70,62 50,82 30,62" fill="#92400E" opacity="0.4" />
          {/* Foul lines */}
          <line x1="50" y1="88" x2="3" y2="42" stroke="#94A3B8" strokeWidth="0.5" opacity="0.4" />
          <line x1="50" y1="88" x2="97" y2="42" stroke="#94A3B8" strokeWidth="0.5" opacity="0.4" />
          {/* Bases */}
          {[{ cx: 50, cy: 42 }, { cx: 70, cy: 62 }, { cx: 50, cy: 82 }, { cx: 30, cy: 62 }].map(({ cx, cy }, i) => (
            <rect key={i} x={cx - 2.5} y={cy - 2.5} width={5} height={5} rx={1}
              fill="white" opacity={0.6} transform={`rotate(45, ${cx}, ${cy})`} />
          ))}
          <circle cx={50} cy={62} r={2} fill="#A16207" opacity={0.5} />

          {/* Animated hit trajectory */}
          {animatingHit && (() => {
            const pos = ZONE_CENTERS[animatingHit.zone];
            if (!pos) return null;
            const isHR = animatingHit.color === RESULT_COLORS.home_run;
            // Unique id for clipPath
            const lineId = `hit-line-${animatingHit.id}`;
            return (
              <g key={animatingHit.id}>
                <defs>
                  <style>{`
                    @keyframes drawLine-${animatingHit.id} {
                      0%   { stroke-dashoffset: 200; opacity: 1; }
                      60%  { stroke-dashoffset: 0;   opacity: 1; }
                      100% { stroke-dashoffset: 0;   opacity: 0; }
                    }
                    @keyframes pulseDot-${animatingHit.id} {
                      0%   { r: 0;  opacity: 1; }
                      50%  { r: ${isHR ? 12 : 8}; opacity: 0.7; }
                      100% { r: ${isHR ? 16 : 12}; opacity: 0; }
                    }
                  `}</style>
                </defs>
                {/* Trail line */}
                <line
                  x1={HOME_PLATE.x} y1={HOME_PLATE.y}
                  x2={pos.x} y2={pos.y}
                  stroke={animatingHit.color}
                  strokeWidth={isHR ? 2.2 : 1.5}
                  strokeLinecap="round"
                  strokeDasharray="200"
                  strokeDashoffset="200"
                  opacity="1"
                  style={{ animation: `drawLine-${animatingHit.id} 2.2s ease-out forwards` }}
                />
                {/* Impact burst at destination */}
                <circle
                  cx={pos.x} cy={pos.y} r="0"
                  fill={animatingHit.color}
                  style={{ animation: `pulseDot-${animatingHit.id} 2.2s ease-out forwards`, animationDelay: '0.5s' }}
                />
              </g>
            );
          })()}

          {/* Hit markers */}
          {Object.entries(byZone).map(([zone, hits]) => {
            const pos = ZONE_CENTERS[zone];
            if (!pos) return null;
            const count = hits.length;
            const color = RESULT_COLORS[hits[hits.length - 1]?.result] || '#10B981';
            const lastName = getPlayerName(hits[hits.length - 1]?.batter_id);

            return (
              <g key={zone}>
                {/* Glow ring */}
                <circle cx={pos.x} cy={pos.y} r={count > 1 ? 7 : 5.5} fill={color} opacity={0.2} />
                {/* Dot */}
                <circle cx={pos.x} cy={pos.y} r={count > 1 ? 5 : 4} fill={color} opacity={0.9} />
                {/* Count badge */}
                {count > 1 && (
                  <text x={pos.x} y={pos.y + 1.2} textAnchor="middle" dominantBaseline="middle"
                    fill="white" fontSize={3.5} fontWeight="bold">{count}</text>
                )}
                {/* Batter name */}
                <text x={pos.x} y={pos.y + (count > 1 ? 9 : 8)} textAnchor="middle"
                  fill="white" fontSize={3} opacity={0.85} fontWeight="500"
                  style={{ textShadow: '0 1px 2px black' }}>
                  {lastName}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Empty state */}
        {atBats.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-black/50 rounded-xl px-4 py-2 text-center">
              <div className="text-white/60 text-xs font-medium">{emptyLabel}</div>
            </div>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="absolute bottom-0 right-0 flex gap-2 p-1">
        {Object.entries(RESULT_COLORS).map(([type, color]) => (
          <div key={type} className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
            <span className="text-white/50" style={{ fontSize: '8px' }}>
              {type === 'home_run' ? 'HR' : type.charAt(0).toUpperCase()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}