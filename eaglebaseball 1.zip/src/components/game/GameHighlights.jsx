import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Trophy, Star, Loader2 } from 'lucide-react';

function computeHighlights(atBats, playLogs, game) {
  const highlights = [];

  // --- Final Score / Winner ---
  const homeScore = game.home_score ?? 0;
  const awayScore = game.away_score ?? 0;
  const winner = homeScore > awayScore ? game.home_team_name : awayScore > homeScore ? game.away_team_name : null;
  highlights.push({
    key: 'score',
    emoji: '🏆',
    title: winner ? `${winner} Win!` : 'Final Score — Tie',
    detail: `${game.away_team_name} ${awayScore} – ${homeScore} ${game.home_team_name}`,
    always: true,
  });

  // Aggregate from AtBat records
  const hitterStats = {}; // batterId -> { name, hits, rbis }
  const homeRunHitters = [];
  const stolenBaseers = [];

  for (const ab of atBats) {
    const id = ab.batter_id;
    const name = ab.batter_name || 'Unknown';
    if (!hitterStats[id]) hitterStats[id] = { name, hits: 0, rbis: 0 };
    const isHit = ['single', 'double', 'triple', 'home_run'].includes(ab.result);
    if (isHit) hitterStats[id].hits++;
    hitterStats[id].rbis += ab.rbis || 0;
    if (ab.result === 'home_run') homeRunHitters.push(name);
  }

  // From PlayLogs
  const stolenBaseMap = {};
  for (const pl of playLogs) {
    if (pl.play_type === 'stolen_base') {
      const name = pl.player_name || 'Unknown';
      stolenBaseMap[name] = (stolenBaseMap[name] || 0) + 1;
    }
  }
  for (const [name, count] of Object.entries(stolenBaseMap)) {
    stolenBaseers.push({ name, count });
  }

  // Top Hitter
  const hitterArr = Object.values(hitterStats).filter(h => h.hits > 0);
  hitterArr.sort((a, b) => b.hits - a.hits);
  if (hitterArr[0]) {
    highlights.push({
      key: 'top_hitter',
      emoji: '⚾',
      title: `Top Hitter — ${hitterArr[0].name}`,
      detail: `${hitterArr[0].hits} hit${hitterArr[0].hits !== 1 ? 's' : ''} in the game`,
    });
  }

  // RBI Leader
  const rbiArr = Object.values(hitterStats).filter(h => h.rbis > 0);
  rbiArr.sort((a, b) => b.rbis - a.rbis);
  if (rbiArr[0] && rbiArr[0].rbis > 0) {
    highlights.push({
      key: 'rbi_leader',
      emoji: '🎯',
      title: `RBI Leader — ${rbiArr[0].name}`,
      detail: `${rbiArr[0].rbis} RBI${rbiArr[0].rbis !== 1 ? 's' : ''}`,
    });
  }

  // Home Runs
  if (homeRunHitters.length > 0) {
    const counts = {};
    homeRunHitters.forEach(n => counts[n] = (counts[n] || 0) + 1);
    const hrStr = Object.entries(counts).map(([n, c]) => c > 1 ? `${n} (${c})` : n).join(', ');
    highlights.push({
      key: 'home_runs',
      emoji: '🚀',
      title: `Home Run${homeRunHitters.length > 1 ? 's' : ''}`,
      detail: hrStr,
    });
  }

  // Stolen Bases
  if (stolenBaseers.length > 0) {
    const sbStr = stolenBaseers.map(s => s.count > 1 ? `${s.name} (${s.count})` : s.name).join(', ');
    highlights.push({
      key: 'stolen_bases',
      emoji: '💨',
      title: 'Stolen Base' + (stolenBaseers.reduce((a, s) => a + s.count, 0) > 1 ? 's' : ''),
      detail: sbStr,
    });
  }

  // Double plays — from atBats with result double_play (or playLogs)
  const dpFromPlay = playLogs.filter(pl => pl.play_type === 'double_play');
  const dpFromAb = atBats.filter(ab => ab.result === 'double_play');
  const dpCount = dpFromPlay.length + dpFromAb.length;
  if (dpCount > 0) {
    highlights.push({
      key: 'double_plays',
      emoji: '🔁',
      title: `Double Play${dpCount > 1 ? 's' : ''}`,
      detail: `${dpCount} twin killing${dpCount !== 1 ? 's' : ''} recorded`,
    });
  }

  // Turning Point — inning with largest swing using inning_scores
  const inningScores = game.inning_scores || [];
  if (inningScores.length > 0) {
    const innings = {};
    for (const s of inningScores) {
      if (!innings[s.inning]) innings[s.inning] = { home: 0, away: 0 };
      innings[s.inning][s.team] = s.runs;
    }
    let maxSwing = 0;
    let turningInning = null;
    let runningHome = 0, runningAway = 0;
    const sortedInnings = Object.entries(innings).sort((a, b) => Number(a[0]) - Number(b[0]));
    for (const [inning, runs] of sortedInnings) {
      const prevDiff = Math.abs(runningAway - runningHome);
      runningHome += runs.home || 0;
      runningAway += runs.away || 0;
      const newDiff = Math.abs(runningAway - runningHome);
      const swing = newDiff - prevDiff;
      if (swing > maxSwing) { maxSwing = swing; turningInning = inning; }
    }
    if (turningInning && maxSwing >= 2) {
      highlights.push({
        key: 'turning_point',
        emoji: '🔄',
        title: `Turning Point — Inning ${turningInning}`,
        detail: `${maxSwing}-run swing changed the game`,
      });
    }
  }

  return highlights;
}

export default function GameHighlights({ game }) {
  const [highlights, setHighlights] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!game?.id) return;
    Promise.all([
      base44.entities.AtBat.filter({ game_id: game.id }),
      base44.entities.PlayLog.filter({ game_id: game.id }),
    ]).then(([atBats, playLogs]) => {
      setHighlights(computeHighlights(atBats, playLogs, game));
    }).finally(() => setLoading(false));
  }, [game?.id]);

  if (loading) return (
    <div className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3 text-muted-foreground text-sm">
      <Loader2 className="w-4 h-4 animate-spin" /> Loading highlights...
    </div>
  );

  if (!highlights.length) return null;

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center gap-2 bg-amber-50 dark:bg-amber-900/10">
        <Trophy className="w-4 h-4 text-amber-500" />
        <h3 className="font-bold text-sm text-amber-700 dark:text-amber-400 uppercase tracking-wider">Game Highlights</h3>
        <Star className="w-3.5 h-3.5 text-amber-400 ml-auto" />
      </div>
      <div className="divide-y divide-border">
        {highlights.map((h) => (
          <div key={h.key} className={`px-4 py-3 flex items-start gap-3 ${h.key === 'score' ? 'bg-primary/5' : ''}`}>
            <span className="text-xl leading-none mt-0.5 flex-shrink-0">{h.emoji}</span>
            <div>
              <div className={`font-bold text-sm ${h.key === 'score' ? 'text-primary' : 'text-foreground'}`}>{h.title}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{h.detail}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}