import { useState } from 'react';
import { ArrowLeft, GripVertical, Plus, Trash2, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

/**
 * LineupTemplateEditor
 *
 * Props:
 *   template  – existing template obj or null for new
 *   players   – all players for this team
 *   onSave    – callback(templateData)
 *   onClose   – callback to cancel
 */
export default function LineupTemplateEditor({ template, players, onSave, onClose }) {
  const [name, setName] = useState(template?.name || '');
  const [isDefault, setIsDefault] = useState(template?.is_default || false);
  const [battingOrder, setBattingOrder] = useState(
    (template?.batting_order || []).map((entry, i) => ({ ...entry, _key: i }))
  );
  const [showRosterPicker, setShowRosterPicker] = useState(false);
  const [saving, setSaving] = useState(false);
  const [dragIdx, setDragIdx] = useState(null);
  const [dragOverIdx, setDragOverIdx] = useState(null);

  const positions = ['P', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH', 'UT', 'EH', 'Sub'];
  const addedPlayerIds = new Set(battingOrder.map(e => e.player_id));
  const availablePlayers = players.filter(p => !addedPlayerIds.has(p.id));

  const addPlayer = (player) => {
    setBattingOrder(prev => [
      ...prev,
      {
        player_id: player.id,
        jersey_number: player.number || '',
        name: player.name,
        batting_position: prev.length + 1,
        field_position: player.position || '',
        _key: Date.now() + Math.random(),
      },
    ]);
    setShowRosterPicker(false);
  };

  const removePlayer = (idx) => {
    setBattingOrder(prev => {
      const next = prev.filter((_, i) => i !== idx);
      return next.map((e, i) => ({ ...e, batting_position: i + 1 }));
    });
  };

  // Drag-to-reorder (touch + mouse)
  const handleDragStart = (idx) => setDragIdx(idx);
  const handleDragEnter = (idx) => setDragOverIdx(idx);
  const handleDragEnd = () => {
    if (dragIdx !== null && dragOverIdx !== null && dragIdx !== dragOverIdx) {
      setBattingOrder(prev => {
        const next = [...prev];
        const [moved] = next.splice(dragIdx, 1);
        next.splice(dragOverIdx, 0, moved);
        return next.map((e, i) => ({ ...e, batting_position: i + 1 }));
      });
    }
    setDragIdx(null);
    setDragOverIdx(null);
  };

  const moveUp = (idx) => {
    if (idx === 0) return;
    setBattingOrder(prev => {
      const next = [...prev];
      [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
      return next.map((e, i) => ({ ...e, batting_position: i + 1 }));
    });
  };

  const moveDown = (idx) => {
    if (idx === battingOrder.length - 1) return;
    setBattingOrder(prev => {
      const next = [...prev];
      [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
      return next.map((e, i) => ({ ...e, batting_position: i + 1 }));
    });
  };

  const handleSave = async () => {
    if (!name.trim()) { toast.error('Lineup name is required'); return; }
    if (battingOrder.length === 0) { toast.error('Add at least one player'); return; }
    setSaving(true);
    const clean = battingOrder.map(({ _key, ...rest }) => rest);
    await onSave({
      ...(template || {}),
      name: name.trim(),
      is_default: isDefault,
      batting_order: clean,
    });
    setSaving(false);
  };

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={onClose} className="p-2 rounded-lg hover:bg-muted transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h1 className="text-xl font-bold flex-1">{template ? 'Edit Lineup' : 'New Lineup'}</h1>
        <Button onClick={handleSave} disabled={saving} className="gap-2">
          {saving ? 'Saving...' : 'Save'}
        </Button>
      </div>

      {/* Name + default toggle */}
      <div className="bg-card border border-border rounded-xl p-4 space-y-4">
        <div className="space-y-1.5">
          <Label>Lineup Name</Label>
          <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Default, Tournament, Lefty Heavy" />
        </div>
        <div className="flex items-center gap-3">
          <Switch id="is-default" checked={isDefault} onCheckedChange={setIsDefault} />
          <Label htmlFor="is-default" className="flex items-center gap-1.5 cursor-pointer">
            <Star className="w-4 h-4 text-accent" /> Set as Default Lineup
          </Label>
        </div>
      </div>

      {/* Batting order */}
      <div>
        <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3">
          Batting Order — drag ≡ to reorder
        </h3>
        <div className="space-y-2">
          {battingOrder.map((entry, idx) => (
            <div
              key={entry._key}
              draggable
              onDragStart={() => handleDragStart(idx)}
              onDragEnter={() => handleDragEnter(idx)}
              onDragEnd={handleDragEnd}
              onDragOver={e => e.preventDefault()}
              className={`flex items-center gap-3 bg-card border rounded-xl p-3 transition-all cursor-grab active:cursor-grabbing ${
                dragOverIdx === idx && dragIdx !== idx ? 'border-primary bg-primary/5 scale-[1.01]' : 'border-border'
              }`}
            >
              <GripVertical className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center flex-shrink-0">
                {idx + 1}
              </span>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm">{entry.name}</div>
                <div className="text-xs text-muted-foreground">#{entry.jersey_number}</div>
              </div>
              <div className="w-20">
                <Select value={entry.field_position || ''} onValueChange={pos => setBattingOrder(prev => prev.map((e, i) => i === idx ? { ...e, field_position: pos } : e))}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="Pos" />
                  </SelectTrigger>
                  <SelectContent>
                    {positions.map(p => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-1">
                <button onClick={() => moveUp(idx)} className="p-1 hover:bg-muted rounded text-xs">↑</button>
                <button onClick={() => moveDown(idx)} className="p-1 hover:bg-muted rounded text-xs">↓</button>
                <button onClick={() => removePlayer(idx)} className="p-1 hover:bg-destructive/10 rounded text-destructive">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}

          {battingOrder.length === 0 && (
            <div className="text-center py-8 text-muted-foreground text-sm border-2 border-dashed border-border rounded-xl">
              No players added yet
            </div>
          )}
        </div>

        <button
          onClick={() => setShowRosterPicker(true)}
          className="mt-3 w-full flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-dashed border-border text-sm text-muted-foreground hover:bg-muted touch-manipulation"
        >
          <Plus className="w-4 h-4" /> Add Player from Roster
        </button>
      </div>

      {/* Roster picker modal */}
      {showRosterPicker && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-end sm:items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm max-h-[70vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-border flex-shrink-0">
              <h3 className="font-semibold">Add from Roster</h3>
              <button onClick={() => setShowRosterPicker(false)} className="p-1.5 rounded-lg hover:bg-muted">✕</button>
            </div>
            <div className="overflow-y-auto p-3 space-y-2">
              {availablePlayers.length === 0 && (
                <div className="text-center py-6 text-muted-foreground text-sm">All roster players added</div>
              )}
              {availablePlayers.map(player => (
                <button
                  key={player.id}
                  onClick={() => addPlayer(player)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl border border-border bg-card hover:bg-muted text-left touch-manipulation"
                >
                  <div className="w-8 h-8 rounded-full bg-primary/10 text-primary font-bold text-xs flex items-center justify-center flex-shrink-0">
                    {player.number || '?'}
                  </div>
                  <div>
                    <div className="font-medium text-sm">{player.name}</div>
                    <div className="text-xs text-muted-foreground">{player.position}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}