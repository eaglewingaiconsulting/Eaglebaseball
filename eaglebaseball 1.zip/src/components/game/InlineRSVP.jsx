import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { CheckCircle, XCircle, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function InlineRSVP({ game, managedTeamId }) {
  const { user } = useAuth();
  const [players, setPlayers] = useState([]);
  const [rsvps, setRsvps] = useState([]);
  const [saving, setSaving] = useState(null);

  useEffect(() => {
    if (!user || !game) return;
    Promise.all([
      base44.entities.Player.filter({ parent_email: user.email }),
      base44.entities.RSVP.filter({ game_id: game.id, parent_email: user.email })
    ]).then(([myPlayers, existingRsvps]) => {
      // Filter to the managed team if known, otherwise either team in the game
      const teamId = managedTeamId || game.home_team_id;
      const gamePlayers = myPlayers.filter(p => p.team_id === teamId);
      setPlayers(gamePlayers);
      setRsvps(existingRsvps);
    });
  }, [user, game, managedTeamId]);

  const getRsvp = (playerId) => rsvps.find(r => r.player_id === playerId);

  const submitRsvp = async (player, status) => {
    setSaving(player.id);
    const existing = getRsvp(player.id);
    let updated;
    if (existing) {
      updated = await base44.entities.RSVP.update(existing.id, { status });
      setRsvps(prev => prev.map(r => r.id === existing.id ? updated : r));
    } else {
      updated = await base44.entities.RSVP.create({
        game_id: game.id,
        player_id: player.id,
        player_name: player.name,
        parent_email: user.email,
        team_id: player.team_id,
        status
      });
      setRsvps(prev => [...prev, updated]);
    }
    setSaving(null);
    toast.success(`RSVP updated: ${status}`);
  };

  if (!user || players.length === 0) return null;

  return (
    <div className="bg-card border border-border rounded-2xl p-5">
      <h3 className="font-semibold mb-4">Your RSVP</h3>
      <div className="space-y-3">
        {players.map(player => {
          const rsvp = getRsvp(player.id);
          return (
            <div key={player.id} className="flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex-1">
                <div className="font-medium text-sm">{player.name}</div>
                <div className="text-xs text-muted-foreground">#{player.number} · {player.position}</div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant={rsvp?.status === 'attending' ? 'default' : 'outline'}
                  className="gap-1.5" onClick={() => submitRsvp(player, 'attending')} disabled={saving === player.id}>
                  <CheckCircle className="w-3.5 h-3.5" /> Going
                </Button>
                <Button size="sm" variant={rsvp?.status === 'maybe' ? 'default' : 'outline'}
                  className="gap-1.5" onClick={() => submitRsvp(player, 'maybe')} disabled={saving === player.id}>
                  <HelpCircle className="w-3.5 h-3.5" /> Maybe
                </Button>
                <Button size="sm" variant={rsvp?.status === 'not_attending' ? 'destructive' : 'outline'}
                  className="gap-1.5" onClick={() => submitRsvp(player, 'not_attending')} disabled={saving === player.id}>
                  <XCircle className="w-3.5 h-3.5" /> Can't Go
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}