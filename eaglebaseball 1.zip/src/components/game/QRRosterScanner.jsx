import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X, Check, AlertCircle, Loader2, Camera } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';

// Map common GameChanger / CSV column names to our fields
function parseCSV(csvText) {
  const lines = csvText.trim().split(/\r?\n/);
  if (lines.length < 2) throw new Error('CSV is empty or has no data rows');

  const rawHeaders = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/['"]/g, ''));

  const colMap = {
    name: ['name', 'player name', 'full name', 'player'],
    first: ['first name', 'firstname', 'first'],
    last: ['last name', 'lastname', 'last', 'last_name'],
    number: ['jersey', 'jersey number', 'jersey#', '#', 'number', 'jersey_number', 'num'],
    position: ['position', 'pos', 'primary position'],
    email: ['parent email', 'email', 'guardian email', 'contact email', 'parent_email'],
    bats: ['bats', 'batting hand', 'bat'],
    throws: ['throws', 'throwing hand', 'throw'],
  };

  const idx = {};
  for (const [field, aliases] of Object.entries(colMap)) {
    for (const alias of aliases) {
      const i = rawHeaders.indexOf(alias);
      if (i !== -1) { idx[field] = i; break; }
    }
  }

  // Must have at least number or name
  if (idx.name === undefined && idx.first === undefined && idx.last === undefined) {
    throw new Error(`Could not find player name column. Found headers: ${rawHeaders.join(', ')}`);
  }

  const players = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map(c => c.trim().replace(/^["']|["']$/g, ''));
    if (cols.every(c => !c)) continue; // skip empty rows

    let name = '';
    if (idx.name !== undefined) {
      name = cols[idx.name] || '';
    } else {
      const first = idx.first !== undefined ? (cols[idx.first] || '') : '';
      const last = idx.last !== undefined ? (cols[idx.last] || '') : '';
      name = [first, last].filter(Boolean).join(' ');
    }

    if (!name) continue;

    const number = idx.number !== undefined ? (cols[idx.number] || '') : '';
    const position = idx.position !== undefined ? normalizePosition(cols[idx.position] || '') : 'UT';
    const parent_email = idx.email !== undefined ? (cols[idx.email] || '') : '';
    const bats = idx.bats !== undefined ? normalizeBats(cols[idx.bats] || '') : undefined;
    const throws_ = idx.throws !== undefined ? normalizeThrows(cols[idx.throws] || '') : undefined;

    players.push({ name, number, position, parent_email, bats, throws: throws_ });
  }

  if (players.length === 0) throw new Error('No valid player rows found in CSV');
  return players;
}

function normalizePosition(raw) {
  const map = {
    'pitcher': 'P', 'p': 'P',
    'catcher': 'C', 'c': 'C',
    'first base': '1B', '1b': '1B', '1': '1B',
    'second base': '2B', '2b': '2B', '2': '2B',
    'third base': '3B', '3b': '3B', '3': '3B',
    'shortstop': 'SS', 'ss': 'SS',
    'left field': 'LF', 'lf': 'LF',
    'center field': 'CF', 'cf': 'CF',
    'right field': 'RF', 'rf': 'RF',
    'designated hitter': 'DH', 'dh': 'DH',
  };
  return map[raw.toLowerCase()] || 'UT';
}
function normalizeBats(raw) {
  const r = raw.toLowerCase();
  if (r === 'left' || r === 'l') return 'L';
  if (r === 'switch' || r === 's' || r === 'b' || r === 'both') return 'S';
  return 'R';
}
function normalizeThrows(raw) {
  const r = raw.toLowerCase();
  if (r === 'left' || r === 'l') return 'L';
  return 'R';
}

export default function QRRosterScanner({ teamId, onRosterScanned, onClose }) {
  const scannerRef = useRef(null);
  const [status, setStatus] = useState('init'); // init | scanning | loading | preview | error
  const [errorMsg, setErrorMsg] = useState('');
  const [previewPlayers, setPreviewPlayers] = useState([]);
  const [importing, setImporting] = useState(false);

  const showError = (msg) => {
    setErrorMsg(msg);
    setStatus('error');
  };

  const startScanner = () => {
    setStatus('scanning');
    setErrorMsg('');
  };

  useEffect(() => {
    if (status !== 'scanning') return;

    const scannerId = 'qr-roster-scanner-view';
    const html5QrCode = new Html5Qrcode(scannerId, { verbose: false });
    scannerRef.current = html5QrCode;

    html5QrCode.start(
      { facingMode: 'environment' },
      { fps: 10, qrbox: { width: 240, height: 240 }, aspectRatio: 1.0 },
      async (decodedText) => {
        await html5QrCode.stop().catch(() => {});
        setStatus('loading');
        await handleScannedText(decodedText);
      },
      () => {} // per-frame errors ignored
    ).catch((err) => {
      const msg = String(err);
      if (msg.includes('Permission') || msg.includes('permission') || msg.includes('NotAllowed')) {
        showError('Camera permission denied. Please allow camera access in your browser settings and try again.');
      } else if (msg.includes('NotFound') || msg.includes('device')) {
        showError('No camera found on this device.');
      } else {
        showError('Could not start camera. Please check permissions and try again.');
      }
    });

    return () => {
      if (scannerRef.current) scannerRef.current.stop().catch(() => {});
    };
  }, [status]);

  const handleScannedText = async (text) => {
    // 1. Check if it's an internal EagleBaseball share code URL
    const internalMatch = text.match(/\/teams\/(?:import|fan)\/([A-Za-z0-9]+)/);
    if (internalMatch) {
      const shareCode = internalMatch[1];
      try {
        const teams = await base44.entities.Team.filter({ share_code: shareCode });
        if (!teams || teams.length === 0) return showError('No team found for this QR code.');
        const team = teams[0];
        const players = await base44.entities.Player.filter({ team_id: team.id });
        toast.success(`Imported ${players.length} players from ${team.name}`);
        onRosterScanned(team, players);
        return;
      } catch {
        return showError('Failed to look up team from QR code.');
      }
    }

    // 2. Check if it's a URL (GameChanger or CSV link)
    let url = null;
    try { url = new URL(text); } catch { /* not a URL */ }

    if (url) {
      try {
        // Fetch the URL — GameChanger links to a CSV or a page with a CSV
        const res = await fetch(text, { mode: 'cors' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const contentType = res.headers.get('content-type') || '';
        const body = await res.text();

        let csvText = body;
        // If it returned HTML (redirect page), look for a CSV link inside it
        if (contentType.includes('html')) {
          const csvLinkMatch = body.match(/href="([^"]+\.csv[^"]*)"/i);
          if (csvLinkMatch) {
            const csvRes = await fetch(csvLinkMatch[1]);
            if (!csvRes.ok) throw new Error('Could not fetch CSV from link');
            csvText = await csvRes.text();
          } else {
            throw new Error('QR code linked to a web page but no CSV download was found. Make sure you are scanning a GameChanger roster export QR code.');
          }
        }

        const players = parseCSV(csvText);
        setPreviewPlayers(players);
        setStatus('preview');
      } catch (err) {
        showError(err.message || 'Could not fetch or parse the CSV from the scanned URL.');
      }
      return;
    }

    // 3. Fallback — treat as bare share code
    try {
      const teams = await base44.entities.Team.filter({ share_code: text.trim() });
      if (!teams || teams.length === 0) return showError(`Could not recognize QR code content: "${text.slice(0, 60)}"`);
      const team = teams[0];
      const players = await base44.entities.Player.filter({ team_id: team.id });
      onRosterScanned(team, players);
    } catch {
      showError(`Unrecognized QR code: "${text.slice(0, 60)}"`);
    }
  };

  const handleConfirmImport = async () => {
    if (!teamId) return toast.error('No team selected — cannot import players');
    setImporting(true);
    try {
      const created = await Promise.all(
        previewPlayers.map(p =>
          base44.entities.Player.create({
            team_id: teamId,
            name: p.name,
            number: p.number || '0',
            position: p.position || 'UT',
            parent_email: p.parent_email || '',
            bats: p.bats || 'R',
            throws: p.throws || 'R',
          })
        )
      );
      toast.success(`${created.length} players imported!`);
      onRosterScanned(null, created);
    } catch (err) {
      toast.error('Import failed: ' + (err.message || 'Unknown error'));
    } finally {
      setImporting(false);
    }
  };

  const retry = () => {
    setErrorMsg('');
    setPreviewPlayers([]);
    setStatus('scanning');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onClick={onClose}>
      <div
        className="bg-card border border-border rounded-2xl w-full max-w-sm shadow-2xl flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border flex-shrink-0">
          <div>
            <h2 className="font-semibold text-sm">Import Roster</h2>
            <p className="text-xs text-muted-foreground">
              {status === 'preview' ? `${previewPlayers.length} players found` : 'Scan a GameChanger or team QR code'}
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted touch-manipulation">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">

          {/* Init — prompt to start camera */}
          {status === 'init' && (
            <div className="p-6 flex flex-col items-center gap-4 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Camera className="w-8 h-8 text-primary" />
              </div>
              <div>
                <p className="font-medium mb-1">Ready to scan</p>
                <p className="text-xs text-muted-foreground">Point your camera at a GameChanger roster QR code or an EagleBaseball team QR code.</p>
              </div>
              <Button onClick={startScanner} className="w-full">Start Camera</Button>
            </div>
          )}

          {/* Scanning */}
          {status === 'scanning' && (
            <div className="p-3">
              <div id="qr-roster-scanner-view" className="w-full rounded-xl overflow-hidden" style={{ minHeight: 260 }} />
              <p className="text-xs text-muted-foreground text-center mt-2">Align QR code within the frame</p>
            </div>
          )}

          {/* Loading */}
          {status === 'loading' && (
            <div className="h-48 flex flex-col items-center justify-center gap-3 text-muted-foreground">
              <Loader2 className="w-6 h-6 animate-spin" />
              <span className="text-sm">Reading roster data...</span>
            </div>
          )}

          {/* Error */}
          {status === 'error' && (
            <div className="p-5 flex flex-col items-center gap-4 text-center">
              <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-destructive" />
              </div>
              <p className="text-sm text-destructive font-medium">Import Failed</p>
              <p className="text-xs text-muted-foreground">{errorMsg}</p>
              <div className="flex gap-2 w-full">
                <Button variant="outline" className="flex-1" onClick={onClose}>Close</Button>
                <Button className="flex-1" onClick={retry}>Try Again</Button>
              </div>
            </div>
          )}

          {/* Preview */}
          {status === 'preview' && (
            <div className="p-4 space-y-3">
              <p className="text-xs text-muted-foreground">Review players before importing. Missing numbers or positions will use defaults.</p>
              <div className="space-y-1.5 max-h-64 overflow-y-auto">
                {previewPlayers.map((p, i) => (
                  <div key={i} className="flex items-center gap-2 bg-muted/50 rounded-lg px-3 py-2 text-sm">
                    <span className="w-7 text-center font-mono font-bold text-muted-foreground text-xs">#{p.number || '?'}</span>
                    <span className="flex-1 font-medium truncate">{p.name}</span>
                    <span className="text-xs text-muted-foreground bg-background px-1.5 py-0.5 rounded">{p.position}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer for preview */}
        {status === 'preview' && (
          <div className="p-4 border-t border-border flex gap-2 flex-shrink-0">
            <Button variant="outline" className="flex-1" onClick={retry}>Re-scan</Button>
            <Button className="flex-1 gap-2" onClick={handleConfirmImport} disabled={importing}>
              {importing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              {importing ? 'Importing...' : `Import ${previewPlayers.length} Players`}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}