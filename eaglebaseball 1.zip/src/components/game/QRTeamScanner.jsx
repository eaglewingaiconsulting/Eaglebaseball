import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function QRTeamScanner({ onTeamScanned, onClose }) {
  const scannerRef = useRef(null);
  const [status, setStatus] = useState('scanning'); // scanning | loading | done | error

  useEffect(() => {
    const scannerId = 'qr-team-scanner';
    const html5QrCode = new Html5Qrcode(scannerId);
    scannerRef.current = html5QrCode;

    html5QrCode.start(
      { facingMode: 'environment' },
      { fps: 10, qrbox: { width: 250, height: 250 } },
      async (decodedText) => {
        // Stop scanning immediately
        await html5QrCode.stop().catch(() => {});
        setStatus('loading');

        try {
          // URL format: .../teams/import/<share_code>
          const match = decodedText.match(/\/teams\/(?:import|fan)\/([A-Za-z0-9]+)/);
          const shareCode = match ? match[1] : decodedText.trim();

          const teams = await base44.entities.Team.filter({ share_code: shareCode });
          if (!teams || teams.length === 0) {
            setStatus('error');
            toast.error('No team found for this QR code');
            return;
          }
          const team = teams[0];
          toast.success(`Found: ${team.name}`);
          onTeamScanned(team);
        } catch {
          setStatus('error');
          toast.error('Failed to look up team');
        }
      },
      () => {} // ignore per-frame errors
    ).catch(() => {
      setStatus('error');
      toast.error('Camera not accessible');
    });

    return () => {
      html5QrCode.stop().catch(() => {});
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
      <div className="bg-card border border-border rounded-2xl p-5 w-full max-w-sm shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-semibold">Scan Away Team QR</h2>
            <p className="text-xs text-muted-foreground">Point at the opposing team's QR code</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted"><X className="w-4 h-4" /></button>
        </div>

        {status === 'scanning' && (
          <div id="qr-team-scanner" className="w-full rounded-xl overflow-hidden" />
        )}

        {status === 'loading' && (
          <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
            Looking up team...
          </div>
        )}

        {status === 'error' && (
          <div className="h-48 flex flex-col items-center justify-center gap-3">
            <p className="text-sm text-destructive">Could not read team QR code.</p>
            <button className="text-xs text-primary underline" onClick={onClose}>Try again</button>
          </div>
        )}
      </div>
    </div>
  );
}