import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Trash2, Upload, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';

const PAYMENT_APPS = [
  { value: 'venmo', label: 'Venmo', color: '#3D95CE' },
  { value: 'paypal', label: 'PayPal', color: '#003087' },
  { value: 'cashapp', label: 'Cash App', color: '#00D54B' },
  { value: 'zelle', label: 'Zelle', color: '#6D1ED4' },
  { value: 'applepay', label: 'Apple Pay', color: '#000000' },
  { value: 'other', label: 'Other', color: '#6B7280' },
];

export default function PaymentQRManager({ entity, entityType, onSave }) {
  // entity = team or org object, entityType = 'Team' | 'Organization'
  const [qrCodes, setQrCodes] = useState(entity?.payment_qr_codes || []);
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newEntry, setNewEntry] = useState({ app: 'venmo', label: '', qr_url: '', handle: '' });
  const [uploading, setUploading] = useState(false);

  const handleQrUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setNewEntry(n => ({ ...n, qr_url: file_url }));
      toast.success('QR image uploaded');
    } catch {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const addQrCode = () => {
    if (!newEntry.app) return;
    const appInfo = PAYMENT_APPS.find(a => a.value === newEntry.app);
    const label = newEntry.label || appInfo?.label || newEntry.app;
    setQrCodes(prev => [...prev, { ...newEntry, label }]);
    setNewEntry({ app: 'venmo', label: '', qr_url: '', handle: '' });
    setAdding(false);
  };

  const removeQrCode = (idx) => {
    setQrCodes(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const updated = await base44.entities[entityType].update(entity.id, { payment_qr_codes: qrCodes });
      onSave?.(updated);
      toast.success('Payment options saved!');
    } catch {
      toast.error('Failed to save');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Existing QR codes */}
      {qrCodes.length === 0 && !adding && (
        <p className="text-sm text-muted-foreground text-center py-4">No payment options added yet.</p>
      )}

      <div className="grid sm:grid-cols-2 gap-3">
        {qrCodes.map((qr, idx) => {
          const appInfo = PAYMENT_APPS.find(a => a.value === qr.app);
          return (
            <div key={idx} className="bg-muted/50 rounded-xl p-4 flex items-start gap-3 border border-border">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                style={{ backgroundColor: appInfo?.color || '#6B7280' }}>
                {qr.label?.slice(0, 2).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm">{qr.label}</div>
                {qr.handle && <div className="text-xs text-muted-foreground">{qr.handle}</div>}
                {qr.qr_url && (
                  <a href={qr.qr_url} target="_blank" rel="noopener noreferrer"
                    className="text-xs text-primary flex items-center gap-1 mt-1">
                    <ExternalLink className="w-3 h-3" /> View QR
                  </a>
                )}
              </div>
              <button onClick={() => removeQrCode(idx)} className="text-destructive hover:text-destructive/80 p-1">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Add new */}
      {adding ? (
        <div className="bg-card border border-border rounded-xl p-4 space-y-3">
          <div className="space-y-1.5">
            <Label>Payment App</Label>
            <div className="flex flex-wrap gap-2">
              {PAYMENT_APPS.map(app => (
                <button
                  key={app.value}
                  onClick={() => setNewEntry(n => ({ ...n, app: app.value }))}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    newEntry.app === app.value
                      ? 'text-white border-transparent'
                      : 'bg-muted text-muted-foreground border-border hover:border-primary/50'
                  }`}
                  style={newEntry.app === app.value ? { backgroundColor: app.color } : {}}
                >
                  {app.label}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Label (optional)</Label>
              <Input
                value={newEntry.label}
                onChange={e => setNewEntry(n => ({ ...n, label: e.target.value }))}
                placeholder="e.g. Coach Mike's Venmo"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Handle / Username</Label>
              <Input
                value={newEntry.handle}
                onChange={e => setNewEntry(n => ({ ...n, handle: e.target.value }))}
                placeholder="@username"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>QR Code Image</Label>
            <div className="flex items-center gap-3">
              {newEntry.qr_url
                ? <img src={newEntry.qr_url} alt="QR" className="w-16 h-16 rounded-lg object-contain border border-border" />
                : null
              }
              <label className="cursor-pointer">
                <input type="file" accept="image/*" className="hidden" onChange={handleQrUpload} />
                <span className="flex items-center gap-2 px-3 py-2 rounded-lg border border-dashed border-border text-sm text-muted-foreground hover:border-primary/50 transition-colors">
                  <Upload className="w-4 h-4" />
                  {uploading ? 'Uploading...' : 'Upload QR Image'}
                </span>
              </label>
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" onClick={addQrCode} disabled={!newEntry.app}>Add</Button>
            <Button size="sm" variant="outline" onClick={() => setAdding(false)}>Cancel</Button>
          </div>
        </div>
      ) : (
        <Button variant="outline" size="sm" className="gap-2 w-full" onClick={() => setAdding(true)}>
          <Plus className="w-4 h-4" /> Add Payment Option
        </Button>
      )}

      <Button onClick={handleSave} disabled={saving} className="w-full">
        {saving ? 'Saving...' : 'Save Payment Options'}
      </Button>
    </div>
  );
}