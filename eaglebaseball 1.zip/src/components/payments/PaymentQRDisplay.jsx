import { useState } from 'react';
import { X } from 'lucide-react';

const PAYMENT_APPS = [
  { value: 'venmo', label: 'Venmo', color: '#3D95CE' },
  { value: 'paypal', label: 'PayPal', color: '#003087' },
  { value: 'cashapp', label: 'Cash App', color: '#00D54B' },
  { value: 'zelle', label: 'Zelle', color: '#6D1ED4' },
  { value: 'applepay', label: 'Apple Pay', color: '#000000' },
  { value: 'other', label: 'Other', color: '#6B7280' },
];

export default function PaymentQRDisplay({ qrCodes = [], title = 'Pay Now' }) {
  const [selected, setSelected] = useState(null);

  if (!qrCodes.length) return null;

  return (
    <>
      <div className="space-y-3">
        <h3 className="font-semibold text-sm">{title}</h3>
        <div className="flex flex-wrap gap-2">
          {qrCodes.map((qr, idx) => {
            const appInfo = PAYMENT_APPS.find(a => a.value === qr.app);
            return (
              <button
                key={idx}
                onClick={() => setSelected(qr)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-white text-sm font-medium shadow-sm active:scale-95 transition-transform"
                style={{ backgroundColor: appInfo?.color || '#6B7280' }}
              >
                {qr.label}
              </button>
            );
          })}
        </div>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-6" onClick={() => setSelected(null)}>
          <div className="bg-card rounded-2xl p-6 max-w-xs w-full shadow-2xl text-center" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="font-semibold">{selected.label}</div>
                {selected.handle && <div className="text-xs text-muted-foreground">{selected.handle}</div>}
              </div>
              <button onClick={() => setSelected(null)} className="p-1.5 rounded-lg hover:bg-muted">
                <X className="w-4 h-4" />
              </button>
            </div>
            {selected.qr_url ? (
              <img src={selected.qr_url} alt={`${selected.label} QR`} className="w-full rounded-xl border border-border" />
            ) : (
              <div className="text-muted-foreground text-sm py-8">
                {selected.handle ? `Send to: ${selected.handle}` : 'No QR code available'}
              </div>
            )}
            <p className="text-xs text-muted-foreground mt-4">Tap outside to close</p>
          </div>
        </div>
      )}
    </>
  );
}