/**
 * MobileSelect — renders a bottom Drawer on mobile (<768px) and a standard
 * Radix Select popover on desktop. Drop-in replacement for Select.
 *
 * Usage:
 *   <MobileSelect value={v} onValueChange={setV} placeholder="Pick one">
 *     <MobileSelectItem value="a">Option A</MobileSelectItem>
 *     <MobileSelectItem value="b">Option B</MobileSelectItem>
 *   </MobileSelect>
 */
import { useState, useEffect, createContext, useContext } from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Check, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

// ─── context so MobileSelectItem can read parent state ───────────────────────
const MobileSelectCtx = createContext(null);

// ─── hook: true if window width < 768 ────────────────────────────────────────
function useMobile() {
  const [mobile, setMobile] = useState(() => window.innerWidth < 768);
  useEffect(() => {
    const handler = () => setMobile(window.innerWidth < 768);
    window.addEventListener('resize', handler, { passive: true });
    return () => window.removeEventListener('resize', handler);
  }, []);
  return mobile;
}

// ─── Item (works for both desktop Select and mobile Drawer) ──────────────────
export function MobileSelectItem({ value, children, className }) {
  const ctx = useContext(MobileSelectCtx);

  // Desktop — delegate to Radix SelectItem
  if (!ctx?.mobile) {
    return <SelectItem value={value} className={className}>{children}</SelectItem>;
  }

  // Mobile — plain button inside Drawer
  const selected = ctx.value === value;
  return (
    <button
      type="button"
      onClick={() => { ctx.onChange(value); ctx.setOpen(false); }}
      className={cn(
        'w-full flex items-center justify-between px-5 py-4 text-sm text-left',
        'transition-colors active:bg-muted/60',
        selected
          ? 'text-primary font-semibold bg-primary/5'
          : 'text-foreground hover:bg-muted/40',
        className
      )}
    >
      <span>{children}</span>
      {selected && <Check className="w-4 h-4 text-primary flex-shrink-0" />}
    </button>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export function MobileSelect({
  value,
  onValueChange,
  placeholder = 'Select…',
  disabled = false,
  className,
  label,          // optional: shown as DrawerTitle on mobile
  children,
}) {
  const mobile = useMobile();
  const [open, setOpen] = useState(false);

  // Find the label of the currently selected item so we can show it in trigger
  // We parse children to extract text for the selected value
  const selectedLabel = (() => {
    if (!value) return null;
    let found = null;
    const scan = (nodes) => {
      if (!nodes) return;
      const arr = Array.isArray(nodes) ? nodes : [nodes];
      arr.forEach(child => {
        if (!child) return;
        if (child.props?.value === value) { found = child.props.children; }
        if (child.props?.children) scan(child.props.children);
      });
    };
    scan(children);
    return found;
  })();

  // ── Desktop: standard Radix Select ──────────────────────────────────────────
  if (!mobile) {
    return (
      <Select value={value} onValueChange={onValueChange} disabled={disabled}>
        <SelectTrigger className={className}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          <MobileSelectCtx.Provider value={{ mobile: false }}>
            {children}
          </MobileSelectCtx.Provider>
        </SelectContent>
      </Select>
    );
  }

  // ── Mobile: Drawer ───────────────────────────────────────────────────────────
  return (
    <MobileSelectCtx.Provider value={{ mobile: true, value, onChange: onValueChange, setOpen }}>
      {/* Trigger button — mimics SelectTrigger styling */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen(true)}
        className={cn(
          'flex h-9 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2',
          'text-sm shadow-sm transition-colors',
          'placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring',
          'disabled:cursor-not-allowed disabled:opacity-50',
          className
        )}
      >
        <span className={value ? 'text-foreground' : 'text-muted-foreground'}>
          {selectedLabel ?? placeholder}
        </span>
        <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0 opacity-50" />
      </button>

      <Drawer open={open} onOpenChange={setOpen}>
        <DrawerContent className="max-h-[80vh]">
          {label && (
            <DrawerHeader className="pb-2 border-b border-border">
              <DrawerTitle className="text-base">{label}</DrawerTitle>
            </DrawerHeader>
          )}
          <div className="overflow-y-auto py-2 divide-y divide-border/50">
            {children}
          </div>
          {/* Bottom safe area spacer */}
          <div className="h-safe pb-safe" />
        </DrawerContent>
      </Drawer>
    </MobileSelectCtx.Provider>
  );
}

export default MobileSelect;