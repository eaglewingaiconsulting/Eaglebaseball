import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { MessageSquarePlus, X, ChevronRight } from 'lucide-react';

const CATEGORIES = [
  "I won't use this app without this feature",
  "I'd like to see this feature",
  "This app would be amazing if...",
];

export default function FeedbackButton() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [selected, setSelected] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState(null); // 'success' | 'error'

  const reset = () => {
    setStep(1);
    setSelected(null);
    setFeedback('');
    setName('');
    setEmail('');
    setStatus(null);
    setSubmitting(false);
  };

  const handleClose = () => {
    setOpen(false);
    setTimeout(reset, 300);
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setStatus(null);
    try {
      const res = await base44.functions.invoke('submitFeedback', {
        app_name: 'EagleBaseball',
        category: selected,
        feedback,
        name: name || null,
        email: email || null,
      });
      if (res.data?.success) {
        setStatus('success');
        setTimeout(handleClose, 2000);
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    } finally {
      setSubmitting(false);
    }
  };

  const canSubmit = feedback.trim().length >= 20 && !submitting;

  return (
    <>
      {/* FAB */}
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-20 right-4 lg:bottom-6 z-50 bg-primary text-primary-foreground rounded-full px-4 py-3 shadow-lg flex items-center gap-2 text-sm font-semibold hover:bg-primary/90 transition-all active:scale-95 touch-manipulation select-none"
        aria-label="Send feedback"
      >
        <MessageSquarePlus className="w-4 h-4" />
        <span className="hidden sm:inline">Feedback</span>
      </button>

      {/* Modal overlay */}
      {open && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4" onClick={handleClose}>
          <div
            className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl"
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div>
                <div className="font-semibold text-base">Share Feedback</div>
                <div className="text-xs text-muted-foreground">Step {step} of 2</div>
              </div>
              <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-muted transition-colors touch-manipulation">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5">
              {/* Step 1 — Category */}
              {step === 1 && (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground mb-4">What kind of feedback do you have?</p>
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setSelected(cat)}
                      className={`w-full text-left px-4 py-3.5 rounded-xl border text-sm font-medium transition-all touch-manipulation ${
                        selected === cat
                          ? 'border-primary bg-primary/10 text-primary'
                          : 'border-border bg-background hover:border-primary/40 hover:bg-muted/50'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                  <button
                    onClick={() => setStep(2)}
                    disabled={!selected}
                    className="mt-2 w-full bg-primary text-primary-foreground rounded-xl py-3 font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-[0.98] touch-manipulation"
                  >
                    Next <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Step 2 — Form */}
              {step === 2 && (
                <div className="space-y-4">
                  <div className="bg-muted/50 rounded-lg px-3 py-2 text-xs text-muted-foreground border border-border">
                    {selected}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1.5">
                      Describe your feedback <span className="text-destructive">*</span>
                    </label>
                    <textarea
                      value={feedback}
                      onChange={e => setFeedback(e.target.value)}
                      placeholder="Tell us more... (min 20 characters)"
                      rows={4}
                      className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
                    />
                    <div className={`text-xs mt-1 ${feedback.length < 20 ? 'text-muted-foreground' : 'text-green-600'}`}>
                      {feedback.trim().length} / 20 min characters
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1.5">Your Name <span className="text-muted-foreground text-xs">(optional)</span></label>
                    <input
                      type="text"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="e.g. John Smith"
                      className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1.5">Your Email <span className="text-muted-foreground text-xs">(optional)</span></label>
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="e.g. you@example.com"
                      className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
                    />
                  </div>

                  {status === 'success' && (
                    <div className="bg-green-50 border border-green-200 text-green-700 rounded-xl px-4 py-3 text-sm font-medium text-center">
                      🎉 Thanks for your feedback!
                    </div>
                  )}
                  {status === 'error' && (
                    <div className="bg-destructive/10 border border-destructive/20 text-destructive rounded-xl px-4 py-3 text-sm text-center">
                      Something went wrong. Please try again.
                    </div>
                  )}

                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => setStep(1)}
                      className="px-4 py-2.5 rounded-xl border border-border text-sm font-medium hover:bg-muted transition-colors touch-manipulation"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleSubmit}
                      disabled={!canSubmit}
                      className="flex-1 bg-primary text-primary-foreground rounded-xl py-2.5 font-semibold text-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-[0.98] touch-manipulation"
                    >
                      {submitting ? 'Submitting...' : 'Submit'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}