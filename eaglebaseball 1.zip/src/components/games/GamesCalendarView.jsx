import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const STATUS_DOT = {
  scheduled: 'bg-blue-500',
  in_progress: 'bg-green-500 animate-pulse',
  completed: 'bg-gray-400',
  postponed: 'bg-amber-500',
  cancelled: 'bg-red-500',
};

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

export default function GamesCalendarView({ games }) {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());

  const prevMonth = () => {
    if (month === 0) { setMonth(11); setYear(y => y - 1); }
    else setMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (month === 11) { setMonth(0); setYear(y => y + 1); }
    else setMonth(m => m + 1);
  };

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Map games to day numbers
  const gamesByDay = {};
  games.forEach(g => {
    if (!g.scheduled_date) return;
    const d = new Date(g.scheduled_date);
    if (d.getFullYear() === year && d.getMonth() === month) {
      const day = d.getDate();
      if (!gamesByDay[day]) gamesByDay[day] = [];
      gamesByDay[day].push(g);
    }
  });

  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const isToday = (d) => d === today.getDate() && month === today.getMonth() && year === today.getFullYear();

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={prevMonth}><ChevronLeft className="w-4 h-4" /></Button>
        <span className="font-semibold">{MONTHS[month]} {year}</span>
        <Button variant="ghost" size="icon" onClick={nextMonth}><ChevronRight className="w-4 h-4" /></Button>
      </div>

      {/* Day labels */}
      <div className="grid grid-cols-7 border-b border-border">
        {DAYS.map(d => (
          <div key={d} className="text-center text-xs text-muted-foreground py-2 font-medium">{d}</div>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-7">
        {cells.map((day, idx) => (
          <div key={idx} className={`min-h-[80px] border-b border-r border-border p-1.5 ${!day ? 'bg-muted/20' : ''} ${isToday(day) ? 'bg-primary/5' : ''}`}>
            {day && (
              <>
                <div className={`text-xs font-medium mb-1 w-6 h-6 flex items-center justify-center rounded-full ${isToday(day) ? 'bg-primary text-primary-foreground' : 'text-foreground'}`}>
                  {day}
                </div>
                <div className="space-y-0.5">
                  {(gamesByDay[day] || []).slice(0, 3).map(g => (
                    <Link key={g.id} to={g.status === 'in_progress' ? `/games/${g.id}/live` : `/games/${g.id}`}
                      className="flex items-center gap-1 px-1 py-0.5 rounded text-xs hover:bg-muted transition-colors truncate">
                      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${STATUS_DOT[g.status] || 'bg-gray-400'}`} />
                      <span className="truncate text-[10px] leading-tight">{g.away_team_name} @ {g.home_team_name}</span>
                    </Link>
                  ))}
                  {(gamesByDay[day] || []).length > 3 && (
                    <div className="text-[10px] text-muted-foreground pl-1">+{gamesByDay[day].length - 3} more</div>
                  )}
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}