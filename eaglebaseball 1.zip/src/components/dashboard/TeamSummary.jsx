import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Trophy, TrendingUp, Calendar, Loader2 } from 'lucide-react';
import { PlayerAvatar } from '@/components/player/PlayerPhotoUpload';

export default function TeamSummary({ team }) {
  const [recentGames, setRecentGames] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!team) return;
    Promise.all([
      base44.entities.Game.list('-scheduled_date', 30),
      base44.entities.Player.filter({ team_id: team.id }),
    ]).then(([allGames, pls]) => {
      const teamGames = allGames.filter(g => g.home_team_id === team.id || g.away_team_id === team.id);
      setRecentGames(teamGames.filter(g => g.status === 'completed' || g.status === 'final').slice(0, 3));
      setPlayers(pls);
      setLoading(false);
    });
  }, [team?.id]);

  if (!team || loading) return (
    <div className="flex justify-center py-6">
      <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
    </div>
  );

  const pitchers = players.filter(p => (p.innings_pitched || 0) >= 1);
  const bestERA = pitchers.reduce((best, p) => (!best || (p.era || 99) < (best.era || 99)) ? p : best, null);
  const bestAvg = players.reduce((best, p) => (!best || (p.batting_avg || 0) > (best.batting_avg || 0)) ? p : best, null);
  const mostRBIs = players.reduce((best, p) => (!best || (p.rbis || 0) > (best.rbis || 0)) ? p : best, null);
  const mostKs = pitchers.reduce((best, p) => (!best || (p.strikeouts_pitching || 0) > (best.strikeouts_pitching || 0)) ? p : best, null);
  const mostHits = players.reduce((best, p) => (!best || (p.hits || 0) > (best.hits || 0)) ? p : best, null);

  const highlights = [
    { label: 'Best ERA', player: bestERA, stat: bestERA ? (bestERA.era || 0).toFixed(2) : null },
    { label: 'Batting Avg', player: bestAvg, stat: bestAvg ? (bestAvg.batting_avg || 0).toFixed(3) : null },
    { label: 'Most RBIs', player: mostRBIs, stat: mostRBIs?.rbis || 0 },
    { label: 'Most Ks (P)', player: mostKs, stat: mostKs?.strikeouts_pitching || 0 },
    { label: 'Most Hits', player: mostHits, stat: mostHits?.hits || 0 },
  ].filter(h => h.player && h.stat);

  return (
    <div className="space-y-4">
      {/* Recent Games */}
      <div>
        <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-2">
          <Trophy className="w-4 h-4" /> Recent Games
        </h2>
        {recentGames.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4 bg-card border border-dashed border-border rounded-xl">No completed games yet</p>
        ) : (
          <div className="space-y-2">
            {recentGames.map(game => {
              const isHome = game.home_team_id === team.id;
              const myScore = isHome ? game.home_score : game.away_score;
              const oppScore = isHome ? game.away_score : game.home_score;
              const won = myScore > oppScore;
              return (
                <Link key={game.id} to={`/games/${game.id}`}
                  className="flex items-center justify-between bg-card border border-border rounded-xl p-3.5 hover:border-primary/40 transition-colors active:scale-[0.99]">
                  <div>
                    <div className="text-sm font-medium">{game.away_team_name} @ {game.home_team_name}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />{game.scheduled_date}
                      {game.location && ` · ${game.location}`}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold font-bebas text-lg">{game.away_score}–{game.home_score}</span>
                    <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${won ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {won ? 'W' : 'L'}
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>

      {/* Season Highlights */}
      {highlights.length > 0 && (
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" /> Season Highlights
          </h2>
          <div className="grid sm:grid-cols-2 gap-2">
            {highlights.map(h => (
              <Link key={h.label} to={`/players/${h.player.id}`}
                className="flex items-center gap-3 bg-card border border-border rounded-xl p-3 hover:border-primary/40 transition-colors">
                <PlayerAvatar player={h.player} size="sm" />
                <div className="min-w-0 flex-1">
                  <div className="text-xs text-muted-foreground">{h.label}</div>
                  <div className="text-sm font-semibold truncate">{h.player.name}</div>
                </div>
                <div className="text-base font-bold font-bebas">{h.stat}</div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}