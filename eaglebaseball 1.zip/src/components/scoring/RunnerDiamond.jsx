// RunnerDiamond — base diamond with highlighted occupied bases + tap-to-action
import { useState, useEffect } from 'react';

function BasePad({ occupied, label, size, runnerLabel, onClick, pulse, isNew }) {
  return (
    <div
      className="relative flex items-center justify-center"
      style={{ width: size, height: size, transform: 'rotate(45deg)', cursor: occupied ? 'pointer' : 'default' }}
      onClick={occupied ? onClick : undefined}>
      {/* Base pad */}
      <div
        className={`w-full h-full rounded-sm border-2 transition-all duration-300 ${
          occupied
            ? `border-[#FFB81C] bg-[#FFB81C] ${isNew ? 'scale-110' : 'scale-100'}`
            : 'border-white/40 bg-white/5'
        }`}
        style={occupied ? {
          boxShadow: '0 0 12px 4px rgba(255,184,28,0.7), 0 0 24px 8px rgba(255,184,28,0.35)',
        } : {}}
      />
      {/* Runner number */}
      {occupied && runnerLabel && (
        <span
          className="absolute font-bold text-[#002D62] leading-none select-none z-10"
          style={{ transform: 'rotate(-45deg)', fontSize: size * 0.3 }}>
          {runnerLabel}
        </span>
      )}
      {/* Base label when empty */}
      {!occupied && (
        <span
          className="absolute text-white/35 font-bold leading-none select-none"
          style={{ transform: 'rotate(-45deg)', fontSize: size * 0.22 }}>
          {label}
        </span>
      )}
      {/* Tap indicator ring when occupied */}
      {occupied && (
        <div
          className={`absolute inset-[-4px] rounded-sm border-2 border-white/40 pointer-events-none ${pulse ? 'animate-ping' : ''}`}
          style={{ zIndex: 0 }}
        />
      )}
    </div>
  );
}

export default function RunnerDiamond({ game, players, onBaseClick, isPhone }) {
  const baseSize = isPhone ? 38 : 52;
  const totalSize = isPhone ? 140 : 195;

  const [newBases, setNewBases] = useState({ first: false, second: false, third: false });
  const [pulseBases, setPulseBases] = useState({ first: false, second: false, third: false });

  useEffect(() => {
    const n = {
      first: !!game?.runner_first,
      second: !!game?.runner_second,
      third: !!game?.runner_third,
    };
    setNewBases(n);
    setPulseBases(n);
    const t = setTimeout(() => {
      setNewBases({ first: false, second: false, third: false });
      setPulseBases({ first: false, second: false, third: false });
    }, 900);
    return () => clearTimeout(t);
  }, [game?.runner_first, game?.runner_second, game?.runner_third]);

  // runner_first/second/third may be a player ID string or boolean true
  function getRunnerLabel(base) {
    const val = base === 'first' ? game?.runner_first : base === 'second' ? game?.runner_second : game?.runner_third;
    if (!val) return '';
    if (typeof val === 'string') {
      const p = players?.find(pl => pl.id === val);
      return p?.number || p?.name?.charAt(0) || '●';
    }
    return '●';
  }

  const balls = game?.balls || 0;
  const strikes = game?.strikes || 0;
  const outs = game?.outs || 0;

  const dotSz = isPhone ? 14 : 16;

  return (
    <div className="flex items-center justify-center gap-4 py-3">
      {/* Diamond */}
      <div className="relative flex-shrink-0" style={{ width: totalSize, height: totalSize }}>
        {/* Diamond background lines */}
        <svg className="absolute inset-0 w-full h-full" viewBox={`0 0 ${totalSize} ${totalSize}`} style={{ opacity: 0.15 }}>
          <polygon
            points={`${totalSize/2},${baseSize/2} ${totalSize-baseSize/2},${totalSize/2} ${totalSize/2},${totalSize-baseSize/2} ${baseSize/2},${totalSize/2}`}
            fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="1" strokeDasharray="4 4"
          />
        </svg>

        {/* 2B */}
        <div className="absolute" style={{ top: 0, left: '50%', transform: 'translateX(-50%)' }}>
          <BasePad occupied={!!game?.runner_second} label="2B" size={baseSize} runnerLabel={getRunnerLabel('second')} onClick={() => onBaseClick?.('second')} pulse={pulseBases.second} isNew={newBases.second} />
        </div>
        {/* 3B */}
        <div className="absolute" style={{ top: '50%', left: 0, transform: 'translateY(-50%)' }}>
          <BasePad occupied={!!game?.runner_third} label="3B" size={baseSize} runnerLabel={getRunnerLabel('third')} onClick={() => onBaseClick?.('third')} pulse={pulseBases.third} isNew={newBases.third} />
        </div>
        {/* 1B */}
        <div className="absolute" style={{ top: '50%', right: 0, transform: 'translateY(-50%)' }}>
          <BasePad occupied={!!game?.runner_first} label="1B" size={baseSize} runnerLabel={getRunnerLabel('first')} onClick={() => onBaseClick?.('first')} pulse={pulseBases.first} isNew={newBases.first} />
        </div>
        {/* Home */}
        <div className="absolute" style={{ bottom: 0, left: '50%', transform: 'translateX(-50%)' }}>
          <svg width={baseSize} height={baseSize} viewBox="0 0 30 30">
            <polygon points="15,2 28,12 23,28 7,28 2,12" fill="rgba(255,255,255,0.08)" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" />
          </svg>
        </div>
        {/* Center dot */}
        <div className="absolute" style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}>
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: 'rgba(255,184,28,0.3)' }} />
        </div>
      </div>

      {/* BSO vertical */}
      <div className="flex flex-col gap-3">
        {[
          { label: 'B', count: balls, max: 4, activeColor: '#4ade80' },
          { label: 'S', count: strikes, max: 3, activeColor: '#facc15' },
          { label: 'O', count: outs, max: 3, activeColor: '#f87171' },
        ].map(({ label, count, max, activeColor }) => (
          <div key={label} className="flex items-center gap-2">
            <span className="text-[11px] font-black uppercase w-3.5 text-right" style={{ color: 'rgba(255,255,255,0.3)' }}>{label}</span>
            <div className="flex gap-1.5">
              {Array.from({ length: max }).map((_, i) => (
                <div key={i} className="rounded-full border-2 transition-all duration-200"
                  style={{
                    width: dotSz, height: dotSz,
                    ...(i < count
                      ? { backgroundColor: activeColor, borderColor: activeColor, boxShadow: `0 0 6px ${activeColor}90` }
                      : { backgroundColor: 'transparent', borderColor: 'rgba(255,255,255,0.12)' })
                  }} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}