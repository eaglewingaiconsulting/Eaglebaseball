// FielderSelectModal — prompts user to select fielder(s) before recording an out
import { useState } from 'react';
import { X } from 'lucide-react';

const POSITIONS = ['P', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF'];

function PositionGrid({ value, onChange, defensivePlayers, mode }) {
  if (mode === 'position') {
    return (
      <div className="flex flex-wrap gap-2">
        {POSITIONS.map(pos => (
          <button key={pos} onClick={() => onChange(pos)}
            className="px-3 py-2 rounded-xl text-sm font-bold select-none touch-manipulation transition-all"
            style={value === pos
              ? { backgroundColor: '#FFB81C', color: '#002D62' }
              : { backgroundColor: 'rgba(255,255,255,0.1)', color: 'white' }}>
            {pos}
          </button>
        ))}
      </div>
    );
  }
  return (
    <div className="grid grid-cols-2 gap-1.5 max-h-32 overflow-y-auto">
      {defensivePlayers.map(p => (
        <button key={p.id} onClick={() => onChange(p.name)}
          className="px-3 py-2 rounded-xl text-sm text-left select-none touch-manipulation transition-all"
          style={value === p.name
            ? { backgroundColor: '#FFB81C', color: '#002D62', fontWeight: 600 }
            : { backgroundColor: 'rgba(255,255,255,0.1)', color: 'white' }}>
          #{p.number} {p.name}
        </button>
      ))}
    </div>
  );
}

export default function FielderSelectModal({ game, players, isDoublePlay, onConfirm, onClose }) {
  const [fielder1, setFielder1] = useState('');
  const [fielder2, setFielder2] = useState('');
  const [fielder3, setFielder3] = useState('');
  const [mode, setMode] = useState('position');

  const isTop = game.inning_half === 'top';
  const defensiveTeamId = isTop ? game.home_team_id : game.away_team_id;
  const defensivePlayers = players.filter(p => p.team_id === defensiveTeamId);

  const canConfirm = isDoublePlay ? (fielder1 && fielder2) : fielder1;
  const getSequence = () => [fielder1, fielder2, fielder3].filter(Boolean).join('-');

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70" onClick={onClose}>
      <div
        className="bg-[hsl(214,90%,9%)] border-t border-white/20 rounded-t-2xl w-full max-w-lg p-5 space-y-4"
        style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 20px)' }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-white font-bold text-base">
              {isDoublePlay ? '⚾ Double Play — Select Fielders' : '⚾ Select Fielder'}
            </div>
            <div className="text-white/50 text-xs mt-0.5">
              {isDoublePlay
                ? `Sequence (e.g. 6-4-3)${fielder1 && fielder2 ? ` → ${getSequence()}` : ''}`
                : 'Who made this play?'}
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 select-none touch-manipulation">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Mode toggle */}
        <div className="flex gap-1 bg-white/5 rounded-lg p-1">
          {['position', 'player'].map(m => (
            <button key={m} onClick={() => setMode(m)}
              className="flex-1 py-2 rounded-md text-sm font-semibold capitalize transition-all select-none touch-manipulation"
              style={mode === m ? { backgroundColor: '#FFB81C', color: '#002D62' } : { color: 'rgba(255,255,255,0.5)' }}>
              {m === 'position' ? 'By Position' : 'By Player'}
            </button>
          ))}
        </div>

        <div className="space-y-5 max-h-[50vh] overflow-y-auto">
          {/* Out #1 */}
          <div>
            <div className="text-xs uppercase tracking-wide font-bold mb-2" style={{ color: '#FFB81C' }}>
              {isDoublePlay ? 'Out #1 — Fielder *' : 'Fielder *'}
            </div>
            <PositionGrid value={fielder1} onChange={setFielder1} defensivePlayers={defensivePlayers} mode={mode} />
            {fielder1 && <div className="text-green-400 text-xs mt-1.5 font-semibold">✓ {fielder1}</div>}
          </div>

          {/* Out #2 — only for double play */}
          {isDoublePlay && (
            <div>
              <div className="text-xs uppercase tracking-wide font-bold mb-2" style={{ color: '#f87171' }}>
                Out #2 — Fielder *
              </div>
              <PositionGrid value={fielder2} onChange={setFielder2} defensivePlayers={defensivePlayers} mode={mode} />
              {fielder2 && <div className="text-green-400 text-xs mt-1.5 font-semibold">✓ {fielder2}</div>}
            </div>
          )}

          {/* Relay — optional for double play */}
          {isDoublePlay && (
            <div>
              <div className="text-xs uppercase tracking-wide font-bold mb-2" style={{ color: 'rgba(255,255,255,0.35)' }}>
                Relay Fielder (optional)
              </div>
              <PositionGrid
                value={fielder3}
                onChange={(val) => setFielder3(prev => prev === val ? '' : val)}
                defensivePlayers={defensivePlayers}
                mode={mode}
              />
              {fielder3 && <div className="text-blue-400 text-xs mt-1.5 font-semibold">✓ {fielder3}</div>}
            </div>
          )}
        </div>

        {/* Sequence preview */}
        {isDoublePlay && fielder1 && fielder2 && (
          <div className="text-center py-2 rounded-xl bg-white/5 text-white font-bold text-lg tracking-widest">
            {getSequence()}
          </div>
        )}

        <button
          disabled={!canConfirm}
          onClick={() => onConfirm({ fielder1, fielder2: fielder2 || null, fielder3: fielder3 || null, sequence: getSequence() })}
          className="w-full py-4 rounded-xl font-bold text-base disabled:opacity-40 disabled:cursor-not-allowed select-none touch-manipulation"
          style={{ backgroundColor: canConfirm ? '#FFB81C' : 'rgba(255,255,255,0.1)', color: canConfirm ? '#002D62' : 'rgba(255,255,255,0.4)' }}>
          {isDoublePlay ? `Confirm Double Play${canConfirm ? ` (${getSequence()})` : ''}` : 'Confirm Out'}
        </button>
      </div>
    </div>
  );
}