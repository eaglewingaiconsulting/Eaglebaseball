// RunnerActionSheet — bottom sheet for moving a base runner
export default function RunnerActionSheet({ runner, base, players, game, onAction, onClose }) {
  const player = players.find(p => p.id === runner);
  const displayName = player ? `#${player.number} ${player.name}` : 'Runner';
  const baseLabel = { first: '1st Base', second: '2nd Base', third: '3rd Base' }[base];

  const actions = [];

  if (base === 'first') {
    actions.push({ id: 'advance_2b', label: '→ Advance to 2nd', color: 'bg-blue-700' });
    actions.push({ id: 'advance_3b', label: '→ Advance to 3rd', color: 'bg-blue-700' });
    actions.push({ id: 'advance_home', label: '🏠 Advance to Home (Score)', color: 'bg-green-700' });
  }
  if (base === 'second') {
    actions.push({ id: 'advance_3b', label: '→ Advance to 3rd', color: 'bg-blue-700' });
    actions.push({ id: 'advance_home', label: '🏠 Advance to Home (Score)', color: 'bg-green-700' });
  }
  if (base === 'third') {
    actions.push({ id: 'advance_home', label: '🏠 Score Run', color: 'bg-green-700' });
    actions.push({ id: 'score_throw', label: '🏠 Score — Advance on Throw', color: 'bg-green-600' });
    actions.push({ id: 'score_passed_ball', label: '🏠 Score — Passed Ball', color: 'bg-teal-700' });
    actions.push({ id: 'score_wild_pitch', label: '🏠 Score — Wild Pitch', color: 'bg-teal-700' });
    actions.push({ id: 'score_balk', label: '🏠 Score — Balk', color: 'bg-teal-700' });
  }
  actions.push({ id: 'steal_safe', label: '🔴 Steal — Safe', color: 'bg-emerald-700' });
  actions.push({ id: 'steal_caught', label: '🔴 Steal — Caught (Out)', color: 'bg-orange-700' });
  if (base !== 'third') {
    actions.push({ id: 'advance_throw_safe', label: '↩ Advance on Throw — Safe', color: 'bg-teal-700' });
    actions.push({ id: 'advance_throw_out', label: '↩ Advance on Throw — Out', color: 'bg-amber-700' });
  }
  actions.push({ id: 'runner_out', label: '❌ Runner Out (other)', color: 'bg-red-700' });
  // Send Back — only for runners on 2nd or 3rd
  if (base === 'second') {
    actions.push({ id: 'send_back', label: '← Send Back to 1st', color: 'bg-slate-600' });
  }
  if (base === 'third') {
    actions.push({ id: 'send_back', label: '← Send Back to 2nd', color: 'bg-slate-600' });
  }

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-end"
      style={{ touchAction: 'none' }}
      onTouchStart={onClose}
      onClick={onClose}
    >
      <div
        className="bg-[hsl(214,90%,10%)] border-t border-white/20 rounded-t-2xl p-4 max-h-[80vh] overflow-y-auto"
        style={{ touchAction: 'pan-y' }}
        onTouchStart={e => e.stopPropagation()}
        onClick={e => e.stopPropagation()}
      >
        <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-4" />
        <div className="text-center mb-4">
          <div className="text-white font-bold text-lg">{displayName}</div>
          <div className="text-white/50 text-sm">on {baseLabel}</div>
        </div>
        <div className="space-y-2">
          {actions.map(a => (
            <button key={a.id}
              className={`w-full py-4 rounded-xl font-semibold text-white text-base ${a.color} active:brightness-90 transition-all select-none touch-manipulation`}
              onClick={() => onAction({ base, runnerId: runner, actionId: a.id, player })}>
              {a.label}
            </button>
          ))}
          <button
            className="w-full py-4 rounded-xl font-semibold text-white/60 text-base bg-white/10 active:bg-white/20 transition-all select-none touch-manipulation mt-2"
            onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}