const ORDINAL = ['', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'];

export default function InningEndModal({ game, players, inningStats, recentEvents, onContinue, isFinal }) {
  if (!game) return null;

  const isTop = game.inning_half === 'top';
  const endedLabel = `End of ${isTop ? 'Top' : 'Bottom'} ${ORDINAL[game.inning] || game.inning}`;
  const nextBattingTeam = isTop ? game.home_team_name : game.away_team_name;
  const nextBattingTeamId = isTop ? game.home_team_id : game.away_team_id;
  const nextLineup = isTop ? (game.home_lineup || []) : (game.away_lineup || []);
  const nextBatIdx = isTop ? (game.home_batting_order_idx || 0) : (game.away_batting_order_idx || 0);

  const nextThree = [0, 1, 2].map(offset => {
    const idx = (nextBatIdx + offset) % Math.max(nextLineup.length, 1);
    const playerId = nextLineup[idx];
    return players.find(p => p.id === playerId) || null;
  }).filter(Boolean);

  const lastPlays = (recentEvents || []).slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-white/20 rounded-2xl w-full max-w-md text-white shadow-2xl overflow-y-auto max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-white/10 text-center">
          <div className="text-white/60 text-sm uppercase tracking-widest mb-1">{endedLabel}</div>
          <div className="font-bebas text-6xl tracking-wider text-accent">
            {game.away_score ?? 0} – {game.home_score ?? 0}
          </div>
          <div className="text-white/60 text-sm mt-1">
            {game.away_team_name} vs {game.home_team_name}
          </div>
        </div>

        {/* Inning Recap */}
        <div className="p-4 border-b border-white/10">
          <div className="text-xs text-white/50 uppercase tracking-wider mb-3">Inning Recap</div>
          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              { label: 'Runs', val: inningStats.runs },
              { label: 'Hits', val: inningStats.hits },
              { label: 'Errors', val: inningStats.errors },
              { label: 'Pitches', val: inningStats.pitches },
            ].map(s => (
              <div key={s.label} className="bg-white/5 rounded-lg py-2">
                <div className="text-2xl font-bold">{s.val}</div>
                <div className="text-xs text-white/50">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Pitcher stats */}
          {game.current_pitcher_name && (
            <div className="mt-3 bg-white/5 rounded-lg px-3 py-2 text-sm flex items-center gap-2">
              <span className="text-white/50">P:</span>
              <span className="font-medium">{game.current_pitcher_name}</span>
              <span className="ml-auto text-white/50">{inningStats.strikeouts}K · {inningStats.walks}BB</span>
            </div>
          )}
        </div>

        {/* Next 3 batters */}
        {nextThree.length > 0 && (
          <div className="p-4 border-b border-white/10">
            <div className="text-xs text-white/50 uppercase tracking-wider mb-2">
              Due Up — {nextBattingTeam}
            </div>
            <div className="space-y-2">
              {nextThree.map((p, i) => (
                <div key={p.id} className="flex items-center gap-3 text-sm">
                  <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold text-white/60 flex-shrink-0">
                    {i + 1}
                  </div>
                  <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center text-xs font-bold flex-shrink-0">
                    #{p.number}
                  </div>
                  <span className="font-medium">{p.name}</span>
                  <span className="ml-auto text-white/40 text-xs">{p.position}</span>
                  <span className="text-white/40 text-xs">{p.batting_avg ? p.batting_avg.toFixed(3) : '.000'}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Last 3 plays */}
        {lastPlays.length > 0 && (
          <div className="p-4 border-b border-white/10">
            <div className="text-xs text-white/50 uppercase tracking-wider mb-2">Highlights</div>
            <div className="space-y-1.5">
              {lastPlays.map((evt, i) => (
                <div key={i} className="text-sm text-white/70">{evt.description}</div>
              ))}
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="p-4">
          <button
            onClick={onContinue}
            className="w-full bg-accent text-accent-foreground font-bold py-4 rounded-xl text-base transition-all active:scale-95 select-none touch-manipulation"
          >
            {isFinal ? '🏁 View Final Score' : '▶ Start Next Half-Inning'}
          </button>
        </div>
      </div>
    </div>
  );
}