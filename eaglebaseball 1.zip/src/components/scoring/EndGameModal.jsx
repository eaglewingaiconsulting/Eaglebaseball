export default function EndGameModal({ game, onConfirm, onCancel, confirming }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-white/20 rounded-2xl w-full max-w-sm text-white shadow-2xl p-6 text-center space-y-5">
        <div className="text-4xl">🏁</div>
        <div>
          <div className="text-xl font-bold mb-1">End this game?</div>
          <div className="text-white/60 text-sm">This cannot be undone.</div>
        </div>
        <div className="bg-white/5 rounded-xl px-4 py-3 font-bebas text-4xl tracking-wider">
          {game.away_score ?? 0} – {game.home_score ?? 0}
        </div>
        <div className="text-white/50 text-sm">
          {game.away_team_name} vs {game.home_team_name} · Inning {game.inning}
        </div>
        <div className="flex gap-3 pt-1">
          <button
            onClick={onCancel}
            disabled={confirming}
            className="flex-1 py-3 rounded-xl border border-white/20 text-white/70 hover:bg-white/5 transition-colors select-none touch-manipulation font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={confirming}
            className="flex-1 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-colors active:scale-95 select-none touch-manipulation"
          >
            {confirming ? 'Ending...' : 'End Game'}
          </button>
        </div>
      </div>
    </div>
  );
}