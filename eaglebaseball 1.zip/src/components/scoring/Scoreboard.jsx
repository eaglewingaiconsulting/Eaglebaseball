export default function Scoreboard({ game }) {
  const innings = game.inning_scores || [];
  const totalInnings = Math.max(game.total_innings || 9, game.inning || 1);
  const inningNums = Array.from({ length: totalInnings }, (_, i) => i + 1);

  const getScore = (team, inning) => {
    const entry = innings.find(e => e.inning === inning && e.team === team);
    return entry ? entry.runs : '-';
  };

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted/50">
              <th className="text-left px-4 py-2.5 font-semibold w-32">Team</th>
              {inningNums.map(i => (
                <th key={i} className="px-3 py-2.5 font-semibold text-center w-10">{i}</th>
              ))}
              <th className="px-3 py-2.5 font-bold text-center bg-muted">R</th>
              <th className="px-3 py-2.5 font-semibold text-center">H</th>
              <th className="px-3 py-2.5 font-semibold text-center">E</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-t border-border">
              <td className="px-4 py-2.5 font-semibold truncate max-w-[120px]">{game.away_team_name}</td>
              {inningNums.map(i => (
                <td key={i} className="px-3 py-2.5 text-center text-muted-foreground">{getScore('away', i)}</td>
              ))}
              <td className="px-3 py-2.5 text-center font-bold bg-muted">{game.away_score ?? 0}</td>
              <td className="px-3 py-2.5 text-center">{game.away_hits ?? 0}</td>
              <td className="px-3 py-2.5 text-center">{game.away_errors ?? 0}</td>
            </tr>
            <tr className="border-t border-border">
              <td className="px-4 py-2.5 font-semibold truncate max-w-[120px]">{game.home_team_name}</td>
              {inningNums.map(i => (
                <td key={i} className="px-3 py-2.5 text-center text-muted-foreground">{getScore('home', i)}</td>
              ))}
              <td className="px-3 py-2.5 text-center font-bold bg-muted">{game.home_score ?? 0}</td>
              <td className="px-3 py-2.5 text-center">{game.home_hits ?? 0}</td>
              <td className="px-3 py-2.5 text-center">{game.home_errors ?? 0}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}