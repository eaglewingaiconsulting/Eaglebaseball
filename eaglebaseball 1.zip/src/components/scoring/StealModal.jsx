// StealModal — runner selection + safe/caught flow for stolen bases
import { useState } from 'react';

export default function StealModal({ game, players, onResult, onClose }) {
  const [selectedBase, setSelectedBase] = useState(null); // 'first'|'second'|'third'
  const [step, setStep] = useState('select'); // 'select' | 'outcome' | 'double_steal'
  const [resolvedSteals, setResolvedSteals] = useState([]);

  // Build list of runners who CAN steal
  const stealOptions = [];
  if (game.runner_first && !game.runner_second) {
    const p = players.find(pl => pl.id === game.runner_first);
    stealOptions.push({ base: 'first', dest: 'second', playerId: game.runner_first, label: `#${p?.number || '?'} ${p?.name || 'Runner'} on 1st → stealing 2nd` });
  }
  if (game.runner_second && !game.runner_third) {
    const p = players.find(pl => pl.id === game.runner_second);
    stealOptions.push({ base: 'second', dest: 'third', playerId: game.runner_second, label: `#${p?.number || '?'} ${p?.name || 'Runner'} on 2nd → stealing 3rd` });
  }
  if (game.runner_third) {
    const p = players.find(pl => pl.id === game.runner_third);
    stealOptions.push({ base: 'third', dest: 'home', playerId: game.runner_third, label: `#${p?.number || '?'} ${p?.name || 'Runner'} on 3rd → stealing home` });
  }

  const selectedOption = stealOptions.find(o => o.base === selectedBase);

  const handleSelectRunner = (opt) => {
    setSelectedBase(opt.base);
    // If only one option, skip straight to outcome
    if (stealOptions.length === 1 || opt) setStep('outcome');
  };

  const handleOutcome = (outcome) => {
    const opt = selectedOption;
    const remaining = stealOptions.filter(o => o.base !== opt.base);
    const canDoubleSteal = remaining.length > 0 && resolvedSteals.length === 0;

    onResult({
      base: opt.base,
      dest: opt.dest,
      playerId: opt.playerId,
      outcome, // 'safe' | 'caught'
    });

    if (canDoubleSteal) {
      setResolvedSteals([...resolvedSteals, opt]);
      setStep('double_steal');
    } else {
      onClose();
    }
  };

  const handleDoubleStealYes = () => {
    // Re-filter options without already-resolved bases
    const remaining = stealOptions.filter(o => !resolvedSteals.find(r => r.base === o.base));
    if (remaining.length === 1) {
      setSelectedBase(remaining[0].base);
      setStep('outcome');
    } else {
      setSelectedBase(null);
      setStep('select');
    }
  };

  const playerForBase = (base) => {
    const pid = base === 'first' ? game.runner_first : base === 'second' ? game.runner_second : game.runner_third;
    return players.find(p => p.id === pid);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={onClose}>
      <div className="bg-[hsl(214,90%,10%)] border-t border-white/20 rounded-t-2xl p-5"
        onClick={e => e.stopPropagation()}>
        <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-4" />

        {/* STEP: Select runner */}
        {step === 'select' && (
          <>
            <div className="text-white font-bold text-lg text-center mb-1">Who attempted the steal?</div>
            <div className="text-white/50 text-sm text-center mb-4">Select the runner</div>
            <div className="space-y-2">
              {stealOptions.map(opt => (
                <button key={opt.base}
                  className="w-full py-4 px-5 rounded-xl bg-[#FFB81C] text-[#002D62] font-bold text-base active:brightness-90 select-none touch-manipulation"
                  onClick={() => handleSelectRunner(opt)}>
                  {opt.label}
                </button>
              ))}
            </div>
          </>
        )}

        {/* STEP: Safe or Caught */}
        {step === 'outcome' && selectedOption && (
          <>
            <div className="text-white font-bold text-lg text-center mb-1">
              #{playerForBase(selectedOption.base)?.number} {playerForBase(selectedOption.base)?.name}
            </div>
            <div className="text-white/50 text-sm text-center mb-5">
              Stealing {selectedOption.dest === 'home' ? 'Home' : selectedOption.dest === 'second' ? '2nd' : '3rd'}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                className="py-5 rounded-xl bg-emerald-600 text-white font-bold text-lg active:brightness-90 select-none touch-manipulation"
                onClick={() => handleOutcome('safe')}>
                ✅ Safe
              </button>
              <button
                className="py-5 rounded-xl bg-red-600 text-white font-bold text-lg active:brightness-90 select-none touch-manipulation"
                onClick={() => handleOutcome('caught')}>
                ❌ Caught
              </button>
            </div>
          </>
        )}

        {/* STEP: Double steal prompt */}
        {step === 'double_steal' && (
          <>
            <div className="text-white font-bold text-lg text-center mb-1">Double Steal?</div>
            <div className="text-white/50 text-sm text-center mb-5">Did another runner also go?</div>
            <div className="grid grid-cols-2 gap-3">
              <button
                className="py-4 rounded-xl bg-[#FFB81C] text-[#002D62] font-bold text-base active:brightness-90 select-none touch-manipulation"
                onClick={handleDoubleStealYes}>
                Yes — Select Runner
              </button>
              <button
                className="py-4 rounded-xl bg-white/10 text-white font-bold text-base active:brightness-90 select-none touch-manipulation"
                onClick={onClose}>
                No
              </button>
            </div>
          </>
        )}

        <button
          className="w-full mt-3 py-3 rounded-xl text-white/50 bg-white/5 active:bg-white/10 select-none touch-manipulation"
          onClick={onClose}>
          Cancel
        </button>
      </div>
    </div>
  );
}