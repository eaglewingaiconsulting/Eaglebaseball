export default function DropThirdStrikeModal({ onCaught, onDropped, onClose }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-white/20 rounded-2xl p-6 w-full max-w-sm text-white text-center shadow-2xl">
        <div className="text-5xl mb-3">⚾</div>
        <h2 className="text-xl font-bold mb-1">Drop 3rd Strike?</h2>
        <p className="text-sm text-white/60 mb-6">
          Strike 3 — did the catcher catch the ball?
        </p>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <button
            onClick={onCaught}
            className="bg-slate-700 hover:bg-slate-600 active:scale-95 text-white font-bold py-4 px-4 rounded-xl transition-all select-none touch-manipulation"
          >
            ✅ Caught
            <div className="text-xs font-normal text-white/60 mt-1">Batter out</div>
          </button>
          <button
            onClick={onDropped}
            className="bg-amber-600 hover:bg-amber-500 active:scale-95 text-white font-bold py-4 px-4 rounded-xl transition-all select-none touch-manipulation"
          >
            🏃 Dropped
            <div className="text-xs font-normal text-white/90 mt-1">Batter runs</div>
          </button>
        </div>

        <button onClick={onClose} className="text-xs text-white/40 hover:text-white/70 transition-colors touch-manipulation">
          Cancel
        </button>
      </div>
    </div>
  );
}