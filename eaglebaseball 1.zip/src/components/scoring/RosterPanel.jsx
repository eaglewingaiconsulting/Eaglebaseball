// RosterPanel — in-game roster management bottom sheet
import { useState } from 'react';
import { X, Camera, ChevronDown } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import OpponentLineupImporter from '@/components/scoring/OpponentLineupImporter';
import PitcherManagementPanel from '@/components/scoring/PitcherManagementPanel';

const POSITIONS = ['P', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH', 'UT'];

// Inline position selector — shows current position, tapping opens a dropdown
function PositionBadge({ player, onSave }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSelect = async (pos) => {
    setOpen(false);
    if (pos === player.position) return;
    setSaving(true);
    try {
      await base44.entities.Player.update(player.id, { position: pos });
      onSave(player.id, pos);
      toast.success(`${player.name} → ${pos}`);
    } catch {
      toast.error('Failed to update position');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="relative flex-shrink-0">
      <button
        onClick={() => setOpen(v => !v)}
        disabled={saving}
        className="flex items-center gap-0.5 px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold select-none touch-manipulation">
        {saving ? '…' : (player?.position || '?')}
        <ChevronDown className="w-3 h-3 text-white/50" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-8 z-20 bg-[hsl(214,90%,12%)] border border-white/20 rounded-xl shadow-xl overflow-hidden grid grid-cols-3 w-32">
            {POSITIONS.map(pos => (
              <button
                key={pos}
                onClick={() => handleSelect(pos)}
                className={`py-2 text-xs font-bold text-center hover:bg-white/10 select-none touch-manipulation transition-colors ${
                  pos === player?.position ? 'text-[#FFB81C] bg-white/10' : 'text-white/80'
                }`}>
                {pos}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function RosterPanel({ game, players: initialPlayers, onClose, onGameUpdate }) {
  const [tab, setTab] = useState('lineup');
  const [teamSide, setTeamSide] = useState('batting'); // 'batting' | 'fielding'
  const [subFlow, setSubFlow] = useState(null); // { playerIn, slotIdx, step }
  const [saving, setSaving] = useState(false);
  const [showOpponentImporter, setShowOpponentImporter] = useState(false);
  // Local player state so position updates reflect immediately
  const [players, setPlayers] = useState(initialPlayers);

  const isTop = game.inning_half === 'top';
  const battingLineup = isTop ? (game.away_lineup || []) : (game.home_lineup || []);
  const fieldingLineup = isTop ? (game.home_lineup || []) : (game.away_lineup || []);
  const battingIdxField = isTop ? 'away_batting_order_idx' : 'home_batting_order_idx';
  const currentIdx = isTop ? (game.away_batting_order_idx || 0) : (game.home_batting_order_idx || 0);
  const battingTeamId = isTop ? game.away_team_id : game.home_team_id;
  const fieldingTeamId = isTop ? game.home_team_id : game.away_team_id;

  const activeLineup = teamSide === 'batting' ? battingLineup : fieldingLineup;

  const getPlayer = (pid) => players.find(p => p.id === pid);
  const benchPlayers = players.filter(p =>
    p.team_id === battingTeamId && !battingLineup.includes(p.id)
  );

  const handlePositionSave = (playerId, newPos) => {
    setPlayers(prev => prev.map(p => p.id === playerId ? { ...p, position: newPos } : p));
  };

  const saveLineup = async (newLineup) => {
    setSaving(true);
    const lineupField = isTop ? 'away_lineup' : 'home_lineup';
    const updates = { [lineupField]: newLineup };
    if (game.current_batter_id && !newLineup.includes(game.current_batter_id)) {
      updates.current_batter_id = newLineup[0] || null;
      updates[battingIdxField] = 0;
    }
    try {
      await base44.entities.Game.update(game.id, updates);
      onGameUpdate(updates);
      toast.success('Lineup updated');
    } catch {
      toast.error('Failed to save lineup');
    } finally {
      setSaving(false);
    }
  };

  // Add a bench player to the END of the lineup (game started — no reordering)
  const addToLineup = async (playerId) => {
    const newLineup = [...battingLineup, playerId];
    await saveLineup(newLineup);
  };

  const handleSub = async (lineupSlotIdx, playerInId) => {
    setSaving(true);
    const lineupField = isTop ? 'away_lineup' : 'home_lineup';
    const newLineup = [...battingLineup];
    const playerOutId = newLineup[lineupSlotIdx];
    newLineup[lineupSlotIdx] = playerInId;

    const updates = { [lineupField]: newLineup };
    if (game.current_batter_id === playerOutId) {
      updates.current_batter_id = playerInId;
    }

    try {
      await base44.entities.Game.update(game.id, updates);
      await base44.entities.PlayLog.create({
        game_id: game.id,
        player_id: playerInId,
        player_name: getPlayer(playerInId)?.name || '',
        team_id: battingTeamId,
        play_type: 'substitution',
        inning: game.inning,
        inning_half: game.inning_half,
        notes: `Sub: #${getPlayer(playerInId)?.number} in for #${getPlayer(playerOutId)?.number}`,
      });
      onGameUpdate(updates);
      toast.success('Substitution made');
    } catch {
      toast.error('Failed to save substitution');
    } finally {
      setSaving(false);
      setSubFlow(null);
    }
  };

  const fieldingPlayers = players.filter(p => p.team_id === fieldingTeamId);

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={onClose}>
      <div
        className="bg-[hsl(214,90%,9%)] border-t border-white/20 rounded-t-2xl flex flex-col"
        style={{ height: '100dvh' }}
        onClick={e => e.stopPropagation()}>

        {/* Handle + header */}
        <div className="flex-shrink-0 p-4 pb-0">
          <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-3" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-white font-bold text-base">📋 Roster</span>
            <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 select-none touch-manipulation">
              <X className="w-4 h-4 text-white" />
            </button>
          </div>
          {/* Tabs */}
          <div className="flex gap-1 bg-white/5 rounded-lg p-1 mb-3">
            {['lineup', 'pitching', 'bench'].map(t => (
              <button key={t} onClick={() => { setTab(t); setSubFlow(null); }}
                className={`flex-1 py-2 rounded-md text-sm font-semibold capitalize transition-all select-none touch-manipulation ${
                  tab === t ? 'bg-accent text-accent-foreground' : 'text-white/50 hover:text-white'
                }`}>
                {t === 'lineup' ? 'Lineup' : t === 'pitching' ? 'Pitching' : 'Bench'}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 pt-0 space-y-2">

          {/* ── LINEUP TAB ── */}
          {tab === 'lineup' && (
            <>
              {/* Sub confirm */}
              {subFlow?.step === 'confirm' && (
                <div className="bg-white/10 rounded-xl p-4 space-y-3 mb-2">
                  <div className="text-white font-bold text-sm">Substitution</div>
                  <div className="text-green-400 text-sm">IN: #{getPlayer(subFlow.playerIn)?.number} {getPlayer(subFlow.playerIn)?.name}</div>
                  <div className="text-red-400 text-sm">OUT: #{getPlayer(battingLineup[subFlow.slotIdx])?.number} {getPlayer(battingLineup[subFlow.slotIdx])?.name}</div>
                  <div className="text-white/50 text-xs">Batting slot #{subFlow.slotIdx + 1}</div>
                  <div className="flex gap-2">
                    <button onClick={() => setSubFlow(null)} className="flex-1 py-2.5 rounded-xl bg-white/10 text-white text-sm font-semibold select-none touch-manipulation">Cancel</button>
                    <button disabled={saving} onClick={() => handleSub(subFlow.slotIdx, subFlow.playerIn)}
                      className="flex-1 py-2.5 rounded-xl bg-green-600 text-white text-sm font-semibold select-none touch-manipulation">
                      {saving ? 'Saving…' : 'Confirm Sub'}
                    </button>
                  </div>
                </div>
              )}

              {/* Team toggle */}
              <div className="flex gap-1 bg-white/5 rounded-lg p-1">
                <button onClick={() => { setTeamSide('batting'); setSubFlow(null); }}
                  className={`flex-1 py-2 rounded-md text-xs font-semibold select-none touch-manipulation transition-all leading-tight ${teamSide === 'batting' ? 'bg-white/20 text-white' : 'text-white/40'}`}>
                  {isTop ? '🆚 Opp' : '⚾ Yours'}{'\n'}Batting
                </button>
                <button onClick={() => { setTeamSide('fielding'); setSubFlow(null); }}
                  className={`flex-1 py-2 rounded-md text-xs font-semibold select-none touch-manipulation transition-all leading-tight ${teamSide === 'fielding' ? 'bg-white/20 text-white' : 'text-white/40'}`}>
                  {isTop ? '⚾ Yours' : '🆚 Opp'}{'\n'}Fielding
                </button>
              </div>

              {/* Info label */}
              <div className="text-white/30 text-xs text-center py-0.5">
                Batting order is locked • Tap position to edit • Sub button to swap players
              </div>

              {/* Import opponent lineup button — fielding team only */}
              {teamSide === 'fielding' && !subFlow && (
                <button
                  onClick={() => setShowOpponentImporter(true)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-dashed border-white/20 text-sm text-white/60 hover:bg-white/5 touch-manipulation">
                  <Camera className="w-4 h-4" /> Import Lineup from Photo
                </button>
              )}

              {activeLineup.length === 0 && (
                <div className="text-white/40 text-sm text-center py-4">No lineup set</div>
              )}

              {activeLineup.map((pid, idx) => {
                const p = getPlayer(pid);
                const isCurrent = teamSide === 'batting' && idx === currentIdx;
                return (
                  <div key={pid} className={`flex items-center gap-2 p-3 rounded-xl ${isCurrent ? 'bg-[#FFB81C]/20 border border-[#FFB81C]/40' : 'bg-white/5'}`}>
                    <span className={`text-xs font-bold w-5 text-center flex-shrink-0 ${isCurrent ? 'text-[#FFB81C]' : 'text-white/40'}`}>{idx + 1}</span>
                    <span className={`text-sm font-bold flex-shrink-0 ${isCurrent ? 'text-[#FFB81C]' : 'text-white/70'}`}>#{p?.number || '?'}</span>
                    <span className={`text-sm flex-1 min-w-0 truncate ${isCurrent ? 'text-white font-semibold' : 'text-white/70'}`}>{p?.name || 'Unknown'}</span>
                    {isCurrent && !subFlow && <span className="text-[10px] text-[#FFB81C] font-bold flex-shrink-0">AT BAT</span>}

                    {/* Position badge — always editable */}
                    {p && <PositionBadge player={p} onSave={handlePositionSave} />}

                    {/* Sub button — batting team only, no sub-flow active */}
                    {teamSide === 'batting' && !subFlow && (
                      <button
                        onClick={() => setSubFlow({ playerIn: null, slotIdx: idx, step: 'pick_in' })}
                        className="px-2.5 py-1.5 rounded-lg bg-white/10 text-white/70 text-xs font-semibold select-none touch-manipulation flex-shrink-0">
                        Sub
                      </button>
                    )}
                  </div>
                );
              })}

              {/* Pick bench player to sub IN */}
              {subFlow?.step === 'pick_in' && (
                <div className="mt-2">
                  <div className="text-white/60 text-xs mb-2 font-semibold uppercase tracking-wide">Select player coming IN:</div>
                  {benchPlayers.length === 0 && <div className="text-white/30 text-sm">No bench players available</div>}
                  {benchPlayers.map(p => (
                    <button key={p.id}
                      onClick={() => setSubFlow(prev => ({ ...prev, playerIn: p.id, step: 'confirm' }))}
                      className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 mb-1 select-none touch-manipulation">
                      <span className="text-sm font-bold text-white/70">#{p.number}</span>
                      <span className="text-sm text-white flex-1">{p.name}</span>
                      <span className="text-xs text-white/40">{p.position}</span>
                    </button>
                  ))}
                  <button onClick={() => setSubFlow(null)} className="w-full py-2 mt-1 rounded-xl bg-white/5 text-white/40 text-sm select-none touch-manipulation">Cancel</button>
                </div>
              )}

              {/* Add player from bench to end of lineup (no reordering) */}
              {teamSide === 'batting' && !subFlow && benchPlayers.length > 0 && (
                <div className="mt-2 pt-2 border-t border-white/10">
                  <div className="text-white/40 text-xs uppercase tracking-wide font-semibold mb-2">Add to lineup (end of order):</div>
                  {benchPlayers.map(p => (
                    <button key={p.id}
                      disabled={saving}
                      onClick={() => addToLineup(p.id)}
                      className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-emerald-700/20 mb-1 select-none touch-manipulation border border-white/5">
                      <span className="text-sm font-bold text-emerald-400">+</span>
                      <span className="text-sm font-bold text-white/70">#{p.number}</span>
                      <span className="text-sm text-white flex-1">{p.name}</span>
                      <span className="text-xs text-white/40">{p.position}</span>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}

          {/* ── PITCHING TAB ── */}
          {tab === 'pitching' && (
            <PitcherManagementPanel
              game={game}
              players={players}
              onClose={onClose}
              onGameUpdate={onGameUpdate}
            />
          )}

          {/* ── BENCH TAB ── */}
          {tab === 'bench' && (
            <>
              {benchPlayers.length === 0 && (
                <div className="text-white/40 text-sm text-center py-4">No bench players — full lineup active</div>
              )}
              {benchPlayers.map(p => (
                <div key={p.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
                  <span className="text-sm font-bold text-white/70">#{p.number}</span>
                  <span className="text-sm text-white flex-1">{p.name}</span>
                  <PositionBadge player={p} onSave={handlePositionSave} />
                  <div className="flex gap-1.5">
                    <button
                      disabled={saving}
                      onClick={() => addToLineup(p.id)}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-semibold select-none touch-manipulation">
                      + Add
                    </button>
                    <button
                      onClick={() => setTab('pitching')}
                      className="px-2.5 py-1.5 rounded-lg bg-primary text-white text-xs font-semibold select-none touch-manipulation">
                      Pitch
                    </button>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      </div>

      {/* Opponent lineup photo importer */}
      {showOpponentImporter && (
        <OpponentLineupImporter
          game={game}
          opponentTeamId={fieldingTeamId}
          isOpponentHome={!isTop}
          existingPlayers={players}
          onConfirm={async (lineupIds) => {
            setSaving(true);
            const lineupField = isTop ? 'home_lineup' : 'away_lineup';
            const updates = { [lineupField]: lineupIds };
            try {
              await base44.entities.Game.update(game.id, updates);
              onGameUpdate(updates);
            } finally {
              setSaving(false);
              setShowOpponentImporter(false);
            }
          }}
          onClose={() => setShowOpponentImporter(false)}
        />
      )}
    </div>
  );
}