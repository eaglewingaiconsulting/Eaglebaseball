import { useState } from 'react';
import { Gauge, Loader2, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function PitchSpeedDisplay({ game, pitcherName }) {
  const [estimating, setEstimating] = useState(false);
  const [lastSpeed, setLastSpeed] = useState(null); // { mph, confidence }
  const [error, setError] = useState(null);

  const videoUrl = game?.home_stream_url || game?.away_stream_url || game?.video_url;

  if (!videoUrl) return null;

  const estimate = async () => {
    setEstimating(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('estimatePitchSpeed', {
        video_url: videoUrl,
        timestamp_seconds: game?.game_start_timestamp
          ? Math.floor((Date.now() - new Date(game.game_start_timestamp).getTime()) / 1000)
          : null,
        pitcher_name: pitcherName,
      });
      if (res.data?.estimated_mph) {
        setLastSpeed({ mph: res.data.estimated_mph, confidence: res.data.confidence });
      } else {
        setError('No reading');
      }
    } catch {
      setError('Failed');
    } finally {
      setEstimating(false);
    }
  };

  const confidenceColor = {
    high: 'text-green-400',
    medium: 'text-amber-400',
    low: 'text-white/40',
  };

  return (
    <div className="flex items-center gap-2">
      {lastSpeed ? (
        <div className="flex items-center gap-1">
          <Gauge className="w-3.5 h-3.5 text-accent" />
          <span className={`font-bold text-sm tabular-nums ${confidenceColor[lastSpeed.confidence] || 'text-white'}`}>
            ~{Math.round(lastSpeed.mph)} mph
          </span>
          <span className="text-white/30 text-xs">(est.)</span>
        </div>
      ) : error ? (
        <span className="text-white/30 text-xs">{error}</span>
      ) : null}

      <button
        onClick={estimate}
        disabled={estimating}
        title="Estimate pitch speed from video"
        className="flex items-center gap-1 text-xs text-white/40 hover:text-accent transition-colors px-1.5 py-1 rounded hover:bg-white/10 select-none touch-manipulation disabled:opacity-40"
      >
        {estimating
          ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
          : <Zap className="w-3.5 h-3.5" />
        }
        {estimating ? 'Reading...' : 'Speed'}
      </button>
    </div>
  );
}