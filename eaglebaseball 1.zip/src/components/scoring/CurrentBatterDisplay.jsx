// CurrentBatterDisplay — shows who is at bat with prev/next controls and on-deck
import { useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function CurrentBatterDisplay({ game, players, lineupIds, isPhone, onBatterChange, teamName, onPlayerAdded }) {
  const [showPicker, setShowPicker] = useState(false);
  const [showAddBatter, setShowAddBatter] = useState(false);
  const [addForm, setAddForm] = useState({ number: '', name: '' });
  const [adding, setAdding] = useState(false);

  const battingTeamId = game?.inning_half === 'top' ? game?.away_team_id : game?.home_team_id;
  const lineup = lineupIds || (game?.inning_half === 'top' ? game?.away_lineup : game?.home_lineup) || [];

  const currentIdx = game?.home_batting_order_idx !== undefined
    ? (game?.inning_half === 'top' ? (game?.away_batting_order_idx || 0) : (game?.home_batting_order_idx || 0))
    : 0;

  const currentBatterId = lineup[currentIdx] || lineup[0];
  const nextIdx = lineup.length > 0 ? (currentIdx + 1) % lineup.length : 0;
  const onDeckId = lineup[nextIdx];

  const currentBatter = players.find(p => p.id === currentBatterId);
  const onDeck = players.find(p => p.id === onDeckId);

  const navigate = (dir) => {
    if (!lineup.length) return;
    const newIdx = ((currentIdx + dir) + lineup.length) % lineup.length;
    const idxField = game?.inning_half === 'top' ? 'away_batting_order_idx' : 'home_batting_order_idx';
    onBatterChange({ [idxField]: newIdx, current_batter_id: lineup[newIdx] });
  };

  const selectBatter = (playerId) => {
    const idx = lineup.indexOf(playerId);
    if (idx < 0) return;
    const idxField = game?.inning_half === 'top' ? 'away_batting_order_idx' : 'home_batting_order_idx';
    onBatterChange({ [idxField]: idx, current_batter_id: playerId });
    setShowPicker(false);
  };

  const handleAddBatter = async () => {
    if (!addForm.number.trim()) return;
    setAdding(true);
    try {
      const newPlayer = await base44.entities.Player.create({
        team_id: battingTeamId,
        number: addForm.number.trim(),
        name: addForm.name.trim() || `#${addForm.number.trim()}`,
        position: 'UT',
      });
      const newLineup = [...lineup, newPlayer.id];
      const newIdx = newLineup.length - 1;
      const lineupField = game?.inning_half === 'top' ? 'away_lineup' : 'home_lineup';
      const idxField = game?.inning_half === 'top' ? 'away_batting_order_idx' : 'home_batting_order_idx';
      onPlayerAdded && onPlayerAdded(newPlayer);
      onBatterChange({ [lineupField]: newLineup, [idxField]: newIdx, current_batter_id: newPlayer.id });
      setAddForm({ number: '', name: '' });
      setShowAddBatter(false);
    } finally {
      setAdding(false);
    }
  };

  // No lineup — show prompt to add batter
  if (!lineup.length) {
    return (
      <>
        <div className="bg-[hsl(214,90%,8%)] border border-white/10 rounded-xl p-4 text-center space-y-3">
          <div className="text-[#FFB81C] text-xs font-bold uppercase tracking-widest mb-1">🏏 At Bat{teamName ? ` — ${teamName}` : ''}</div>
          <p className="text-white/50 text-sm">No lineup set — who's batting?</p>
          <button
            onClick={() => setShowAddBatter(true)}
            className="w-full py-3 rounded-xl bg-[#FFB81C] text-[#002D62] font-bold text-sm select-none touch-manipulation active:brightness-90">
            + Add Batter
          </button>
        </div>
        {showAddBatter && <AddBatterModal form={addForm} onChange={setAddForm} onConfirm={handleAddBatter} onClose={() => setShowAddBatter(false)} adding={adding} />}
      </>
    );
  }

  return (
    <>
      <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#0a1628', border: '1px solid rgba(255,184,28,0.2)' }}>
        {/* Header */}
        <div className="flex items-center justify-between px-4 pt-3 pb-1">
          <span className="text-[10px] font-black uppercase tracking-widest" style={{ color: '#FFB81C' }}>
            ⚡ At Bat{teamName ? ` · ${teamName}` : ''}
          </span>
          <button onClick={() => setShowAddBatter(true)}
            className="text-[10px] font-bold px-2 py-1 rounded-lg select-none touch-manipulation"
            style={{ color: 'rgba(255,255,255,0.35)', backgroundColor: 'rgba(255,255,255,0.06)' }}>
            + Add
          </button>
        </div>

        {/* Batter row */}
        <div className="flex items-center gap-2 px-3 pb-3">
          <button className="w-10 h-10 rounded-xl flex items-center justify-center text-xl font-black select-none touch-manipulation active:scale-95"
            style={{ backgroundColor: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.4)' }}
            onClick={() => navigate(-1)}>‹</button>

          <button className="flex-1 flex items-center gap-3 select-none touch-manipulation active:opacity-80"
            onClick={() => setShowPicker(true)}>
            <div className="font-bebas leading-none flex-shrink-0" style={{ fontSize: 44, color: '#FFB81C', lineHeight: 1 }}>
              {currentBatter?.number || '?'}
            </div>
            <div className="text-left min-w-0">
              <div className="font-bold text-white text-base leading-tight truncate">
                {currentBatter?.name || 'Unknown'}
              </div>
              <div className="text-[11px] mt-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>
                {currentBatter?.position || 'POS'} · tap to switch
              </div>
            </div>
          </button>

          <button className="w-10 h-10 rounded-xl flex items-center justify-center text-xl font-black select-none touch-manipulation active:scale-95"
            style={{ backgroundColor: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.4)' }}
            onClick={() => navigate(1)}>›</button>
        </div>

        {/* On Deck */}
        {onDeck && (
          <div className="px-4 py-2 flex items-center gap-2" style={{ borderTop: '1px solid rgba(255,255,255,0.06)', backgroundColor: 'rgba(0,0,0,0.2)' }}>
            <span className="text-[10px] uppercase tracking-widest font-bold" style={{ color: 'rgba(255,255,255,0.25)' }}>On Deck</span>
            <span className="text-xs font-bold" style={{ color: 'rgba(255,255,255,0.5)' }}>#{onDeck.number} {onDeck.name}</span>
          </div>
        )}
      </div>

      {/* Add Batter Modal */}
      {showAddBatter && <AddBatterModal form={addForm} onChange={setAddForm} onConfirm={handleAddBatter} onClose={() => setShowAddBatter(false)} adding={adding} />}

      {/* Lineup Picker Modal */}
      {showPicker && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={() => setShowPicker(false)}>
          <div className="bg-[hsl(214,90%,10%)] border-t border-white/20 rounded-t-2xl p-4 max-h-[75vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-3" />
            <div className="text-white font-bold text-center mb-3">Select Batter</div>
            <div className="space-y-1.5">
              {lineup.map((pid, idx) => {
                const p = players.find(pl => pl.id === pid);
                if (!p) return null;
                const isCurrent = idx === currentIdx;
                return (
                  <button key={pid}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all select-none touch-manipulation ${
                      isCurrent
                        ? 'bg-[#FFB81C] text-[#002D62]'
                        : 'bg-white/5 text-white hover:bg-white/10'
                    }`}
                    onClick={() => selectBatter(pid)}>
                    <span className="text-sm opacity-60 w-5">{idx + 1}.</span>
                    <span className="font-bold text-lg w-12">#{p.number}</span>
                    <span className="flex-1 text-left">{p.name}</span>
                    <span className="text-xs opacity-60">{p.position}</span>
                  </button>
                );
              })}
            </div>
            <button
              className="w-full mt-3 py-3 rounded-xl text-white/50 bg-white/5 active:bg-white/10 select-none touch-manipulation"
              onClick={() => setShowPicker(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function AddBatterModal({ form, onChange, onConfirm, onClose, adding }) {
  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={onClose}>
      <div className="bg-[hsl(214,90%,10%)] border-t border-white/20 rounded-t-2xl p-5 space-y-4"
        onClick={e => e.stopPropagation()}>
        <div className="w-10 h-1 bg-white/20 rounded-full mx-auto" />
        <div className="text-white font-bold text-center text-base">Add Batter to Lineup</div>

        <div className="space-y-3">
          <div>
            <label className="text-white/50 text-xs uppercase tracking-wide font-semibold block mb-1">Jersey Number <span className="text-red-400">*</span></label>
            <input
              type="text"
              inputMode="numeric"
              placeholder="e.g. 24"
              value={form.number}
              onChange={e => onChange(f => ({ ...f, number: e.target.value }))}
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white text-lg font-bold placeholder:text-white/30 focus:outline-none focus:border-[#FFB81C]"
              autoFocus
            />
          </div>
          <div>
            <label className="text-white/50 text-xs uppercase tracking-wide font-semibold block mb-1">Player Name <span className="text-white/30">(optional)</span></label>
            <input
              type="text"
              placeholder="e.g. Smith"
              value={form.name}
              onChange={e => onChange(f => ({ ...f, name: e.target.value }))}
              onKeyDown={e => e.key === 'Enter' && form.number.trim() && onConfirm()}
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-[#FFB81C]"
            />
          </div>
        </div>

        <div className="flex gap-3 pt-1">
          <button onClick={onClose} className="flex-1 py-3 rounded-xl bg-white/10 text-white/60 font-semibold text-sm select-none touch-manipulation">
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={!form.number.trim() || adding}
            className="flex-1 py-3 rounded-xl bg-[#FFB81C] text-[#002D62] font-bold text-sm select-none touch-manipulation disabled:opacity-50 active:brightness-90">
            {adding ? 'Adding...' : 'Add to Lineup'}
          </button>
        </div>
      </div>
    </div>
  );
}