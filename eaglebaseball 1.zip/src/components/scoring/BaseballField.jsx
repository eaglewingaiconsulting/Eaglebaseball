export default function BaseballField({ game }) {
  const hasFirst = game?.runner_first;
  const hasSecond = game?.runner_second;
  const hasThird = game?.runner_third;

  return (
    <div className="bg-[hsl(142,71%,15%)] border border-white/10 rounded-xl p-2 flex flex-col items-center justify-center relative overflow-hidden min-h-[200px] h-full">
      {/* Grass texture */}
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,0.1) 10px, rgba(0,0,0,0.1) 20px)'
      }} />

      {/* Field SVG */}
      <svg viewBox="0 0 300 300" className="w-full h-full max-w-[130px]" style={{ filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.5))' }}>
        {/* Outfield grass arc */}
        <path d="M 150 270 L 30 100 Q 150 10 270 100 Z" fill="#16a34a" opacity="0.6" />
        {/* Infield dirt */}
        <path d="M 150 220 L 80 155 L 150 90 L 220 155 Z" fill="#c2772a" opacity="0.8" />
        {/* Foul lines */}
        <line x1="150" y1="220" x2="30" y2="80" stroke="white" strokeWidth="1" opacity="0.4" />
        <line x1="150" y1="220" x2="270" y2="80" stroke="white" strokeWidth="1" opacity="0.4" />
        {/* Pitcher's mound */}
        <circle cx="150" cy="155" r="10" fill="#c2772a" />
        <circle cx="150" cy="155" r="4" fill="white" opacity="0.7" />
        {/* Home plate */}
        <polygon points="150,225 143,215 143,208 157,208 157,215" fill="white" />
        {/* 1B - right */}
        <rect x="208" y="143" width="18" height="18" rx="2"
          fill={hasFirst ? '#f59e0b' : '#e5e7eb'}
          className="transition-all duration-300"
          style={{ filter: hasFirst ? 'drop-shadow(0 0 8px #f59e0b)' : 'none' }}
        />
        {/* 2B - top */}
        <rect x="141" y="80" width="18" height="18" rx="2"
          fill={hasSecond ? '#f59e0b' : '#e5e7eb'}
          className="transition-all duration-300"
          style={{ filter: hasSecond ? 'drop-shadow(0 0 8px #f59e0b)' : 'none' }}
        />
        {/* 3B - left */}
        <rect x="73" y="143" width="18" height="18" rx="2"
          fill={hasThird ? '#f59e0b' : '#e5e7eb'}
          className="transition-all duration-300"
          style={{ filter: hasThird ? 'drop-shadow(0 0 8px #f59e0b)' : 'none' }}
        />
        <text x="217" y="158" textAnchor="middle" fill="white" fontSize="9" fontWeight="bold" opacity="0.9">1B</text>
        <text x="150" y="94" textAnchor="middle" fill="white" fontSize="9" fontWeight="bold" opacity="0.9">2B</text>
        <text x="82" y="158" textAnchor="middle" fill="white" fontSize="9" fontWeight="bold" opacity="0.9">3B</text>
        <text x="150" y="250" textAnchor="middle" fill="white" fontSize="9" fontWeight="bold" opacity="0.9">HP</text>
      </svg>

      {/* Runner indicators — compact inline */}
      <div className="flex justify-center gap-2 text-xs mt-1">
        <div className={`px-1.5 py-0.5 rounded text-xs ${hasFirst ? 'bg-accent text-accent-foreground font-bold' : 'bg-white/10 text-white/40'}`}>1B {hasFirst ? '●' : '○'}</div>
        <div className={`px-1.5 py-0.5 rounded text-xs ${hasSecond ? 'bg-accent text-accent-foreground font-bold' : 'bg-white/10 text-white/40'}`}>2B {hasSecond ? '●' : '○'}</div>
        <div className={`px-1.5 py-0.5 rounded text-xs ${hasThird ? 'bg-accent text-accent-foreground font-bold' : 'bg-white/10 text-white/40'}`}>3B {hasThird ? '●' : '○'}</div>
      </div>
    </div>
  );
}