// SendBackModal — reason prompt when sending a runner back
import { useEffect, useState } from 'react';

export default function SendBackModal({ runner, base, players, onConfirm, onClose }) {
  const [selected, setSelected] = useState(null);
  const player = players.find(p => p.id === runner);
  const displayName = player ? `#${player.number} ${player.name}` : 'Runner';
  const destBase = base === 'third' ? '2nd' : '1st';

  const reasons = [
    { id: 'retreated', label: '🔁 Retreated on Line Drive' },
    { id: 'correction', label: '✏️ Correction / Error' },
  ];

  // Auto-select "correction" after 3 seconds
  useEffect(() => {
    const t = setTimeout(() => {
      if (!selected) {
        setSelected('correction');
        onConfirm('correction');
      }
    }, 3000);
    return () => clearTimeout(t);
  }, [selected]);

  const handleSelect = (id) => {
    setSelected(id);
    onConfirm(id);
  };

  return (
    <div className="fixed inset-0 z-[60] flex flex-col justify-end" onClick={onClose}>
      <div className="bg-[hsl(214,90%,10%)] border-t border-white/20 rounded-t-2xl p-5"
        onClick={e => e.stopPropagation()}>
        <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-4" />
        <div className="text-white font-bold text-base text-center mb-1">
          Why is {displayName} going back?
        </div>
        <div className="text-white/50 text-sm text-center mb-4">
          → Back to {destBase} Base <span className="text-white/30 ml-2">(auto-selects in 3s)</span>
        </div>
        <div className="space-y-2">
          {reasons.map(r => (
            <button key={r.id}
              className={`w-full py-4 rounded-xl font-semibold text-white text-base active:brightness-90 select-none touch-manipulation transition-all ${
                selected === r.id ? 'ring-2 ring-white' : ''
              } ${r.id === 'retreated' ? 'bg-blue-700' : 'bg-slate-600'}`}
              onClick={() => handleSelect(r.id)}>
              {r.label}
            </button>
          ))}
          <button
            className="w-full py-3 rounded-xl text-white/50 bg-white/5 active:bg-white/10 select-none touch-manipulation mt-1"
            onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}