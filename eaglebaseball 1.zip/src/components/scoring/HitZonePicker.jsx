import { useState } from 'react';

const ZONES = [
  // Deep outfield
  { id: 'deep_left', label: 'Deep LF', x: 18, y: 18, w: 22, h: 18, color: '#1D4ED8' },
  { id: 'deep_center', label: 'Deep CF', x: 39, y: 10, w: 22, h: 18, color: '#1D4ED8' },
  { id: 'deep_right', label: 'Deep RF', x: 60, y: 18, w: 22, h: 18, color: '#1D4ED8' },

  // Shallow outfield
  { id: 'shallow_left', label: 'Shallow LF', x: 18, y: 36, w: 22, h: 16, color: '#2563EB' },
  { id: 'shallow_center', label: 'Shallow CF', x: 39, y: 28, w: 22, h: 16, color: '#2563EB' },
  { id: 'shallow_right', label: 'Shallow RF', x: 60, y: 36, w: 22, h: 16, color: '#2563EB' },

  // Gaps
  { id: 'gap_left', label: 'LCF Gap', x: 27, y: 27, w: 14, h: 14, color: '#3B82F6' },
  { id: 'gap_right', label: 'RCF Gap', x: 59, y: 27, w: 14, h: 14, color: '#3B82F6' },

  // Infield
  { id: 'infield_left', label: 'IF Left', x: 22, y: 52, w: 18, h: 16, color: '#7C3AED' },
  { id: 'infield_center', label: 'IF Center', x: 41, y: 49, w: 18, h: 16, color: '#7C3AED' },
  { id: 'infield_right', label: 'IF Right', x: 60, y: 52, w: 18, h: 16, color: '#7C3AED' },

  // Foul lines
  { id: 'line_left', label: '3B Line', x: 5, y: 38, w: 16, h: 28, color: '#DC2626' },
  { id: 'line_right', label: '1B Line', x: 79, y: 38, w: 16, h: 28, color: '#DC2626' },
];

const HIT_COLORS = {
  single: '#10B981',
  double: '#3B82F6',
  triple: '#8B5CF6',
  home_run: '#F59E0B',
};

export default function HitZonePicker({ hitType, onConfirm, onCancel }) {
  const [selected, setSelected] = useState(null);

  const hitLabel = { single: 'Single', double: 'Double', triple: 'Triple', home_run: 'Home Run' }[hitType] || 'Hit';
  const accentColor = HIT_COLORS[hitType] || '#3B82F6';

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex flex-col items-center justify-center p-4">
      <div className="bg-[hsl(220,25%,9%)] border border-white/10 rounded-2xl w-full max-w-sm shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between">
          <div>
            <div className="text-xs text-white/40 uppercase tracking-wider font-semibold">Hit Location</div>
            <div className="font-bold text-white" style={{ color: accentColor }}>{hitLabel}</div>
          </div>
          <button onClick={onCancel} className="text-white/40 hover:text-white text-xl leading-none px-2 py-1 select-none touch-manipulation">✕</button>
        </div>

        {/* Field diagram */}
        <div className="px-4 pt-3 pb-1">
          <div className="text-xs text-white/40 text-center mb-2">Tap where the ball was hit</div>

          <div className="relative w-full" style={{ paddingBottom: '90%' }}>
            <div className="absolute inset-0">
              {/* SVG field background */}
              <svg viewBox="0 0 100 90" className="absolute inset-0 w-full h-full">
                {/* Outfield grass */}
                <path d="M 50 88 L 3 42 Q 50 2 97 42 Z" fill="#14532D" opacity="0.6" />
                {/* Infield dirt */}
                <polygon points="50,42 70,62 50,82 30,62" fill="#92400E" opacity="0.5" />
                {/* Foul lines */}
                <line x1="50" y1="88" x2="3" y2="42" stroke="#94A3B8" strokeWidth="0.5" opacity="0.5" />
                <line x1="50" y1="88" x2="97" y2="42" stroke="#94A3B8" strokeWidth="0.5" opacity="0.5" />
                {/* Bases */}
                {[
                  { cx: 50, cy: 42 }, // 2nd
                  { cx: 70, cy: 62 }, // 1st
                  { cx: 50, cy: 82 }, // home
                  { cx: 30, cy: 62 }, // 3rd
                ].map(({ cx, cy }, i) => (
                  <rect key={i} x={cx - 3} y={cy - 3} width={6} height={6} rx={1}
                    fill="white" opacity={0.7}
                    transform={`rotate(45, ${cx}, ${cy})`} />
                ))}
                {/* Pitcher mound */}
                <circle cx={50} cy={62} r={2.5} fill="#A16207" opacity={0.6} />
              </svg>

              {/* Zone overlay buttons */}
              {ZONES.map(zone => (
                <button
                  key={zone.id}
                  onClick={() => setSelected(zone.id)}
                  className="absolute rounded-lg border transition-all select-none touch-manipulation flex items-center justify-center text-center"
                  style={{
                    left: `${zone.x}%`,
                    top: `${zone.y}%`,
                    width: `${zone.w}%`,
                    height: `${zone.h}%`,
                    backgroundColor: selected === zone.id ? accentColor : `${zone.color}33`,
                    borderColor: selected === zone.id ? accentColor : `${zone.color}66`,
                    borderWidth: selected === zone.id ? 2 : 1,
                    transform: selected === zone.id ? 'scale(1.05)' : 'scale(1)',
                  }}
                >
                  <span className="text-white font-semibold leading-tight px-0.5"
                    style={{ fontSize: '9px', textShadow: '0 1px 2px rgba(0,0,0,0.8)' }}>
                    {zone.label}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Selected zone label */}
        <div className="px-4 py-2 text-center min-h-[28px]">
          {selected ? (
            <span className="text-sm font-semibold" style={{ color: accentColor }}>
              ✓ {ZONES.find(z => z.id === selected)?.label}
            </span>
          ) : (
            <span className="text-xs text-white/30">No zone selected</span>
          )}
        </div>

        {/* Actions */}
        <div className="px-4 pb-4 flex gap-2">
          <button
            onClick={onCancel}
            className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-white/70 font-semibold text-sm select-none touch-manipulation active:brightness-90">
            Cancel
          </button>
          <button
            onClick={() => selected && onConfirm(selected)}
            disabled={!selected}
            className="flex-1 py-3 rounded-xl font-bold text-sm select-none touch-manipulation active:brightness-90 disabled:opacity-40 disabled:cursor-not-allowed text-white"
            style={{ backgroundColor: selected ? accentColor : '#4B5563' }}>
            Confirm Hit
          </button>
        </div>
      </div>
    </div>
  );
}