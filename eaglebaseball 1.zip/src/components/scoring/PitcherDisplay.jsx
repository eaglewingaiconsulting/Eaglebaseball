import { useState } from 'react';
import { Flame } from 'lucide-react';
import PitchSpeedDisplay from './PitchSpeedDisplay';

export default function PitcherDisplay({ game, players, onChangePitcher }) {
  const [showSelector, setShowSelector] = useState(false);

  const pitcherName = game?.current_pitcher_name || null;
  const pitchCount = game?.current_pitcher_pitch_count || 0;
  const isTop = game?.inning_half === 'top';
  const pitchingTeamId = isTop ? game?.home_team_id : game?.away_team_id;
  const pitchers = players.filter(p => p.team_id === pitchingTeamId);

  const countColor = pitchCount >= 80 ? '#f87171' : pitchCount >= 50 ? '#fbbf24' : '#4ade80';

  return (
    <div className="flex-shrink-0 relative" style={{ backgroundColor: '#060e1d', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="flex items-center gap-3 px-4 py-2.5">
        <div className="flex items-center justify-center w-7 h-7 rounded-lg flex-shrink-0"
          style={{ backgroundColor: 'rgba(255,184,28,0.1)', border: '1px solid rgba(255,184,28,0.25)' }}>
          <Flame className="w-3.5 h-3.5" style={{ color: '#FFB81C' }} />
        </div>
        <div className="flex-1 min-w-0">
          {pitcherName ? (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-white text-sm truncate">{pitcherName}</span>
              <span className="font-bebas text-lg leading-none px-2 py-0.5 rounded-md"
                style={{ color: countColor, backgroundColor: `${countColor}18`, border: `1px solid ${countColor}40` }}>
                {pitchCount}p
              </span>
              <PitchSpeedDisplay game={game} pitcherName={pitcherName} />
            </div>
          ) : (
            <span className="text-white/35 text-sm italic">No pitcher set</span>
          )}
        </div>
        <button onClick={() => setShowSelector(v => !v)}
          className="flex-shrink-0 text-xs font-semibold px-3 py-1.5 rounded-lg select-none touch-manipulation transition-all"
          style={{ backgroundColor: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.5)', border: '1px solid rgba(255,255,255,0.1)' }}>
          Change
        </button>
      </div>

      {showSelector && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setShowSelector(false)} />
          <div className="absolute left-0 right-0 z-50 shadow-2xl overflow-hidden"
            style={{ top: '100%', backgroundColor: '#0d1b2e', border: '1px solid rgba(255,184,28,0.2)', borderTop: 'none', borderRadius: '0 0 16px 16px' }}>
            <div className="px-4 py-2 text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(255,255,255,0.3)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              Select Pitcher
            </div>
            <div className="max-h-48 overflow-y-auto">
              {pitchers.length === 0 && <div className="px-4 py-3 text-sm text-white/30">No players on roster</div>}
              {pitchers.map(p => (
                <button key={p.id}
                  onClick={() => { onChangePitcher(p); setShowSelector(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left select-none touch-manipulation transition-colors hover:bg-white/5"
                  style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <span className="font-bebas text-xl leading-none" style={{ color: '#FFB81C', width: 36 }}>#{p.number}</span>
                  <span className="flex-1 text-white font-medium text-sm">{p.name}</span>
                  <span className="text-xs font-bold px-2 py-0.5 rounded" style={{ backgroundColor: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.5)' }}>{p.position}</span>
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}