import { useState, useRef } from 'react';
import { X, Camera, Upload, RefreshCw, Check, AlertCircle, Loader2, ImageIcon, ZoomIn, Plus, Trash2, Pencil } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

/**
 * OpponentLineupImporter
 * Imports opponent lineup from a photo. Since opponent players may not be in the DB,
 * this creates Player records for them under the opponent team and saves their IDs to the game lineup.
 *
 * Props:
 *   game         – current game object
 *   opponentTeamId – the team_id for the opposing team
 *   isOpponentHome – true if opponent is the home team
 *   onConfirm    – callback(lineupIds: string[]) after saving
 *   onClose      – cancel callback
 */
export default function OpponentLineupImporter({ game, opponentTeamId, isOpponentHome, existingPlayers = [], onConfirm, onClose }) {
  const [stage, setStage] = useState('pick'); // pick | preview | parsing | review | error
  const [photoFile, setPhotoFile] = useState(null);
  const [photoDataUrl, setPhotoDataUrl] = useState(null);
  const [uploadedPhotoUrl, setUploadedPhotoUrl] = useState(null);
  const [rows, setRows] = useState([]);
  const [editingIdx, setEditingIdx] = useState(null);
  const [editDraft, setEditDraft] = useState({});
  const [errorMsg, setErrorMsg] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [showPhotoViewer, setShowPhotoViewer] = useState(false);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);

  const handleFile = (file) => {
    if (!file) return;
    setPhotoFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setPhotoDataUrl(e.target.result);
      setStage('preview');
    };
    reader.readAsDataURL(file);
  };

  const parsePhoto = async () => {
    setStage('parsing');
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: photoFile });
      setUploadedPhotoUrl(file_url);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `This is a photo of a baseball lineup card (likely Rawlings format).
Extract the STARTERS section lineup order as a JSON array.
For each row return: batting_position (1-9), player_name (name from STARTERS column), jersey_number (number from "No" column).
If jersey_number is not visible use an empty string "".
Return ONLY the JSON, no explanation.`,
        file_urls: [file_url],
        response_json_schema: {
          type: 'object',
          properties: {
            lineup: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  batting_position: { type: 'number' },
                  player_name: { type: 'string' },
                  jersey_number: { type: 'string' },
                },
              },
            },
          },
        },
      });

      const entries = result?.lineup || [];
      if (!entries.length) throw new Error('No lineup entries found. Try again with a clearer photo.');

      const sorted = [...entries].sort((a, b) => a.batting_position - b.batting_position);
      setRows(sorted.map(e => ({
        batting_position: e.batting_position,
        jersey_number: e.jersey_number || '',
        player_name: e.player_name || '',
      })));
      setStage('review');
    } catch (err) {
      setErrorMsg(err.message || 'Could not parse lineup. Try again with a clearer photo.');
      setStage('error');
    }
  };

  const retake = () => {
    setPhotoFile(null);
    setPhotoDataUrl(null);
    setUploadedPhotoUrl(null);
    setRows([]);
    setEditingIdx(null);
    setErrorMsg('');
    setStage('pick');
  };

  const startEdit = (idx) => { setEditingIdx(idx); setEditDraft({ ...rows[idx] }); };
  const saveEdit = () => {
    if (!editDraft.player_name?.trim()) { toast.error('Player name is required'); return; }
    setRows(prev => prev.map((r, i) => i === editingIdx ? { ...editDraft } : r));
    setEditingIdx(null);
  };
  const cancelEdit = () => setEditingIdx(null);
  const removeRow = (idx) => { setRows(prev => prev.filter((_, i) => i !== idx)); if (editingIdx === idx) setEditingIdx(null); };
  const addRow = () => {
    const maxPos = rows.reduce((m, r) => Math.max(m, r.batting_position || 0), 0);
    const newRow = { batting_position: maxPos + 1, jersey_number: '', player_name: '' };
    setRows(prev => [...prev, newRow]);
    setEditingIdx(rows.length);
    setEditDraft(newRow);
  };

  const hasDuplicatePositions = () => {
    const positions = rows.map(r => r.batting_position);
    return positions.some((p, i) => positions.indexOf(p) !== i);
  };

  const handleConfirm = async () => {
    if (rows.some(r => !r.player_name?.trim())) { toast.error('All players must have a name'); return; }
    if (hasDuplicatePositions()) { toast.error('Fix duplicate batting order numbers before saving'); return; }

    setConfirming(true);
    try {
      const sorted = [...rows].sort((a, b) => a.batting_position - b.batting_position);
      const lineupIds = [];

      for (const row of sorted) {
        // Try to match existing player by jersey number or name
        let player = null;
        if (row.jersey_number) player = existingPlayers.find(p => p.number === row.jersey_number && p.team_id === opponentTeamId);
        if (!player && row.player_name) {
          const nameLower = row.player_name.toLowerCase();
          player = existingPlayers.find(p =>
            p.team_id === opponentTeamId && (
              p.name.toLowerCase() === nameLower ||
              p.name.toLowerCase().includes(nameLower.split(' ')[0]) ||
              nameLower.includes(p.name.toLowerCase().split(' ')[0])
            )
          );
        }

        // If no match, create a new Player record for this opponent
        if (!player) {
          player = await base44.entities.Player.create({
            team_id: opponentTeamId,
            name: row.player_name.trim(),
            number: row.jersey_number || '0',
            position: 'UT',
          });
        }

        lineupIds.push(player.id);
      }

      await onConfirm(lineupIds);
      toast.success('Opponent lineup imported!');
    } catch (err) {
      toast.error('Failed to save lineup');
    } finally {
      setConfirming(false);
    }
  };

  const photoSrc = uploadedPhotoUrl || photoDataUrl;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-4">
      <div className="bg-[hsl(214,90%,9%)] border border-white/20 rounded-2xl w-full max-w-sm shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 flex-shrink-0">
          <div>
            <h2 className="font-semibold text-sm text-white">Import Opponent Lineup</h2>
            <p className="text-xs text-white/50">
              {stage === 'pick'    && 'Photo the printed lineup card'}
              {stage === 'preview' && 'Review photo before scanning'}
              {stage === 'parsing' && 'AI is reading the lineup...'}
              {stage === 'review'  && `${rows.length} players found — tap ✏️ to edit`}
              {stage === 'error'   && 'Something went wrong'}
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 touch-manipulation">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">

          {stage === 'pick' && (
            <div className="p-6 flex flex-col items-center gap-4 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                <ImageIcon className="w-8 h-8 text-primary" />
              </div>
              <div>
                <p className="font-medium text-white mb-1">Photo the lineup card</p>
                <p className="text-xs text-white/50">Take or upload a photo of the opponent's lineup card. AI will extract the batting order.</p>
              </div>
              <div className="w-full space-y-2">
                <Button className="w-full gap-2" onClick={() => cameraInputRef.current?.click()}>
                  <Camera className="w-4 h-4" /> Take Photo
                </Button>
                <Button variant="outline" className="w-full gap-2 border-white/20 text-white hover:bg-white/10" onClick={() => fileInputRef.current?.click()}>
                  <Upload className="w-4 h-4" /> Choose from Library
                </Button>
              </div>
              <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden"
                onChange={e => { handleFile(e.target.files?.[0]); e.target.value = ''; }} />
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden"
                onChange={e => { handleFile(e.target.files?.[0]); e.target.value = ''; }} />
            </div>
          )}

          {stage === 'preview' && photoDataUrl && (
            <div className="p-4 space-y-3">
              <img src={photoDataUrl} alt="Lineup card" className="w-full rounded-xl object-contain max-h-64 bg-black" />
              <p className="text-xs text-white/50 text-center">Looks good? Tap "Scan Lineup" to extract the batting order.</p>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 gap-1.5 border-white/20 text-white hover:bg-white/10" onClick={retake}>
                  <RefreshCw className="w-4 h-4" /> Retake
                </Button>
                <Button className="flex-1 gap-1.5" onClick={parsePhoto}>
                  <Camera className="w-4 h-4" /> Scan Lineup
                </Button>
              </div>
            </div>
          )}

          {stage === 'parsing' && (
            <div className="h-48 flex flex-col items-center justify-center gap-3 text-white/50">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <span className="text-sm font-medium text-white">Reading lineup card...</span>
              <span className="text-xs">This takes a few seconds</span>
            </div>
          )}

          {stage === 'error' && (
            <div className="p-5 flex flex-col items-center gap-4 text-center">
              <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-red-400" />
              </div>
              <p className="text-sm text-red-400 font-medium">Import Failed</p>
              <p className="text-xs text-white/50">{errorMsg}</p>
              <div className="flex gap-2 w-full">
                <Button variant="outline" className="flex-1 border-white/20 text-white" onClick={onClose}>Close</Button>
                <Button className="flex-1" onClick={retake}>Try Again</Button>
              </div>
            </div>
          )}

          {stage === 'review' && (
            <div className="p-4 space-y-3">
              {photoSrc && (
                <button onClick={() => setShowPhotoViewer(true)}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg border border-white/15 bg-white/5 text-sm font-medium text-white touch-manipulation">
                  <Camera className="w-4 h-4 text-primary" />
                  📷 View Source Photo
                  <ZoomIn className="w-3.5 h-3.5 ml-auto text-white/40" />
                </button>
              )}
              <p className="text-xs text-white/50">Tap ✏️ to edit any row before saving.</p>
              <div className="space-y-2">
                {rows.map((row, idx) => {
                  const isDupe = rows.filter(r => r.batting_position === row.batting_position).length > 1;
                  const isEditing = editingIdx === idx;
                  return (
                    <div key={idx} className={`rounded-lg border p-3 ${isDupe ? 'border-red-500/50 bg-red-500/10' : 'border-white/10 bg-white/5'}`}>
                      {isEditing ? (
                        <div className="space-y-2">
                          <div className="flex gap-2">
                            <div className="w-14">
                              <label className="text-xs text-white/40">Order</label>
                              <Input type="number" min={1} max={99}
                                value={editDraft.batting_position}
                                onChange={e => setEditDraft(d => ({ ...d, batting_position: parseInt(e.target.value) || 1 }))}
                                className="h-8 text-sm bg-white/10 border-white/20 text-white" />
                            </div>
                            <div className="w-16">
                              <label className="text-xs text-white/40">Jersey #</label>
                              <Input value={editDraft.jersey_number}
                                onChange={e => setEditDraft(d => ({ ...d, jersey_number: e.target.value }))}
                                className="h-8 text-sm bg-white/10 border-white/20 text-white" placeholder="0" />
                            </div>
                            <div className="flex-1">
                              <label className="text-xs text-white/40">Player Name</label>
                              <Input value={editDraft.player_name}
                                onChange={e => setEditDraft(d => ({ ...d, player_name: e.target.value }))}
                                className="h-8 text-sm bg-white/10 border-white/20 text-white" placeholder="Full name" />
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" className="flex-1 gap-1 h-8" onClick={saveEdit}><Check className="w-3.5 h-3.5" /> Save</Button>
                            <Button size="sm" variant="outline" className="h-8 px-2 border-white/20 text-white" onClick={cancelEdit}>Cancel</Button>
                            <Button size="sm" variant="ghost" className="h-8 px-2 text-red-400 hover:bg-red-500/10" onClick={() => removeRow(idx)}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center flex-shrink-0 ${isDupe ? 'bg-red-500 text-white' : 'bg-primary text-white'}`}>
                            {row.batting_position}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium text-white truncate">{row.player_name || '—'}</div>
                            {row.jersey_number && <div className="text-xs text-white/40">#{row.jersey_number}</div>}
                          </div>
                          <button onClick={() => startEdit(idx)} className="p-1.5 rounded hover:bg-white/10 touch-manipulation flex-shrink-0">
                            <Pencil className="w-3.5 h-3.5 text-white/50" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              <button onClick={addRow}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border-2 border-dashed border-white/15 text-sm text-white/50 hover:bg-white/5 touch-manipulation">
                <Plus className="w-4 h-4" /> Add Missing Player
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        {stage === 'review' && (
          <div className="p-4 border-t border-white/10 flex-shrink-0">
            {hasDuplicatePositions() && (
              <p className="text-xs text-red-400 mb-2 text-center">Fix duplicate batting order numbers before saving</p>
            )}
            <Button className="w-full gap-2" onClick={handleConfirm} disabled={confirming || hasDuplicatePositions()}>
              {confirming ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              {confirming ? 'Saving...' : '✅ Confirm & Save Opponent Lineup'}
            </Button>
          </div>
        )}
      </div>

      {showPhotoViewer && photoSrc && (
        <div className="fixed inset-0 z-[70] bg-black flex items-center justify-center" onClick={() => setShowPhotoViewer(false)}>
          <button className="absolute top-4 right-4 p-2 rounded-full bg-white/20 text-white z-10 touch-manipulation">
            <X className="w-5 h-5" />
          </button>
          <img src={photoSrc} alt="Source lineup card" className="max-w-full max-h-full object-contain"
            onClick={e => e.stopPropagation()} style={{ touchAction: 'pinch-zoom' }} />
        </div>
      )}
    </div>
  );
}