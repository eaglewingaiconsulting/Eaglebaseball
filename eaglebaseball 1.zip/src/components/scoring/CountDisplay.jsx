export default function CountDisplay({ game }) {
  const balls = game?.balls || 0;
  const strikes = game?.strikes || 0;
  const outs = game?.outs || 0;
  const twoStrikes = strikes >= 2;

  return (
    <div className="bg-[hsl(214,90%,12%)] border border-white/10 rounded-xl p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-5 sm:gap-8">
          {/* Balls */}
          <div className="text-center">
            <div className="text-xs text-white/50 uppercase tracking-wider mb-2">Balls</div>
            <div className="flex gap-2">
              {[0,1,2,3].map(i => (
                <div key={i} className={`w-6 h-6 rounded-full border-2 transition-all ${
                  i < balls ? 'bg-green-400 border-green-400 shadow-[0_0_8px_rgba(74,222,128,0.6)]' : 'border-white/20'
                }`} />
              ))}
            </div>
            <div className="text-3xl font-bebas tracking-wider mt-1">{balls}</div>
          </div>

          {/* Strikes — state-aware */}
          <div className="text-center">
            <div className={`text-xs uppercase tracking-wider mb-2 ${twoStrikes ? 'text-red-400 font-bold' : 'text-white/50'}`}>
              Strikes {twoStrikes ? '⚠' : ''}
            </div>
            <div className="flex gap-2">
              {[0,1,2].map(i => (
                <div key={i} className={`w-6 h-6 rounded-full border-2 transition-all ${
                  i < strikes
                    ? twoStrikes
                      ? 'bg-red-400 border-red-400 shadow-[0_0_10px_rgba(248,113,113,0.8)] animate-pulse'
                      : 'bg-white border-white shadow-[0_0_6px_rgba(255,255,255,0.4)]'
                    : 'border-white/20'
                }`} />
              ))}
            </div>
            <div className={`text-3xl font-bebas tracking-wider mt-1 ${twoStrikes ? 'text-red-400' : ''}`}>{strikes}</div>
            {twoStrikes && (
              <div className="text-xs text-red-400 font-bold animate-pulse mt-0.5">K?</div>
            )}
          </div>

          {/* Outs */}
          <div className="text-center">
            <div className="text-xs text-white/50 uppercase tracking-wider mb-2">Outs</div>
            <div className="flex gap-2">
              {[0,1,2].map(i => (
                <div key={i} className={`w-6 h-6 rounded-full border-2 transition-all ${
                  i < outs ? 'bg-amber-400 border-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]' : 'border-white/20'
                }`} />
              ))}
            </div>
            <div className="text-3xl font-bebas tracking-wider mt-1">{outs}</div>
          </div>
        </div>

        {/* Inning */}
        <div className="text-center">
          <div className="text-xs text-white/50 uppercase tracking-wider mb-1">Inning</div>
          <div className="text-5xl font-bebas tracking-wider text-accent">
            {game?.inning_half === 'top' ? '▲' : '▼'}{game?.inning || 1}
          </div>
        </div>
      </div>
    </div>
  );
}