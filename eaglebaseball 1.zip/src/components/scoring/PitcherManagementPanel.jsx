/**
 * PitcherManagementPanel
 * Source of truth: GamePitcher records. Current pitcher = most recent record with exit_inning == null.
 * Handles: our team pitcher, opponent pitcher, pitch type breakdown, pitcher history.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { X, ChevronDown } from 'lucide-react';

const PITCH_TYPES = ['fastball', 'curveball', 'changeup', 'slider', 'other'];
const PITCH_LABELS = { fastball: 'FB', curveball: 'CB', changeup: 'CH', slider: 'SL', other: 'OT' };

function StatBadge({ label, value }) {
  return (
    <div className="flex flex-col items-center px-2.5 py-1.5 rounded-lg bg-white/5 min-w-[36px]">
      <span className="text-xs font-black text-white">{value ?? 0}</span>
      <span className="text-[10px] text-white/40 uppercase tracking-wide">{label}</span>
    </div>
  );
}

function PitchBreakdownEditor({ breakdown = {}, onUpdate, disabled }) {
  const total = PITCH_TYPES.reduce((s, k) => s + (breakdown[k] || 0), 0);
  return (
    <div className="space-y-1.5">
      <div className="text-white/40 text-[10px] uppercase tracking-wide font-semibold flex justify-between">
        <span>Pitch Type Breakdown</span>
        <span className="text-white/60">{total} total</span>
      </div>
      <div className="grid grid-cols-5 gap-1">
        {PITCH_TYPES.map(pt => (
          <div key={pt} className="flex flex-col items-center gap-0.5">
            <span className="text-[10px] text-white/50 font-bold">{PITCH_LABELS[pt]}</span>
            <div className="flex flex-col items-center gap-0.5">
              <button
                disabled={disabled}
                onClick={() => onUpdate(pt, (breakdown[pt] || 0) + 1)}
                className="w-7 h-5 rounded text-white text-xs bg-white/10 hover:bg-white/20 active:scale-95 touch-manipulation select-none leading-none">
                +
              </button>
              <span className="text-sm font-bold text-white tabular-nums w-7 text-center">{breakdown[pt] || 0}</span>
              <button
                disabled={disabled || !breakdown[pt]}
                onClick={() => onUpdate(pt, Math.max(0, (breakdown[pt] || 0) - 1))}
                className="w-7 h-5 rounded text-white/50 text-xs bg-white/5 hover:bg-white/10 active:scale-95 touch-manipulation select-none leading-none disabled:opacity-30">
                −
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function PitcherManagementPanel({
  game,
  players,        // all players loaded in ScoringView
  onClose,
  onGameUpdate,   // (updates) => void — to keep game state in sync
}) {
  const [gamePitchers, setGamePitchers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [view, setView] = useState('our'); // 'our' | 'opp'
  const [changingPitcher, setChangingPitcher] = useState(false);
  const [oppNameInput, setOppNameInput] = useState('');

  const isTop = game.inning_half === 'top';
  const ourTeamId = game.home_team_id; // home team is always "our" team
  const oppTeamId = game.away_team_id;
  const fieldingTeamId = isTop ? ourTeamId : oppTeamId;

  const ourPlayers = players.filter(p => p.team_id === ourTeamId);

  useEffect(() => {
    base44.entities.GamePitcher.filter({ game_id: game.id })
      .then(records => setGamePitchers(records))
      .finally(() => setLoading(false));
  }, [game.id]);

  // Current pitcher = most recent GamePitcher record for a team where exit_inning is null
  const currentOurRecord = [...gamePitchers]
    .filter(r => !r.is_opponent && r.exit_inning == null)
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0] || null;

  const currentOppRecord = [...gamePitchers]
    .filter(r => r.is_opponent && r.exit_inning == null)
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0] || null;

  const ourHistory = gamePitchers
    .filter(r => !r.is_opponent && r.exit_inning != null)
    .sort((a, b) => (a.entry_inning || 1) - (b.entry_inning || 1));

  const oppHistory = gamePitchers
    .filter(r => r.is_opponent && r.exit_inning != null)
    .sort((a, b) => (a.entry_inning || 1) - (b.entry_inning || 1));

  // ── PITCH TYPE BREAKDOWN ──────────────────────────────────────────────────
  const updateBreakdown = async (record, pitchType, newCount) => {
    if (!record) return;
    const breakdown = { ...(record.pitch_type_breakdown || {}), [pitchType]: newCount };
    setSaving(true);
    const updated = await base44.entities.GamePitcher.update(record.id, { pitch_type_breakdown: breakdown });
    setGamePitchers(prev => prev.map(r => r.id === record.id ? { ...r, pitch_type_breakdown: breakdown } : r));
    setSaving(false);
  };

  // ── CHANGE OUR PITCHER ────────────────────────────────────────────────────
  const handleSelectNewPitcher = async (player) => {
    setSaving(true);
    const currentBatterName = players.find(p => p.id === game.current_batter_id)?.name || '';

    // 1. Close out current pitcher record
    if (currentOurRecord) {
      await base44.entities.GamePitcher.update(currentOurRecord.id, {
        exit_inning: game.inning,
        exit_batter: currentBatterName,
        pitch_count: game.current_pitcher_pitch_count || 0,
      });
    }

    // 2. Create new entry record
    const newRecord = await base44.entities.GamePitcher.create({
      game_id: game.id,
      player_id: player.id,
      player_name: player.name,
      team_id: ourTeamId,
      entry_inning: game.inning,
      pitch_count: 0,
      is_opponent: false,
    });

    setGamePitchers(prev => {
      const updated = currentOurRecord
        ? prev.map(r => r.id === currentOurRecord.id ? { ...r, exit_inning: game.inning, exit_batter: currentBatterName } : r)
        : prev;
      return [...updated, newRecord];
    });

    // 3. Update game fields so rest of scoring view stays in sync
    const gameUpdates = {
      current_pitcher_id: player.id,
      current_pitcher_name: player.name,
      current_pitcher_pitch_count: 0,
    };
    await base44.entities.Game.update(game.id, gameUpdates);
    onGameUpdate(gameUpdates);

    setSaving(false);
    setChangingPitcher(false);
    toast.success(`${player.name} now pitching`);
  };

  // ── SET / CHANGE OPPONENT PITCHER ─────────────────────────────────────────
  const handleSetOppPitcher = async () => {
    if (!oppNameInput.trim()) return;
    setSaving(true);

    // Close existing opp record
    if (currentOppRecord) {
      await base44.entities.GamePitcher.update(currentOppRecord.id, {
        exit_inning: game.inning,
        exit_batter: players.find(p => p.id === game.current_batter_id)?.name || '',
      });
    }

    const newRecord = await base44.entities.GamePitcher.create({
      game_id: game.id,
      player_id: 'opp',
      player_name: oppNameInput.trim(),
      team_id: oppTeamId,
      entry_inning: game.inning,
      pitch_count: 0,
      is_opponent: true,
      opponent_pitcher_name: oppNameInput.trim(),
    });

    setGamePitchers(prev => {
      const updated = currentOppRecord
        ? prev.map(r => r.id === currentOppRecord.id ? { ...r, exit_inning: game.inning } : r)
        : prev;
      return [...updated, newRecord];
    });

    setOppNameInput('');
    setSaving(false);
    toast.success(`Opponent pitcher set: ${newRecord.player_name}`);
  };

  // ── UI HELPERS ─────────────────────────────────────────────────────────────
  const pitchersToChangeTo = ourPlayers.filter(p =>
    !currentOurRecord || p.id !== currentOurRecord.player_id
  );

  if (loading) return (
    <div className="flex items-center justify-center py-10">
      <div className="w-5 h-5 border-2 border-white/20 border-t-white/70 rounded-full animate-spin" />
    </div>
  );

  const activeRecord = view === 'our' ? currentOurRecord : currentOppRecord;
  const historyList = view === 'our' ? ourHistory : oppHistory;

  return (
    <div className="space-y-3">
      {/* Team toggle */}
      <div className="flex gap-1 bg-white/5 rounded-lg p-1">
        <button onClick={() => { setView('our'); setChangingPitcher(false); }}
          className={`flex-1 py-1.5 rounded-md text-xs font-semibold select-none touch-manipulation transition-all ${view === 'our' ? 'bg-white/20 text-white' : 'text-white/40'}`}>
          {game.home_team_name} (Our Team)
        </button>
        <button onClick={() => { setView('opp'); setChangingPitcher(false); }}
          className={`flex-1 py-1.5 rounded-md text-xs font-semibold select-none touch-manipulation transition-all ${view === 'opp' ? 'bg-white/20 text-white' : 'text-white/40'}`}>
          {game.away_team_name} (Opp.)
        </button>
      </div>

      {/* ── OUR TEAM ── */}
      {view === 'our' && (
        <>
          {/* Current pitcher card */}
          <div className="bg-white/5 rounded-xl p-3 space-y-3">
            <div className="text-white/40 text-[10px] uppercase tracking-wide font-semibold">Current Pitcher</div>

            {currentOurRecord ? (
              <>
                <div className="flex items-center gap-2">
                  <div className="flex-1">
                    <div className="font-bold text-white text-sm">
                      {ourPlayers.find(p => p.id === currentOurRecord.player_id)
                        ? `#${ourPlayers.find(p => p.id === currentOurRecord.player_id).number} `
                        : ''}
                      {currentOurRecord.player_name}
                    </div>
                    <div className="text-white/40 text-xs">Since inning {currentOurRecord.entry_inning}</div>
                  </div>
                  <div className="text-accent font-black text-xl tabular-nums">
                    {game.current_pitcher_pitch_count || 0}
                    <span className="text-white/30 text-xs font-normal ml-0.5">p</span>
                  </div>
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  <StatBadge label="K" value={currentOurRecord.strikeouts} />
                  <StatBadge label="BB" value={currentOurRecord.walks} />
                  <StatBadge label="H" value={currentOurRecord.hits_allowed} />
                  <StatBadge label="R" value={currentOurRecord.runs_allowed} />
                </div>
                <PitchBreakdownEditor
                  breakdown={currentOurRecord.pitch_type_breakdown}
                  onUpdate={(pt, val) => updateBreakdown(currentOurRecord, pt, val)}
                  disabled={saving}
                />
              </>
            ) : (
              <div className="text-white/40 text-sm">No pitcher set yet</div>
            )}

            {!changingPitcher && (
              <button
                onClick={() => setChangingPitcher(true)}
                className="w-full py-2.5 rounded-xl bg-primary text-white font-semibold text-sm select-none touch-manipulation">
                {currentOurRecord ? 'Change Pitcher' : 'Set Pitcher'}
              </button>
            )}
          </div>

          {/* Pitcher selector */}
          {changingPitcher && (
            <div className="space-y-1.5">
              <div className="text-white/50 text-xs uppercase tracking-wide font-semibold">Select new pitcher:</div>
              {pitchersToChangeTo.length === 0 && (
                <div className="text-white/30 text-sm text-center py-3">No other players available</div>
              )}
              {pitchersToChangeTo.map(p => (
                <button key={p.id}
                  disabled={saving}
                  onClick={() => handleSelectNewPitcher(p)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-primary/30 select-none touch-manipulation">
                  <span className="text-sm font-bold text-white/70 w-7">#{p.number}</span>
                  <span className="text-sm text-white flex-1">{p.name}</span>
                  <span className="text-xs text-white/40">{p.position}</span>
                </button>
              ))}
              <button onClick={() => setChangingPitcher(false)}
                className="w-full py-2 rounded-xl bg-white/5 text-white/40 text-sm select-none touch-manipulation">
                Cancel
              </button>
            </div>
          )}

          {/* Pitcher history */}
          {historyList.length > 0 && (
            <div className="space-y-1.5 pt-1 border-t border-white/10">
              <div className="text-white/30 text-[10px] uppercase tracking-wide font-semibold">Pitching History</div>
              {historyList.map(r => (
                <div key={r.id} className="flex items-center gap-2 p-2.5 rounded-xl bg-white/5">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-white/70 truncate">{r.player_name}</div>
                    <div className="text-[10px] text-white/30">Inn {r.entry_inning}–{r.exit_inning} · {r.pitch_count}p</div>
                  </div>
                  <div className="flex gap-1">
                    <StatBadge label="K" value={r.strikeouts} />
                    <StatBadge label="H" value={r.hits_allowed} />
                    <StatBadge label="R" value={r.runs_allowed} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* ── OPPONENT TEAM ── */}
      {view === 'opp' && (
        <>
          <div className="bg-white/5 rounded-xl p-3 space-y-3">
            <div className="text-white/40 text-[10px] uppercase tracking-wide font-semibold">Opponent's Current Pitcher</div>

            {currentOppRecord ? (
              <>
                <div className="flex items-center gap-2">
                  <div className="flex-1">
                    <div className="font-bold text-white text-sm">{currentOppRecord.player_name}</div>
                    <div className="text-white/40 text-xs">Since inning {currentOppRecord.entry_inning}</div>
                  </div>
                </div>
                <PitchBreakdownEditor
                  breakdown={currentOppRecord.pitch_type_breakdown}
                  onUpdate={(pt, val) => updateBreakdown(currentOppRecord, pt, val)}
                  disabled={saving}
                />
              </>
            ) : (
              <div className="text-white/40 text-sm">No opponent pitcher tracked</div>
            )}

            {/* Set/change opponent pitcher */}
            <div className="flex gap-2 pt-1">
              <input
                type="text"
                placeholder="Pitcher name (e.g. Smith #14)"
                value={oppNameInput}
                onChange={e => setOppNameInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && oppNameInput.trim() && handleSetOppPitcher()}
                className="flex-1 bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-accent"
              />
              <button
                disabled={saving || !oppNameInput.trim()}
                onClick={handleSetOppPitcher}
                className="px-3 py-2 rounded-lg bg-accent text-accent-foreground text-sm font-semibold select-none touch-manipulation disabled:opacity-40">
                Set
              </button>
            </div>
          </div>

          {/* Opponent history */}
          {historyList.length > 0 && (
            <div className="space-y-1.5 pt-1 border-t border-white/10">
              <div className="text-white/30 text-[10px] uppercase tracking-wide font-semibold">Opponent Pitching History</div>
              {historyList.map(r => (
                <div key={r.id} className="flex items-center gap-2 p-2.5 rounded-xl bg-white/5">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-white/70 truncate">{r.player_name}</div>
                    <div className="text-[10px] text-white/30">Inn {r.entry_inning}–{r.exit_inning}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}