import { useState } from 'react';

export default function PickoffModal({ game, onResult, onClose }) {
  const [base, setBase] = useState(null);

  const bases = [
    { label: '1st', key: 'first', occupied: game?.runner_first },
    { label: '2nd', key: 'second', occupied: game?.runner_second },
    { label: '3rd', key: 'third', occupied: game?.runner_third },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-white/20 rounded-2xl p-6 w-full max-w-sm text-white shadow-2xl">
        <h2 className="text-xl font-bold mb-1 text-center">Pickoff</h2>
        <p className="text-sm text-white/60 mb-5 text-center">
          {!base ? 'Which base?' : 'What was the result?'}
        </p>

        {!base ? (
          <div className="grid grid-cols-3 gap-3 mb-4">
            {bases.map(b => (
              <button
                key={b.key}
                onClick={() => setBase(b)}
                className={`py-4 rounded-xl font-bold text-sm transition-all active:scale-95 select-none touch-manipulation ${
                  b.occupied
                    ? 'bg-amber-600 hover:bg-amber-500 text-white'
                    : 'bg-slate-700 hover:bg-slate-600 text-white/60'
                }`}
              >
                {b.label}
                {b.occupied && <div className="text-xs font-normal mt-1">●</div>}
              </button>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 mb-4">
            <button
              onClick={() => onResult({ base: base.key, result: 'out' })}
              className="bg-red-700 hover:bg-red-600 active:scale-95 text-white font-bold py-5 rounded-xl transition-all select-none touch-manipulation"
            >
              ✅ Out
              <div className="text-xs font-normal text-white/70 mt-1">Runner retired</div>
            </button>
            <button
              onClick={() => onResult({ base: base.key, result: 'safe' })}
              className="bg-green-700 hover:bg-green-600 active:scale-95 text-white font-bold py-5 rounded-xl transition-all select-none touch-manipulation"
            >
              🏃 Safe
              <div className="text-xs font-normal text-white/70 mt-1">Runner safe</div>
            </button>
          </div>
        )}

        <div className="flex items-center justify-between text-xs text-white/40">
          {base && (
            <button onClick={() => setBase(null)} className="hover:text-white/70 transition-colors touch-manipulation">
              ← Back
            </button>
          )}
          <button onClick={onClose} className="ml-auto hover:text-white/70 transition-colors touch-manipulation">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}