// RunnerAdvancementModal — for Passed Ball and Wild Pitch runner advancement
import { useState } from 'react';
import { X } from 'lucide-react';

const OPTIONS = [
  { value: 'stayed', label: 'Stayed' },
  { value: 'next', label: 'Advance 1 Base' },
  { value: 'two', label: 'Advance 2 Bases' },
  { value: 'scored', label: 'Scored 🏃' },
];

export default function RunnerAdvancementModal({ game, players, eventLabel, onConfirm, onClose }) {
  const occupied = [
    game.runner_first && 'first',
    game.runner_second && 'second',
    game.runner_third && 'third',
  ].filter(Boolean);

  const [selections, setSelections] = useState(
    Object.fromEntries(occupied.map(b => [b, 'stayed']))
  );

  const baseLabel = { first: '1st Base', second: '2nd Base', third: '3rd Base' };

  const allSelected = occupied.every(b => selections[b]);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70" onClick={onClose}>
      <div
        className="bg-[hsl(214,90%,9%)] border-t border-white/20 rounded-t-2xl w-full max-w-lg p-5 space-y-4"
        style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 24px)' }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-white font-bold text-base">⚡ {eventLabel} — Runner Advancement</div>
            <div className="text-white/50 text-xs mt-0.5">Select what each runner did</div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 select-none touch-manipulation">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {occupied.map(base => {
          // Filter options: runner on 3rd can't advance 2 bases (only stay, next=score, scored)
          const opts = base === 'third'
            ? OPTIONS.filter(o => o.value !== 'two')
            : base === 'second'
            ? OPTIONS.filter(o => o.value !== 'two' || !game.runner_third) // suppress 2-base if 3rd occupied
            : OPTIONS;

          return (
            <div key={base}>
              <div className="text-white/60 text-xs uppercase tracking-wide font-semibold mb-2">
                Runner on {baseLabel[base]}
              </div>
              <div className="grid grid-cols-2 gap-2">
                {opts.map(opt => (
                  <button key={opt.value} onClick={() => setSelections(s => ({ ...s, [base]: opt.value }))}
                    className={`py-3 px-3 rounded-xl text-sm font-semibold select-none touch-manipulation transition-all ${
                      selections[base] === opt.value
                        ? opt.value === 'scored'
                          ? 'bg-green-600 text-white'
                          : 'bg-accent text-accent-foreground'
                        : 'bg-white/10 text-white hover:bg-white/20'
                    }`}>
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          );
        })}

        <button
          disabled={!allSelected}
          onClick={() => onConfirm(selections)}
          className="w-full py-4 rounded-xl bg-accent text-accent-foreground font-bold text-base disabled:opacity-40 disabled:cursor-not-allowed select-none touch-manipulation">
          Confirm Advancement
        </button>
      </div>
    </div>
  );
}