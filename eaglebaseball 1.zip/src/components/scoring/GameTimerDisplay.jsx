/**
 * GameTimerDisplay — shows time remaining for time-limited games.
 * Fires toast alerts at 15, 10, 5, and 2 minutes remaining.
 * Props:
 *   game        – game object with time_limit_minutes and game_start_timestamp
 *   compact     – if true, renders a small inline badge (for ScoringHeader)
 */
import { useState, useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { Timer } from 'lucide-react';

const ALERT_MINUTES = [15, 10, 5, 2];

export default function GameTimerDisplay({ game, compact = false }) {
  const [secondsLeft, setSecondsLeft] = useState(null);
  const alertedRef = useRef(new Set());

  useEffect(() => {
    if (!game?.time_limit_minutes || !game?.game_start_timestamp) return;

    const totalSeconds = game.time_limit_minutes * 60;

    const tick = () => {
      const elapsed = (Date.now() - new Date(game.game_start_timestamp).getTime()) / 1000;
      const remaining = Math.max(0, totalSeconds - elapsed);
      setSecondsLeft(Math.floor(remaining));

      // Fire alerts
      const minutesLeft = remaining / 60;
      for (const threshold of ALERT_MINUTES) {
        if (minutesLeft <= threshold && !alertedRef.current.has(threshold)) {
          alertedRef.current.add(threshold);
          const msg = threshold === 2
            ? '⏰ 2 minutes left — finish this at-bat!'
            : `⏰ ${threshold} minutes remaining in the game`;
          toast(msg, {
            duration: 6000,
            style: {
              background: threshold <= 2 ? '#7f1d1d' : threshold <= 5 ? '#78350f' : '#1e3a5f',
              color: '#fff',
              fontWeight: 600,
            },
          });
        }
      }
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [game?.time_limit_minutes, game?.game_start_timestamp]);

  if (secondsLeft === null || !game?.time_limit_minutes) return null;

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;
  const timeStr = `${mins}:${String(secs).padStart(2, '0')}`;
  const isWarning = mins < 5;
  const isDanger = mins < 2;
  const isExpired = secondsLeft === 0;

  if (compact) {
    return (
      <div
        className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold select-none"
        style={{
          backgroundColor: isDanger ? 'rgba(220,38,38,0.3)' : isWarning ? 'rgba(245,158,11,0.25)' : 'rgba(255,255,255,0.08)',
          border: `1px solid ${isDanger ? 'rgba(220,38,38,0.6)' : isWarning ? 'rgba(245,158,11,0.5)' : 'rgba(255,255,255,0.15)'}`,
          color: isDanger ? '#FCA5A5' : isWarning ? '#FCD34D' : 'rgba(255,255,255,0.7)',
        }}
      >
        <Timer className="w-3 h-3" />
        {isExpired ? 'TIME' : timeStr}
      </div>
    );
  }

  return (
    <div
      className="flex items-center justify-between px-4 py-3 rounded-xl"
      style={{
        backgroundColor: isDanger ? 'rgba(220,38,38,0.15)' : isWarning ? 'rgba(245,158,11,0.1)' : 'rgba(255,255,255,0.05)',
        border: `1px solid ${isDanger ? 'rgba(220,38,38,0.4)' : isWarning ? 'rgba(245,158,11,0.35)' : 'rgba(255,255,255,0.1)'}`,
      }}
    >
      <div className="flex items-center gap-2">
        <Timer className="w-4 h-4" style={{ color: isDanger ? '#FCA5A5' : isWarning ? '#FCD34D' : 'rgba(255,255,255,0.5)' }} />
        <span className="text-sm font-semibold" style={{ color: isDanger ? '#FCA5A5' : isWarning ? '#FCD34D' : 'rgba(255,255,255,0.6)' }}>
          Time Remaining
        </span>
      </div>
      <div
        className="font-bebas text-2xl leading-none tracking-wider"
        style={{ color: isDanger ? '#FCA5A5' : isWarning ? '#FCD34D' : 'white' }}
      >
        {isExpired ? 'EXPIRED' : timeStr}
      </div>
    </div>
  );
}