/**
 * LineupChangeSheet — in-game lineup management sheet triggered from ActionPanel > Misc.
 * Allows: substitutions, position changes, pitcher changes.
 * Order changes are NOT permitted.
 */
import { useState } from 'react';
import { X, ChevronDown } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const POSITIONS = ['P', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH', 'UT'];

function PositionBadge({ player, onSave }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSelect = async (pos) => {
    setOpen(false);
    if (pos === player.position) return;
    setSaving(true);
    try {
      await base44.entities.Player.update(player.id, { position: pos });
      onSave(player.id, pos);
      toast.success(`${player.name} → ${pos}`);
    } catch {
      toast.error('Failed to update position');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="relative flex-shrink-0">
      <button
        onClick={() => setOpen(v => !v)}
        disabled={saving}
        className="flex items-center gap-0.5 px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold select-none touch-manipulation">
        {saving ? '…' : (player?.position || '?')}
        <ChevronDown className="w-3 h-3 text-white/50" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-8 z-20 bg-[hsl(214,90%,12%)] border border-white/20 rounded-xl shadow-xl overflow-hidden grid grid-cols-3 w-32">
            {POSITIONS.map(pos => (
              <button
                key={pos}
                onClick={() => handleSelect(pos)}
                className={`py-2 text-xs font-bold text-center hover:bg-white/10 select-none touch-manipulation transition-colors ${
                  pos === player?.position ? 'text-[#FFB81C] bg-white/10' : 'text-white/80'
                }`}>
                {pos}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function LineupChangeSheet({ game, players, onClose, onGameUpdate }) {
  // Step 1: pick team. Step 2: manage lineup.
  const [team, setTeam] = useState(null); // 'home' | 'away'
  const [localPlayers, setLocalPlayers] = useState(players);
  const [saving, setSaving] = useState(false);

  // Sub flow
  const [subSlotIdx, setSubSlotIdx] = useState(null);

  const isTop = game.inning_half === 'top';

  // Determine lineup + team details based on selection
  const homeLineup = game.home_lineup || [];
  const awayLineup = game.away_lineup || [];

  const lineup = team === 'home' ? homeLineup : awayLineup;
  const teamId = team === 'home' ? game.home_team_id : game.away_team_id;
  const lineupField = team === 'home' ? 'home_lineup' : 'away_lineup';
  const battingIdxField = team === 'home' ? 'home_batting_order_idx' : 'away_batting_order_idx';
  const currentIdx = team === 'home' ? (game.home_batting_order_idx || 0) : (game.away_batting_order_idx || 0);

  const getPlayer = (pid) => localPlayers.find(p => p.id === pid);
  const benchPlayers = localPlayers.filter(p => p.team_id === teamId && !lineup.includes(p.id));

  const handlePositionSave = (playerId, newPos) => {
    setLocalPlayers(prev => prev.map(p => p.id === playerId ? { ...p, position: newPos } : p));
  };

  const handleSub = async (slotIdx, playerInId) => {
    setSaving(true);
    const newLineup = [...lineup];
    const playerOutId = newLineup[slotIdx];
    newLineup[slotIdx] = playerInId;

    const updates = { [lineupField]: newLineup };
    // If subbing out current batter, update current_batter_id
    if (game.current_batter_id === playerOutId) {
      updates.current_batter_id = playerInId;
    }

    try {
      await base44.entities.Game.update(game.id, updates);
      await base44.entities.PlayLog.create({
        game_id: game.id,
        player_id: playerInId,
        player_name: getPlayer(playerInId)?.name || '',
        team_id: teamId,
        play_type: 'substitution',
        inning: game.inning,
        inning_half: game.inning_half,
        notes: `Sub: #${getPlayer(playerInId)?.number} in for #${getPlayer(playerOutId)?.number}`,
      });
      onGameUpdate(updates);
      toast.success('Substitution recorded');
    } catch {
      toast.error('Failed to save substitution');
    } finally {
      setSaving(false);
      setSubSlotIdx(null);
    }
  };

  const handlePitcherChange = async (player) => {
    setSaving(true);
    try {
      const g = game;
      if (g.current_pitcher_id) {
        const openRecords = await base44.entities.GamePitcher.filter({ game_id: g.id });
        const openRecord = openRecords
          .filter(r => !r.is_opponent && r.exit_inning == null)
          .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
        if (openRecord) {
          await base44.entities.GamePitcher.update(openRecord.id, {
            exit_inning: g.inning,
            pitch_count: g.current_pitcher_pitch_count || 0,
          });
        }
      }
      await base44.entities.GamePitcher.create({
        game_id: g.id,
        player_id: player.id,
        player_name: player.name,
        team_id: teamId,
        entry_inning: g.inning,
        pitch_count: 0,
        is_opponent: false,
      });
      const updates = { current_pitcher_id: player.id, current_pitcher_name: player.name, current_pitcher_pitch_count: 0 };
      await base44.entities.Game.update(g.id, updates);
      onGameUpdate(updates);
      toast.success(`Pitcher changed to ${player.name}`);
    } catch {
      toast.error('Failed to change pitcher');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={onClose}>
      <div
        className="bg-[hsl(214,90%,9%)] border-t border-white/20 rounded-t-2xl flex flex-col"
        style={{ maxHeight: '90dvh' }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex-shrink-0 p-4 pb-0">
          <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-3" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-white font-bold text-base">
              {team ? `📋 ${team === 'home' ? game.home_team_name : game.away_team_name} — Lineup` : '📋 Lineup Change'}
            </span>
            <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 touch-manipulation">
              <X className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>

        {/* Step 1 — Team Picker */}
        {!team && (
          <div className="p-4 space-y-3">
            <p className="text-white/50 text-sm text-center">Which team is making the change?</p>
            <button
              onClick={() => setTeam('home')}
              className="w-full py-4 rounded-xl font-bold text-white text-base touch-manipulation"
              style={{ backgroundColor: 'rgba(59,130,246,0.2)', border: '2px solid rgba(59,130,246,0.5)' }}>
              ⚾ {game.home_team_name} <span className="text-white/40 text-sm font-normal">(Home)</span>
            </button>
            <button
              onClick={() => setTeam('away')}
              className="w-full py-4 rounded-xl font-bold text-white text-base touch-manipulation"
              style={{ backgroundColor: 'rgba(245,158,11,0.15)', border: '2px solid rgba(245,158,11,0.4)' }}>
              🆚 {game.away_team_name} <span className="text-white/40 text-sm font-normal">(Away)</span>
            </button>
          </div>
        )}

        {/* Step 2 — Lineup Manager */}
        {team && (
          <>
            <div className="flex-1 overflow-y-auto p-4 pt-2 space-y-2">

              {/* Sub confirm */}
              {subSlotIdx !== null && (
                <div className="bg-white/10 rounded-xl p-4 space-y-3 mb-2">
                  <div className="text-white font-bold text-sm">Select player coming IN:</div>
                  {benchPlayers.length === 0 && <div className="text-white/30 text-sm">No bench players available</div>}
                  {benchPlayers.map(p => (
                    <button key={p.id}
                      disabled={saving}
                      onClick={() => handleSub(subSlotIdx, p.id)}
                      className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 touch-manipulation">
                      <span className="text-sm font-bold text-white/70">#{p.number}</span>
                      <span className="text-sm text-white flex-1 text-left">{p.name}</span>
                      <span className="text-xs text-white/40">{p.position}</span>
                      <span className="text-green-400 text-sm">↔</span>
                    </button>
                  ))}
                  <button onClick={() => setSubSlotIdx(null)} className="w-full py-2 rounded-xl bg-white/5 text-white/40 text-sm touch-manipulation">Cancel</button>
                </div>
              )}

              {subSlotIdx === null && (
                <>
                  <div className="text-white/30 text-xs text-center">Order is locked · Tap position to edit · Sub to swap</div>

                  {lineup.length === 0 && (
                    <div className="text-white/40 text-sm text-center py-4">No lineup set for this team</div>
                  )}

                  {lineup.map((pid, idx) => {
                    const p = getPlayer(pid);
                    const isCurrent = idx === currentIdx && (
                      (team === 'home' && !isTop) || (team === 'away' && isTop)
                    );
                    const isPitcher = pid === game.current_pitcher_id;
                    return (
                      <div key={pid} className={`flex items-center gap-2 p-3 rounded-xl ${isCurrent ? 'bg-[#FFB81C]/20 border border-[#FFB81C]/40' : 'bg-white/5'}`}>
                        <span className={`text-xs font-bold w-5 text-center flex-shrink-0 ${isCurrent ? 'text-[#FFB81C]' : 'text-white/40'}`}>{idx + 1}</span>
                        <span className={`text-sm font-bold flex-shrink-0 ${isCurrent ? 'text-[#FFB81C]' : 'text-white/70'}`}>#{p?.number || '?'}</span>
                        <span className={`text-sm flex-1 min-w-0 truncate ${isCurrent ? 'text-white font-semibold' : 'text-white/70'}`}>{p?.name || 'Unknown'}</span>
                        {isPitcher && <span className="text-[10px] text-blue-300 font-bold flex-shrink-0">P</span>}
                        {isCurrent && <span className="text-[10px] text-[#FFB81C] font-bold flex-shrink-0">AT BAT</span>}
                        {p && <PositionBadge player={p} onSave={handlePositionSave} />}
                        <button
                          onClick={() => setSubSlotIdx(idx)}
                          className="px-2.5 py-1.5 rounded-lg bg-white/10 text-white/70 text-xs font-semibold touch-manipulation flex-shrink-0">
                          Sub
                        </button>
                        {/* Pitcher change — only for home team (fielding when away bats, batting when home bats) */}
                        {p?.position === 'P' && (
                          <button
                            disabled={saving || isPitcher}
                            onClick={() => handlePitcherChange(p)}
                            className={`px-2 py-1.5 rounded-lg text-xs font-semibold touch-manipulation flex-shrink-0 ${isPitcher ? 'bg-blue-900/30 text-blue-300 cursor-default' : 'bg-blue-700 hover:bg-blue-600 text-white'}`}>
                            {isPitcher ? 'Pitching' : 'Set P'}
                          </button>
                        )}
                      </div>
                    );
                  })}

                  {/* Bench players — add to lineup */}
                  {benchPlayers.length > 0 && (
                    <div className="pt-2 border-t border-white/10">
                      <div className="text-white/40 text-xs uppercase tracking-wide font-semibold mb-2">Bench</div>
                      {benchPlayers.map(p => (
                        <div key={p.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 mb-1">
                          <span className="text-sm font-bold text-white/70">#{p.number}</span>
                          <span className="text-sm text-white flex-1">{p.name}</span>
                          <PositionBadge player={p} onSave={handlePositionSave} />
                          {p.position === 'P' && (
                            <button
                              disabled={saving || p.id === game.current_pitcher_id}
                              onClick={() => handlePitcherChange(p)}
                              className={`px-2 py-1.5 rounded-lg text-xs font-semibold touch-manipulation flex-shrink-0 ${p.id === game.current_pitcher_id ? 'bg-blue-900/30 text-blue-300 cursor-default' : 'bg-blue-700 hover:bg-blue-600 text-white'}`}>
                              {p.id === game.current_pitcher_id ? 'Pitching' : 'Set P'}
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Back button */}
            <div className="flex-shrink-0 p-4 pt-2 border-t border-white/10">
              <button
                onClick={() => { setTeam(null); setSubSlotIdx(null); }}
                className="w-full py-3 rounded-xl bg-white/5 text-white/50 text-sm font-semibold touch-manipulation">
                ← Switch Team
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}