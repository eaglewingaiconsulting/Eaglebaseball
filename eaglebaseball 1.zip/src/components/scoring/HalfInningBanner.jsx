// HalfInningBanner — full-width flash banner when half-inning changes
import { useEffect, useState } from 'react';

const ORDINAL = ['', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'];

export default function HalfInningBanner({ game, homeTeam, awayTeam }) {
  const [visible, setVisible] = useState(false);
  const [bannerText, setBannerText] = useState('');
  const [bannerColor, setBannerColor] = useState('#1e3a8a');
  const [prevHalf, setPrevHalf] = useState(null);
  const [prevInning, setPrevInning] = useState(null);

  useEffect(() => {
    if (!game) return;
    const key = `${game.inning}-${game.inning_half}`;
    const prevKey = prevHalf !== null ? `${prevInning}-${prevHalf}` : null;

    if (prevKey !== null && prevKey !== key) {
      const isTop = game.inning_half === 'top';
      const battingTeam = isTop ? awayTeam : homeTeam;
      const teamName = isTop ? game.away_team_name : game.home_team_name;
      const half = isTop ? 'Top' : 'Bottom';
      const inningLabel = ORDINAL[game.inning] || game.inning;
      setBannerText(`${half} of ${inningLabel} — ${teamName} now batting`);
      setBannerColor(battingTeam?.primary_color || '#FFB81C');
      setVisible(true);
      const t = setTimeout(() => setVisible(false), 2500);
      return () => clearTimeout(t);
    }

    setPrevHalf(game.inning_half);
    setPrevInning(game.inning);
  }, [game?.inning, game?.inning_half]);

  // Init tracking without showing banner
  useEffect(() => {
    if (game && prevHalf === null) {
      setPrevHalf(game.inning_half);
      setPrevInning(game.inning);
    }
  }, [game]);

  if (!visible) return null;

  return (
    <div
      className="fixed top-0 left-0 right-0 z-[100] flex items-center justify-center py-5 text-white font-bold text-xl shadow-2xl transition-all"
      style={{ backgroundColor: bannerColor }}>
      {bannerText}
    </div>
  );
}