import { ArrowLeft, RefreshCw, RotateCcw, Users } from 'lucide-react';

export default function ScoringHeader({ game, homeTeam, awayTeam, onBack, onRefresh, updating, onUndo, canUndo, onRoster }) {
  if (!game) return null;
  const isTop = game.inning_half === 'top';
  const triangle = isTop ? '▲' : '▼';
  const awayBatting = isTop;

  const balls = game.balls ?? 0;
  const strikes = game.strikes ?? 0;
  const outs = game.outs ?? 0;

  const awayName = game.away_team_name?.split(' ').slice(-1)[0] || 'Away';
  const homeName = game.home_team_name?.split(' ').slice(-1)[0] || 'Home';

  return (
    <div className="flex-shrink-0" style={{ background: 'linear-gradient(180deg, #050d1a 0%, #0a1628 100%)', borderBottom: '1px solid rgba(255,184,28,0.15)' }}>
      {/* Score row */}
      <div className="flex items-center px-2 pt-2 pb-1 gap-1 text-white">
        <button onClick={onBack} className="p-2 rounded-xl hover:bg-white/10 active:bg-white/20 select-none touch-manipulation flex-shrink-0">
          <ArrowLeft className="w-4 h-4 text-white/70" />
        </button>

        {/* Away */}
        <div className={`flex-1 flex flex-col items-center transition-opacity ${awayBatting ? 'opacity-100' : 'opacity-40'}`}>
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/50 mb-0.5">{awayName}</span>
          <span className="font-bebas text-4xl leading-none" style={{ color: awayBatting ? '#FFB81C' : 'white' }}>
            {game.away_score ?? 0}
          </span>
          {awayBatting && <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse mt-0.5" />}
        </div>

        {/* Center inning */}
        <div className="flex flex-col items-center px-3 flex-shrink-0">
          <div className="font-bebas text-xl leading-none" style={{ color: '#FFB81C' }}>
            {triangle} {game.inning}
          </div>
          <div className="text-[9px] uppercase tracking-widest text-white/30 mt-0.5">inning</div>
        </div>

        {/* Home */}
        <div className={`flex-1 flex flex-col items-center transition-opacity ${!awayBatting ? 'opacity-100' : 'opacity-40'}`}>
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/50 mb-0.5">{homeName}</span>
          <span className="font-bebas text-4xl leading-none" style={{ color: !awayBatting ? '#FFB81C' : 'white' }}>
            {game.home_score ?? 0}
          </span>
          {!awayBatting && <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse mt-0.5" />}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-1 flex-shrink-0">
          <button onClick={onUndo} disabled={!canUndo}
            className="p-2 rounded-xl select-none touch-manipulation transition-all"
            style={{ backgroundColor: canUndo ? 'rgba(255,184,28,0.15)' : 'rgba(255,255,255,0.05)', opacity: canUndo ? 1 : 0.4 }}>
            <RotateCcw className="w-3.5 h-3.5" style={{ color: canUndo ? '#FFB81C' : 'rgba(255,255,255,0.3)' }} />
          </button>
          <button onClick={onRoster} className="p-2 rounded-xl hover:bg-white/10 select-none touch-manipulation">
            <Users className="w-3.5 h-3.5 text-white/60" />
          </button>
          <button onClick={onRefresh} className="p-2 rounded-xl hover:bg-white/10 select-none touch-manipulation">
            <RefreshCw className={`w-3.5 h-3.5 text-white/40 ${updating ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* BSO bar */}
      <div className="flex items-center justify-center gap-5 px-4 py-2" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        {[
          { label: 'B', count: balls, max: 4, activeColor: '#4ade80', activeBg: 'rgba(74,222,128,0.15)' },
          { label: 'S', count: strikes, max: 3, activeColor: '#facc15', activeBg: 'rgba(250,204,21,0.15)' },
          { label: 'O', count: outs, max: 3, activeColor: '#f87171', activeBg: 'rgba(248,113,113,0.15)' },
        ].map(({ label, count, max, activeColor, activeBg }) => (
          <div key={label} className="flex items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-widest w-3" style={{ color: 'rgba(255,255,255,0.3)' }}>{label}</span>
            <div className="flex gap-1.5">
              {Array.from({ length: max }).map((_, i) => (
                <div key={i} className="w-4 h-4 rounded-full border-2 transition-all duration-200"
                  style={i < count
                    ? { backgroundColor: activeColor, borderColor: activeColor, boxShadow: `0 0 8px ${activeColor}80` }
                    : { backgroundColor: 'transparent', borderColor: 'rgba(255,255,255,0.15)' }
                  } />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Batting indicator strip */}
      <div className="h-0.5 w-full" style={{ background: `linear-gradient(90deg, transparent, ${awayBatting ? (awayTeam?.primary_color || '#FFB81C') : (homeTeam?.primary_color || '#FFB81C')}, transparent)` }} />
    </div>
  );
}