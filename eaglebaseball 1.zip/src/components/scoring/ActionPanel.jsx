import { useState } from 'react';
import HitZonePicker from '@/components/scoring/HitZonePicker';
import FielderSelectModal from '@/components/scoring/FielderSelectModal';
import RunnerAdvancementModal from '@/components/scoring/RunnerAdvancementModal';
import LineupChangeSheet from '@/components/scoring/LineupChangeSheet';
import { ChevronLeft } from 'lucide-react';

// Shared button styles
const btn = (bg, border, color, extra = '') =>
  `w-full font-bold select-none touch-manipulation active:scale-[0.97] transition-all rounded-2xl ${extra}`;

const GHOST_BTN = { backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.55)' };

// ── STEP 1: Pitch Type ───────────────────────────────────────────────────────
function PitchTypeStep({ onSelect }) {
  const [showOther, setShowOther] = useState(false);
  const primary = ['Fastball', 'Breaking Ball', 'Change Up'];
  const other = ['Intentional Ball', 'Pitchout', 'Unknown'];

  return (
    <div className="space-y-2.5">
      <div className="text-[10px] font-black uppercase tracking-widest text-center pb-1" style={{ color: 'rgba(255,255,255,0.25)' }}>
        Select Pitch Type
      </div>
      {primary.map(pt => (
        <button key={pt} onClick={() => onSelect(pt)}
          className="w-full py-5 rounded-2xl font-bold text-base select-none touch-manipulation active:scale-[0.97] transition-all text-white"
          style={{ background: 'linear-gradient(135deg, rgba(99,102,241,0.3), rgba(59,130,246,0.2))', border: '1px solid rgba(99,102,241,0.4)' }}>
          {pt}
        </button>
      ))}
      {!showOther ? (
        <button onClick={() => setShowOther(true)}
          className="w-full py-3 rounded-2xl text-sm font-semibold select-none touch-manipulation"
          style={GHOST_BTN}>
          Other…
        </button>
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {other.map(pt => (
            <button key={pt} onClick={() => onSelect(pt)}
              className="py-3 rounded-xl text-xs font-semibold select-none touch-manipulation active:scale-95"
              style={GHOST_BTN}>
              {pt}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ── STEP 2: Outcome ──────────────────────────────────────────────────────────
function OutcomeStep({ pitchType, game, onAction, onBack, onPendingOut, onPassedBallOrWildPitch }) {
  const [showSecondary, setShowSecondary] = useState(false);

  return (
    <div className="space-y-2.5">
      {/* Back + pitch chip */}
      <div className="flex items-center gap-2 mb-1">
        <button onClick={onBack} className="p-2 rounded-xl select-none touch-manipulation active:scale-95"
          style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}>
          <ChevronLeft className="w-4 h-4 text-white/60" />
        </button>
        <div className="flex-1 text-center">
          <span className="text-xs font-bold px-3 py-1.5 rounded-full"
            style={{ background: 'rgba(99,102,241,0.2)', color: '#a5b4fc', border: '1px solid rgba(99,102,241,0.4)' }}>
            ⚾ {pitchType}
          </span>
        </div>
      </div>

      {/* Strike / Ball / Foul */}
      <div className="grid grid-cols-2 gap-2">
        <button onClick={() => onAction({ type: 'strike' })}
          className="py-5 rounded-2xl font-bold text-base select-none touch-manipulation active:scale-[0.97] transition-all text-white"
          style={{ background: 'linear-gradient(135deg, #7f1d1d, #991b1b)', border: '1px solid rgba(248,113,113,0.3)' }}>
          Strike<br /><span className="text-xs font-normal opacity-70">Swinging</span>
        </button>
        <button onClick={() => onAction({ type: 'strike', called: true })}
          className="py-5 rounded-2xl font-bold text-base select-none touch-manipulation active:scale-[0.97] transition-all text-white"
          style={{ background: 'linear-gradient(135deg, #7c2d12, #9a3412)', border: '1px solid rgba(251,146,60,0.3)' }}>
          Strike<br /><span className="text-xs font-normal opacity-70">Looking</span>
        </button>
        <button onClick={() => onAction({ type: 'ball' })}
          className="py-5 rounded-2xl font-bold text-base select-none touch-manipulation active:scale-[0.97] transition-all text-white"
          style={{ background: 'linear-gradient(135deg, #14532d, #166534)', border: '1px solid rgba(74,222,128,0.3)' }}>
          Ball
        </button>
        <button onClick={() => onAction({ type: 'foul' })}
          className="py-5 rounded-2xl font-bold text-base select-none touch-manipulation active:scale-[0.97] transition-all text-white"
          style={{ background: 'linear-gradient(135deg, #78350f, #92400e)', border: '1px solid rgba(251,191,36,0.3)' }}>
          Foul Ball
        </button>
      </div>

      {/* In Play — hero button */}
      <button onClick={() => onAction({ type: '_in_play' })}
        className="w-full py-5 rounded-2xl font-black text-xl select-none touch-manipulation active:scale-[0.97] transition-all"
        style={{ background: 'linear-gradient(135deg, #b45309, #d97706)', border: '2px solid rgba(245,158,11,0.6)', color: '#0B1120', boxShadow: '0 0 20px rgba(245,158,11,0.25)' }}>
        🏏 In Play
      </button>

      {/* More outcomes */}
      <button onClick={() => setShowSecondary(v => !v)}
        className="w-full py-2 text-xs font-semibold select-none touch-manipulation"
        style={{ color: 'rgba(255,255,255,0.3)' }}>
        {showSecondary ? '▲' : '▼'} More outcomes
      </button>
      {showSecondary && (
        <div className="grid grid-cols-2 gap-2">
          {[
            { label: 'Hit By Pitch', action: () => onAction({ type: 'hit', hit_type: 'hit_by_pitch' }) },
            { label: 'Int. Walk', action: () => onAction({ type: 'walk' }) },
            { label: 'Wild Pitch', action: () => onPassedBallOrWildPitch('wild_pitch') },
            { label: 'Passed Ball', action: () => onPassedBallOrWildPitch('passed_ball') },
            { label: 'Balk', action: () => onAction({ type: 'misc', event: 'balk' }) },
            { label: 'Stolen Base', action: () => onAction({ type: 'misc', event: 'stolen_base' }) },
          ].map(item => (
            <button key={item.label} onClick={item.action}
              className="py-3 rounded-xl text-xs font-semibold select-none touch-manipulation active:scale-95"
              style={GHOST_BTN}>
              {item.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ── STEP 3: In Play ──────────────────────────────────────────────────────────
function InPlayStep({ pitchType, game, players, onAction, onBack, onPendingHit, onPendingOut }) {
  return (
    <div className="space-y-2.5">
      <div className="flex items-center gap-2 mb-1">
        <button onClick={onBack} className="p-2 rounded-xl select-none touch-manipulation active:scale-95"
          style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}>
          <ChevronLeft className="w-4 h-4 text-white/60" />
        </button>
        <div className="flex-1 text-center">
          <span className="text-xs font-bold px-3 py-1.5 rounded-full"
            style={{ background: 'rgba(99,102,241,0.2)', color: '#a5b4fc', border: '1px solid rgba(99,102,241,0.4)' }}>
            ⚾ {pitchType} · In Play
          </span>
        </div>
      </div>

      {/* Hits grid */}
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: '1B · Single', hit: 'single', bg: 'linear-gradient(135deg, #064e3b, #065f46)', border: 'rgba(52,211,153,0.35)' },
          { label: '2B · Double', hit: 'double', bg: 'linear-gradient(135deg, #1e3a8a, #1d4ed8)', border: 'rgba(96,165,250,0.35)' },
          { label: '3B · Triple', hit: 'triple', bg: 'linear-gradient(135deg, #4c1d95, #6d28d9)', border: 'rgba(167,139,250,0.35)' },
          { label: '🚀 Home Run', hit: 'home_run', bg: 'linear-gradient(135deg, #92400e, #d97706)', border: 'rgba(251,191,36,0.5)', textColor: '#0B1120' },
        ].map(({ label, hit, bg, border, textColor }) => (
          <button key={hit} onClick={() => onPendingHit({ type: 'hit', hit_type: hit })}
            className="py-6 rounded-2xl font-bold text-base select-none touch-manipulation active:scale-[0.97] transition-all"
            style={{ background: bg, border: `1px solid ${border}`, color: textColor || 'white' }}>
            {label}
          </button>
        ))}
      </div>

      {/* Out */}
      <button onClick={() => onPendingOut({ description: 'Ground out', isDoublePlay: false })}
        className="w-full py-5 rounded-2xl font-bold text-base select-none touch-manipulation active:scale-[0.97] transition-all text-white"
        style={{ background: 'linear-gradient(135deg, #1e293b, #334155)', border: '1px solid rgba(148,163,184,0.25)' }}>
        Out (Ground / Fly / Line)
      </button>

      <div className="grid grid-cols-2 gap-2">
        {[
          { label: 'Fly Out', desc: 'Fly out' },
          { label: 'Line Out', desc: 'Line drive out' },
          { label: 'Sac Fly', desc: 'Sacrifice fly' },
          { label: 'Sac Bunt', desc: 'Sacrifice bunt' },
          { label: "Fielder's Choice", desc: "Fielder's choice" },
          { label: 'Double Play', desc: 'double_play', isDoublePlay: true },
        ].map(item => (
          <button key={item.label} onClick={() => onPendingOut({ description: item.desc, isDoublePlay: !!item.isDoublePlay })}
            className="py-3 rounded-xl text-xs font-semibold select-none touch-manipulation active:scale-95"
            style={GHOST_BTN}>
            {item.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-2 pt-1">
        <button onClick={() => onAction({ type: 'run' })}
          className="py-4 rounded-2xl font-bold text-sm select-none touch-manipulation active:scale-[0.97] text-white"
          style={{ background: 'linear-gradient(135deg, #14532d, #166534)', border: '1px solid rgba(74,222,128,0.3)' }}>
          ✅ Run Scores
        </button>
        <button onClick={() => onAction({ type: 'error' })}
          className="py-4 rounded-2xl font-bold text-sm select-none touch-manipulation active:scale-[0.97] text-white"
          style={{ background: 'linear-gradient(135deg, #7f1d1d, #991b1b)', border: '1px solid rgba(248,113,113,0.3)' }}>
          ⚠️ Error
        </button>
      </div>
    </div>
  );
}

// ── Misc Tab ─────────────────────────────────────────────────────────────────
function MiscTab({ game, onAction, onPassedBallOrWildPitch, onLineupChange }) {
  return (
    <div className="space-y-2.5">
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: '🏃 Stolen Base', action: () => onAction({ type: 'misc', event: 'stolen_base' }), accent: 'rgba(99,102,241,0.25)', border: 'rgba(99,102,241,0.4)' },
          { label: 'Passed Ball', action: () => onPassedBallOrWildPitch('passed_ball'), accent: 'rgba(255,255,255,0.06)', border: 'rgba(255,255,255,0.12)' },
          { label: 'Balk', action: () => onAction({ type: 'misc', event: 'balk' }), accent: 'rgba(255,255,255,0.06)', border: 'rgba(255,255,255,0.12)' },
          { label: 'Mound Visit', action: () => onAction({ type: 'misc', event: 'mound_visit' }), accent: 'rgba(255,255,255,0.06)', border: 'rgba(255,255,255,0.12)' },
          { label: '🎯 Pickoff', action: () => onAction({ type: 'pickoff' }), accent: 'rgba(139,92,246,0.25)', border: 'rgba(139,92,246,0.4)' },
          { label: 'Walk (BB)', action: () => onAction({ type: 'walk' }), accent: 'rgba(20,83,45,0.5)', border: 'rgba(74,222,128,0.3)' },
        ].map(item => (
          <button key={item.label} onClick={item.action}
            className="py-5 rounded-2xl font-semibold text-sm select-none touch-manipulation active:scale-[0.97] transition-all text-white"
            style={{ backgroundColor: item.accent, border: `1px solid ${item.border}` }}>
            {item.label}
          </button>
        ))}
      </div>
      <div className="space-y-2 pt-1" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <button onClick={onLineupChange}
          className="w-full py-4 rounded-2xl font-bold text-sm select-none touch-manipulation active:scale-[0.97] transition-all text-white"
          style={{ background: 'linear-gradient(135deg, rgba(109,40,217,0.4), rgba(139,92,246,0.3))', border: '1px solid rgba(139,92,246,0.4)' }}>
          📋 Lineup Change
        </button>
        <button onClick={() => onAction({ type: 'end_game' })}
          className="w-full py-4 rounded-2xl font-bold text-sm select-none touch-manipulation active:scale-[0.97] transition-all text-white"
          style={{ background: 'linear-gradient(135deg, #450a0a, #7f1d1d)', border: '1px solid rgba(248,113,113,0.35)' }}>
          🏁 End Game
        </button>
      </div>
    </div>
  );
}

// ── Main ActionPanel ─────────────────────────────────────────────────────────
export default function ActionPanel({ game, players = [], onAction, onGameUpdate, updating, isTablet = false }) {
  const [flowStep, setFlowStep] = useState('type');
  const [selectedPitchType, setSelectedPitchType] = useState(null);
  const [pendingHit, setPendingHit] = useState(null);
  const [pendingOut, setPendingOut] = useState(null);
  const [pendingAdvancement, setPendingAdvancement] = useState(null);
  const [activeSection, setActiveSection] = useState('pitch');
  const [showLineupSheet, setShowLineupSheet] = useState(false);

  const hasRunners = game.runner_first || game.runner_second || game.runner_third;

  const handleFielderConfirm = ({ fielder1, fielder2, fielder3, sequence }) => {
    const action = { type: 'out', description: pendingOut.description, fielder1, fielder2, fielder3: fielder3 || null, sequence: sequence || fielder1 };
    setPendingOut(null);
    fireAction(action);
  };

  const handlePassedBallOrWildPitch = (type) => {
    if (!hasRunners) { fireAction({ type }); return; }
    const label = type === 'wild_pitch' ? 'Wild Pitch' : 'Passed Ball';
    setPendingAdvancement({ eventLabel: label, originalAction: { type } });
  };

  const handleAdvancementConfirm = (selections) => {
    const { originalAction } = pendingAdvancement;
    setPendingAdvancement(null);
    fireAction({ ...originalAction, runnerAdvancements: selections });
  };

  const fireAction = (action) => {
    const enriched = selectedPitchType ? { ...action, pitch_type: selectedPitchType } : action;
    onAction(enriched);
    if (!['end_game', 'pickoff'].includes(action.type) && action.type !== '_in_play') {
      setFlowStep('type');
      setSelectedPitchType(null);
    }
  };

  const handlePitchTypeSelect = (pt) => { setSelectedPitchType(pt); setFlowStep('outcome'); };
  const handleOutcomeAction = (action) => {
    if (action.type === '_in_play') { setFlowStep('inplay'); return; }
    fireAction(action);
  };

  return (
    <div className={`rounded-2xl overflow-hidden ${isTablet ? 'h-full flex flex-col' : ''}`}
      style={{ backgroundColor: '#060e1d', border: '1px solid rgba(255,184,28,0.12)' }}>

      {/* Tabs */}
      <div className="flex p-1.5 gap-1.5 flex-shrink-0" style={{ backgroundColor: 'rgba(0,0,0,0.3)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        {[{ id: 'pitch', label: '⚾ Pitch' }, { id: 'misc', label: '⚙️ Misc' }].map(s => (
          <button key={s.id} onClick={() => setActiveSection(s.id)}
            className="flex-1 py-2.5 rounded-xl font-bold text-sm select-none touch-manipulation transition-all"
            style={activeSection === s.id
              ? { backgroundColor: '#FFB81C', color: '#0B1120' }
              : { backgroundColor: 'transparent', color: 'rgba(255,255,255,0.4)' }}>
            {s.label}
          </button>
        ))}
      </div>

      <div className={`p-4 ${isTablet ? 'flex-1 overflow-y-auto' : ''}`}>
        {activeSection === 'pitch' && (
          <>
            {flowStep === 'type' && <PitchTypeStep onSelect={handlePitchTypeSelect} />}
            {flowStep === 'outcome' && (
              <OutcomeStep pitchType={selectedPitchType} game={game}
                onAction={handleOutcomeAction}
                onBack={() => { setFlowStep('type'); setSelectedPitchType(null); }}
                onPendingOut={(d, dp) => setPendingOut({ description: d, isDoublePlay: !!dp })}
                onPassedBallOrWildPitch={handlePassedBallOrWildPitch}
              />
            )}
            {flowStep === 'inplay' && (
              <InPlayStep pitchType={selectedPitchType} game={game} players={players}
                onAction={fireAction} onBack={() => setFlowStep('outcome')}
                onPendingHit={setPendingHit}
                onPendingOut={setPendingOut}
              />
            )}
            {pendingHit && (
              <HitZonePicker hitType={pendingHit.hit_type}
                onConfirm={(hitZone) => { fireAction({ ...pendingHit, hitZone }); setPendingHit(null); }}
                onCancel={() => setPendingHit(null)} />
            )}
          </>
        )}
        {activeSection === 'misc' && (
          <MiscTab game={game} onAction={fireAction}
            onPassedBallOrWildPitch={handlePassedBallOrWildPitch}
            onLineupChange={() => setShowLineupSheet(true)} />
        )}
      </div>

      {pendingOut && (
        <FielderSelectModal game={game} players={players} isDoublePlay={pendingOut.isDoublePlay}
          onConfirm={handleFielderConfirm} onClose={() => setPendingOut(null)} />
      )}
      {pendingAdvancement && (
        <RunnerAdvancementModal game={game} players={players} eventLabel={pendingAdvancement.eventLabel}
          onConfirm={handleAdvancementConfirm} onClose={() => setPendingAdvancement(null)} />
      )}
      {showLineupSheet && (
        <LineupChangeSheet game={game} players={players}
          onClose={() => setShowLineupSheet(false)}
          onGameUpdate={(updates) => { if (onGameUpdate) onGameUpdate(updates); setShowLineupSheet(false); }} />
      )}
    </div>
  );
}