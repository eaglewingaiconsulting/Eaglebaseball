/**
 * LineupGate — blocks scoring until both lineups are confirmed.
 *
 * PANEL ASSIGNMENT: Based on team_id, NOT home/away position.
 *   "Your Team"  = home_team_id (the team the scoring admin manages)
 *   "Opponent"   = away_team_id
 * Both panels have "Import from Photo" + manual entry options.
 */
import { useState } from 'react';
import { X, Check, ChevronRight, Camera, Users, BookOpen } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import OpponentLineupImporter from '@/components/scoring/OpponentLineupImporter';

// ── Saved Lineup Picker ───────────────────────────────────────────────────────
function SavedLineupPicker({ templates, players, onSelect, onClose }) {
  return (
    <div className="fixed inset-0 z-[70] flex flex-col justify-end bg-black/70" onClick={onClose}>
      <div className="bg-[hsl(214,90%,9%)] border-t border-white/20 rounded-t-2xl flex flex-col" style={{ maxHeight: '85dvh' }}
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-white/10 flex-shrink-0">
          <span className="font-bold text-white text-base">Saved Lineups</span>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 touch-manipulation">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>
        <div className="overflow-y-auto flex-1 p-3 space-y-2">
          {templates.length === 0 && (
            <div className="text-white/40 text-sm text-center py-8">No saved lineups — create one in the Lineups tab</div>
          )}
          {templates.map(t => {
            const order = t.batting_order || [];
            return (
              <button key={t.id}
                onClick={() => onSelect(t)}
                className="w-full text-left p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 touch-manipulation">
                <div className="font-bold text-white text-sm mb-1">{t.name}</div>
                <div className="text-white/40 text-xs">{order.length} players</div>
                <div className="text-white/30 text-xs mt-0.5 truncate">
                  {order.slice(0, 5).map(e => e.name || e.player_id).join(', ')}{order.length > 5 ? '…' : ''}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── Manual Lineup Builder ─────────────────────────────────────────────────────
function ManualLineupBuilder({ players, existingLineup, onConfirm, onClose }) {
  const [lineup, setLineup] = useState(existingLineup || []);

  const toggle = (id) => {
    setLineup(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const moveUp = (idx) => {
    if (idx === 0) return;
    const n = [...lineup];
    [n[idx - 1], n[idx]] = [n[idx], n[idx - 1]];
    setLineup(n);
  };

  const moveDown = (idx) => {
    if (idx === lineup.length - 1) return;
    const n = [...lineup];
    [n[idx], n[idx + 1]] = [n[idx + 1], n[idx]];
    setLineup(n);
  };

  const ordered = lineup.map(id => players.find(p => p.id === id)).filter(Boolean);
  const bench = players.filter(p => !lineup.includes(p.id));

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-[hsl(214,90%,9%)]">
      <div className="flex flex-col h-full" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-white/10 flex-shrink-0">
          <span className="font-bold text-white text-base">Set Lineup ({lineup.length} selected)</span>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 touch-manipulation">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {ordered.length > 0 && (
            <div>
              <div className="text-white/40 text-xs uppercase tracking-wide font-semibold mb-2">Batting Order</div>
              <div className="space-y-1.5">
                {ordered.map((p, idx) => (
                  <div key={p.id} className="flex items-center gap-2 p-2.5 rounded-xl bg-white/10 border border-white/10">
                    <span className="text-xs font-bold text-white/50 w-5 text-center">{idx + 1}</span>
                    <span className="text-sm font-bold text-[#FFB81C] w-7">#{p.number}</span>
                    <span className="text-sm text-white flex-1 truncate">{p.name}</span>
                    <span className="text-xs text-white/30">{p.position}</span>
                    <button onClick={() => moveUp(idx)} className="px-1.5 py-1 text-xs text-white/40 hover:text-white touch-manipulation">▲</button>
                    <button onClick={() => moveDown(idx)} className="px-1.5 py-1 text-xs text-white/40 hover:text-white touch-manipulation">▼</button>
                    <button onClick={() => toggle(p.id)} className="px-1.5 py-1 text-xs text-red-400 touch-manipulation">✕</button>
                  </div>
                ))}
              </div>
            </div>
          )}
          {bench.length > 0 && (
            <div>
              <div className="text-white/40 text-xs uppercase tracking-wide font-semibold mb-2">Tap to Add</div>
              <div className="space-y-1.5">
                {bench.map(p => (
                  <button key={p.id} onClick={() => toggle(p.id)}
                    className="w-full flex items-center gap-2 p-2.5 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 touch-manipulation">
                    <span className="text-sm font-bold text-white/50 w-7">#{p.number}</span>
                    <span className="text-sm text-white flex-1 truncate">{p.name}</span>
                    <span className="text-xs text-white/30">{p.position}</span>
                    <span className="text-green-400 text-sm">+</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className="p-3 border-t border-white/10 flex-shrink-0" style={{ paddingBottom: 'max(12px, env(safe-area-inset-bottom))' }}>
          <button
            disabled={lineup.length === 0}
            onClick={() => onConfirm(lineup)}
            className="w-full py-3.5 rounded-xl font-bold text-sm disabled:opacity-40 touch-manipulation"
            style={{ backgroundColor: '#FFB81C', color: '#002D62' }}>
            Confirm Lineup ({lineup.length} players)
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Opponent Manual Entry ─────────────────────────────────────────────────────
function OpponentManualEntry({ onConfirm, onClose }) {
  const [rows, setRows] = useState(
    Array.from({ length: 9 }, (_, i) => ({ batting_position: i + 1, player_name: '', jersey_number: '' }))
  );

  const update = (idx, field, val) => {
    setRows(prev => prev.map((r, i) => i === idx ? { ...r, [field]: val } : r));
  };

  const handleConfirm = () => {
    const filled = rows.filter(r => r.player_name.trim());
    if (!filled.length) return;
    onConfirm(filled);
  };

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-[hsl(214,90%,9%)]" onClick={onClose}>
      <div className="flex flex-col h-full" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-white/10 flex-shrink-0">
          <span className="font-bold text-white text-base">Opponent Lineup</span>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 touch-manipulation">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1.5">
          <div className="text-white/40 text-xs text-center pb-1">Enter opponent batting order. Leave blank to skip slots.</div>
          {rows.map((row, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <span className="text-white/40 text-xs w-5 text-right flex-shrink-0">{idx + 1}.</span>
              <input
                type="text"
                inputMode="numeric"
                placeholder="#"
                value={row.jersey_number}
                onChange={e => update(idx, 'jersey_number', e.target.value)}
                className="w-12 bg-white/10 border border-white/20 rounded-lg px-2 py-1.5 text-white text-sm text-center focus:outline-none focus:border-[#FFB81C]"
              />
              <input
                type="text"
                placeholder={`Batter ${idx + 1}`}
                value={row.player_name}
                onChange={e => update(idx, 'player_name', e.target.value)}
                className="flex-1 bg-white/10 border border-white/20 rounded-lg px-3 py-1.5 text-white text-sm focus:outline-none focus:border-[#FFB81C] placeholder:text-white/30"
              />
            </div>
          ))}
        </div>
        <div className="p-3 border-t border-white/10 flex-shrink-0" style={{ paddingBottom: 'max(12px, env(safe-area-inset-bottom))' }}>
          <button
            onClick={handleConfirm}
            className="w-full py-3.5 rounded-xl font-bold text-sm touch-manipulation"
            style={{ backgroundColor: '#FFB81C', color: '#002D62' }}>
            Confirm Opponent Lineup
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main LineupGate ───────────────────────────────────────────────────────────
export default function LineupGate({ game, homePlayers, allPlayers, onComplete }) {
  const [saving, setSaving] = useState(false);
  const [yourConfirmed, setYourConfirmed] = useState(!!game.home_lineup_confirmed && (game.home_lineup || []).length > 0);
  const [opponentConfirmed, setOpponentConfirmed] = useState(!!game.opponent_lineup_confirmed && (game.away_lineup || []).length > 0);

  const [showSavedPicker, setShowSavedPicker] = useState(false);
  const [showManualYour, setShowManualYour] = useState(false);
  const [showYourPhoto, setShowYourPhoto] = useState(false);
  const [showOpponentPhoto, setShowOpponentPhoto] = useState(false);
  const [showOpponentManual, setShowOpponentManual] = useState(false);
  const [templates, setTemplates] = useState(null);

  // "Your Team" is always the home_team_id — the team the scoring admin manages.
  const yourTeamId = game.home_team_id;
  const yourTeamName = game.home_team_name;
  const opponentTeamId = game.away_team_id;
  const opponentTeamName = game.away_team_name;
  const yourPlayers = homePlayers; // filtered by home_team_id by parent

  const loadTemplates = async () => {
    if (templates !== null) { setShowSavedPicker(true); return; }
    const tpls = await base44.entities.LineupTemplate.filter({ team_id: yourTeamId });
    setTemplates(tpls || []);
    setShowSavedPicker(true);
  };

  const confirmYourFromTemplate = async (template) => {
    setShowSavedPicker(false);
    setSaving(true);
    const order = (template.batting_order || []).map(e => e.player_id).filter(Boolean);
    await base44.entities.Game.update(game.id, { home_lineup: order, home_lineup_confirmed: true });
    setYourConfirmed(true);
    setSaving(false);
    toast.success(`Lineup loaded: ${template.name}`);
  };

  const confirmYourManual = async (lineupIds) => {
    setShowManualYour(false);
    setSaving(true);
    await base44.entities.Game.update(game.id, { home_lineup: lineupIds, home_lineup_confirmed: true });
    setYourConfirmed(true);
    setSaving(false);
    toast.success('Your lineup confirmed!');
  };

  const confirmYourPhoto = async (lineupIds) => {
    setShowYourPhoto(false);
    setSaving(true);
    await base44.entities.Game.update(game.id, { home_lineup: lineupIds, home_lineup_confirmed: true });
    setYourConfirmed(true);
    setSaving(false);
    toast.success('Your lineup imported from photo!');
  };

  const confirmOpponentPhoto = async (lineupIds) => {
    setShowOpponentPhoto(false);
    setSaving(true);
    await base44.entities.Game.update(game.id, { away_lineup: lineupIds, opponent_lineup_confirmed: true });
    setOpponentConfirmed(true);
    setSaving(false);
    toast.success('Opponent lineup imported!');
  };

  const confirmOpponentManual = async (rows) => {
    setShowOpponentManual(false);
    setSaving(true);
    const ids = [];
    for (const row of rows) {
      if (!row.player_name.trim()) continue;
      const existing = allPlayers.find(p =>
        p.team_id === opponentTeamId &&
        (p.number === row.jersey_number || p.name.toLowerCase() === row.player_name.toLowerCase())
      );
      if (existing) {
        ids.push(existing.id);
      } else {
        const p = await base44.entities.Player.create({
          team_id: opponentTeamId,
          name: row.player_name.trim(),
          number: row.jersey_number || '0',
          position: 'UT',
        });
        ids.push(p.id);
      }
    }
    await base44.entities.Game.update(game.id, { away_lineup: ids, opponent_lineup_confirmed: true });
    setOpponentConfirmed(true);
    setSaving(false);
    toast.success('Opponent lineup confirmed!');
  };

  const handleStartScoring = async () => {
    if (!yourConfirmed || !opponentConfirmed) return;
    // Pre-fill probable pitcher if set and not already assigned
    if (game.probable_pitcher_id && !game.current_pitcher_id) {
      const pitcher = allPlayers.find(p => p.id === game.probable_pitcher_id);
      if (pitcher) {
        await base44.entities.Game.update(game.id, {
          current_pitcher_id: pitcher.id,
          current_pitcher_name: pitcher.name,
          current_pitcher_pitch_count: 0,
        });
        // Create GamePitcher record
        base44.entities.GamePitcher.create({
          game_id: game.id,
          player_id: pitcher.id,
          player_name: pitcher.name,
          team_id: game.home_team_id,
          entry_inning: 1,
          pitch_count: 0,
          is_opponent: false,
        }).catch(() => {});
      }
    }
    onComplete();
  };

  const statusIcon = (confirmed) => confirmed
    ? <span className="text-green-400 text-lg">✓</span>
    : <span className="text-white/20 text-lg">○</span>;

  const btnStyle = { backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' };

  return (
    <div className="fixed inset-0 z-40 bg-[hsl(220,25%,6%)] flex flex-col overflow-y-auto">
      <div className="flex-shrink-0 px-4 pt-6 pb-4">
        <h1 className="font-bold text-white text-2xl mb-1">Set Lineups</h1>
        <p className="text-white/50 text-sm">{yourTeamName} vs {opponentTeamName}</p>
      </div>

      <div className="px-4 space-y-4 pb-6">
        {/* ── YOUR TEAM ── */}
        <div className="rounded-2xl overflow-hidden" style={{ border: yourConfirmed ? '1.5px solid rgba(74,222,128,0.4)' : '1px solid rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.04)' }}>
          <div className="flex items-center gap-3 px-4 py-3.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
            {statusIcon(yourConfirmed)}
            <div className="flex-1">
              <div className="font-bold text-white text-sm">⚾ Your Team — {yourTeamName}</div>
              <div className="text-white/40 text-xs">{yourConfirmed ? `${(game.home_lineup || []).length} players confirmed` : 'Required before scoring'}</div>
            </div>
          </div>
          {!yourConfirmed && (
            <div className="p-3 space-y-2">
              <button onClick={loadTemplates} disabled={saving} className="w-full flex items-center gap-3 p-3 rounded-xl touch-manipulation" style={btnStyle}>
                <BookOpen className="w-4 h-4 text-white/50 flex-shrink-0" />
                <span className="text-sm text-white flex-1 text-left">Use Saved Lineup</span>
                <ChevronRight className="w-4 h-4 text-white/30" />
              </button>
              <button onClick={() => setShowYourPhoto(true)} disabled={saving} className="w-full flex items-center gap-3 p-3 rounded-xl touch-manipulation" style={btnStyle}>
                <Camera className="w-4 h-4 text-white/50 flex-shrink-0" />
                <span className="text-sm text-white flex-1 text-left">Import from Photo</span>
                <ChevronRight className="w-4 h-4 text-white/30" />
              </button>
              <button onClick={() => setShowManualYour(true)} disabled={saving} className="w-full flex items-center gap-3 p-3 rounded-xl touch-manipulation" style={btnStyle}>
                <Users className="w-4 h-4 text-white/50 flex-shrink-0" />
                <span className="text-sm text-white flex-1 text-left">Enter Manually</span>
                <ChevronRight className="w-4 h-4 text-white/30" />
              </button>
            </div>
          )}
          {yourConfirmed && (
            <button onClick={() => setYourConfirmed(false)} className="w-full px-4 py-2 text-xs text-white/30 hover:text-white/60 touch-manipulation text-left">
              ↩ Edit lineup
            </button>
          )}
        </div>

        {/* ── OPPONENT ── */}
        <div className="rounded-2xl overflow-hidden" style={{ border: opponentConfirmed ? '1.5px solid rgba(74,222,128,0.4)' : '1px solid rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.04)' }}>
          <div className="flex items-center gap-3 px-4 py-3.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
            {statusIcon(opponentConfirmed)}
            <div className="flex-1">
              <div className="font-bold text-white text-sm">🆚 Opponent — {opponentTeamName}</div>
              <div className="text-white/40 text-xs">{opponentConfirmed ? `${(game.away_lineup || []).length} players confirmed` : 'Required before scoring'}</div>
            </div>
          </div>
          {!opponentConfirmed && (
            <div className="p-3 space-y-2">
              <button onClick={() => setShowOpponentPhoto(true)} disabled={saving} className="w-full flex items-center gap-3 p-3 rounded-xl touch-manipulation" style={btnStyle}>
                <Camera className="w-4 h-4 text-white/50 flex-shrink-0" />
                <span className="text-sm text-white flex-1 text-left">Import from Photo</span>
                <ChevronRight className="w-4 h-4 text-white/30" />
              </button>
              <button onClick={() => setShowOpponentManual(true)} disabled={saving} className="w-full flex items-center gap-3 p-3 rounded-xl touch-manipulation" style={btnStyle}>
                <Users className="w-4 h-4 text-white/50 flex-shrink-0" />
                <span className="text-sm text-white flex-1 text-left">Enter Manually</span>
                <ChevronRight className="w-4 h-4 text-white/30" />
              </button>
            </div>
          )}
          {opponentConfirmed && (
            <button onClick={() => setOpponentConfirmed(false)} className="w-full px-4 py-2 text-xs text-white/30 hover:text-white/60 touch-manipulation text-left">
              ↩ Edit lineup
            </button>
          )}
        </div>

        <button
          disabled={!yourConfirmed || !opponentConfirmed || saving}
          onClick={handleStartScoring}
          className="w-full py-4 rounded-2xl font-bold text-lg transition-all touch-manipulation disabled:opacity-30"
          style={{ backgroundColor: (yourConfirmed && opponentConfirmed) ? '#FFB81C' : 'rgba(255,255,255,0.1)', color: (yourConfirmed && opponentConfirmed) ? '#002D62' : 'rgba(255,255,255,0.3)' }}>
          {saving ? 'Saving…' : (yourConfirmed && opponentConfirmed) ? '▶ Start Scoring' : 'Set Both Lineups to Continue'}
        </button>

        <div className="flex gap-4 justify-center text-xs text-white/30">
          <span className={yourConfirmed ? 'text-green-400' : ''}>Your lineup {yourConfirmed ? '✓' : '○'}</span>
          <span className={opponentConfirmed ? 'text-green-400' : ''}>Opponent {opponentConfirmed ? '✓' : '○'}</span>
        </div>
      </div>

      {/* Modals */}
      {showSavedPicker && templates !== null && (
        <SavedLineupPicker templates={templates} players={yourPlayers} onSelect={confirmYourFromTemplate} onClose={() => setShowSavedPicker(false)} />
      )}
      {showManualYour && (
        <ManualLineupBuilder players={yourPlayers} existingLineup={game.home_lineup || []} onConfirm={confirmYourManual} onClose={() => setShowManualYour(false)} />
      )}
      {showYourPhoto && (
        <OpponentLineupImporter game={game} opponentTeamId={yourTeamId} isOpponentHome={true} existingPlayers={allPlayers} onConfirm={confirmYourPhoto} onClose={() => setShowYourPhoto(false)} />
      )}
      {showOpponentPhoto && (
        <OpponentLineupImporter game={game} opponentTeamId={opponentTeamId} isOpponentHome={false} existingPlayers={allPlayers} onConfirm={confirmOpponentPhoto} onClose={() => setShowOpponentPhoto(false)} />
      )}
      {showOpponentManual && (
        <OpponentManualEntry onConfirm={confirmOpponentManual} onClose={() => setShowOpponentManual(false)} />
      )}
    </div>
  );
}