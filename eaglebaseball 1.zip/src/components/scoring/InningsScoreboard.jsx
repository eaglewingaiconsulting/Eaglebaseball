// InningsScoreboard — collapsible bottom sheet with line score
import { useEffect, useState } from 'react';
import { X } from 'lucide-react';

export default function InningsScoreboard({ game, onClose }) {
  const totalInnings = Math.max(game.total_innings || 9, game.inning || 1);
  const inningNums = Array.from({ length: totalInnings }, (_, i) => i + 1);
  const innings = game.inning_scores || [];

  const getScore = (team, inning) => {
    // Current live inning — show live score delta
    if (inning === game.inning) {
      const isTop = game.inning_half === 'top';
      if (team === 'away' && isTop) {
        // Currently batting — show live runs this half
        const prev = innings.filter(e => e.inning === inning && e.team === 'away');
        if (prev.length) return prev[prev.length - 1].runs;
        return '…';
      }
      if (team === 'home' && !isTop) {
        const prev = innings.filter(e => e.inning === inning && e.team === 'home');
        if (prev.length) return prev[prev.length - 1].runs;
        return '…';
      }
      // Half not yet played
      if (team === 'away' && !isTop) {
        const entry = innings.find(e => e.inning === inning && e.team === 'away');
        return entry ? entry.runs : '—';
      }
      if (team === 'home' && isTop) return '—';
    }
    // Past innings
    if (inning < game.inning) {
      const entry = innings.find(e => e.inning === inning && e.team === team);
      return entry !== undefined ? entry.runs : '—';
    }
    // Future innings
    return '—';
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={onClose}>
      <div
        className="bg-[hsl(214,90%,9%)] border-t border-white/20 rounded-t-2xl p-4"
        style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 16px)' }}
        onClick={e => e.stopPropagation()}>
        <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-3" />
        <div className="flex items-center justify-between mb-3">
          <span className="text-white font-bold text-base">📊 Innings Scoreboard</span>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 select-none touch-manipulation">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="text-sm min-w-full">
            <thead>
              <tr className="text-white/50 text-xs">
                <th className="text-left pr-3 py-1.5 font-semibold w-20 sticky left-0 bg-[hsl(214,90%,9%)]">Team</th>
                {inningNums.map(i => (
                  <th key={i} className={`px-2 py-1.5 font-semibold text-center w-8 ${i === game.inning ? 'text-[#FFB81C]' : ''}`}>{i}</th>
                ))}
                <th className="px-2 py-1.5 font-bold text-center text-white w-8">R</th>
                <th className="px-2 py-1.5 font-semibold text-center text-white/70 w-8">H</th>
                <th className="px-2 py-1.5 font-semibold text-center text-white/70 w-8">E</th>
              </tr>
            </thead>
            <tbody>
              {[
                { key: 'away', name: game.away_team_name, score: game.away_score, hits: game.away_hits, errors: game.away_errors },
                { key: 'home', name: game.home_team_name, score: game.home_score, hits: game.home_hits, errors: game.home_errors },
              ].map(team => (
                <tr key={team.key} className="border-t border-white/10">
                  <td className="pr-3 py-2 font-semibold text-white truncate max-w-[80px] sticky left-0 bg-[hsl(214,90%,9%)] text-xs">
                    {(team.name || '').split(' ').slice(-1)[0]}
                  </td>
                  {inningNums.map(i => {
                    const val = getScore(team.key, i);
                    const isCurrentInning = i === game.inning;
                    return (
                      <td key={i} className={`px-2 py-2 text-center font-mono ${
                        val === '—' ? 'text-white/20' :
                        val === '…' ? 'text-[#FFB81C] animate-pulse' :
                        isCurrentInning ? 'text-[#FFB81C] font-bold' :
                        'text-white/80'
                      }`}>
                        {val}
                      </td>
                    );
                  })}
                  <td className="px-2 py-2 text-center font-bold text-white">{team.score ?? 0}</td>
                  <td className="px-2 py-2 text-center text-white/70">{team.hits ?? 0}</td>
                  <td className="px-2 py-2 text-center text-white/70">{team.errors ?? 0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}