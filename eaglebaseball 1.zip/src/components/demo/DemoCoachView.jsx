/**
 * DemoCoachView — Coach/Admin perspective using real live data.
 * Shows first team the user coaches (or any team), real games, players, store.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { Calendar, Users, Trophy, BarChart3, ShoppingBag, Play, Clock, Plus, Loader2 } from 'lucide-react';

export default function DemoCoachView() {
  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [games, setGames] = useState([]);
  const [storeItems, setStoreItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    (async () => {
      const teams = await base44.entities.Team.list('-created_date', 1);
      const t = teams[0];
      if (!t) { setLoading(false); return; }
      setTeam(t);
      const [ps, gs, si] = await Promise.all([
        base44.entities.Player.filter({ team_id: t.id }),
        base44.entities.Game.filter({ home_team_id: t.id }),
        base44.entities.StoreItem.filter({ team_id: t.id, status: 'active' }),
      ]);
      setPlayers(ps);
      setGames(gs.sort((a, b) => new Date(b.scheduled_date) - new Date(a.scheduled_date)));
      setStoreItems(si);
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  if (!team) return <div className="p-8 text-center text-muted-foreground text-sm">No team data available yet.</div>;

  const completed = games.filter(g => g.status === 'completed' || g.status === 'final');
  const upcoming = games.filter(g => g.status === 'scheduled');
  const liveGame = games.find(g => g.status === 'in_progress');
  const wins = completed.filter(g => (g.home_team_id === team.id ? g.home_score > g.away_score : g.away_score > g.home_score)).length;
  const losses = completed.length - wins;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'roster',   label: 'Roster',   icon: Users },
    { id: 'games',    label: 'Games',    icon: Calendar },
    { id: 'store',    label: 'Store',    icon: ShoppingBag },
  ];

  return (
    <div className="pb-28 lg:pb-8">
      {/* Hero */}
      <div className="relative overflow-hidden px-5 py-6 text-white"
        style={{ background: `linear-gradient(135deg, ${team.primary_color || '#1e3a8a'} 0%, ${team.secondary_color || '#1e40af'} 100%)` }}>
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 80% 50%, rgba(255,255,255,0.3), transparent 60%)' }} />
        <div className="relative flex items-center gap-3 mb-3">
          {team.logo_url
            ? <img src={team.logo_url} alt={team.name} className="w-12 h-12 rounded-xl object-contain bg-white/20" />
            : <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-sm bg-white/20">{team.name.slice(0,2).toUpperCase()}</div>}
          <div>
            <h1 className="font-bebas text-2xl tracking-wider leading-none" style={{ color: team.secondary_color || '#F59E0B' }}>{team.name}</h1>
            <p className="text-white/60 text-xs mt-0.5">{[team.city, team.league, team.season].filter(Boolean).join(' · ')}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-white/80 font-semibold">{wins}W – {losses}L</span>
          <span className="text-white/30">·</span>
          <span className="text-white/60 text-sm">Coach View</span>
        </div>
      </div>

      {/* Live game banner */}
      {liveGame && (
        <Link to={`/games/${liveGame.id}/score`} className="mx-4 mt-4 flex items-center justify-between bg-green-950 border border-green-500/40 rounded-xl p-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-green-400 text-xs font-semibold uppercase tracking-wider">Live Now</span>
            </div>
            <div className="text-white font-semibold">{liveGame.away_team_name} @ {liveGame.home_team_name}</div>
            <div className="text-white/60 text-xs mt-0.5">Inn. {liveGame.inning} {liveGame.inning_half === 'bottom' ? '▼' : '▲'} · {liveGame.outs} outs</div>
          </div>
          <div className="text-right">
            <div className="font-bebas text-4xl text-green-400 tracking-wider">{liveGame.away_score}–{liveGame.home_score}</div>
            <div className="text-xs text-green-400/70 flex items-center gap-1 justify-end mt-0.5"><Play className="w-3 h-3" /> Score Live</div>
          </div>
        </Link>
      )}

      {/* Tabs */}
      <div className="flex gap-1 px-4 mt-4 overflow-x-auto">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${activeTab === t.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-muted'}`}>
            <t.icon className="w-3.5 h-3.5" />{t.label}
          </button>
        ))}
      </div>

      <div className="px-4 mt-4 space-y-4">
        {activeTab === 'overview' && (
          <>
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: 'Players', value: players.length,    icon: Users,    color: 'text-blue-500' },
                { label: 'Games',   value: games.length,      icon: Calendar, color: 'text-purple-500' },
                { label: 'Wins',    value: wins,              icon: Trophy,   color: 'text-amber-500' },
                { label: 'Store',   value: storeItems.length, icon: ShoppingBag, color: 'text-green-500' },
              ].map(s => (
                <div key={s.label} className="bg-card border border-border rounded-xl p-3 text-center">
                  <s.icon className={`w-4 h-4 mx-auto mb-1 ${s.color}`} />
                  <div className="text-lg font-bold leading-none">{s.value}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>
            {upcoming[0] && (
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-sm flex items-center gap-1.5 text-muted-foreground uppercase tracking-wider"><Clock className="w-4 h-4" /> Next Game</h3>
                </div>
                <div className="font-semibold">{upcoming[0].away_team_name} @ {upcoming[0].home_team_name}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{upcoming[0].scheduled_date}{upcoming[0].scheduled_time ? ` · ${upcoming[0].scheduled_time}` : ''}{upcoming[0].location ? ` · ${upcoming[0].location}` : ''}</div>
                <div className="flex gap-2 mt-3">
                  <Link to={`/games/${upcoming[0].id}/lineup`} className="text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg font-medium">Set Lineup</Link>
                  <Link to={`/games/${upcoming[0].id}/score`} className="text-xs bg-secondary text-secondary-foreground px-3 py-1.5 rounded-lg font-medium">Score Game</Link>
                </div>
              </div>
            )}
            {completed.length > 0 && (
              <div>
                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5"><Trophy className="w-4 h-4 text-amber-500" /> Recent Results</h3>
                <div className="space-y-2">
                  {completed.slice(0, 3).map(g => {
                    const isHome = g.home_team_id === team.id;
                    const ourScore = isHome ? g.home_score : g.away_score;
                    const oppScore = isHome ? g.away_score : g.home_score;
                    const won = ourScore > oppScore;
                    return (
                      <Link key={g.id} to={`/games/${g.id}`} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between block">
                        <div>
                          <div className="text-sm font-semibold">vs {isHome ? g.away_team_name : g.home_team_name}</div>
                          <div className="text-xs text-muted-foreground">{g.scheduled_date} · {isHome ? 'HOME' : 'AWAY'}</div>
                        </div>
                        <div className={`font-bebas text-xl tracking-wider ${won ? 'text-green-600' : 'text-red-500'}`}>{won ? 'W' : 'L'} {ourScore}–{oppScore}</div>
                      </Link>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}

        {activeTab === 'roster' && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">{players.length} Players</h3>
              <Link to={`/teams/${team.id}`} className="flex items-center gap-1 text-xs text-primary font-medium"><Plus className="w-3.5 h-3.5" /> Manage</Link>
            </div>
            <div className="space-y-2">
              {players.slice(0, 10).map(p => (
                <div key={p.id} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center">#{p.number}</div>
                    <div>
                      <div className="font-semibold text-sm">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.position}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold">{p.batting_avg ? p.batting_avg.toFixed(3) : '—'}</div>
                    <div className="text-xs text-muted-foreground">AVG</div>
                  </div>
                </div>
              ))}
              {players.length > 10 && <div className="text-center text-xs text-muted-foreground py-2">+ {players.length - 10} more players</div>}
            </div>
          </div>
        )}

        {activeTab === 'games' && (
          <div className="space-y-2">
            {games.slice(0, 10).map(g => {
              const isHome = g.home_team_id === team.id;
              const ourScore = isHome ? g.home_score : g.away_score;
              const oppScore = isHome ? g.away_score : g.home_score;
              const won = ourScore > oppScore;
              const isScheduled = g.status === 'scheduled';
              return (
                <Link key={g.id} to={`/games/${g.id}`} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between block">
                  <div>
                    <div className="text-sm font-semibold">vs {isHome ? g.away_team_name : g.home_team_name}</div>
                    <div className="text-xs text-muted-foreground">{g.scheduled_date} · {isHome ? 'HOME' : 'AWAY'} · {g.status}</div>
                  </div>
                  {isScheduled
                    ? <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">Upcoming</span>
                    : <div className={`font-bebas text-xl tracking-wider ${won ? 'text-green-600' : 'text-red-500'}`}>{won ? 'W' : 'L'} {ourScore}–{oppScore}</div>}
                </Link>
              );
            })}
          </div>
        )}

        {activeTab === 'store' && (
          <div className="space-y-3">
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-muted rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-primary">{storeItems.length}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Active Items</div>
                </div>
                <Link to={`/teams/${team.id}/store`} className="bg-muted rounded-lg p-3 text-center flex flex-col items-center justify-center">
                  <div className="text-sm font-bold text-primary">View Store →</div>
                </Link>
              </div>
            </div>
            {storeItems.map(item => (
              <div key={item.id} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {item.image_url ? <img src={item.image_url} alt={item.name} className="w-10 h-10 rounded-lg object-cover" /> : <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-lg">{item.item_type === 'dues' ? '💰' : '🛍️'}</div>}
                  <div>
                    <div className="font-semibold text-sm">{item.name}</div>
                    <div className="text-xs text-muted-foreground capitalize">{item.item_type}</div>
                  </div>
                </div>
                <div className="text-sm font-semibold">${(item.price || 0).toFixed(2)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}