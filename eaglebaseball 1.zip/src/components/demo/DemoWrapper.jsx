/**
 * DemoWrapper — renders the correct demo dashboard for the active role,
 * using real live app data. Each sub-dashboard fetches from the DB directly.
 */
import { useDemo } from '@/lib/DemoContext';
import DemoCoachView from './DemoCoachView';
import DemoParentView from './DemoParentView';
import DemoFanView from './DemoFanView';
import DemoOrgView from './DemoOrgView';

export default function DemoWrapper() {
  const { demoRole } = useDemo();

  if (demoRole === 'org_owner') return <DemoOrgView />;
  if (demoRole === 'parent')    return <DemoParentView />;
  if (demoRole === 'fan')       return <DemoFanView />;
  return <DemoCoachView />;  // default: coach
}