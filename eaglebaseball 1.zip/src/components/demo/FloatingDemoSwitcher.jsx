/**
 * FloatingDemoSwitcher — always-visible FAB during demo mode.
 * Allows switching roles and exiting demo without navigating anywhere.
 */
import { useState } from 'react';
import { useDemo, DEMO_ROLES } from '@/lib/DemoContext';
import { X, ChevronUp, LogOut } from 'lucide-react';

export default function FloatingDemoSwitcher() {
  const { isDemoMode, activeRole, setDemoRole, exitDemo } = useDemo();
  const [open, setOpen] = useState(false);

  if (!isDemoMode) return null;

  return (
    <>
      {/* Backdrop */}
      {open && (
        <div className="fixed inset-0 z-[998] bg-black/40" onClick={() => setOpen(false)} />
      )}

      <div className="fixed bottom-20 right-4 z-[999] lg:bottom-6 flex flex-col items-end gap-2">
        {/* Role menu */}
        {open && (
          <div className="bg-[#0F1729] border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden w-60">
            <div className="px-4 py-2.5 border-b border-white/10 flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">Demo Role</span>
              <button onClick={exitDemo} className="flex items-center gap-1 text-xs text-red-400 hover:text-red-300 touch-manipulation">
                <LogOut className="w-3 h-3" /> Exit
              </button>
            </div>
            {DEMO_ROLES.map(role => {
              const isActive = activeRole.id === role.id;
              return (
                <button key={role.id}
                  onClick={() => { setDemoRole(role.id); setOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left transition-colors touch-manipulation select-none"
                  style={{ backgroundColor: isActive ? 'rgba(245,158,11,0.15)' : 'transparent', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  <span className="text-lg w-6 text-center flex-shrink-0">{role.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold" style={{ color: isActive ? '#F59E0B' : 'rgba(255,255,255,0.85)' }}>{role.label}</div>
                    <div className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.4)' }}>{role.description}</div>
                  </div>
                  {isActive && <span className="text-[10px] font-bold text-amber-400 flex-shrink-0">●</span>}
                </button>
              );
            })}
          </div>
        )}

        {/* FAB */}
        <button
          onClick={() => setOpen(v => !v)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-full font-bold text-sm shadow-2xl touch-manipulation select-none transition-all active:scale-95"
          style={{
            backgroundColor: '#F59E0B',
            color: '#000',
            boxShadow: '0 0 20px rgba(245,158,11,0.5)',
          }}
        >
          <span>{activeRole.icon}</span>
          <span className="hidden sm:inline">{activeRole.label}</span>
          {open ? <X className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
        </button>
      </div>
    </>
  );
}