/**
 * DemoOrgView — Org Owner perspective using real live data.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { Building2, Users, Trophy, ShoppingBag, DollarSign, Calendar, TrendingUp, ChevronRight, Loader2 } from 'lucide-react';

export default function DemoOrgView() {
  const [org, setOrg] = useState(null);
  const [teams, setTeams] = useState([]);
  const [storeItems, setStoreItems] = useState([]);
  const [seasons, setSeasons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    (async () => {
      const orgs = await base44.entities.Organization.list();
      const o = orgs[0];
      if (!o) {
        // Fallback: just show teams
        const ts = await base44.entities.Team.list('-created_date', 10);
        setTeams(ts);
        setLoading(false);
        return;
      }
      setOrg(o);
      const [ts, si, ss] = await Promise.all([
        base44.entities.Team.filter({ org_id: o.id }),
        base44.entities.StoreItem.filter({ org_id: o.id, scope: 'org' }),
        base44.entities.Season.filter({ org_id: o.id }),
      ]);
      setTeams(ts);
      setStoreItems(si);
      setSeasons(ss);
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;

  const orgName = org?.name || 'Your Organization';
  const activeSeason = seasons.find(s => s.status === 'active') || seasons[0];
  const tabs = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'teams',    label: 'Teams',    icon: Users },
    { id: 'store',    label: 'Org Store', icon: ShoppingBag },
  ];

  return (
    <div className="pb-28 lg:pb-8">
      {/* Hero */}
      <div className="px-5 py-6 text-white"
        style={{ background: `linear-gradient(135deg, ${org?.primary_color || '#1e3a8a'}, #1e40af)` }}>
        <div className="flex items-center gap-3 mb-4">
          {org?.logo_url
            ? <img src={org.logo_url} alt={orgName} className="w-12 h-12 rounded-xl object-contain bg-white/20" />
            : <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center"><Building2 className="w-6 h-6 text-white" /></div>}
          <div>
            <h1 className="font-bold text-xl leading-tight">{orgName}</h1>
            <p className="text-white/50 text-xs mt-0.5">{teams.length} Teams{activeSeason ? ` · ${activeSeason.name}` : ''}</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-white/10 rounded-xl p-3 text-center"><div className="text-2xl font-bold">{teams.length}</div><div className="text-white/60 text-xs mt-0.5">Teams</div></div>
          <div className="bg-white/10 rounded-xl p-3 text-center"><div className="text-2xl font-bold">{storeItems.length}</div><div className="text-white/60 text-xs mt-0.5">Store Items</div></div>
          <div className="bg-white/10 rounded-xl p-3 text-center"><div className="text-2xl font-bold text-amber-400">{seasons.length}</div><div className="text-white/60 text-xs mt-0.5">Seasons</div></div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 px-4 mt-4 overflow-x-auto">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${activeTab === t.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-muted'}`}>
            <t.icon className="w-3.5 h-3.5" />{t.label}
          </button>
        ))}
      </div>

      <div className="px-4 mt-4 space-y-4">
        {activeTab === 'overview' && (
          <>
            {activeSeason && (
              <div className="bg-card border border-border rounded-xl p-4">
                <h3 className="font-semibold text-sm flex items-center gap-2 mb-3"><Calendar className="w-4 h-4 text-primary" />{activeSeason.name}</h3>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Status</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold capitalize ${activeSeason.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-muted text-muted-foreground'}`}>{activeSeason.status}</span>
                </div>
                {activeSeason.start_date && (
                  <div className="flex items-center justify-between text-sm mt-2">
                    <span className="text-muted-foreground">Period</span>
                    <span className="font-medium">{activeSeason.start_date} – {activeSeason.end_date || '?'}</span>
                  </div>
                )}
              </div>
            )}
            {/* Org standings */}
            {teams.length > 0 && (
              <div className="bg-card border border-border rounded-xl p-4">
                <h3 className="font-semibold text-sm mb-3 flex items-center gap-2"><Trophy className="w-4 h-4 text-amber-500" /> Org Standings</h3>
                {teams.map((team, i) => (
                  <div key={team.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <div className="flex items-center gap-3">
                      <span className="text-muted-foreground text-sm w-4">{i + 1}</span>
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: team.primary_color || '#1e3a8a' }} />
                      <span className="text-sm font-medium">{team.name}</span>
                    </div>
                    <span className="text-sm font-semibold">{team.wins || 0}–{team.losses || 0}</span>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {activeTab === 'teams' && (
          <div className="space-y-3">
            {teams.map(team => (
              <Link key={team.id} to={`/teams/${team.id}`} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between block">
                <div className="flex items-center gap-3">
                  {team.logo_url
                    ? <img src={team.logo_url} alt={team.name} className="w-10 h-10 rounded-xl object-contain" />
                    : <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>{team.name.slice(0,2).toUpperCase()}</div>}
                  <div>
                    <div className="font-semibold text-sm">{team.name}</div>
                    <div className="text-xs text-muted-foreground">{[team.age_group, team.season].filter(Boolean).join(' · ')} · {team.wins || 0}W–{team.losses || 0}L</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </Link>
            ))}
          </div>
        )}

        {activeTab === 'store' && (
          <div className="space-y-3">
            {storeItems.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground text-sm">No org store items yet.</div>
            ) : storeItems.map(item => (
              <div key={item.id} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {item.image_url ? <img src={item.image_url} alt={item.name} className="w-10 h-10 rounded-lg object-cover" /> : <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-lg">{item.item_type === 'dues' ? '💰' : '🏷️'}</div>}
                  <div>
                    <div className="font-semibold text-sm">{item.name}</div>
                    <div className="text-xs text-muted-foreground capitalize">{item.item_type}</div>
                  </div>
                </div>
                <div className="text-sm font-semibold">${(item.price || 0).toFixed(2)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}