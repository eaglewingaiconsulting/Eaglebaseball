/**
 * DemoParentView — Parent/Player perspective using real live data.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Trophy, Star, Loader2, CheckCircle, XCircle, HelpCircle } from 'lucide-react';

const RSVP_CFG = {
  attending:     { label: 'Attending',   icon: CheckCircle, color: 'text-green-500' },
  not_attending: { label: 'Not Going',   icon: XCircle,     color: 'text-red-500' },
  pending:       { label: 'No Response', icon: HelpCircle,  color: 'text-amber-500' },
};

export default function DemoParentView() {
  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const teams = await base44.entities.Team.list('-created_date', 1);
      const t = teams[0];
      if (!t) { setLoading(false); return; }
      setTeam(t);
      const [ps, gs] = await Promise.all([
        base44.entities.Player.filter({ team_id: t.id }),
        base44.entities.Game.filter({ home_team_id: t.id }),
      ]);
      setPlayers(ps);
      setGames(gs.sort((a, b) => new Date(b.scheduled_date) - new Date(a.scheduled_date)));
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  if (!team) return <div className="p-8 text-center text-muted-foreground text-sm">No team data available yet.</div>;

  const spotlightPlayer = players[0];
  const upcoming = games.filter(g => g.status === 'scheduled').slice(0, 3);
  const lastGame = games.find(g => g.status === 'completed' || g.status === 'final');

  return (
    <div className="pb-28 lg:pb-8 space-y-5">
      {/* Player Header */}
      <div className="px-5 py-6 text-white"
        style={{ background: `linear-gradient(135deg, ${team.primary_color || '#1e3a8a'}, #15803d)` }}>
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-2xl font-bold font-bebas">
            {spotlightPlayer ? `#${spotlightPlayer.number}` : '?'}
          </div>
          <div>
            <h1 className="font-bold text-xl leading-tight">{spotlightPlayer?.name || 'Your Player'}</h1>
            <p className="text-white/70 text-sm">#{spotlightPlayer?.number} · {spotlightPlayer?.position}</p>
            <p className="text-white/50 text-xs mt-0.5">{team.name}</p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-5">
        {/* Stats */}
        {spotlightPlayer && (
          <div>
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><Star className="w-4 h-4 text-amber-500" /> Season Stats</h2>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'AVG', value: spotlightPlayer.batting_avg ? spotlightPlayer.batting_avg.toFixed(3) : '—' },
                { label: 'AB',  value: spotlightPlayer.at_bats || 0 },
                { label: 'H',   value: spotlightPlayer.hits || 0 },
                { label: 'RBI', value: spotlightPlayer.rbis || 0 },
                { label: 'HR',  value: spotlightPlayer.home_runs || 0 },
                { label: 'K',   value: spotlightPlayer.strikeouts_batting || 0 },
              ].map(s => (
                <div key={s.label} className="bg-card border border-border rounded-xl p-3 text-center">
                  <div className="text-xl font-bold leading-none">{s.value}</div>
                  <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Last game */}
        {lastGame && (
          <div>
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><Trophy className="w-4 h-4 text-amber-500" /> Last Game</h2>
            <Link to={`/games/${lastGame.id}`} className="bg-card border border-border rounded-xl p-4 block">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <div className="font-semibold">{lastGame.away_team_name} @ {lastGame.home_team_name}</div>
                  <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1"><Clock className="w-3 h-3" /> {lastGame.scheduled_date}</div>
                </div>
                <div className="font-bebas text-2xl tracking-wider text-primary">{lastGame.away_score}–{lastGame.home_score}</div>
              </div>
            </Link>
          </div>
        )}

        {/* Upcoming games with RSVP hint */}
        {upcoming.length > 0 && (
          <div>
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> Upcoming Games</h2>
            <div className="space-y-2">
              {upcoming.map(game => (
                <Link key={game.id} to={`/games/${game.id}/rsvp`} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between block">
                  <div className="min-w-0">
                    <div className="font-semibold text-sm truncate">{game.away_team_name} @ {game.home_team_name}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1"><Clock className="w-3 h-3" /> {game.scheduled_date}{game.scheduled_time ? ` · ${game.scheduled_time}` : ''}</div>
                  </div>
                  <span className="text-xs px-2 py-1 rounded-lg bg-primary/10 text-primary font-medium flex-shrink-0 ml-2">RSVP →</span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}