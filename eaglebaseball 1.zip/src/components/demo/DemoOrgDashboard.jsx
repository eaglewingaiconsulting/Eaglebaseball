import { useState } from 'react';
import { Building2, Users, Trophy, ShoppingBag, DollarSign, TrendingUp, Calendar, ChevronRight } from 'lucide-react';

const DEMO_ORG = { name: 'Marietta Baseball Association', teams: 4, activeSeason: 'Spring 2026' };

const DEMO_TEAMS = [
  { name: 'Eagles 12U',   wins: 4, losses: 2, players: 15, dues: '$1,800', color: '#1e3a8a' },
  { name: 'Eagles 10U',   wins: 6, losses: 1, players: 13, dues: '$1,560', color: '#15803d' },
  { name: 'Eagles 14U',   wins: 2, losses: 4, players: 14, dues: '$1,680', color: '#b45309' },
  { name: 'Eagles 8U',    wins: 3, losses: 3, players: 12, dues: '$1,440', color: '#7c3aed' },
];

const DEMO_ORG_STORE = [
  { name: 'Organization Hat',   price: '$28.00', orders: 34, revenue: '$952' },
  { name: 'Wind Jacket',        price: '$65.00', orders: 21, revenue: '$1,365' },
  { name: 'Registration Fee',   price: '$200.00',orders: 54, revenue: '$10,800' },
];

const DEMO_SEASON = {
  name: 'Spring 2026',
  start: 'Mar 15',
  end: 'Jun 28',
  gamesPlayed: 28,
  totalGames: 56,
};

export default function DemoOrgDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview',  icon: TrendingUp },
    { id: 'teams',    label: 'Teams',     icon: Users },
    { id: 'store',    label: 'Org Store', icon: ShoppingBag },
  ];

  const totalRevenue = DEMO_TEAMS.reduce((sum, t) => sum + parseInt(t.dues.replace(/\D/g, '')), 0);

  return (
    <div className="pb-24 lg:pb-8">
      {/* Hero */}
      <div className="bg-gradient-to-br from-[hsl(214,90%,14%)] to-[hsl(214,90%,28%)] px-5 py-6 text-white">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-xl leading-tight">{DEMO_ORG.name}</h1>
            <p className="text-white/50 text-xs mt-0.5">{DEMO_ORG.teams} Teams · {DEMO_ORG.activeSeason}</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-4">
          <div className="bg-white/10 rounded-xl p-3 text-center">
            <div className="text-2xl font-bold">{DEMO_ORG.teams}</div>
            <div className="text-white/60 text-xs mt-0.5">Teams</div>
          </div>
          <div className="bg-white/10 rounded-xl p-3 text-center">
            <div className="text-2xl font-bold">54</div>
            <div className="text-white/60 text-xs mt-0.5">Players</div>
          </div>
          <div className="bg-white/10 rounded-xl p-3 text-center">
            <div className="text-2xl font-bold text-amber-400">${(totalRevenue / 1000).toFixed(1)}k</div>
            <div className="text-white/60 text-xs mt-0.5">Dues Collected</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 px-4 mt-4 overflow-x-auto">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              activeTab === t.id
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <t.icon className="w-3.5 h-3.5" />
            {t.label}
          </button>
        ))}
      </div>

      <div className="px-4 mt-4 space-y-4">
        {/* Overview */}
        {activeTab === 'overview' && (
          <>
            {/* Season progress */}
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-sm flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" />{DEMO_SEASON.name}</h3>
                <span className="text-xs text-muted-foreground">{DEMO_SEASON.start} – {DEMO_SEASON.end}</span>
              </div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-muted-foreground">Games Played</span>
                <span className="font-semibold">{DEMO_SEASON.gamesPlayed} / {DEMO_SEASON.totalGames}</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-primary h-2 rounded-full" style={{ width: `${(DEMO_SEASON.gamesPlayed / DEMO_SEASON.totalGames) * 100}%` }} />
              </div>
              <div className="text-xs text-muted-foreground mt-1.5 text-right">{Math.round((DEMO_SEASON.gamesPlayed / DEMO_SEASON.totalGames) * 100)}% complete</div>
            </div>

            {/* Financials */}
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="font-semibold text-sm mb-3 flex items-center gap-2"><DollarSign className="w-4 h-4 text-green-600" /> Dues Overview</h3>
              <div className="space-y-2">
                {DEMO_TEAMS.map(team => (
                  <div key={team.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: team.color }} />
                      <span className="text-sm">{team.name}</span>
                    </div>
                    <span className="text-sm font-semibold text-green-700 dark:text-green-400">{team.dues}</span>
                  </div>
                ))}
                <div className="border-t border-border pt-2 flex items-center justify-between mt-2">
                  <span className="text-sm font-semibold">Total Collected</span>
                  <span className="font-bold text-green-700 dark:text-green-400">${totalRevenue.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Standings */}
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="font-semibold text-sm mb-3 flex items-center gap-2"><Trophy className="w-4 h-4 text-amber-500" /> Org Standings</h3>
              {[...DEMO_TEAMS].sort((a, b) => b.wins - a.wins).map((team, i) => (
                <div key={team.name} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div className="flex items-center gap-3">
                    <span className="text-muted-foreground text-sm w-4">{i + 1}</span>
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: team.color }} />
                    <span className="text-sm font-medium">{team.name}</span>
                  </div>
                  <span className="text-sm font-semibold">{team.wins}–{team.losses}</span>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Teams */}
        {activeTab === 'teams' && (
          <div className="space-y-3">
            {DEMO_TEAMS.map(team => (
              <div key={team.name} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: team.color }}>
                    {team.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{team.name}</div>
                    <div className="text-xs text-muted-foreground">{team.players} players · {team.wins}W–{team.losses}L</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-green-700 dark:text-green-400">{team.dues}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Org Store */}
        {activeTab === 'store' && (
          <div className="space-y-3">
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="font-semibold text-sm mb-3">Org Store Revenue</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-muted rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-primary">109</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Total Orders</div>
                </div>
                <div className="bg-muted rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-green-600">$13.1k</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Revenue</div>
                </div>
              </div>
            </div>
            <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Org Store Items</h3>
            {DEMO_ORG_STORE.map(item => (
              <div key={item.name} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-sm">{item.name}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{item.orders} orders · {item.revenue}</div>
                </div>
                <div className="text-sm font-semibold">{item.price}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}