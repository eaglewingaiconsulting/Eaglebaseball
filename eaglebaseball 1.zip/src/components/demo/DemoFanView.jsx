/**
 * DemoFanView — Fan perspective using real live data.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Trophy, TrendingUp, Star, Loader2, Radio } from 'lucide-react';

export default function DemoFanView() {
  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const teams = await base44.entities.Team.list('-created_date', 1);
      const t = teams[0];
      if (!t) { setLoading(false); return; }
      setTeam(t);
      const [ps, gs] = await Promise.all([
        base44.entities.Player.filter({ team_id: t.id }),
        base44.entities.Game.filter({ home_team_id: t.id }),
      ]);
      setPlayers(ps.sort((a, b) => (b.batting_avg || 0) - (a.batting_avg || 0)));
      setGames(gs.sort((a, b) => new Date(b.scheduled_date) - new Date(a.scheduled_date)));
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  if (!team) return <div className="p-8 text-center text-muted-foreground text-sm">No team data available yet.</div>;

  const completed = games.filter(g => g.status === 'completed' || g.status === 'final');
  const upcoming = games.filter(g => g.status === 'scheduled').slice(0, 3);
  const liveGame = games.find(g => g.status === 'in_progress');
  const wins = completed.filter(g => (g.home_team_id === team.id ? g.home_score > g.away_score : g.away_score > g.home_score)).length;
  const losses = completed.length - wins;
  const winPct = completed.length > 0 ? ((wins / completed.length) * 100).toFixed(0) : '—';
  const spotlight = players[0];

  return (
    <div className="pb-28 lg:pb-8 space-y-5">
      {/* Following Header */}
      <div className="px-5 py-6 text-white"
        style={{ background: `linear-gradient(135deg, ${team.primary_color || '#1e3a8a'}, #1e40af)` }}>
        <div className="text-white/60 text-xs uppercase tracking-widest mb-2">You're Following</div>
        <div className="flex items-center gap-4 mb-4">
          {team.logo_url
            ? <img src={team.logo_url} alt={team.name} className="w-14 h-14 rounded-xl object-contain bg-white/20" />
            : <div className="w-14 h-14 rounded-xl flex items-center justify-center text-white text-lg font-bold font-bebas bg-white/20">{team.name.slice(0,2).toUpperCase()}</div>}
          <div>
            <h1 className="font-bold text-xl leading-tight">{team.name}</h1>
            <p className="text-white/50 text-xs mt-0.5">{[team.city, team.league].filter(Boolean).join(' · ')}</p>
          </div>
        </div>
        {spotlight && (
          <div className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2 w-fit">
            <div className="w-8 h-8 rounded-full bg-amber-500/30 flex items-center justify-center text-amber-300 text-xs font-bold">#{spotlight.number}</div>
            <div>
              <div className="text-white text-sm font-semibold">{spotlight.name}</div>
              <div className="text-white/50 text-xs">{spotlight.position} · Top Batter</div>
            </div>
          </div>
        )}
      </div>

      <div className="px-4 space-y-5">
        {/* Live */}
        {liveGame && (
          <Link to={`/games/${liveGame.id}`} className="flex items-center justify-between bg-green-950 border border-green-500/40 rounded-xl p-4 block">
            <div>
              <div className="flex items-center gap-2 mb-1"><div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" /><span className="text-green-400 text-xs font-semibold uppercase">Live Now</span></div>
              <div className="text-white font-semibold">{liveGame.away_team_name} @ {liveGame.home_team_name}</div>
            </div>
            <div className="font-bebas text-4xl text-green-400 tracking-wider">{liveGame.away_score}–{liveGame.home_score}</div>
          </Link>
        )}

        {/* Record */}
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><Trophy className="w-4 h-4 text-amber-500" /> Season Record</h2>
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-card border border-border rounded-xl p-4 text-center"><div className="text-2xl font-bold text-green-600">{wins}</div><div className="text-xs text-muted-foreground mt-1">Wins</div></div>
            <div className="bg-card border border-border rounded-xl p-4 text-center"><div className="text-2xl font-bold text-red-500">{losses}</div><div className="text-xs text-muted-foreground mt-1">Losses</div></div>
            <div className="bg-card border border-border rounded-xl p-4 text-center"><div className="text-2xl font-bold text-primary">{winPct}%</div><div className="text-xs text-muted-foreground mt-1">Win %</div></div>
          </div>
        </div>

        {/* Spotlight stats */}
        {spotlight && (
          <div>
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><Star className="w-4 h-4 text-amber-500" /> Player Spotlight — {spotlight.name}</h2>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'AVG', value: spotlight.batting_avg ? spotlight.batting_avg.toFixed(3) : '—' },
                { label: 'HR',  value: spotlight.home_runs || 0 },
                { label: 'RBI', value: spotlight.rbis || 0 },
              ].map(s => (
                <div key={s.label} className="bg-card border border-border rounded-xl p-4 text-center">
                  <div className="text-2xl font-bold">{s.value}</div>
                  <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Upcoming */}
        {upcoming.length > 0 && (
          <div>
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> Next Games</h2>
            <div className="space-y-2">
              {upcoming.map(game => (
                <Link key={game.id} to={`/games/${game.id}`} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between block">
                  <div className="min-w-0">
                    <div className="font-semibold text-sm truncate">{game.away_team_name} @ {game.home_team_name}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1"><Clock className="w-3 h-3" /> {game.scheduled_date}{game.scheduled_time ? ` · ${game.scheduled_time}` : ''}</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}