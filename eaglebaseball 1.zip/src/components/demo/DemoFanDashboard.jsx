import { Calendar, Clock, Trophy, Star, TrendingUp } from 'lucide-react';

const DEMO_TEAM = {
  name: 'Marietta Warriors',
  org: 'Marietta Baseball Association',
  primaryColor: '#1e3a8a',
  wins: 9,
  losses: 3,
};

const DEMO_PLAYER_SPOTLIGHT = {
  name: 'Jake Ewing',
  number: '12',
  position: 'SS',
  avg: '.342',
  hr: 4,
  rbi: 18,
};

const DEMO_LAST_GAME = {
  opponent: 'North Atlanta Eagles',
  score: '7–4',
  result: 'W',
  date: 'Apr 12, 2026',
  performance: '2 for 3, 1 RBI',
};

const DEMO_UPCOMING = [
  { id: 1, opponent: 'Kennesaw Tigers',  date: 'Apr 19', time: '10:00 AM', home: true },
  { id: 2, opponent: 'Alpharetta Braves', date: 'Apr 22', time: '6:00 PM',  home: false },
  { id: 3, opponent: 'Roswell Red Sox',  date: 'Apr 26', time: '11:00 AM', home: true },
];

export default function DemoFanDashboard() {
  const winPct = ((DEMO_TEAM.wins / (DEMO_TEAM.wins + DEMO_TEAM.losses)) * 100).toFixed(0);

  return (
    <div className="pb-24 lg:pb-8 space-y-5">
      {/* Following Header */}
      <div className="bg-gradient-to-br from-[hsl(214,90%,18%)] to-[hsl(214,90%,32%)] px-5 py-6 text-white">
        <div className="text-white/60 text-xs uppercase tracking-widest mb-2">You're Following</div>
        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-xl flex items-center justify-center text-white text-lg font-bold font-bebas"
            style={{ backgroundColor: DEMO_TEAM.primaryColor }}>
            MW
          </div>
          <div>
            <h1 className="font-bold text-xl leading-tight">{DEMO_TEAM.name}</h1>
            <p className="text-white/50 text-xs mt-0.5">{DEMO_TEAM.org}</p>
          </div>
        </div>
        {/* Player spotlight chip */}
        <div className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2 w-fit">
          <div className="w-8 h-8 rounded-full bg-amber-500/30 flex items-center justify-center text-amber-300 text-xs font-bold">
            #{DEMO_PLAYER_SPOTLIGHT.number}
          </div>
          <div>
            <div className="text-white text-sm font-semibold">{DEMO_PLAYER_SPOTLIGHT.name}</div>
            <div className="text-white/50 text-xs">{DEMO_PLAYER_SPOTLIGHT.position} · Following</div>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-5">
        {/* Season Record */}
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-500" /> Season Record
          </h2>
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{DEMO_TEAM.wins}</div>
              <div className="text-xs text-muted-foreground mt-1">Wins</div>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-red-500">{DEMO_TEAM.losses}</div>
              <div className="text-xs text-muted-foreground mt-1">Losses</div>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-primary">{winPct}%</div>
              <div className="text-xs text-muted-foreground mt-1">Win %</div>
            </div>
          </div>
        </div>

        {/* Player Spotlight Stats */}
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-500" /> Player Spotlight — {DEMO_PLAYER_SPOTLIGHT.name}
          </h2>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'AVG', value: DEMO_PLAYER_SPOTLIGHT.avg },
              { label: 'HR',  value: DEMO_PLAYER_SPOTLIGHT.hr },
              { label: 'RBI', value: DEMO_PLAYER_SPOTLIGHT.rbi },
            ].map(s => (
              <div key={s.label} className="bg-card border border-border rounded-xl p-4 text-center">
                <div className="text-2xl font-bold">{s.value}</div>
                <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Last Game */}
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" /> Last Game
          </h2>
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="font-semibold">vs {DEMO_LAST_GAME.opponent}</div>
                <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {DEMO_LAST_GAME.date}
                </div>
              </div>
              <div className={`text-2xl font-bebas tracking-wider ${DEMO_LAST_GAME.result === 'W' ? 'text-green-600' : 'text-red-500'}`}>
                {DEMO_LAST_GAME.result} {DEMO_LAST_GAME.score}
              </div>
            </div>
            <div className="mt-2 pt-2 border-t border-border text-sm text-muted-foreground">
              Jake's game: <span className="font-semibold text-foreground">{DEMO_LAST_GAME.performance}</span>
            </div>
          </div>
        </div>

        {/* Next Games — no RSVP */}
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" /> Next Games
          </h2>
          <div className="space-y-2">
            {DEMO_UPCOMING.map(game => (
              <div key={game.id} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between">
                <div className="min-w-0">
                  <div className="font-semibold text-sm truncate">vs {game.opponent}</div>
                  <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {game.date} · {game.time}
                  </div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full font-medium flex-shrink-0 ${game.home ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'}`}>
                  {game.home ? 'HOME' : 'AWAY'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}