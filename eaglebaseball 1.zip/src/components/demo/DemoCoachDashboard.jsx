import { useState } from 'react';
import { Calendar, Users, Trophy, BarChart3, ShoppingBag, Play, Clock, Activity, Plus } from 'lucide-react';

const DEMO_TEAM = {
  id: 'demo-team',
  name: 'Eagles 12U',
  city: 'Springfield',
  wins: 4, losses: 2,
  primaryColor: '#1e3a8a',
  league: 'Metro Youth League',
};

const DEMO_GAMES = [
  { id: 'g1', away: 'Raptors',  home: 'Eagles 12U', awayScore: 3, homeScore: 7, date: 'Apr 5',  status: 'final' },
  { id: 'g2', away: 'Eagles 12U', home: 'Wolves',   awayScore: 5, homeScore: 2, date: 'Apr 8',  status: 'final' },
  { id: 'g3', away: 'Tigers',   home: 'Eagles 12U', awayScore: 4, homeScore: 9, date: 'Apr 10', status: 'final' },
  { id: 'g4', away: 'Eagles 12U', home: 'Thunder',  awayScore: 6, homeScore: 6, date: 'Apr 11', status: 'final' },
];

const DEMO_UPCOMING = { away: 'Hawks', home: 'Eagles 12U', date: 'Apr 19', time: '10:00 AM', location: 'Eagles Field', rsvpAttending: 9, rsvpPending: 3, rsvpNo: 1 };

const DEMO_PLAYERS = [
  { name: 'Jake Torres',  number: '1',  pos: 'P',  avg: '.312' },
  { name: 'Mason Lee',    number: '2',  pos: 'C',  avg: '.285' },
  { name: 'Ethan Brooks', number: '3',  pos: '1B', avg: '.350' },
  { name: 'Lucas Patel',  number: '4',  pos: '2B', avg: '.265' },
  { name: 'Caleb Ryan',   number: '5',  pos: '3B', avg: '.290' },
  { name: 'Noah Kim',     number: '6',  pos: 'SS', avg: '.330' },
];

const DEMO_STORE = [
  { name: 'Team Jersey',   price: '$45.00', status: 'Published',   orders: 8 },
  { name: 'Team Hat',      price: '$22.00', status: 'Published',   orders: 11 },
  { name: 'Spring Dues',   price: '$150.00',status: 'Published',   orders: 12 },
  { name: 'Batting Gloves',price: '$18.00', status: 'Unpublished', orders: 0 },
];

const DEMO_LIVE = { away: 'Storm', home: 'Eagles 12U', awayScore: 2, homeScore: 4, inning: 4, half: 'bottom', outs: 1, balls: 2, strikes: 1 };

export default function DemoCoachDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'roster',   label: 'Roster',   icon: Users },
    { id: 'games',    label: 'Games',    icon: Calendar },
    { id: 'store',    label: 'Store',    icon: ShoppingBag },
  ];

  return (
    <div className="pb-24 lg:pb-8">
      {/* Hero */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[hsl(214,90%,18%)] to-[hsl(214,90%,30%)] px-5 py-6 text-white">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 80% 50%, hsl(38,95%,50%), transparent 60%)' }} />
        <div className="relative">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: DEMO_TEAM.primaryColor }}>
              EA
            </div>
            <div>
              <h1 className="font-bebas text-2xl tracking-wider text-accent leading-none">{DEMO_TEAM.name}</h1>
              <p className="text-white/50 text-xs">{DEMO_TEAM.league}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 mt-3">
            <span className="text-white/80 font-semibold">{DEMO_TEAM.wins}W – {DEMO_TEAM.losses}L</span>
            <span className="text-white/30">·</span>
            <span className="text-white/60 text-sm">Coach View</span>
          </div>
        </div>
      </div>

      {/* Live Game Banner */}
      <div className="mx-4 mt-4 bg-green-950 border border-green-500/40 rounded-xl p-4 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-green-400 text-xs font-semibold uppercase tracking-wider">Live Now</span>
          </div>
          <div className="text-white font-semibold">{DEMO_LIVE.away} @ {DEMO_LIVE.home}</div>
          <div className="text-white/60 text-xs mt-0.5">Inn. {DEMO_LIVE.inning} {DEMO_LIVE.half === 'bottom' ? '▼' : '▲'} · {DEMO_LIVE.outs} outs · {DEMO_LIVE.balls}-{DEMO_LIVE.strikes}</div>
        </div>
        <div className="text-right">
          <div className="font-bebas text-4xl text-green-400 tracking-wider">{DEMO_LIVE.awayScore}–{DEMO_LIVE.homeScore}</div>
          <div className="text-xs text-green-400/70 flex items-center gap-1 justify-end mt-0.5">
            <Play className="w-3 h-3" /> Score Live
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 px-4 mt-4 overflow-x-auto">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              activeTab === t.id
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <t.icon className="w-3.5 h-3.5" />
            {t.label}
          </button>
        ))}
      </div>

      <div className="px-4 mt-4 space-y-4">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <>
            {/* Stats */}
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: 'Players', value: 15, icon: Users, color: 'text-blue-500' },
                { label: 'Games',   value: 7,  icon: Calendar, color: 'text-purple-500' },
                { label: 'Wins',    value: 4,  icon: Trophy, color: 'text-amber-500' },
                { label: 'Avg',     value: '.295', icon: BarChart3, color: 'text-green-500' },
              ].map(s => (
                <div key={s.label} className="bg-card border border-border rounded-xl p-3 text-center">
                  <s.icon className={`w-4 h-4 mx-auto mb-1 ${s.color}`} />
                  <div className="text-lg font-bold leading-none">{s.value}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>

            {/* Next Game — RSVP summary */}
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                  <Clock className="w-4 h-4" /> Next Game
                </h3>
                <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">RSVP Open</span>
              </div>
              <div className="font-semibold">{DEMO_UPCOMING.away} @ {DEMO_UPCOMING.home}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{DEMO_UPCOMING.date} · {DEMO_UPCOMING.time} · {DEMO_UPCOMING.location}</div>
              <div className="flex gap-3 mt-3">
                <div className="flex items-center gap-1 text-sm text-green-600 font-semibold"><span className="w-2 h-2 rounded-full bg-green-500 inline-block" />{DEMO_UPCOMING.rsvpAttending} ✓</div>
                <div className="flex items-center gap-1 text-sm text-amber-600 font-semibold"><span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />{DEMO_UPCOMING.rsvpPending} ?</div>
                <div className="flex items-center gap-1 text-sm text-red-500 font-semibold"><span className="w-2 h-2 rounded-full bg-red-400 inline-block" />{DEMO_UPCOMING.rsvpNo} ✗</div>
              </div>
            </div>

            {/* Recent results */}
            <div>
              <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-amber-500" /> Recent Results
              </h3>
              <div className="space-y-2">
                {DEMO_GAMES.slice(-3).reverse().map(g => {
                  const weAreHome = g.home === 'Eagles 12U';
                  const ourScore = weAreHome ? g.homeScore : g.awayScore;
                  const oppScore = weAreHome ? g.awayScore : g.homeScore;
                  const won = ourScore > oppScore;
                  const tied = ourScore === oppScore;
                  return (
                    <div key={g.id} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between">
                      <div>
                        <div className="text-sm font-semibold">vs {weAreHome ? g.away : g.home}</div>
                        <div className="text-xs text-muted-foreground">{g.date} · {weAreHome ? 'HOME' : 'AWAY'}</div>
                      </div>
                      <div className={`font-bebas text-xl tracking-wider ${won ? 'text-green-600' : tied ? 'text-amber-500' : 'text-red-500'}`}>
                        {won ? 'W' : tied ? 'T' : 'L'} {ourScore}–{oppScore}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}

        {/* Roster Tab */}
        {activeTab === 'roster' && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">15 Players</h3>
              <button className="flex items-center gap-1 text-xs text-primary font-medium"><Plus className="w-3.5 h-3.5" /> Add Player</button>
            </div>
            <div className="space-y-2">
              {DEMO_PLAYERS.map(p => (
                <div key={p.number} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center">
                      #{p.number}
                    </div>
                    <div>
                      <div className="font-semibold text-sm">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.pos}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold">{p.avg}</div>
                    <div className="text-xs text-muted-foreground">AVG</div>
                  </div>
                </div>
              ))}
              <div className="text-center text-xs text-muted-foreground py-2">+ 9 more players</div>
            </div>
          </div>
        )}

        {/* Games Tab */}
        {activeTab === 'games' && (
          <div className="space-y-3">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 dark:bg-amber-950/30 dark:border-amber-700/40">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="w-4 h-4 text-amber-600" />
                <span className="font-semibold text-sm text-amber-800 dark:text-amber-400">Upcoming — Apr 19</span>
              </div>
              <div className="font-semibold">{DEMO_UPCOMING.away} @ {DEMO_UPCOMING.home}</div>
              <div className="text-xs text-muted-foreground mt-1">{DEMO_UPCOMING.time} · {DEMO_UPCOMING.location}</div>
              <div className="flex gap-2 mt-3">
                <button className="text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg font-medium">Set Lineup</button>
                <button className="text-xs bg-secondary text-secondary-foreground px-3 py-1.5 rounded-lg font-medium">Score Game</button>
              </div>
            </div>
            {DEMO_GAMES.reverse().map(g => {
              const weAreHome = g.home === 'Eagles 12U';
              const ourScore = weAreHome ? g.homeScore : g.awayScore;
              const oppScore = weAreHome ? g.awayScore : g.homeScore;
              const won = ourScore > oppScore;
              const tied = ourScore === oppScore;
              return (
                <div key={g.id} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-semibold">vs {weAreHome ? g.away : g.home}</div>
                    <div className="text-xs text-muted-foreground">{g.date} · {weAreHome ? 'HOME' : 'AWAY'} · Final</div>
                  </div>
                  <div className={`font-bebas text-xl tracking-wider ${won ? 'text-green-600' : tied ? 'text-amber-500' : 'text-red-500'}`}>
                    {won ? 'W' : tied ? 'T' : 'L'} {ourScore}–{oppScore}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Store Tab */}
        {activeTab === 'store' && (
          <div className="space-y-3">
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-semibold text-sm">Store Summary</h3>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-2">
                <div className="bg-muted rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-primary">31</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Total Orders</div>
                </div>
                <div className="bg-muted rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-green-600">$1,876</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Revenue</div>
                </div>
              </div>
            </div>
            <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Store Items</h3>
            {DEMO_STORE.map(item => (
              <div key={item.name} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-sm">{item.name}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{item.orders} orders</div>
                </div>
                <div className="text-right flex items-center gap-3">
                  <span className="font-semibold text-sm">{item.price}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${item.status === 'Published' ? 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400' : 'bg-muted text-muted-foreground'}`}>
                    {item.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}