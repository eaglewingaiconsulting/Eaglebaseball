import { useState } from 'react';
import { Calendar, Clock, CheckCircle, XCircle, HelpCircle, Trophy, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DEMO_PLAYER = {
  name: 'Jake Ewing',
  number: '12',
  position: 'SS',
  team: 'Marietta Warriors',
  org: 'Marietta Baseball Association',
  stats: {
    avg: '.342', ab: 73, h: 25, rbi: 18, hr: 4, errors: 2,
  },
};

const DEMO_LAST_GAME = {
  opponent: 'North Atlanta Eagles',
  score: '7–4',
  result: 'W',
  date: 'Apr 12, 2026',
  performance: '2 for 3, 1 RBI, 1 Run',
};

const DEMO_UPCOMING = [
  { id: 1, opponent: 'Kennesaw Tigers', date: 'Apr 19', time: '10:00 AM', home: true, rsvp: 'attending' },
  { id: 2, opponent: 'Alpharetta Braves', date: 'Apr 22', time: '6:00 PM', home: false, rsvp: 'pending' },
  { id: 3, opponent: 'Roswell Red Sox', date: 'Apr 26', time: '11:00 AM', home: true, rsvp: 'not_attending' },
];

const RSVP_CONFIG = {
  attending:     { label: 'Attending',     icon: CheckCircle, color: 'text-green-500' },
  not_attending: { label: 'Not Going',     icon: XCircle,     color: 'text-red-500' },
  pending:       { label: 'No Response',   icon: HelpCircle,  color: 'text-amber-500' },
};

export default function DemoParentDashboard() {
  const [rsvps, setRsvps] = useState(
    Object.fromEntries(DEMO_UPCOMING.map(g => [g.id, g.rsvp]))
  );

  const cycle = (id) => {
    const order = ['attending', 'not_attending', 'pending'];
    setRsvps(prev => {
      const cur = prev[id] || 'pending';
      const next = order[(order.indexOf(cur) + 1) % order.length];
      return { ...prev, [id]: next };
    });
  };

  return (
    <div className="pb-24 lg:pb-8 space-y-5">
      {/* Player Header */}
      <div className="bg-gradient-to-br from-[hsl(214,90%,18%)] to-[hsl(142,71%,28%)] px-5 py-6 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-2xl font-bold font-bebas">
            #{DEMO_PLAYER.number}
          </div>
          <div>
            <h1 className="font-bold text-xl leading-tight">{DEMO_PLAYER.name}</h1>
            <p className="text-white/70 text-sm">#{DEMO_PLAYER.number} · {DEMO_PLAYER.position}</p>
            <p className="text-white/50 text-xs mt-0.5">{DEMO_PLAYER.team} · {DEMO_PLAYER.org}</p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-5">
        {/* This Season Stats */}
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-500" /> This Season
          </h2>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'AVG', value: DEMO_PLAYER.stats.avg },
              { label: 'AB',  value: DEMO_PLAYER.stats.ab },
              { label: 'H',   value: DEMO_PLAYER.stats.h },
              { label: 'RBI', value: DEMO_PLAYER.stats.rbi },
              { label: 'HR',  value: DEMO_PLAYER.stats.hr },
              { label: 'E',   value: DEMO_PLAYER.stats.errors },
            ].map(s => (
              <div key={s.label} className="bg-card border border-border rounded-xl p-3 text-center">
                <div className="text-xl font-bold leading-none">{s.value}</div>
                <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Last Game */}
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-500" /> Last Game
          </h2>
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="font-semibold">vs {DEMO_LAST_GAME.opponent}</div>
                <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {DEMO_LAST_GAME.date}
                </div>
              </div>
              <div className="text-right">
                <div className={`text-2xl font-bebas tracking-wider ${DEMO_LAST_GAME.result === 'W' ? 'text-green-600' : 'text-red-500'}`}>
                  {DEMO_LAST_GAME.result} {DEMO_LAST_GAME.score}
                </div>
              </div>
            </div>
            <div className="mt-2 pt-2 border-t border-border text-sm text-muted-foreground">
              Jake's performance: <span className="font-semibold text-foreground">{DEMO_LAST_GAME.performance}</span>
            </div>
          </div>
        </div>

        {/* Upcoming Games */}
        <div>
          <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" /> Upcoming Games
          </h2>
          <div className="space-y-2">
            {DEMO_UPCOMING.map(game => {
              const rsvp = rsvps[game.id] || 'pending';
              const cfg = RSVP_CONFIG[rsvp];
              return (
                <div key={game.id} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-semibold text-sm truncate">vs {game.opponent}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {game.date} · {game.time}
                      <span className={`ml-1 px-1.5 py-0.5 rounded text-xs font-medium ${game.home ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'}`}>
                        {game.home ? 'HOME' : 'AWAY'}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => cycle(game.id)}
                    className="flex items-center gap-1.5 text-xs font-medium px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted transition-colors flex-shrink-0"
                  >
                    <cfg.icon className={`w-3.5 h-3.5 ${cfg.color}`} />
                    {cfg.label}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}