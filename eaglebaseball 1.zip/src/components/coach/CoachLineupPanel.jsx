/**
 * CoachLineupPanel — shows my team's batting order with current batter highlighted,
 * on-deck indicator, and season AVG for each player.
 */
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

export default function CoachLineupPanel({ game, players, myTeamId }) {
  const [open, setOpen] = useState(true);

  const myLineup = myTeamId === game.home_team_id ? (game.home_lineup || []) : (game.away_lineup || []);
  const myIdx = myTeamId === game.home_team_id
    ? (game.home_batting_order_idx ?? 0)
    : (game.away_batting_order_idx ?? 0);

  if (myLineup.length === 0) return null;

  const getPlayer = (pid) => players.find(p => p.id === pid);
  const onDeckIdx = (myIdx + 1) % myLineup.length;

  return (
    <div className="bg-[hsl(214,90%,12%)] border border-white/10 rounded-xl overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-4 py-3 select-none touch-manipulation"
        onClick={() => setOpen(v => !v)}
      >
        <span className="font-semibold text-sm text-white flex items-center gap-2">
          📋 Batting Order
          <span className="text-xs text-white/30 font-normal">{myLineup.length} batters</span>
        </span>
        {open ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
      </button>

      {open && (
        <div className="divide-y divide-white/5 border-t border-white/10">
          {myLineup.map((pid, idx) => {
            const p = getPlayer(pid);
            const isCurrent = idx === myIdx;
            const isOnDeck = idx === onDeckIdx && !isCurrent;
            return (
              <div key={pid}
                className={`flex items-center gap-3 px-4 py-2.5 transition-colors ${isCurrent ? 'bg-accent/15' : ''}`}>
                <span className={`text-xs font-bold w-5 text-center flex-shrink-0 ${isCurrent ? 'text-accent' : 'text-white/30'}`}>{idx + 1}</span>
                <span className={`text-sm font-bold w-7 flex-shrink-0 ${isCurrent ? 'text-accent' : 'text-white/40'}`}>#{p?.number || '?'}</span>
                <span className={`text-sm flex-1 min-w-0 truncate ${isCurrent ? 'text-white font-semibold' : 'text-white/70'}`}>{p?.name || 'Unknown'}</span>
                {isCurrent && (
                  <span className="text-[10px] font-bold text-accent bg-accent/20 px-1.5 py-0.5 rounded-full flex-shrink-0">AT BAT</span>
                )}
                {isOnDeck && (
                  <span className="text-[10px] font-bold text-white/50 bg-white/10 px-1.5 py-0.5 rounded-full flex-shrink-0">ON DECK</span>
                )}
                {!isCurrent && !isOnDeck && p?.batting_avg != null && (
                  <span className="text-xs text-white/30 flex-shrink-0">{p.batting_avg.toFixed(3)}</span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}