/**
 * CoachPitcherPanel — sticky bottom bar showing current pitcher pitch count
 * + expandable history of all pitchers used this game.
 */
import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

function pitchColor(count) {
  if (count >= 76) return { text: 'text-red-400', bg: 'bg-red-500/20 border-red-500/40' };
  if (count >= 51) return { text: 'text-yellow-400', bg: 'bg-yellow-500/20 border-yellow-500/40' };
  return { text: 'text-green-400', bg: 'bg-green-500/20 border-green-500/40' };
}

export default function CoachPitcherPanel({ game, players, pitchers }) {
  const [expanded, setExpanded] = useState(false);
  const pitcher = game.current_pitcher_id ? players.find(p => p.id === game.current_pitcher_id) : null;
  const count = game.current_pitcher_pitch_count ?? 0;
  const { text, bg } = pitchColor(count);

  // All pitchers who appeared this game (our side = is_opponent === false)
  const ourPitchers = pitchers.filter(gp => !gp.is_opponent)
    .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

  return (
    <div className="pb-safe">
      {/* Expanded pitcher history */}
      {expanded && ourPitchers.length > 0 && (
        <div className="bg-[hsl(214,90%,8%)] border-t border-white/10 px-4 py-3 space-y-2 max-h-48 overflow-y-auto">
          <div className="text-xs text-white/40 uppercase tracking-wider font-semibold mb-1">All Pitchers This Game</div>
          {ourPitchers.map((gp, i) => {
            const pc = gp.pitch_count ?? 0;
            const { text: ct } = pitchColor(pc);
            const active = !gp.exit_inning;
            return (
              <div key={gp.id || i} className="flex items-center justify-between">
                <div>
                  <span className="text-sm font-semibold text-white">{gp.player_name || 'Unknown'}</span>
                  {active && <span className="ml-2 text-[10px] bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded-full font-bold">active</span>}
                  <div className="text-xs text-white/40 mt-0.5">
                    Inn. {gp.entry_inning}{gp.exit_inning ? `–${gp.exit_inning}` : '+'} · {gp.innings_pitched ?? 0} IP · {gp.strikeouts ?? 0}K · {gp.walks ?? 0}BB · {gp.hits_allowed ?? 0}H
                  </div>
                </div>
                <div className={`font-bebas text-2xl ${ct}`}>{pc}</div>
              </div>
            );
          })}
        </div>
      )}

      {/* Main bar */}
      <div className={`mx-3 mb-3 rounded-xl border ${bg} px-4 py-2.5 flex items-center justify-between`}>
        <div>
          <div className="text-xs text-white/40 uppercase tracking-wider font-semibold">Current Pitcher</div>
          <div className="text-white font-semibold text-sm">{pitcher?.name || game.current_pitcher_name || '—'}</div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className={`font-bebas text-3xl leading-none ${text}`}>{count}</div>
            <div className="text-white/40 text-xs">pitches</div>
          </div>
          {ourPitchers.length > 0 && (
            <button onClick={() => setExpanded(v => !v)} className="p-1 rounded-lg bg-white/10 touch-manipulation">
              {expanded ? <ChevronUp className="w-4 h-4 text-white/60" /> : <ChevronDown className="w-4 h-4 text-white/60" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}