/**
 * CoachAnalysisPanel — pitching matchup analysis + spray chart for current game.
 * Toggled between My Team / Opponent, Pitching / Hitting views.
 */
import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import SprayChart from '@/components/game/SprayChart';

const RESULT_LABELS = {
  single: '1B', double: '2B', triple: '3B', home_run: 'HR',
  walk: 'BB', hit_by_pitch: 'HBP', strikeout_looking: 'Kc',
  strikeout_swinging: 'K', ground_out: 'GO', fly_out: 'FO',
  line_out: 'LO', sacrifice_fly: 'SF', sacrifice_bunt: 'SH',
  double_play: 'DP', fielders_choice: 'FC', error: 'E',
  intentional_walk: 'IBB', in_progress: '…',
};

const HIT_RESULTS = new Set(['single','double','triple','home_run','walk','hit_by_pitch','intentional_walk']);

const PITCH_CFG = {
  B: '#22C55E', S: '#FACC15', F: '#FB923C', X: '#60A5FA',
};

function PitchingView({ atBats, pitchingTeamId }) {
  const [expandedBatter, setExpandedBatter] = useState(null);

  // At-bats where this team was FIELDING (batting_team_id !== pitchingTeamId)
  const relevant = atBats
    .filter(ab => ab.batting_team_id && ab.batting_team_id !== pitchingTeamId)
    .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

  const byBatter = {};
  relevant.forEach(ab => {
    const key = ab.batter_id || ab.batter_name || 'unknown';
    if (!byBatter[key]) byBatter[key] = { name: ab.batter_name || 'Unknown', atBats: [] };
    byBatter[key].atBats.push(ab);
  });

  const entries = Object.entries(byBatter);
  if (entries.length === 0) return <div className="p-4 text-center text-white/30 text-sm">No pitching data yet</div>;

  return (
    <div className="divide-y divide-white/5">
      {entries.map(([key, batter]) => {
        const isExp = expandedBatter === key;
        const totalP = batter.atBats.reduce((s, ab) => s + (ab.pitch_count || 0), 0);
        return (
          <div key={key}>
            <button
              className="w-full flex items-center gap-3 px-4 py-3 touch-manipulation hover:bg-white/5 transition-colors select-none"
              onClick={() => setExpandedBatter(isExp ? null : key)}
            >
              <div className="flex-1 text-left">
                <div className="font-semibold text-sm text-white">{batter.name}</div>
                <div className="text-xs text-white/40 mt-0.5">{batter.atBats.length} AB · {totalP} pitches</div>
              </div>
              <div className="flex gap-1 items-center flex-wrap justify-end max-w-[120px]">
                {batter.atBats.map((ab, i) => (
                  <span key={i} className="text-xs font-bold px-1.5 py-0.5 rounded"
                    style={{
                      backgroundColor: HIT_RESULTS.has(ab.result) ? 'rgba(74,222,128,0.18)' : 'rgba(248,113,113,0.18)',
                      color: HIT_RESULTS.has(ab.result) ? '#4ADE80' : '#F87171',
                    }}>
                    {RESULT_LABELS[ab.result] || '…'}
                  </span>
                ))}
              </div>
              {isExp ? <ChevronUp className="w-4 h-4 text-white/30 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-white/30 flex-shrink-0" />}
            </button>
            {isExp && (
              <div className="px-4 pb-3 space-y-2">
                {batter.atBats.map((ab, i) => (
                  <div key={ab.id || i} className="bg-white/5 rounded-xl p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-white/40">Inn. {ab.inning}{ab.inning_half === 'top' ? '▲' : '▼'} · AB #{i+1}</span>
                      <span className="text-xs font-bold px-2 py-0.5 rounded"
                        style={{
                          backgroundColor: HIT_RESULTS.has(ab.result) ? 'rgba(74,222,128,0.18)' : 'rgba(248,113,113,0.18)',
                          color: HIT_RESULTS.has(ab.result) ? '#4ADE80' : '#F87171',
                        }}>
                        {RESULT_LABELS[ab.result] || ab.result || '…'}
                      </span>
                    </div>
                    {ab.pitches?.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5">
                        {ab.pitches.map((p, pi) => (
                          <div key={pi} className="flex flex-col items-center gap-0.5">
                            <div className="w-6 h-6 rounded-full flex items-center justify-center"
                              style={{ backgroundColor: (PITCH_CFG[p] || '#6B7280') + '40', border: `1.5px solid ${PITCH_CFG[p] || '#6B7280'}` }}>
                              <span className="text-white font-bold" style={{ fontSize: 9 }}>{p}</span>
                            </div>
                            <span className="text-white/30" style={{ fontSize: 8 }}>{pi+1}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-xs text-white/30">{ab.balls ?? 0}-{ab.strikes ?? 0} count</div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function CoachAnalysisPanel({ game, atBats, players, myTeamId, oppTeamId }) {
  const [open, setOpen] = useState(true);
  const [mode, setMode] = useState('pitching'); // pitching | hitting
  const [side, setSide] = useState('my');       // my | opp

  const teamId = side === 'my' ? myTeamId : oppTeamId;

  return (
    <div className="bg-[hsl(214,90%,12%)] border border-white/10 rounded-xl overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-4 py-3 select-none touch-manipulation"
        onClick={() => setOpen(v => !v)}
      >
        <span className="font-semibold text-sm text-white">📊 Pitching &amp; Hitting Analysis</span>
        {open ? <ChevronUp className="w-4 h-4 text-white/40" /> : <ChevronDown className="w-4 h-4 text-white/40" />}
      </button>

      {open && (
        <>
          {/* Mode toggle */}
          <div className="flex border-t border-b border-white/10">
            {[['pitching','⚾ Pitching'],['hitting','🏏 Hitting']].map(([m, label]) => (
              <button key={m} onClick={() => setMode(m)}
                className={`flex-1 py-2.5 text-sm font-semibold transition-all select-none touch-manipulation ${mode === m ? 'bg-accent text-accent-foreground' : 'text-white/50 hover:text-white'}`}>
                {label}
              </button>
            ))}
          </div>

          {/* Team toggle */}
          <div className="flex gap-2 px-3 pt-3 pb-1">
            {[['my', myTeamId === game.home_team_id ? `🏠 ${game.home_team_name}` : `✈️ ${game.away_team_name}`],
              ['opp', oppTeamId === game.home_team_id ? `🏠 ${game.home_team_name}` : `✈️ ${game.away_team_name}`]].map(([s, label]) => (
              <button key={s} onClick={() => setSide(s)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all select-none touch-manipulation border ${
                  side === s ? 'bg-white/15 text-white border-white/30' : 'bg-transparent text-white/40 border-white/10'
                }`}>
                {label}
              </button>
            ))}
          </div>

          {mode === 'pitching' ? (
            <PitchingView atBats={atBats} pitchingTeamId={teamId} />
          ) : (
            <div className="p-3">
              <SprayChart
                gameId={game.id}
                teamId={teamId}
                isOpponent={false}
                players={players}
                emptyLabel="No hit data yet"
              />
            </div>
          )}
        </>
      )}
    </div>
  );
}