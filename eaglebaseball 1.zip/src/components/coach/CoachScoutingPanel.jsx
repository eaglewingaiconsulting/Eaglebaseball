/**
 * CoachScoutingPanel — opponent scouting report from PRIOR game data.
 * Only rendered when scoutAtBats.length > 0 (gate is in CoachDashboard).
 */
import { useState } from 'react';
import { ChevronDown, ChevronUp, Eye } from 'lucide-react';

const PITCH_COLORS = { B: '#22C55E', S: '#FACC15', F: '#FB923C', X: '#60A5FA' };

const RESULT_LABELS = {
  single: '1B', double: '2B', triple: '3B', home_run: 'HR',
  walk: 'BB', hit_by_pitch: 'HBP', strikeout_looking: 'Kc',
  strikeout_swinging: 'K', ground_out: 'GO', fly_out: 'FO',
  line_out: 'LO', sacrifice_fly: 'SF', sacrifice_bunt: 'SH',
  double_play: 'DP', fielders_choice: 'FC', error: 'E',
  intentional_walk: 'IBB',
};

const HIT_RESULTS = new Set(['single','double','triple','home_run','walk','hit_by_pitch','intentional_walk']);
const POWER_RESULTS = new Set(['home_run','triple','double']);

function computeStats(abs) {
  const official = abs.filter(ab => ab.result && ab.result !== 'in_progress' &&
    !['walk','hit_by_pitch','intentional_walk','sacrifice_fly','sacrifice_bunt'].includes(ab.result));
  const hits = abs.filter(ab => ['single','double','triple','home_run'].includes(ab.result));
  const walks = abs.filter(ab => ['walk','intentional_walk','hit_by_pitch'].includes(ab.result));
  const ks = abs.filter(ab => ['strikeout_looking','strikeout_swinging'].includes(ab.result));
  const power = abs.filter(ab => POWER_RESULTS.has(ab.result));
  const avg = official.length > 0 ? (hits.length / official.length) : 0;
  return {
    ab: official.length, h: hits.length, avg: avg.toFixed(3),
    bb: walks.length, k: ks.length, xbh: power.length,
  };
}

function ScoutRow({ name, abs, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  const stats = computeStats(abs);
  const threat = parseFloat(stats.avg) >= 0.300 || stats.xbh > 0;

  return (
    <div className="border-b border-white/5 last:border-0">
      <button
        className="w-full flex items-center gap-3 px-4 py-3 touch-manipulation select-none hover:bg-white/5 transition-colors"
        onClick={() => setOpen(v => !v)}
      >
        <div className="flex-1 text-left">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-white">{name}</span>
            {threat && <span className="text-[10px] bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded-full font-bold">⚠ WATCH</span>}
          </div>
          <div className="text-xs text-white/40 mt-0.5">
            {stats.ab} AB · {stats.h} H · AVG {stats.avg} · {stats.k}K · {stats.bb}BB
            {stats.xbh > 0 ? ` · ${stats.xbh} XBH` : ''}
          </div>
        </div>
        <div className="flex gap-1 flex-wrap justify-end max-w-[100px]">
          {abs.slice(-5).map((ab, i) => (
            <span key={i} className="text-xs font-bold px-1 py-0.5 rounded"
              style={{
                backgroundColor: HIT_RESULTS.has(ab.result) ? 'rgba(74,222,128,0.18)' : 'rgba(255,255,255,0.06)',
                color: HIT_RESULTS.has(ab.result) ? '#4ADE80' : '#9CA3AF',
                fontSize: 10,
              }}>
              {RESULT_LABELS[ab.result] || '?'}
            </span>
          ))}
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-white/30 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-white/30 flex-shrink-0" />}
      </button>

      {open && (
        <div className="px-4 pb-3 space-y-1.5">
          <div className="text-xs text-white/30 uppercase tracking-wider font-semibold mb-2">Recent At-Bats (prior games)</div>
          {abs.map((ab, i) => (
            <div key={ab.id || i} className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
              <span className="text-xs text-white/40">Inn. {ab.inning}{ab.inning_half === 'top' ? '▲' : '▼'}</span>
              {ab.pitches?.length > 0 && (
              <div className="flex gap-1">
              {ab.pitches.map((p, pi) => {
                const pc = PITCH_COLORS[p] || '#6B7280';
                return (
                  <span key={pi} className="text-[10px] font-bold px-1 py-0.5 rounded"
                    style={{ backgroundColor: pc + '33', color: pc }}>
                    {p}
                  </span>
                );
              })}
              </div>
              )}
              <span className="text-xs font-bold px-1.5 py-0.5 rounded"
                style={{
                  backgroundColor: HIT_RESULTS.has(ab.result) ? 'rgba(74,222,128,0.18)' : 'rgba(248,113,113,0.18)',
                  color: HIT_RESULTS.has(ab.result) ? '#4ADE80' : '#F87171',
                }}>
                {RESULT_LABELS[ab.result] || '?'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function CoachScoutingPanel({ scoutAtBats, oppTeamId, oppTeamName, players }) {
  const [open, setOpen] = useState(false);

  // Group by batter name (prior games may not have player IDs matching current DB)
  const byBatter = {};
  scoutAtBats.forEach(ab => {
    const key = ab.batter_name || ab.batter_id || 'Unknown';
    if (!byBatter[key]) byBatter[key] = [];
    byBatter[key].push(ab);
  });

  // Sort by most at-bats / highest threat
  const entries = Object.entries(byBatter).sort((a, b) => {
    const statsA = computeStats(a[1]);
    const statsB = computeStats(b[1]);
    // Threats first, then by AB count
    const threatA = parseFloat(statsA.avg) >= 0.300 || statsA.xbh > 0 ? 1 : 0;
    const threatB = parseFloat(statsB.avg) >= 0.300 || statsB.xbh > 0 ? 1 : 0;
    if (threatB !== threatA) return threatB - threatA;
    return b[1].length - a[1].length;
  });

  return (
    <div className="bg-[hsl(214,90%,12%)] border border-amber-500/30 rounded-xl overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-4 py-3 select-none touch-manipulation"
        onClick={() => setOpen(v => !v)}
      >
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-amber-400" />
          <span className="font-semibold text-sm text-white">Scouting Report</span>
          <span className="text-xs text-amber-400/70 font-normal">{oppTeamName}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full font-semibold">{entries.length} batters</span>
          {open ? <ChevronUp className="w-4 h-4 text-white/40" /> : <ChevronDown className="w-4 h-4 text-white/40" />}
        </div>
      </button>

      {open && (
        <div className="border-t border-white/10">
          <div className="px-4 py-2 bg-amber-500/5 text-xs text-amber-400/70 italic border-b border-white/5">
            Based on {scoutAtBats.length} at-bats from prior games vs this opponent
          </div>
          {entries.map(([name, abs]) => (
            <ScoutRow key={name} name={name} abs={abs} />
          ))}
        </div>
      )}
    </div>
  );
}