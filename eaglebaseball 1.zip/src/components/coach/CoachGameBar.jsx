/** Compact scoreboard + diamond + count bar at top of Coach Dashboard */
import GameTimerDisplay from '@/components/scoring/GameTimerDisplay';

export default function CoachGameBar({ game }) {
  const isLive = game.status === 'in_progress';
  return (
    <div className="bg-[hsl(214,90%,10%)] border-b border-white/10 px-4 py-3 flex items-center justify-between gap-3 flex-shrink-0">
      {/* Score */}
      <div className="text-center min-w-[64px]">
        <div className="font-bebas text-4xl leading-none tracking-wider text-white">
          {game.away_score ?? 0}–{game.home_score ?? 0}
        </div>
        <div className="text-white/40 text-[10px] mt-0.5 truncate max-w-[120px]">
          {game.away_team_name} vs {game.home_team_name}
        </div>
      </div>

      {isLive && (
        <div className="flex items-center gap-4">
          {/* Inning + outs */}
          <div className="text-center">
            <div className="text-white font-bold text-lg leading-none">
              {game.inning_half === 'top' ? '▲' : '▼'} {game.inning}
            </div>
            <div className="text-white/40 text-xs mt-0.5">{game.outs ?? 0} out{game.outs !== 1 ? 's' : ''}</div>
          </div>

          {/* Count */}
          <div className="text-center">
            <div className="text-white font-bold text-lg leading-none">
              {game.balls ?? 0}-{game.strikes ?? 0}
            </div>
            <div className="text-white/40 text-xs mt-0.5">count</div>
          </div>

          {/* Diamond */}
          <svg viewBox="0 0 48 48" width="44" height="44">
            {[
              { cx: 24, cy: 8,  filled: game.runner_second },
              { cx: 8,  cy: 24, filled: game.runner_third  },
              { cx: 40, cy: 24, filled: game.runner_first  },
              { cx: 24, cy: 40, filled: false              },
            ].map(({ cx, cy, filled }, i) => (
              <rect key={i} x={cx - 7} y={cy - 7} width={14} height={14} rx={2}
                fill={filled ? '#F59E0B' : 'transparent'}
                stroke={filled ? '#F59E0B' : '#4B5563'}
                strokeWidth={2}
                transform={`rotate(45, ${cx}, ${cy})`} />
            ))}
          </svg>
        </div>
      )}

      {!isLive && (
        <div className="text-xs font-bold text-white/40 bg-white/5 px-2 py-1 rounded-full">
          {game.status === 'final' || game.status === 'completed' ? 'FINAL' : game.status.toUpperCase()}
        </div>
      )}
      {game.time_limit_minutes > 0 && (
        <GameTimerDisplay game={game} compact />
      )}
    </div>
  );
}