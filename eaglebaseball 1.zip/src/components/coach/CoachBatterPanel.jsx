/**
 * CoachBatterPanel — current batter card with at-bat history this game
 * and live balls/strikes count.
 */
import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const RESULT_LABELS = {
  single: '1B', double: '2B', triple: '3B', home_run: 'HR',
  walk: 'BB', hit_by_pitch: 'HBP', strikeout_looking: 'Kc',
  strikeout_swinging: 'K', ground_out: 'GO', fly_out: 'FO',
  line_out: 'LO', sacrifice_fly: 'SF', sacrifice_bunt: 'SH',
  double_play: 'DP', fielders_choice: 'FC', error: 'E',
  intentional_walk: 'IBB', in_progress: '…',
};

const HIT_RESULTS = new Set(['single','double','triple','home_run','walk','hit_by_pitch','intentional_walk']);

function ResultBadge({ result, size = 'sm' }) {
  const hit = HIT_RESULTS.has(result);
  return (
    <span className={`font-bold rounded px-1.5 py-0.5 ${size === 'lg' ? 'text-sm' : 'text-xs'}`}
      style={{
        backgroundColor: hit ? 'rgba(74,222,128,0.18)' : 'rgba(248,113,113,0.18)',
        color: hit ? '#4ADE80' : '#F87171',
      }}>
      {RESULT_LABELS[result] || result || '…'}
    </span>
  );
}

const PITCH_CFG = {
  B: { bg: '#22C55E', label: 'Ball' },
  S: { bg: '#FACC15', label: 'Strike' },
  F: { bg: '#FB923C', label: 'Foul' },
  X: { bg: '#60A5FA', label: 'In Play' },
};

export default function CoachBatterPanel({ game, players, atBats }) {
  const [historyOpen, setHistoryOpen] = useState(false);

  const batter = game.current_batter_id ? players.find(p => p.id === game.current_batter_id) : null;

  const batterHistory = atBats
    .filter(ab => ab.batter_id === game.current_batter_id && ab.result && ab.result !== 'in_progress')
    .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

  const lastAB = batterHistory[batterHistory.length - 1] || null;

  return (
    <div className="bg-[hsl(214,90%,12%)] border border-white/10 rounded-xl overflow-hidden">
      <div className="px-4 py-2.5 border-b border-white/10 flex items-center justify-between">
        <span className="text-xs text-white/40 uppercase tracking-wider font-semibold">⚾ Current Batter</span>
        {batterHistory.length > 0 && (
          <button onClick={() => setHistoryOpen(v => !v)}
            className="flex items-center gap-1 text-xs text-white/50 touch-manipulation select-none">
            {batterHistory.length} AB {historyOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        )}
      </div>

      {batter ? (
        <div className="p-3 space-y-3">
          {/* Identity row */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-white/10 border border-white/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
              {batter.photo_thumb_url
                ? <img src={batter.photo_thumb_url} alt={batter.name} className="w-full h-full object-cover" />
                : <span className="font-bold text-sm text-white">#{batter.number}</span>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-white">{batter.name}</div>
              <div className="text-white/50 text-xs">{batter.position} · #{batter.number} · {batter.bats === 'L' ? 'LHB' : batter.bats === 'S' ? 'Switch' : 'RHB'}</div>
            </div>
            {/* Season avg */}
            <div className="text-right flex-shrink-0">
              <div className="font-bebas text-2xl text-accent leading-none">{batter.batting_avg ? batter.batting_avg.toFixed(3) : '.000'}</div>
              <div className="text-white/30 text-xs">AVG</div>
            </div>
          </div>

          {/* Live count */}
          <div className="bg-white/5 rounded-xl px-4 py-3 flex items-center justify-around">
            {[
              { label: 'Balls',   count: game.balls   ?? 0, max: 4, color: '#22C55E' },
              { label: 'Strikes', count: game.strikes ?? 0, max: 3, color: '#FACC15' },
              { label: 'Outs',    count: game.outs    ?? 0, max: 3, color: '#F87171' },
            ].map(({ label, count, max, color }) => (
              <div key={label} className="text-center">
                <div className="text-xs text-white/40 font-semibold mb-1.5">{label}</div>
                <div className="flex gap-1 justify-center">
                  {Array.from({ length: max }, (_, i) => (
                    <div key={i} className="w-4 h-4 rounded-full border-2 transition-colors"
                      style={{ backgroundColor: i < count ? color : 'transparent', borderColor: i < count ? color : '#374151' }} />
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Last AB quick line */}
          {lastAB && (
            <div className="flex items-center justify-between px-3 py-2 bg-white/5 rounded-xl">
              <span className="text-xs text-white/40 font-semibold">LAST AB</span>
              <div className="flex items-center gap-2">
                <ResultBadge result={lastAB.result} size="lg" />
                <span className="text-xs text-white/30">Inn. {lastAB.inning}{lastAB.inning_half === 'top' ? '▲' : '▼'}</span>
              </div>
            </div>
          )}

          {/* Expanded AB history */}
          {historyOpen && batterHistory.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs text-white/30 uppercase tracking-wider font-semibold">At-Bat History This Game</div>
              {batterHistory.map((ab, i) => (
                <div key={ab.id || i} className="bg-white/5 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-white/40">AB #{i + 1} · Inn. {ab.inning}{ab.inning_half === 'top' ? '▲' : '▼'}</span>
                    <ResultBadge result={ab.result} />
                  </div>
                  {ab.pitches && ab.pitches.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5">
                      {ab.pitches.map((p, pi) => {
                        const cfg = PITCH_CFG[p] || { bg: '#6B7280', label: p };
                        return (
                          <div key={pi} className="flex flex-col items-center gap-0.5">
                            <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ backgroundColor: cfg.bg + '40', border: `1.5px solid ${cfg.bg}` }}>
                              <span className="text-white font-bold" style={{ fontSize: 9 }}>{p}</span>
                            </div>
                            <span className="text-white/30" style={{ fontSize: 8 }}>{pi + 1}</span>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-xs text-white/30">{ab.balls ?? 0}-{ab.strikes ?? 0} count · {ab.pitch_count ?? 0} pitches</div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div className="p-4 text-center text-white/30 text-sm">No active batter</div>
      )}
    </div>
  );
}