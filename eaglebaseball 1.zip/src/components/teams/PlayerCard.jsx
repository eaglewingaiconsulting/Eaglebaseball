const POSITION_COLORS = {
  P: 'bg-red-100 text-red-700', C: 'bg-blue-100 text-blue-700',
  '1B': 'bg-green-100 text-green-700', '2B': 'bg-green-100 text-green-700',
  '3B': 'bg-green-100 text-green-700', SS: 'bg-purple-100 text-purple-700',
  LF: 'bg-amber-100 text-amber-700', CF: 'bg-amber-100 text-amber-700',
  RF: 'bg-amber-100 text-amber-700', DH: 'bg-gray-100 text-gray-700',
  UT: 'bg-gray-100 text-gray-700',
};

import { useNavigate } from 'react-router-dom';
import { PlayerAvatar } from '@/components/player/PlayerPhotoUpload';

export default function PlayerCard({ player, onClick, selected }) {
  const navigate = useNavigate();
  const handleClick = onClick || (() => navigate(`/players/${player.id}`));
  return (
    <div
      onClick={handleClick}
      className={`bg-card border rounded-xl p-3.5 flex items-center gap-3 transition-all ${
        selected ? 'border-primary ring-2 ring-primary/20 shadow-sm' : 'border-border hover:border-primary/40'
      } cursor-pointer`}
    >
      <div className="relative flex-shrink-0">
        <PlayerAvatar player={player} size="sm" />
        <span className="absolute -bottom-1 -right-1 text-xs bg-primary text-primary-foreground rounded px-0.5 font-bold leading-none py-0.5">
          #{player.number}
        </span>
      </div>
      <div className="min-w-0 flex-1">
        <div className="font-semibold text-sm truncate">{player.name}</div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${POSITION_COLORS[player.position] || 'bg-gray-100 text-gray-700'}`}>
            {player.position}
          </span>
          <span className="text-xs text-muted-foreground">{player.bats}/{player.throws}</span>
        </div>
      </div>
      <div className="text-right flex-shrink-0">
        <div className="text-xs font-medium">{player.batting_avg ? player.batting_avg.toFixed(3) : '.000'}</div>
        <div className="text-xs text-muted-foreground">AVG</div>
      </div>
    </div>
  );
}