import { useState } from 'react';
import { X, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

const POSITIONS = ['P', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH', 'UT'];

/**
 * PlayerFormModal — Add or Edit a player
 * Props:
 *   teamId        – team ID
 *   players       – all players on this team (for duplicate jersey check)
 *   player        – if provided, edit mode; otherwise add mode
 *   onSave(player) – called with the created/updated player record
 *   onDelete(id)  – called after soft-delete confirmation
 *   onClose()     – dismiss modal
 */
export default function PlayerFormModal({ teamId, players, player, onSave, onDelete, onClose }) {
  const isEdit = !!player;

  const [form, setForm] = useState({
    name: player?.name || '',
    number: player?.number || '',
    position: player?.position || 'P',
    bats: player?.bats || 'R',
    throws: player?.throws || 'R',
  });
  const [saving, setSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [hasStats, setHasStats] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleSave = async () => {
    if (!form.name.trim()) {
      toast.error('Full name is required');
      return;
    }
    if (!form.number.trim()) {
      toast.error('Jersey number is required');
      return;
    }
    // Duplicate jersey check (exclude self in edit mode)
    const duplicate = players.find(p =>
      p.number === form.number.trim() &&
      p.id !== player?.id
    );
    if (duplicate) {
      toast.error(`Jersey #${form.number} is already taken by ${duplicate.name}`);
      return;
    }

    setSaving(true);
    try {
      let saved;
      if (isEdit) {
        saved = await base44.entities.Player.update(player.id, form);
        toast.success('Player updated ✅');
      } else {
        saved = await base44.entities.Player.create({ ...form, team_id: teamId });
        toast.success('Player added!');
      }
      onSave(saved);
    } finally {
      setSaving(false);
    }
  };

  const handleDeletePress = async () => {
    // Check for stats
    const logs = await base44.entities.PlayLog.filter({ player_id: player.id });
    setHasStats(logs.length > 0);
    setShowDeleteConfirm(true);
  };

  const handleDeleteConfirm = async () => {
    setDeleting(true);
    try {
      // Soft delete — mark inactive
      await base44.entities.Player.update(player.id, { is_active: false });
      toast.success(`${player.name} removed from roster`);
      onDelete(player.id);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-end sm:items-center justify-center">
      <div className="bg-card border border-border rounded-t-2xl sm:rounded-2xl w-full max-w-sm shadow-2xl flex flex-col"
        style={{ maxHeight: '92dvh' }}>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border flex-shrink-0">
          <h2 className="font-bold text-lg">{isEdit ? 'Edit Player' : 'Add Player'}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted touch-manipulation">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable form body */}
        <div className="flex-1 overflow-y-auto overscroll-contain">
          <div className="p-4 space-y-4 pb-8">
            <div>
              <Label className="text-xs mb-1.5 block">Full Name *</Label>
              <Input
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Enter player's full name"
                autoComplete="off"
              />
            </div>

            <div>
              <Label className="text-xs mb-1.5 block">Jersey Number *</Label>
              <Input
                value={form.number}
                onChange={e => setForm(f => ({ ...f, number: e.target.value }))}
                placeholder="00"
                inputMode="numeric"
              />
            </div>

            <div>
              <Label className="text-xs mb-1.5 block">Position</Label>
              <Select value={form.position} onValueChange={v => setForm(f => ({ ...f, position: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {POSITIONS.map(pos => <SelectItem key={pos} value={pos}>{pos}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs mb-1.5 block">Bats</Label>
                <Select value={form.bats} onValueChange={v => setForm(f => ({ ...f, bats: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="R">R</SelectItem>
                    <SelectItem value="L">L</SelectItem>
                    <SelectItem value="S">S</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs mb-1.5 block">Throws</Label>
                <Select value={form.throws} onValueChange={v => setForm(f => ({ ...f, throws: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="R">R</SelectItem>
                    <SelectItem value="L">L</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {isEdit && (
              <button
                onClick={handleDeletePress}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-destructive/40 text-destructive text-sm font-medium hover:bg-destructive/10 transition-colors touch-manipulation mt-2"
              >
                <Trash2 className="w-4 h-4" /> Remove Player
              </button>
            )}
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-border flex-shrink-0 flex gap-3 pb-safe">
          <Button variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
          <Button className="flex-1" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving...' : isEdit ? 'Save Changes' : 'Add Player'}
          </Button>
        </div>
      </div>

      {/* Delete confirmation */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[60] bg-black/60 flex items-center justify-center p-6">
          <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-sm space-y-4 shadow-2xl">
            <h3 className="font-bold text-base">Remove {player.name}?</h3>
            {hasStats ? (
              <p className="text-sm text-muted-foreground">
                {player.name} has game stats on record. Removing them will preserve their stats history but they will no longer appear on the active roster.
              </p>
            ) : (
              <p className="text-sm text-muted-foreground">
                This will remove {player.name} from the roster. This cannot be undone.
              </p>
            )}
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setShowDeleteConfirm(false)}>Cancel</Button>
              <Button variant="destructive" className="flex-1" onClick={handleDeleteConfirm} disabled={deleting}>
                {deleting ? 'Removing...' : hasStats ? 'Remove Anyway' : 'Remove'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}