import { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Upload, Loader2, X } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

/**
 * Reusable logo + color scheme editor.
 * Props:
 *   logoUrl        - current logo URL string
 *   primaryColor   - current primary color hex
 *   secondaryColor - current secondary color hex
 *   name           - entity name (for initials preview)
 *   onChange       - fn({ logo_url?, primary_color?, secondary_color? })
 */
export default function LogoBrandingEditor({ logoUrl, primaryColor = '#1e3a8a', secondaryColor = '#f59e0b', name = '', onChange }) {
  const [uploading, setUploading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const fileRef = useRef();

  const initials = name ? name.slice(0, 2).toUpperCase() : '??';

  const handleLogoUpload = async (file) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Please select an image file'); return; }
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onChange({ logo_url: file_url });
      toast.success('Logo uploaded! Analyzing colors & enhancing…');

      // Run color extraction and AI enhancement in parallel
      setUploading(false);
      setEnhancing(true);

      const [colorResult, enhancedResult] = await Promise.all([
        base44.integrations.Core.InvokeLLM({
          prompt: `Look at this sports team logo. Identify the two most prominent non-white, non-black colors.
Return primary_color (most dominant color, e.g. navy, red, green) and secondary_color (accent, e.g. gold, orange, white-ish).
Return valid hex codes only. Do NOT return #000000 or #ffffff unless the logo is purely monochrome.`,
          file_urls: [file_url],
          model: 'claude_sonnet_4_6',
          response_json_schema: {
            type: 'object',
            properties: {
              primary_color: { type: 'string' },
              secondary_color: { type: 'string' },
            },
          },
        }),
        base44.integrations.Core.GenerateImage({
          prompt: `Recreate this sports team logo as a clean, sharp, professional vector-style emblem. Preserve all original colors, text, mascot, and design elements exactly. Make it crisp, high-resolution, with clean edges and vivid colors. Transparent-friendly white or transparent background.`,
          existing_image_urls: [file_url],
        }),
      ]);

      // Apply colors
      const normalizeHex = (val) => {
        if (!val) return null;
        const hex = val.trim().startsWith('#') ? val.trim() : `#${val.trim()}`;
        return /^#[0-9a-fA-F]{6}$/.test(hex) ? hex.toLowerCase() : null;
      };
      const primary = normalizeHex(colorResult?.primary_color);
      const secondary = normalizeHex(colorResult?.secondary_color);
      const colorUpdates = {
        ...(primary && { primary_color: primary }),
        ...(secondary && { secondary_color: secondary }),
      };

      // Upload enhanced logo
      const { file_url: enhanced_url } = await base44.integrations.Core.UploadFile({ file: enhancedResult.url });
      onChange({ logo_url: enhanced_url, ...colorUpdates });
      toast.success(primary ? 'Logo enhanced & colors detected!' : 'Logo enhanced!');
    } catch {
      toast.error('Upload failed — try again');
    } finally {
      setUploading(false);
      setEnhancing(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Logo preview + upload */}
      <div className="flex items-center gap-4">
        <div
          className="w-20 h-20 rounded-2xl flex items-center justify-center text-white text-xl font-bold flex-shrink-0 overflow-hidden border-2 border-border shadow"
          style={{ backgroundColor: primaryColor }}
        >
          {logoUrl ? (
            <img src={logoUrl} alt="Logo" className="w-full h-full object-contain" />
          ) : (
            <span>{initials}</span>
          )}
        </div>
        <div className="flex-1 space-y-2">
          <Label>Team / Org Logo</Label>
          <div className="flex gap-2">
            <button
              type="button"
              disabled={uploading || enhancing}
              onClick={() => fileRef.current?.click()}
              className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-muted hover:bg-secondary text-sm font-medium transition-colors select-none touch-manipulation disabled:opacity-60"
            >
              {(uploading || enhancing) ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              {uploading ? 'Uploading…' : enhancing ? 'Enhancing…' : 'Upload Logo'}
            </button>
            {logoUrl && (
              <button
                type="button"
                onClick={() => onChange({ logo_url: '' })}
                className="p-2 rounded-lg border border-border bg-muted hover:bg-destructive/10 hover:text-destructive text-muted-foreground transition-colors select-none"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <p className="text-xs text-muted-foreground">PNG, JPG, SVG — max 5 MB</p>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={e => { handleLogoUpload(e.target.files?.[0]); e.target.value = ''; }}
        />
      </div>

      {/* Color pickers */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label>Primary Color</Label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={primaryColor}
              onChange={e => onChange({ primary_color: e.target.value })}
              className="w-10 h-10 rounded cursor-pointer border border-border flex-shrink-0"
            />
            <Input
              value={primaryColor}
              onChange={e => onChange({ primary_color: e.target.value })}
              className="font-mono text-sm"
              maxLength={7}
            />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>Secondary Color</Label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={secondaryColor}
              onChange={e => onChange({ secondary_color: e.target.value })}
              className="w-10 h-10 rounded cursor-pointer border border-border flex-shrink-0"
            />
            <Input
              value={secondaryColor}
              onChange={e => onChange({ secondary_color: e.target.value })}
              className="font-mono text-sm"
              maxLength={7}
            />
          </div>
        </div>
      </div>

      {/* Color preview swatch */}
      <div className="flex items-center gap-2 p-3 rounded-xl border border-border bg-muted/40">
        <div className="flex-1 h-6 rounded-md" style={{ backgroundColor: primaryColor }} />
        <div className="flex-1 h-6 rounded-md" style={{ backgroundColor: secondaryColor }} />
        <span className="text-xs text-muted-foreground ml-1">Preview</span>
      </div>
    </div>
  );
}