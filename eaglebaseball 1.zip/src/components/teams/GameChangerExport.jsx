import { useRef, useEffect, useState } from 'react';
import { X, Download, FileDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function GameChangerExport({ team, players, onClose }) {
  const canvasRef = useRef(null);

  // Build CSV
  const csvRows = [
    ['First Name', 'Last Name', 'Jersey Number', 'Position', 'Bats', 'Throws', 'Parent Email'],
    ...players.map(p => {
      const parts = p.name.trim().split(' ');
      const firstName = parts[0] || '';
      const lastName = parts.slice(1).join(' ') || '';
      return [firstName, lastName, p.number || '', p.position || '', p.bats || '', p.throws || '', p.parent_email || ''];
    })
  ];
  const csvContent = csvRows.map(r => r.map(v => `"${v}"`).join(',')).join('\n');
  const downloadUrl = `data:text/csv;charset=utf-8,${encodeURIComponent(csvContent)}`;
  const qrTarget = `${window.location.origin}/teams/${team.id}/export-csv`;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => ctx.drawImage(img, 0, 0, 200, 200);
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(downloadUrl)}`;
  }, [downloadUrl]);

  const downloadCSV = () => {
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `${team.name.replace(/\s+/g, '_')}_roster_gamechanger.csv`;
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div className="bg-card border border-border rounded-2xl p-6 max-w-sm w-full shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-semibold flex items-center gap-2"><FileDown className="w-4 h-4" /> Export to GameChanger</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{players.length} players · CSV format</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted"><X className="w-4 h-4" /></button>
        </div>

        <div className="bg-white rounded-xl p-4 flex items-center justify-center mb-4">
          <canvas ref={canvasRef} width={200} height={200} />
        </div>

        <p className="text-xs text-muted-foreground text-center mb-4">
          Scan QR code or click download to get the GameChanger-formatted CSV
        </p>

        <div className="flex gap-2">
          <Button variant="outline" className="flex-1 gap-1.5" onClick={onClose}>Cancel</Button>
          <Button className="flex-1 gap-1.5" onClick={downloadCSV}>
            <Download className="w-4 h-4" /> Download CSV
          </Button>
        </div>
      </div>
    </div>
  );
}