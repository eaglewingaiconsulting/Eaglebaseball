import { useState, useRef } from 'react';
import { X, Camera, Upload, RefreshCw, Check, AlertCircle, Loader2, ImageIcon, ZoomIn, Plus, Trash2, Pencil } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

/**
 * RosterPhotoImporter
 * Imports players from a roster photo (team sheet, roster card, etc.)
 * Props:
 *   teamId       – the team
 *   onConfirm    – callback({ players: [...{name, number, position}], photoUrl: string })
 *   onClose      – cancel callback
 */
export default function RosterPhotoImporter({ teamId, onConfirm, onClose }) {
  const [stage, setStage] = useState('pick'); // pick | preview | parsing | review | error
  const [photoFile, setPhotoFile] = useState(null);
  const [photoDataUrl, setPhotoDataUrl] = useState(null);
  const [uploadedPhotoUrl, setUploadedPhotoUrl] = useState(null);
  const [rows, setRows] = useState([]); // { name, number, position, editMode }
  const [editingIdx, setEditingIdx] = useState(null);
  const [editDraft, setEditDraft] = useState({});
  const [errorMsg, setErrorMsg] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [showPhotoViewer, setShowPhotoViewer] = useState(false);
  const [showDiscardConfirm, setShowDiscardConfirm] = useState(false);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);

  const positions = ['P', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH', 'UT'];

  const handleFile = (file) => {
    if (!file) return;
    setPhotoFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setPhotoDataUrl(e.target.result);
      setStage('preview');
    };
    reader.readAsDataURL(file);
  };

  const parsePhoto = async () => {
    setStage('parsing');
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: photoFile });
      setUploadedPhotoUrl(file_url);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `This is a photo of a baseball team roster sheet (likely Rawlings format).
Extract the player roster as a JSON array.
For each player row, look for columns labeled "No" (jersey number) and "POS" (position).
Return exactly: name (player name string), number (from "No" column - jersey number string), position (from "POS" column - P, C, 1B, 2B, 3B, SS, LF, CF, RF, DH, or UT).
If a field is not visible, use empty string "".
Return ONLY the JSON, no explanation.`,
        file_urls: [file_url],
        response_json_schema: {
          type: 'object',
          properties: {
            roster: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  number: { type: 'string' },
                  position: { type: 'string' },
                },
              },
            },
          },
        },
      });

      const entries = result?.roster || [];
      if (!entries.length) throw new Error('No roster entries found. Please retake with better lighting.');

      setRows(entries.map(e => ({
        name: e.name || '',
        number: e.number || '',
        position: e.position || '',
      })));
      setStage('review');
    } catch (err) {
      setErrorMsg(err.message || 'Could not parse roster. Try again with a clearer photo.');
      setStage('error');
    }
  };

  const retake = () => {
    setPhotoFile(null);
    setPhotoDataUrl(null);
    setUploadedPhotoUrl(null);
    setRows([]);
    setEditingIdx(null);
    setErrorMsg('');
    setStage('pick');
  };

  const startEdit = (idx) => {
    setEditingIdx(idx);
    setEditDraft({ ...rows[idx] });
  };

  const saveEdit = () => {
    if (!editDraft.name?.trim()) {
      toast.error('Player name is required');
      return;
    }
    setRows(prev => prev.map((r, i) => i === editingIdx ? { ...editDraft } : r));
    setEditingIdx(null);
  };

  const cancelEdit = () => setEditingIdx(null);

  const removeRow = (idx) => {
    setRows(prev => prev.filter((_, i) => i !== idx));
    if (editingIdx === idx) setEditingIdx(null);
  };

  const addRow = () => {
    const newRow = { name: '', number: '', position: '' };
    setRows(prev => [...prev, newRow]);
    setEditingIdx(rows.length);
    setEditDraft(newRow);
  };

  const handleConfirm = async () => {
    const blankName = rows.findIndex(r => !r.name?.trim());
    if (blankName !== -1) {
      toast.error('All players must have a name');
      return;
    }

    setConfirming(true);
    try {
      await onConfirm({ players: rows, photoUrl: uploadedPhotoUrl });
    } finally {
      setConfirming(false);
    }
  };

  const handleBack = () => {
    if (stage === 'review') {
      setShowDiscardConfirm(true);
    } else {
      onClose();
    }
  };

  const photoSrc = uploadedPhotoUrl || photoDataUrl;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
        <div className="bg-card border border-border rounded-2xl w-full max-w-sm shadow-2xl flex flex-col max-h-[92vh]">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border flex-shrink-0">
            <div className="flex items-center gap-2">
              {stage !== 'pick' && (
                <button onClick={handleBack} className="p-1.5 rounded-lg hover:bg-muted touch-manipulation">
                  <X className="w-4 h-4" />
                </button>
              )}
              <div>
                <h2 className="font-semibold text-sm">Import Roster from Photo</h2>
                <p className="text-xs text-muted-foreground">
                  {stage === 'pick'    && 'Photo the roster sheet'}
                  {stage === 'preview' && 'Review photo before scanning'}
                  {stage === 'parsing' && 'AI is reading the roster...'}
                  {stage === 'review'  && `${rows.length} players — tap to edit`}
                  {stage === 'error'   && 'Something went wrong'}
                </p>
              </div>
            </div>
            {stage === 'pick' && (
              <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted touch-manipulation">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto">

            {/* Pick */}
            {stage === 'pick' && (
              <div className="p-6 flex flex-col items-center gap-4 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <ImageIcon className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <p className="font-medium mb-1">Photo the roster sheet</p>
                  <p className="text-xs text-muted-foreground">Take or upload a photo of the team roster. AI will extract player names, numbers, and positions.</p>
                </div>
                <div className="w-full space-y-2">
                  <Button className="w-full gap-2" onClick={() => cameraInputRef.current?.click()}>
                    <Camera className="w-4 h-4" /> Take Photo
                  </Button>
                  <Button variant="outline" className="w-full gap-2" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="w-4 h-4" /> Choose from Library
                  </Button>
                </div>
                <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden"
                  onChange={e => { handleFile(e.target.files?.[0]); e.target.value = ''; }} />
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden"
                  onChange={e => { handleFile(e.target.files?.[0]); e.target.value = ''; }} />
              </div>
            )}

            {/* Preview */}
            {stage === 'preview' && photoDataUrl && (
              <div className="p-4 space-y-3">
                <img src={photoDataUrl} alt="Roster sheet" className="w-full rounded-xl object-contain max-h-64 bg-black" />
                <p className="text-xs text-muted-foreground text-center">Looks good? Tap "Scan Roster" to extract player names and positions.</p>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 gap-1.5" onClick={retake}>
                    <RefreshCw className="w-4 h-4" /> Retake
                  </Button>
                  <Button className="flex-1 gap-1.5" onClick={parsePhoto}>
                    <Camera className="w-4 h-4" /> Scan Roster
                  </Button>
                </div>
              </div>
            )}

            {/* Parsing */}
            {stage === 'parsing' && (
              <div className="h-48 flex flex-col items-center justify-center gap-3 text-muted-foreground">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
                <span className="text-sm font-medium">Reading roster sheet...</span>
                <span className="text-xs text-muted-foreground">This takes a few seconds</span>
              </div>
            )}

            {/* Error */}
            {stage === 'error' && (
              <div className="p-5 flex flex-col items-center gap-4 text-center">
                <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-destructive" />
                </div>
                <p className="text-sm text-destructive font-medium">Import Failed</p>
                <p className="text-xs text-muted-foreground">{errorMsg}</p>
                <div className="flex gap-2 w-full">
                  <Button variant="outline" className="flex-1" onClick={onClose}>Close</Button>
                  <Button className="flex-1" onClick={retake}>Try Again</Button>
                </div>
              </div>
            )}

            {/* Review */}
            {stage === 'review' && (
              <div className="p-4 space-y-3">
                {photoSrc && (
                  <button
                    onClick={() => setShowPhotoViewer(true)}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-muted/50 hover:bg-muted text-sm font-medium touch-manipulation"
                  >
                    <Camera className="w-4 h-4 text-primary" />
                    📷 View Source Photo
                    <ZoomIn className="w-3.5 h-3.5 ml-auto text-muted-foreground" />
                  </button>
                )}

                <p className="text-xs text-muted-foreground">Tap ✏️ to edit any row before saving.</p>

                <div className="space-y-2">
                  {rows.map((row, idx) => (
                    <div key={idx} className="rounded-lg border border-border bg-card p-3">
                      {editingIdx === idx ? (
                        <div className="space-y-2">
                          <div className="space-y-1.5">
                            <label className="text-xs text-muted-foreground">Player Name</label>
                            <Input
                              value={editDraft.name}
                              onChange={e => setEditDraft(d => ({ ...d, name: e.target.value }))}
                              className="h-8 text-sm"
                              placeholder="Full name"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-xs text-muted-foreground">Jersey #</label>
                              <Input
                                value={editDraft.number}
                                onChange={e => setEditDraft(d => ({ ...d, number: e.target.value }))}
                                className="h-8 text-sm"
                                placeholder="0"
                              />
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Position</label>
                              <Select value={editDraft.position} onValueChange={v => setEditDraft(d => ({ ...d, position: v }))}>
                                <SelectTrigger className="h-8 text-xs">
                                  <SelectValue placeholder="Pos" />
                                </SelectTrigger>
                                <SelectContent>
                                  {positions.map(p => (
                                    <SelectItem key={p} value={p}>{p}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" className="flex-1 gap-1 h-8" onClick={saveEdit}>
                              <Check className="w-3.5 h-3.5" /> Save
                            </Button>
                            <Button size="sm" variant="outline" className="h-8 px-2" onClick={cancelEdit}>Cancel</Button>
                            <Button size="sm" variant="ghost" className="h-8 px-2 text-destructive hover:bg-destructive/10" onClick={() => removeRow(idx)}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-3">
                          {row.number && <span className="text-xs font-bold bg-muted rounded px-1.5 py-0.5 flex-shrink-0">#{row.number}</span>}
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium truncate">{row.name || '—'}</div>
                            {row.position && <div className="text-xs text-muted-foreground">{row.position}</div>}
                          </div>
                          <button onClick={() => startEdit(idx)} className="p-1.5 rounded hover:bg-muted touch-manipulation flex-shrink-0">
                            <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <button
                  onClick={addRow}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border-2 border-dashed border-border text-sm text-muted-foreground hover:bg-muted touch-manipulation"
                >
                  <Plus className="w-4 h-4" /> Add Player
                </button>
              </div>
            )}
          </div>

          {/* Footer for review */}
          {stage === 'review' && (
            <div className="p-4 border-t border-border flex-shrink-0">
              <Button
                className="w-full gap-2"
                onClick={handleConfirm}
                disabled={confirming}
              >
                {confirming ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                {confirming ? 'Saving...' : `✅ Confirm & Create Players`}
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Full-screen photo viewer */}
      {showPhotoViewer && photoSrc && (
        <div className="fixed inset-0 z-[60] bg-black flex items-center justify-center" onClick={() => setShowPhotoViewer(false)}>
          <button className="absolute top-4 right-4 p-2 rounded-full bg-white/20 text-white hover:bg-white/30 z-10 touch-manipulation">
            <X className="w-5 h-5" />
          </button>
          <img
            src={photoSrc}
            alt="Source roster sheet"
            className="max-w-full max-h-full object-contain"
            onClick={e => e.stopPropagation()}
            style={{ touchAction: 'pinch-zoom' }}
          />
        </div>
      )}

      {/* Discard confirmation */}
      {showDiscardConfirm && (
        <div className="fixed inset-0 z-[70] bg-black/60 flex items-center justify-center p-6">
          <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-sm space-y-4">
            <h3 className="font-semibold">Discard this import?</h3>
            <p className="text-sm text-muted-foreground">Players won't be created.</p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setShowDiscardConfirm(false)}>Keep Editing</Button>
              <Button variant="destructive" className="flex-1" onClick={onClose}>Discard</Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}