import { useEffect, useRef } from 'react';
import { X, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function QRCodeModal({ team, onClose }) {
  const canvasRef = useRef(null);
  const shareUrl = `${window.location.origin}/teams/import/${team.share_code}`;

  useEffect(() => {
    // Simple QR code placeholder using a public API
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => ctx.drawImage(img, 0, 0, 200, 200);
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(shareUrl)}`;
  }, [shareUrl]);

  const download = () => {
    const canvas = canvasRef.current;
    const link = document.createElement('a');
    link.download = `${team.name}-qr.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div className="bg-card border border-border rounded-2xl p-6 max-w-sm w-full shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-semibold">{team.name} QR Code</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Share with opposing team to import roster</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted"><X className="w-4 h-4" /></button>
        </div>

        <div className="bg-white rounded-xl p-4 flex items-center justify-center mb-4">
          <canvas ref={canvasRef} width={200} height={200} />
        </div>

        <div className="bg-muted rounded-lg px-3 py-2 text-xs font-mono break-all mb-4 text-center">
          {shareUrl}
        </div>

        <div className="text-center text-xs text-muted-foreground mb-4">
          Team Code: <span className="font-bold text-foreground text-sm">{team.share_code}</span>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" className="flex-1 gap-1.5" onClick={download}>
            <Download className="w-4 h-4" /> Download
          </Button>
          <Button className="flex-1" onClick={() => { navigator.clipboard.writeText(shareUrl); }}>
            Copy Link
          </Button>
        </div>
      </div>
    </div>
  );
}