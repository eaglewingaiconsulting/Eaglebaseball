import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UserPlus, Loader2, Mail, Star, Copy, Clock, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';

function generateToken() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

const STATUS_ICON = {
  pending: <Clock className="w-3.5 h-3.5 text-amber-500" />,
  accepted: <CheckCircle className="w-3.5 h-3.5 text-green-500" />,
  expired: <XCircle className="w-3.5 h-3.5 text-muted-foreground" />,
};

export default function InvitePanel({ team, players = [] }) {
  const { user } = useAuth();
  const [email, setEmail] = useState('');
  const [playerName, setPlayerName] = useState('');
  const [role, setRole] = useState('parent');
  const [saving, setSaving] = useState(false);
  const [invitations, setInvitations] = useState([]);
  const [loadingInvites, setLoadingInvites] = useState(true);

  useEffect(() => {
    base44.entities.Invitation.filter({ team_id: team.id })
      .then(invs => setInvitations(invs.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))))
      .finally(() => setLoadingInvites(false));
  }, [team.id]);

  const sendInvite = async () => {
    if (!email.trim()) return;
    setSaving(true);
    const token = generateToken();
    const expires_at = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

    const inviteUrl = role === 'fan'
      ? `${window.location.origin}/teams/fan/${team.share_code}`
      : `${window.location.origin}/invite/${token}`;

    const roleLabel = role === 'parent' ? 'parent/guardian' : role;

    const bodyForParent = `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:24px">
        <h2 style="margin:0 0 8px">⚾ You're invited to ${team.name}!</h2>
        <p style="color:#555;margin:0 0 16px">
          <strong>${user.full_name || user.email}</strong> has invited you to register${playerName ? ` <strong>${playerName}</strong>` : ' your child'} on the team.
        </p>
        <p style="margin:0 0 24px;color:#555">
          Click the button below to add your player's details (jersey number, position, etc.) and complete registration.
        </p>
        <a href="${inviteUrl}" style="background:#1e3a8a;color:white;padding:14px 28px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600">
          Register My Player →
        </a>
        <p style="margin-top:20px;color:#999;font-size:13px">This invite expires in 7 days.</p>
      </div>
    `;

    const bodyForOther = `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:24px">
        <h2 style="margin:0 0 8px">⚾ You're invited to ${team.name}!</h2>
        <p style="color:#555;margin:0 0 16px">You've been invited as a <strong>${roleLabel}</strong> by ${user.full_name || user.email}.</p>
        <a href="${inviteUrl}" style="background:#1e3a8a;color:white;padding:14px 28px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600">
          Accept Invitation
        </a>
        <p style="margin-top:20px;color:#999;font-size:13px">This invite expires in 7 days.</p>
      </div>
    `;

    const inv = await base44.entities.Invitation.create({
      team_id: team.id,
      team_name: team.name,
      email: email.trim(),
      role,
      status: 'pending',
      token,
      expires_at,
      invited_by: user.email,
      ...(role === 'parent' && playerName.trim() ? { player_id: playerName.trim() } : {}),
    });

    await base44.integrations.Core.SendEmail({
      to: email.trim(),
      subject: `You've been invited to ${team.name} on EagleBaseball`,
      body: role === 'parent' ? bodyForParent : bodyForOther,
    });

    setInvitations(prev => [inv, ...prev]);
    setEmail('');
    setPlayerName('');
    setSaving(false);
    toast.success(`Invite sent to ${email}`);
  };

  return (
    <div className="space-y-5">
      {/* Fan share link */}
      {team.share_code && (
        <div className="rounded-lg p-3 flex items-center justify-between gap-3 border border-border bg-muted/40">
          <div className="flex items-center gap-2 min-w-0">
            <Star className="w-4 h-4 flex-shrink-0 text-accent" />
            <span className="text-xs truncate text-muted-foreground">Fan link: {window.location.origin}/teams/fan/{team.share_code}</span>
          </div>
          <button
            className="flex-shrink-0 px-2.5 py-1.5 text-xs font-medium rounded-lg border border-border bg-muted hover:bg-secondary transition-colors select-none"
            onClick={() => {
              navigator.clipboard.writeText(`${window.location.origin}/teams/fan/${team.share_code}`);
              toast.success('Fan link copied!');
            }}
          >
            <Copy className="w-3 h-3 inline mr-1" /> Copy
          </button>
        </div>
      )}

      {/* Role selector */}
      <div className="space-y-1.5">
        <Label>Invite as</Label>
        <div className="flex gap-2 flex-wrap">
          {[
            { value: 'parent', label: 'Parent / Player' },
            { value: 'coach', label: 'Coach' },
            { value: 'fan', label: 'Fan' },
            { value: 'game_manager', label: 'Game Manager' },
          ].map(opt => (
            <button
              key={opt.value}
              onClick={() => setRole(opt.value)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
                role === opt.value ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Parent: player name field */}
      {role === 'parent' && (
        <div className="space-y-1.5">
          <Label>Player's Name <span className="text-muted-foreground font-normal">(optional — helps parent pre-fill)</span></Label>
          <Input
            placeholder="e.g. Jake Smith"
            value={playerName}
            onChange={e => setPlayerName(e.target.value)}
          />
        </div>
      )}

      {/* Email */}
      <div className="space-y-1.5">
        <Label>Parent / Recipient Email *</Label>
        <div className="flex gap-2">
          <Input
            placeholder="parent@email.com"
            value={email}
            onChange={e => setEmail(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendInvite()}
            className="flex-1"
          />
          <Button onClick={sendInvite} disabled={saving || !email.trim()} className="gap-1.5 flex-shrink-0">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
            Send
          </Button>
        </div>
        {role === 'parent' && (
          <p className="text-xs text-muted-foreground">
            The parent will receive an email with a link to register their child's details.
          </p>
        )}
      </div>

      {/* Pending invitations list */}
      {!loadingInvites && invitations.length > 0 && (
        <div className="space-y-2 pt-1 border-t border-border">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Sent Invitations</div>
          <div className="space-y-1.5 max-h-48 overflow-y-auto">
            {invitations.map(inv => (
              <div key={inv.id} className="flex items-center gap-2.5 p-2.5 rounded-lg bg-muted/40 border border-border">
                {STATUS_ICON[inv.status] || STATUS_ICON.pending}
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{inv.email}</div>
                  <div className="text-xs text-muted-foreground capitalize">{inv.role} · {inv.status}</div>
                </div>
                {inv.status === 'pending' && (
                  <button
                    className="text-xs text-primary hover:underline flex-shrink-0 select-none"
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/invite/${inv.token}`);
                      toast.success('Invite link copied!');
                    }}
                  >
                    Copy link
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}