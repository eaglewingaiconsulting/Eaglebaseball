/**
 * OrgStoreManager — manage StoreItems for an org (scope="org").
 * Now uses unified StoreItem entity.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, Plus, Pencil, Trash2, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import StoreItemModal from '@/components/store/StoreItemModal';

const ITEM_TYPE_LABEL = { gear: '⚾ Gear', dues: '💰 Dues' };

export default function OrgStoreManager({ org }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [deleting, setDeleting] = useState({});
  const [toggling, setToggling] = useState({});

  useEffect(() => {
    base44.entities.StoreItem.filter({ org_id: org.id, scope: 'org' }).then(data => {
      setItems(data);
      setLoading(false);
    });
  }, [org.id]);

  const togglePublish = async (item) => {
    setToggling(t => ({ ...t, [item.id]: true }));
    const newStatus = item.status === 'active' ? 'archived' : 'active';
    try {
      await base44.entities.StoreItem.update(item.id, { status: newStatus });
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, status: newStatus } : i));
    } catch {
      toast.error('Failed to update status');
    } finally {
      setToggling(t => ({ ...t, [item.id]: false }));
    }
  };

  const deleteItem = async (item) => {
    if (!confirm(`Delete "${item.name}"?`)) return;
    setDeleting(d => ({ ...d, [item.id]: true }));
    try {
      await base44.entities.StoreItem.delete(item.id);
      setItems(prev => prev.filter(i => i.id !== item.id));
      toast.success('Item deleted');
    } catch {
      toast.error('Delete failed');
    } finally {
      setDeleting(d => ({ ...d, [item.id]: false }));
    }
  };

  const handleSaved = (saved, isEdit) => {
    setItems(prev => isEdit ? prev.map(i => i.id === saved.id ? saved : i) : [...prev, saved]);
    setEditingItem(null);
    setShowAdd(false);
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Org Store Items</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Published items visible across all teams in your org</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={() => setShowAdd(true)}>
          <Plus className="w-4 h-4" /> Add Item
        </Button>
      </div>

      {items.length === 0 ? (
        <div className="text-center text-muted-foreground text-sm py-12 bg-card border border-dashed border-border rounded-xl">
          <Plus className="w-8 h-8 mx-auto mb-2 opacity-30" />
          No org store items yet. Tap "Add Item" to get started.
        </div>
      ) : (
        <div className="grid gap-3">
          {items.map(item => {
            const isPublished = item.status === 'active';
            return (
              <div key={item.id} className="bg-card border border-border rounded-xl overflow-hidden flex">
                <div className="w-20 h-20 flex-shrink-0 bg-muted flex items-center justify-center overflow-hidden">
                  {item.image_url
                    ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                    : <span className="text-2xl">{item.item_type === 'dues' ? '💰' : '🏷️'}</span>}
                </div>
                <div className="flex-1 p-3 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-semibold text-sm truncate block">{item.name}</span>
                        <span className="text-xs px-1.5 py-0.5 rounded-full bg-secondary text-secondary-foreground">
                          {ITEM_TYPE_LABEL[item.item_type] || item.item_type}
                        </span>
                      </div>
                      {item.description && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{item.description}</p>}
                      <span className="text-sm font-bold text-primary mt-1 block">${(item.price || 0).toFixed(2)}</span>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${isPublished ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      {isPublished ? 'Live' : 'Draft'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-2">
                    <button onClick={() => togglePublish(item)} disabled={toggling[item.id]}
                      className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg border border-border hover:bg-muted transition-colors">
                      {toggling[item.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : isPublished ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      {isPublished ? 'Unpublish' : 'Publish'}
                    </button>
                    <button onClick={() => setEditingItem(item)}
                      className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg border border-border hover:bg-muted transition-colors">
                      <Pencil className="w-3 h-3" /> Edit
                    </button>
                    <button onClick={() => deleteItem(item)} disabled={deleting[item.id]}
                      className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg border border-destructive/30 text-destructive hover:bg-destructive/10 transition-colors">
                      {deleting[item.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showAdd && (
        <StoreItemModal scope="org" orgId={org.id}
          onSave={(saved) => handleSaved(saved, false)} onClose={() => setShowAdd(false)} />
      )}
      {editingItem && (
        <StoreItemModal scope="org" item={editingItem} orgId={org.id}
          onSave={(saved) => handleSaved(saved, true)} onClose={() => setEditingItem(null)} />
      )}
    </div>
  );
}