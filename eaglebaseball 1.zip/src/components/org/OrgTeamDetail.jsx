import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Calendar, Trophy, TrendingUp, Clock, Loader2 } from 'lucide-react';

function PlayerAvatar({ player, size = 'sm' }) {
  const sz = size === 'sm' ? 'w-7 h-7 text-xs' : 'w-10 h-10 text-sm';
  if (player?.photo_thumb_url) {
    return <img src={player.photo_thumb_url} alt={player.name} className={`${sz} rounded-full object-cover flex-shrink-0`} />;
  }
  const initials = (player?.name || '?').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
  return (
    <div className={`${sz} rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold flex-shrink-0`}>
      {initials}
    </div>
  );
}

export default function OrgTeamDetail({ teamId, orgId, onBack }) {
  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [recentGames, setRecentGames] = useState([]);
  const [upcomingGames, setUpcomingGames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Team.filter({ id: teamId }),
      base44.entities.Player.filter({ team_id: teamId }),
      base44.entities.Game.list('-scheduled_date', 50),
    ]).then(([teams, pls, allGames]) => {
      setTeam(teams[0]);
      setPlayers(pls);
      const teamGames = allGames.filter(g => g.home_team_id === teamId || g.away_team_id === teamId);
      setRecentGames(teamGames.filter(g => g.status === 'completed' || g.status === 'final').slice(0, 3));
      setUpcomingGames(teamGames.filter(g => g.status === 'scheduled').slice(0, 3));
      setLoading(false);
    });
  }, [teamId]);

  if (loading) return <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  if (!team) return <div className="p-6 text-center text-muted-foreground">Team not found</div>;

  // Player highlights
  const pitchers = players.filter(p => (p.innings_pitched || 0) >= 1);
  const bestERA = pitchers.length > 0 ? pitchers.reduce((best, p) => (!best || (p.era || 0) < (best.era || 0)) ? p : best, null) : null;
  const bestAvg = players.reduce((best, p) => (!best || (p.batting_avg || 0) > (best.batting_avg || 0)) ? p : best, null);
  const mostRBIs = players.reduce((best, p) => (!best || (p.rbis || 0) > (best.rbis || 0)) ? p : best, null);
  const mostKs = pitchers.reduce((best, p) => (!best || (p.strikeouts_pitching || 0) > (best.strikeouts_pitching || 0)) ? p : best, null);

  const highlights = [
    { label: 'Best ERA', player: bestERA, stat: bestERA ? (bestERA.era || 0).toFixed(2) : '—' },
    { label: 'Batting Avg', player: bestAvg, stat: bestAvg ? (bestAvg.batting_avg || 0).toFixed(3) : '—' },
    { label: 'Most RBIs', player: mostRBIs, stat: mostRBIs?.rbis || 0 },
    { label: 'Most Ks (P)', player: mostKs, stat: mostKs?.strikeouts_pitching || 0 },
  ];

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-5 pb-24 lg:pb-8">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors select-none">
        <ArrowLeft className="w-4 h-4" /> Back to Teams
      </button>

      {/* Team header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white text-sm font-bold"
          style={{ backgroundColor: team.primary_color || '#1e3a8a' }}>
          {team.name.slice(0, 2).toUpperCase()}
        </div>
        <div>
          <h1 className="text-xl font-bold">{team.name}</h1>
          <p className="text-sm text-muted-foreground">{team.coach_email ? `Coach: ${team.coach_email}` : 'No Coach Assigned'} · {players.length} players</p>
        </div>
      </div>

      {/* Recent Games */}
      <div>
        <h2 className="font-semibold flex items-center gap-2 mb-3 text-sm uppercase tracking-wider text-muted-foreground">
          <Trophy className="w-4 h-4" /> Recent Games
        </h2>
        {recentGames.length === 0 ? (
          <p className="text-sm text-muted-foreground bg-card border border-dashed border-border rounded-xl p-4 text-center">No completed games yet</p>
        ) : (
          <div className="space-y-2">
            {recentGames.map(game => {
              const isHome = game.home_team_id === teamId;
              const won = isHome ? game.home_score > game.away_score : game.away_score > game.home_score;
              return (
                <Link key={game.id} to={`/games/${game.id}`} className="flex items-center justify-between bg-card border border-border rounded-xl p-3.5 hover:border-primary/40 transition-colors">
                  <div>
                    <div className="text-sm font-medium">{game.away_team_name} @ {game.home_team_name}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1"><Calendar className="w-3 h-3" />{game.scheduled_date} · {game.location || ''}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold font-bebas text-lg">{game.away_score}–{game.home_score}</span>
                    <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${won ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{won ? 'W' : 'L'}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>

      {/* Upcoming Games */}
      <div>
        <h2 className="font-semibold flex items-center gap-2 mb-3 text-sm uppercase tracking-wider text-muted-foreground">
          <Clock className="w-4 h-4" /> Upcoming Games
        </h2>
        {upcomingGames.length === 0 ? (
          <p className="text-sm text-muted-foreground bg-card border border-dashed border-border rounded-xl p-4 text-center">No upcoming games</p>
        ) : (
          <div className="space-y-2">
            {upcomingGames.map(game => (
              <Link key={game.id} to={`/games/${game.id}`} className="flex items-center justify-between bg-card border border-border rounded-xl p-3.5 hover:border-primary/40 transition-colors">
                <div>
                  <div className="text-sm font-medium">{game.away_team_name} @ {game.home_team_name}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{game.scheduled_date} {game.scheduled_time ? `· ${game.scheduled_time}` : ''} {game.location ? `· ${game.location}` : ''}</div>
                </div>
                <Calendar className="w-4 h-4 text-muted-foreground" />
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Season Highlights */}
      <div>
        <h2 className="font-semibold flex items-center gap-2 mb-3 text-sm uppercase tracking-wider text-muted-foreground">
          <TrendingUp className="w-4 h-4" /> Season Highlights
        </h2>
        <div className="grid sm:grid-cols-2 gap-3">
          {highlights.map(h => (
            <div key={h.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
              {h.player ? <PlayerAvatar player={h.player} /> : <div className="w-7 h-7 rounded-full bg-muted flex-shrink-0" />}
              <div className="min-w-0 flex-1">
                <div className="text-xs text-muted-foreground">{h.label}</div>
                <div className="font-semibold text-sm truncate">{h.player?.name || 'N/A'}</div>
              </div>
              <div className="text-lg font-bold font-bebas">{h.stat}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}