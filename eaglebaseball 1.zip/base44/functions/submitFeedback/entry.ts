import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const { app_name, category, feedback, name, email } = body;

    if (!category || !feedback) {
      return Response.json({ success: false, error: 'Missing required fields' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);

    const subject = `[Feedback] ${app_name || 'EagleBaseball'} — ${category}`;
    const emailBody = `App: ${app_name || 'EagleBaseball'}
Category: ${category}
Feedback: ${feedback}
Name: ${name || 'Anonymous'}
Email: ${email || 'Not provided'}
Submitted: ${new Date().toISOString()}`;

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: 'eaglewingaiconsulting@gmail.com',
      subject,
      body: emailBody,
    });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});