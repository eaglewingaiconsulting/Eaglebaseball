/**
 * sendTeamMessage — backend push-notification hook for team messages.
 * Called by entity automation when a new TeamMessage is created.
 * Sends an in-app email notification to team members who are NOT the sender.
 *
 * Trigger: Entity automation on TeamMessage create.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    const { data: msg, event } = payload;

    if (!msg || event?.type !== 'create') {
      return Response.json({ skipped: true });
    }

    // Skip deleted or empty messages
    if (msg.is_deleted || !msg.body?.trim()) {
      return Response.json({ skipped: 'deleted or empty' });
    }

    const sr = base44.asServiceRole;

    // Fetch the team
    const teams = await sr.entities.Team.filter({ id: msg.team_id });
    const team = teams[0];
    if (!team) return Response.json({ skipped: 'team not found' });

    // Build recipient list
    const recipientEmails = new Set();

    if (msg.channel === 'team') {
      // Everyone on the team except the sender
      if (team.coach_email) recipientEmails.add(team.coach_email);
      (team.admin_emails || []).forEach(e => recipientEmails.add(e));
      (team.fan_emails || []).forEach(e => recipientEmails.add(e));

      // Parents of players
      const players = await sr.entities.Player.filter({ team_id: msg.team_id });
      players.forEach(p => { if (p.parent_email) recipientEmails.add(p.parent_email); });

    } else if (msg.channel === 'direct' && msg.thread_id) {
      // DM: notify only the other party
      const emails = msg.thread_id.split('|');
      emails.forEach(e => recipientEmails.add(e));
    }

    // Remove the sender
    recipientEmails.delete(msg.sender_email);

    if (recipientEmails.size === 0) {
      return Response.json({ sent: 0, skipped: 'no recipients' });
    }

    const channelLabel = msg.channel === 'direct' ? 'Direct Message' : `#${team.name} Team Channel`;
    const isCoachBadge = msg.is_coach_message ? '[COACH] ' : '';
    const subject = `${isCoachBadge}${msg.sender_name} — ${team.name}`;
    const bodyPreview = msg.body.length > 200 ? msg.body.slice(0, 200) + '…' : msg.body;

    const emailBody = `
<div style="font-family: system-ui, sans-serif; max-width: 540px; margin: 0 auto; padding: 24px;">
  <div style="background: #1e3a8a; color: #fff; padding: 16px 20px; border-radius: 12px 12px 0 0;">
    <div style="font-size: 13px; opacity: 0.7; margin-bottom: 4px;">${channelLabel}</div>
    <div style="font-size: 18px; font-weight: 700;">${team.name}</div>
  </div>
  <div style="border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; padding: 20px;">
    ${msg.is_coach_message ? '<div style="display:inline-block; background:#FEF3C7; color:#92400E; font-size:11px; font-weight:700; padding:3px 8px; border-radius:999px; margin-bottom:12px;">COACH MESSAGE</div>' : ''}
    <div style="font-size: 15px; font-weight: 600; color: #111;">${msg.sender_name}</div>
    <div style="font-size: 15px; color: #374151; margin-top: 8px; line-height: 1.5; background:#f9fafb; padding:12px 16px; border-radius:8px; border-left:3px solid #1e3a8a;">
      ${bodyPreview}
    </div>
    <div style="margin-top: 20px; font-size: 12px; color: #9ca3af;">
      Reply in the EagleBaseball app → Teams → ${team.name} → Messages
    </div>
  </div>
</div>`;

    let sent = 0;
    for (const email of recipientEmails) {
      try {
        await sr.integrations.Core.SendEmail({
          to: email,
          subject,
          body: emailBody,
          from_name: `${team.name} via EagleBaseball`,
        });
        sent++;
      } catch {
        // Best-effort — don't fail if one email bounces
      }
    }

    return Response.json({ sent, total_recipients: recipientEmails.size });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});