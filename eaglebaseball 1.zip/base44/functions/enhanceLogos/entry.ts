import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Fetches all Team and Organization logos, runs them through AI image enhancement,
 * and saves the improved URL back to each record.
 * Admin only.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const [teams, orgs] = await Promise.all([
      base44.asServiceRole.entities.Team.list('-created_date', 200),
      base44.asServiceRole.entities.Organization.list('-created_date', 100),
    ]);

    const toProcess = [
      ...teams.filter(t => t.logo_url).map(t => ({ type: 'Team', id: t.id, logo_url: t.logo_url, name: t.name })),
      ...orgs.filter(o => o.logo_url).map(o => ({ type: 'Organization', id: o.id, logo_url: o.logo_url, name: o.name })),
    ];

    const results = { enhanced: 0, failed: 0, skipped: 0, errors: [] };

    for (const item of toProcess) {
      try {
        // Generate enhanced version
        const generated = await base44.asServiceRole.integrations.Core.GenerateImage({
          prompt: `Recreate this sports team logo as a clean, sharp, professional vector-style emblem. Preserve all original colors, text, mascot, and design elements exactly. Make it crisp, high-resolution, with clean edges and vivid colors. White or transparent background.`,
          existing_image_urls: [item.logo_url],
        });

        // Upload enhanced image to get a permanent URL
        const res = await fetch(generated.url);
        const blob = await res.blob();
        const file = new File([blob], 'logo.png', { type: 'image/png' });
        const { file_url } = await base44.asServiceRole.integrations.Core.UploadFile({ file });

        // Save back
        if (item.type === 'Team') {
          await base44.asServiceRole.entities.Team.update(item.id, { logo_url: file_url });
        } else {
          await base44.asServiceRole.entities.Organization.update(item.id, { logo_url: file_url });
        }

        results.enhanced++;
      } catch (err) {
        results.failed++;
        results.errors.push(`${item.type} "${item.name}": ${err.message}`);
      }
    }

    return Response.json({
      total: toProcess.length,
      ...results,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});