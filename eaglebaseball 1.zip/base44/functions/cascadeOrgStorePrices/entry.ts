import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const updatedItem = body?.data;

    if (!updatedItem?.org_id || !updatedItem?.name || !updatedItem?.price) {
      return Response.json({ skipped: true });
    }

    // Find all team store items in this org with matching name that are org items
    const teamItems = await base44.asServiceRole.entities.TeamStoreItem.filter({
      org_id: updatedItem.org_id,
      name: updatedItem.name,
      is_org_item: true,
    });

    await Promise.all(
      teamItems.map(item =>
        base44.asServiceRole.entities.TeamStoreItem.update(item.id, { price: updatedItem.price })
      )
    );

    return Response.json({ updated: teamItems.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});