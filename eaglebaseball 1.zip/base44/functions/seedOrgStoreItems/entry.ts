import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const orgId = body?.data?.id || body?.event?.entity_id;

    if (!orgId) {
      return Response.json({ error: 'Missing org id' }, { status: 400 });
    }

    await base44.asServiceRole.entities.OrgStoreItem.bulkCreate([
      { org_id: orgId, name: 'Organization Dues', price: 0, status: 'Unpublished' },
      { org_id: orgId, name: 'Uniform Package', price: 0, status: 'Unpublished' },
    ]);

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});