import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const { video_url, timestamp_seconds, pitcher_name } = await req.json();

    if (!video_url) {
      return Response.json({ error: 'video_url is required' }, { status: 400 });
    }

    const prompt = `You are a baseball pitch speed analyst. You are looking at a video frame or screenshot from a baseball game.

Pitcher: ${pitcher_name || 'Unknown'}
Video timestamp: approximately ${timestamp_seconds || 0} seconds into the game video.

Based on the video frame provided, estimate the pitch speed in MPH. Look for:
1. Motion blur on the baseball
2. The ball's position and trajectory
3. Any visible radar gun reading overlays on the broadcast
4. The pitcher's release mechanics and arm velocity

Provide your best estimate as a single number in MPH. For youth baseball (12U-18U), typical speeds range from 45-85 MPH. For high school varsity, 65-90 MPH. For college/adult, 75-95 MPH.

If you cannot determine speed from the image, return null.

Be realistic — if this is youth baseball based on the field/players visible, calibrate accordingly.`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      file_urls: [video_url],
      response_json_schema: {
        type: 'object',
        properties: {
          estimated_mph: { type: 'number', description: 'Estimated pitch speed in MPH, or null if cannot determine' },
          confidence: { type: 'string', enum: ['low', 'medium', 'high'], description: 'Confidence level of the estimate' },
          reasoning: { type: 'string', description: 'Brief explanation of how the speed was estimated' },
        },
      },
    });

    return Response.json({
      estimated_mph: result.estimated_mph || null,
      confidence: result.confidence || 'low',
      reasoning: result.reasoning || '',
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});