import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const DEFAULT_PRIMARY = '#1e3a8a';
const DEFAULT_SECONDARY = '#f59e0b';
const TEAM_NAME = 'Eagles 12U';
const OPPONENT_NAMES = ['Raptors', 'Wolves', 'Tigers', 'Thunder', 'Hawks'];

const PLAYERS = [
  { name: 'Jake Torres',  number: '1',  position: 'P',  bats: 'R', throws: 'R',
    batting_avg: 0.312, era: 2.1, at_bats: 32, hits: 10, runs: 6, rbis: 7, home_runs: 2, walks: 3, strikeouts_batting: 5, stolen_bases: 2, innings_pitched: 18, strikeouts_pitching: 22, hits_allowed: 14, walks_allowed: 5, earned_runs: 4 },
  { name: 'Mason Lee',    number: '2',  position: 'C',  bats: 'R', throws: 'R',
    batting_avg: 0.285, at_bats: 28, hits: 8, runs: 3, rbis: 5, home_runs: 0, walks: 4, strikeouts_batting: 6, stolen_bases: 0 },
  { name: 'Ethan Brooks', number: '3',  position: '1B', bats: 'L', throws: 'L',
    batting_avg: 0.350, at_bats: 30, hits: 11, runs: 8, rbis: 9, home_runs: 3, walks: 5, strikeouts_batting: 4, stolen_bases: 1 },
  { name: 'Lucas Patel',  number: '4',  position: '2B', bats: 'R', throws: 'R',
    batting_avg: 0.265, at_bats: 26, hits: 7, runs: 4, rbis: 3, home_runs: 0, walks: 2, strikeouts_batting: 7, stolen_bases: 4 },
  { name: 'Caleb Ryan',   number: '5',  position: '3B', bats: 'R', throws: 'R',
    batting_avg: 0.290, at_bats: 24, hits: 7, runs: 5, rbis: 6, home_runs: 1, walks: 3, strikeouts_batting: 5, stolen_bases: 2 },
  { name: 'Noah Kim',     number: '6',  position: 'SS', bats: 'S', throws: 'R',
    batting_avg: 0.330, at_bats: 30, hits: 10, runs: 7, rbis: 4, home_runs: 0, walks: 6, strikeouts_batting: 3, stolen_bases: 6 },
  { name: 'Tyler Wade',   number: '7',  position: 'LF', bats: 'L', throws: 'L',
    batting_avg: 0.275, at_bats: 29, hits: 8, runs: 5, rbis: 5, home_runs: 1, walks: 2, strikeouts_batting: 8, stolen_bases: 3 },
  { name: 'Aiden Scott',  number: '8',  position: 'CF', bats: 'R', throws: 'R',
    batting_avg: 0.305, at_bats: 28, hits: 9, runs: 6, rbis: 4, home_runs: 0, walks: 4, strikeouts_batting: 6, stolen_bases: 5 },
  { name: 'Brody Hall',   number: '9',  position: 'RF', bats: 'R', throws: 'R',
    batting_avg: 0.260, at_bats: 27, hits: 7, runs: 3, rbis: 3, home_runs: 1, walks: 1, strikeouts_batting: 9, stolen_bases: 1 },
  { name: 'Connor Mills', number: '10', position: 'DH', bats: 'L', throws: 'R',
    batting_avg: 0.295, at_bats: 25, hits: 7, runs: 4, rbis: 6, home_runs: 2, walks: 3, strikeouts_batting: 5, stolen_bases: 0 },
  { name: 'Dylan Cruz',   number: '11', position: 'P',  bats: 'R', throws: 'R',
    batting_avg: 0.240, era: 3.4, at_bats: 22, hits: 5, runs: 2, rbis: 2, home_runs: 0, walks: 2, strikeouts_batting: 8, innings_pitched: 14, strikeouts_pitching: 16, hits_allowed: 18, walks_allowed: 7, earned_runs: 5 },
  { name: 'Gavin Price',  number: '12', position: '2B', bats: 'R', throws: 'R',
    batting_avg: 0.220, at_bats: 20, hits: 4, runs: 1, rbis: 2, home_runs: 0, walks: 1, strikeouts_batting: 6, stolen_bases: 1 },
  { name: 'Hunter Webb',  number: '13', position: 'LF', bats: 'R', throws: 'R',
    batting_avg: 0.245, at_bats: 18, hits: 4, runs: 2, rbis: 1, home_runs: 0, walks: 2, strikeouts_batting: 5, stolen_bases: 2 },
  { name: 'Isaac Ford',   number: '14', position: '1B', bats: 'L', throws: 'L',
    batting_avg: 0.268, at_bats: 16, hits: 4, runs: 1, rbis: 3, home_runs: 1, walks: 1, strikeouts_batting: 4, stolen_bases: 0 },
  { name: 'Jordan Nash',  number: '15', position: 'C',  bats: 'R', throws: 'R',
    batting_avg: 0.210, at_bats: 14, hits: 3, runs: 1, rbis: 1, home_runs: 0, walks: 2, strikeouts_batting: 4, stolen_bases: 0 },
];

// Realistic spray chart hit zones
const SPRAY_ZONES = [
  'lf_line', 'lf_gap', 'lf_shallow', 'lf_deep',
  'cf_shallow', 'cf_center', 'cf_deep',
  'rf_shallow', 'rf_gap', 'rf_line', 'rf_deep',
  'infield_1b', 'infield_2b', 'infield_3b', 'infield_ss',
  'pull_hard', 'push_opposite',
];

const DEMO_AT_BATS = [
  // Game 1 spray chart data
  { result: 'single', hit_zone: 'lf_gap', inning: 1, inning_half: 'top', balls: 1, strikes: 1, pitch_count: 4 },
  { result: 'double', hit_zone: 'rf_gap', inning: 1, inning_half: 'top', balls: 2, strikes: 1, pitch_count: 6 },
  { result: 'home_run', hit_zone: 'cf_deep', inning: 2, inning_half: 'top', balls: 0, strikes: 2, pitch_count: 5 },
  { result: 'ground_out', hit_zone: 'infield_2b', inning: 2, inning_half: 'top', balls: 1, strikes: 2, pitch_count: 7 },
  { result: 'fly_out', hit_zone: 'rf_shallow', inning: 3, inning_half: 'top', balls: 0, strikes: 1, pitch_count: 3 },
  { result: 'single', hit_zone: 'cf_shallow', inning: 3, inning_half: 'top', balls: 3, strikes: 1, pitch_count: 8 },
  { result: 'double', hit_zone: 'lf_line', inning: 4, inning_half: 'top', balls: 1, strikes: 0, pitch_count: 4 },
  { result: 'single', hit_zone: 'rf_line', inning: 4, inning_half: 'top', balls: 0, strikes: 0, pitch_count: 2 },
  { result: 'triple', hit_zone: 'cf_deep', inning: 5, inning_half: 'top', balls: 2, strikes: 0, pitch_count: 5 },
  { result: 'home_run', hit_zone: 'rf_deep', inning: 5, inning_half: 'top', balls: 0, strikes: 1, pitch_count: 4 },
  { result: 'single', hit_zone: 'infield_1b', inning: 6, inning_half: 'top', balls: 1, strikes: 1, pitch_count: 6 },
  { result: 'ground_out', hit_zone: 'infield_ss', inning: 6, inning_half: 'top', balls: 0, strikes: 2, pitch_count: 5 },
  { result: 'double', hit_zone: 'lf_deep', inning: 7, inning_half: 'top', balls: 2, strikes: 1, pitch_count: 7 },
  { result: 'single', hit_zone: 'rf_gap', inning: 7, inning_half: 'top', balls: 1, strikes: 0, pitch_count: 3 },
  // Opponent
  { result: 'single', hit_zone: 'cf_center', inning: 1, inning_half: 'bottom', balls: 2, strikes: 2, pitch_count: 9 },
  { result: 'fly_out', hit_zone: 'lf_shallow', inning: 2, inning_half: 'bottom', balls: 0, strikes: 1, pitch_count: 3 },
  { result: 'ground_out', hit_zone: 'infield_3b', inning: 3, inning_half: 'bottom', balls: 1, strikes: 2, pitch_count: 6 },
  { result: 'double', hit_zone: 'rf_gap', inning: 4, inning_half: 'bottom', balls: 0, strikes: 0, pitch_count: 1 },
  { result: 'single', hit_zone: 'lf_gap', inning: 5, inning_half: 'bottom', balls: 3, strikes: 1, pitch_count: 8 },
];

function token() {
  return Math.random().toString(36).substring(2, 12);
}

function makeInningScores(homeRuns, awayRuns, totalInnings = 7) {
  const scores = [];
  let hTotal = 0, aTotal = 0;
  for (let i = 1; i <= totalInnings; i++) {
    const isLast = i === totalInnings;
    const hRuns = isLast ? homeRuns - hTotal : Math.min(Math.floor(Math.random() * 3), homeRuns - hTotal);
    const aRuns = isLast ? awayRuns - aTotal : Math.min(Math.floor(Math.random() * 3), awayRuns - aTotal);
    scores.push({ inning: i, team: 'home', runs: Math.max(0, hRuns) });
    scores.push({ inning: i, team: 'away', runs: Math.max(0, aRuns) });
    hTotal += Math.max(0, hRuns);
    aTotal += Math.max(0, aRuns);
  }
  return scores;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    let body = {};
    try { body = await req.json(); } catch {}
    const primaryColor = body.primary_color || DEFAULT_PRIMARY;
    const secondaryColor = body.secondary_color || DEFAULT_SECONDARY;
    const logoUrl = body.logo_url || null;
    const forceReseed = body.force_reseed === true;

    // Check if demo data already exists
    const existing = await base44.asServiceRole.entities.Team.filter({ is_demo: true });
    if (existing.length > 0 && !forceReseed) {
      return Response.json({ message: 'Demo data already seeded', skipped: true });
    }

    // If force reseeding, clear old demo data first
    if (forceReseed && existing.length > 0) {
      const [oldPlayers, oldGames, oldAtBats] = await Promise.all([
        base44.asServiceRole.entities.Player.filter({ is_demo: true }),
        base44.asServiceRole.entities.Game.filter({ is_demo: true }),
        base44.asServiceRole.entities.AtBat.filter({ game_id: existing[0]?.id }).catch(() => []),
      ]);
      // Delete all old at-bats for demo games
      const oldGameIds = oldGames.map(g => g.id);
      const allOldAtBats = [];
      for (const gid of oldGameIds) {
        const abs = await base44.asServiceRole.entities.AtBat.filter({ game_id: gid }).catch(() => []);
        allOldAtBats.push(...abs);
      }
      await Promise.all([
        ...existing.map(r => base44.asServiceRole.entities.Team.delete(r.id)),
        ...oldPlayers.map(r => base44.asServiceRole.entities.Player.delete(r.id)),
        ...oldGames.map(r => base44.asServiceRole.entities.Game.delete(r.id)),
        ...allOldAtBats.map(r => base44.asServiceRole.entities.AtBat.delete(r.id)),
      ]);
    }

    // 1. Create demo team
    const team = await base44.asServiceRole.entities.Team.create({
      name: TEAM_NAME,
      city: 'Springfield',
      league: 'Metro Youth League',
      season: '2026',
      age_group: '12U',
      coach_email: 'demo@eaglebaseball.app',
      admin_emails: ['demo@eaglebaseball.app'],
      primary_color: primaryColor,
      secondary_color: secondaryColor,
      logo_url: logoUrl,
      wins: 4, losses: 2,
      share_code: 'DEMO' + token().toUpperCase().slice(0, 6),
      is_demo: true,
      is_active: true,
    });

    // 1b. Create opponent team
    const opponent = await base44.asServiceRole.entities.Team.create({
      name: 'Visiting Team',
      city: 'Springfield',
      league: 'Metro Youth League',
      season: '2026',
      age_group: '12U',
      coach_email: 'demo@eaglebaseball.app',
      primary_color: '#6b7280',
      secondary_color: '#d1d5db',
      wins: 0, losses: 0,
      share_code: 'DEMOOPP' + token().toUpperCase().slice(0, 4),
      is_demo: true,
      is_active: true,
    });

    // 2. Create players with full stats
    const players = await Promise.all(
      PLAYERS.map(p => base44.asServiceRole.entities.Player.create({
        ...p,
        team_id: team.id,
        games_played: 6,
        caught_stealing: Math.floor((p.stolen_bases || 0) * 0.2),
        is_demo: true,
      }))
    );

    const lineup = players.slice(0, 9).map(p => p.id);

    // 3. Completed games
    const completedGames = [
      { opp: OPPONENT_NAMES[0], home_score: 7, away_score: 3, date: '2026-04-05', total_innings: 7 },
      { opp: OPPONENT_NAMES[1], home_score: 2, away_score: 5, date: '2026-04-08', total_innings: 7 },
      { opp: OPPONENT_NAMES[2], home_score: 9, away_score: 4, date: '2026-04-10', total_innings: 7 },
      { opp: OPPONENT_NAMES[3], home_score: 6, away_score: 6, date: '2026-04-11', total_innings: 7 },
    ];

    let sprayChartGameId = null;

    for (let gi = 0; gi < completedGames.length; gi++) {
      const g = completedGames[gi];
      const game = await base44.asServiceRole.entities.Game.create({
        home_team_id: team.id,
        home_team_name: TEAM_NAME,
        away_team_id: opponent.id,
        away_team_name: g.opp,
        scheduled_date: g.date,
        scheduled_time: '10:00',
        location: 'Eagles Field',
        field_address: '123 Eagle Dr, Springfield, IL',
        status: 'final',
        total_innings: g.total_innings,
        inning: g.total_innings,
        inning_half: 'bottom',
        home_score: g.home_score,
        away_score: g.away_score,
        home_hits: g.home_score + Math.floor(Math.random() * 4) + 2,
        away_hits: g.away_score + Math.floor(Math.random() * 4) + 1,
        home_errors: Math.floor(Math.random() * 2),
        away_errors: Math.floor(Math.random() * 3),
        outs: 3, balls: 0, strikes: 0,
        runner_first: false, runner_second: false, runner_third: false,
        home_lineup: lineup,
        away_lineup: [],
        home_batting_order_idx: 0,
        away_batting_order_idx: 0,
        inning_scores: makeInningScores(g.home_score, g.away_score, g.total_innings),
        public_token: token(),
        is_demo: true,
      });

      // Seed spray chart AtBat records for first completed game
      if (gi === 0) {
        sprayChartGameId = game.id;
        for (let abi = 0; abi < DEMO_AT_BATS.length; abi++) {
          const ab = DEMO_AT_BATS[abi];
          const batterIdx = abi % players.length;
          const batter = players[batterIdx];
          const isHomeBat = ab.inning_half === 'top';
          const battingTeamId = isHomeBat ? team.id : opponent.id;
          await base44.asServiceRole.entities.AtBat.create({
            game_id: game.id,
            inning: ab.inning,
            inning_half: ab.inning_half,
            batter_id: batter.id,
            batter_name: batter.name,
            pitcher_id: players[0].id,
            pitcher_name: players[0].name,
            batting_team_id: battingTeamId,
            result: ab.result,
            hit_zone: ab.hit_zone,
            balls: ab.balls,
            strikes: ab.strikes,
            pitch_count: ab.pitch_count,
            rbis: ab.result === 'home_run' ? 1 : 0,
          });
        }
      }
    }

    // 4. One upcoming game
    await base44.asServiceRole.entities.Game.create({
      home_team_id: team.id,
      home_team_name: TEAM_NAME,
      away_team_id: opponent.id,
      away_team_name: OPPONENT_NAMES[4],
      scheduled_date: '2026-04-26',
      scheduled_time: '10:00',
      arrival_time: '09:30',
      location: 'Eagles Field',
      field_address: '123 Eagle Dr, Springfield, IL',
      status: 'scheduled',
      total_innings: 7,
      inning: 1, inning_half: 'top',
      home_score: 0, away_score: 0,
      home_hits: 0, away_hits: 0,
      home_errors: 0, away_errors: 0,
      outs: 0, balls: 0, strikes: 0,
      runner_first: false, runner_second: false, runner_third: false,
      home_lineup: lineup,
      away_lineup: [],
      home_batting_order_idx: 0,
      away_batting_order_idx: 0,
      inning_scores: [],
      public_token: token(),
      is_demo: true,
    });

    return Response.json({
      message: 'Demo data seeded successfully (with spray chart & full stats)',
      team_id: team.id,
      players: players.length,
      games: completedGames.length + 1,
      at_bats_seeded: DEMO_AT_BATS.length,
      spray_chart_game_id: sprayChartGameId,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});