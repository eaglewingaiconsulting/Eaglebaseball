import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    // Support both direct calls (game_id) and automation payload (event.entity_id)
    const game_id = payload.game_id || payload.event?.entity_id;
    const type = payload.type || payload.event?.type || 'created';
    const changed_fields = payload.changed_fields || [];

    if (!game_id) return Response.json({ error: 'game_id is required' }, { status: 400 });
    const game = await base44.asServiceRole.entities.Game.get(game_id);
    if (!game) return Response.json({ error: 'Game not found' }, { status: 404 });

    // Collect all recipient emails
    const recipientEmails = new Set();

    // Get players from both teams and collect parent emails + fan emails
    const [homePlayers, awayPlayers, homeTeam, awayTeam] = await Promise.all([
      base44.asServiceRole.entities.Player.filter({ team_id: game.home_team_id }),
      base44.asServiceRole.entities.Player.filter({ team_id: game.away_team_id }),
      base44.asServiceRole.entities.Team.get(game.home_team_id),
      base44.asServiceRole.entities.Team.get(game.away_team_id),
    ]);

    [...homePlayers, ...awayPlayers].forEach(p => {
      if (p.parent_email) recipientEmails.add(p.parent_email);
      (p.fan_emails || []).forEach(e => recipientEmails.add(e));
    });

    [homeTeam, awayTeam].forEach(team => {
      if (team) (team.fan_emails || []).forEach(e => recipientEmails.add(e));
    });

    if (recipientEmails.size === 0) return Response.json({ sent: 0 });

    const mapsUrl = game.field_address
      ? `https://www.google.com/maps/search/${encodeURIComponent(game.field_address)}`
      : null;

    let subject, changeNote;
    if (type === 'created') {
      subject = `New Game Scheduled: ${game.away_team_name} @ ${game.home_team_name}`;
      changeNote = '';
    } else {
      const changes = (changed_fields || []).map(f => {
        if (f === 'scheduled_time') return `Game time updated`;
        if (f === 'scheduled_date') return `Game date updated`;
        if (f === 'location' || f === 'field_address') return `Location updated`;
        return f;
      }).join(', ');
      subject = `Game Update: ${game.away_team_name} @ ${game.home_team_name}`;
      changeNote = changes ? `<p style="background:#fef3c7;padding:12px;border-radius:8px;margin-bottom:16px;"><strong>What changed:</strong> ${changes}</p>` : '';
    }

    const body = `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;">
        <h2 style="color:#1e3a8a;">${subject}</h2>
        ${changeNote}
        <div style="background:#f8fafc;padding:16px;border-radius:8px;margin-bottom:16px;">
          <p><strong>📅 Date:</strong> ${game.scheduled_date}${game.scheduled_time ? ` at ${game.scheduled_time}` : ''}</p>
          ${game.arrival_time ? `<p><strong>⏰ Arrive by:</strong> ${game.arrival_time}</p>` : ''}
          ${game.location ? `<p><strong>📍 Field:</strong> ${game.location}</p>` : ''}
          ${mapsUrl ? `<p><a href="${mapsUrl}" style="color:#1e3a8a;">📌 View on Google Maps</a></p>` : ''}
        </div>
        <p>View live scores and game details at <a href="${Deno.env.get('APP_URL') || 'https://eaglebaseball.base44.app'}">EagleBaseball</a></p>
      </div>
    `;

    // Send emails (batched to avoid overload)
    const emails = [...recipientEmails];
    for (const email of emails) {
      await base44.asServiceRole.integrations.Core.SendEmail({ to: email, subject, body });
    }

    return Response.json({ sent: emails.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});