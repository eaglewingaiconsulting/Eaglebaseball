import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const [teams, players, games, storeItems, storeOrders] = await Promise.all([
      base44.asServiceRole.entities.Team.filter({ is_demo: true }),
      base44.asServiceRole.entities.Player.filter({ is_demo: true }),
      base44.asServiceRole.entities.Game.filter({ is_demo: true }),
      base44.asServiceRole.entities.StoreItem.filter({ is_demo: true }),
      base44.asServiceRole.entities.StoreOrder.filter({ is_demo: true }),
    ]);

    await Promise.all([
      ...teams.map(r => base44.asServiceRole.entities.Team.delete(r.id)),
      ...players.map(r => base44.asServiceRole.entities.Player.delete(r.id)),
      ...games.map(r => base44.asServiceRole.entities.Game.delete(r.id)),
      ...storeItems.map(r => base44.asServiceRole.entities.StoreItem.delete(r.id)),
      ...storeOrders.map(r => base44.asServiceRole.entities.StoreOrder.delete(r.id)),
    ]);

    return Response.json({
      message: 'Demo data cleared',
      deleted: {
        teams: teams.length,
        players: players.length,
        games: games.length,
        storeItems: storeItems.length,
        storeOrders: storeOrders.length,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});