/**
 * migrateStoreLegacy — one-time admin function to migrate records from the
 * retired legacy entities (TeamStoreItem, OrgStoreItem, TeamStoreOrder, OrgStoreOrder)
 * into the unified StoreItem and StoreOrder entities.
 *
 * Safe to run multiple times — skips records that already have a matching name+team_id/org_id.
 * Call from: Dashboard > Code > Functions > migrateStoreLegacy (admin only)
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const sr = base44.asServiceRole;
    const results = { items_migrated: 0, orders_migrated: 0, errors: [] };

    // ── 1. Migrate TeamStoreItem → StoreItem (scope=team) ──────────────────────
    let teamItems = [];
    try { teamItems = await sr.entities.TeamStoreItem.list(); } catch { /* entity may not exist */ }

    for (const item of teamItems) {
      try {
        // Check for duplicate
        const existing = await sr.entities.StoreItem.filter({ team_id: item.team_id, name: item.name, scope: 'team' });
        if (existing.length > 0) continue;

        await sr.entities.StoreItem.create({
          team_id: item.team_id,
          org_id: item.org_id || null,
          scope: 'team',
          item_type: item.item_type || 'gear',
          name: item.name,
          description: item.description || '',
          price: item.price || 0,
          season: item.season || null,
          image_url: item.image_url || null,
          status: item.status === 'Published' ? 'active' : 'archived',
        });
        results.items_migrated++;
      } catch (e) {
        results.errors.push(`TeamStoreItem ${item.id}: ${e.message}`);
      }
    }

    // ── 2. Migrate OrgStoreItem → StoreItem (scope=org) ────────────────────────
    let orgItems = [];
    try { orgItems = await sr.entities.OrgStoreItem.list(); } catch { /* entity may not exist */ }

    for (const item of orgItems) {
      try {
        const existing = await sr.entities.StoreItem.filter({ org_id: item.org_id, name: item.name, scope: 'org' });
        if (existing.length > 0) continue;

        await sr.entities.StoreItem.create({
          org_id: item.org_id,
          scope: 'org',
          item_type: 'gear',
          name: item.name,
          description: item.description || '',
          price: item.price || 0,
          image_url: item.image_url || null,
          status: item.status === 'Published' ? 'active' : 'archived',
        });
        results.items_migrated++;
      } catch (e) {
        results.errors.push(`OrgStoreItem ${item.id}: ${e.message}`);
      }
    }

    // ── 3. Migrate TeamStoreOrder → StoreOrder ──────────────────────────────────
    let teamOrders = [];
    try { teamOrders = await sr.entities.TeamStoreOrder.list(); } catch { /* entity may not exist */ }

    for (const order of teamOrders) {
      try {
        // Look up the migrated StoreItem id
        const matchedItems = await sr.entities.StoreItem.filter({ team_id: order.team_id, name: order.item_name });
        const storeItemId = matchedItems[0]?.id || order.item_id || 'unknown';

        await sr.entities.StoreOrder.create({
          store_item_id: storeItemId,
          team_id: order.team_id,
          org_id: order.org_id || null,
          scope: 'team',
          item_type: 'gear',
          item_name: order.item_name || '',
          parent_name: order.parent_name || order.parent_email || '',
          player_id: order.player_id || null,
          player_name: order.player_name || null,
          amount_paid: order.amount_paid || 0,
          payment_status: (order.payment_status || 'pending').toLowerCase(),
          payment_date: order.paid_date || null,
        });
        results.orders_migrated++;
      } catch (e) {
        results.errors.push(`TeamStoreOrder ${order.id}: ${e.message}`);
      }
    }

    // ── 4. Migrate OrgStoreOrder → StoreOrder ───────────────────────────────────
    let orgOrders = [];
    try { orgOrders = await sr.entities.OrgStoreOrder.list(); } catch { /* entity may not exist */ }

    for (const order of orgOrders) {
      try {
        const matchedItems = await sr.entities.StoreItem.filter({ org_id: order.org_id, name: order.item_name, scope: 'org' });
        const storeItemId = matchedItems[0]?.id || order.item_id || 'unknown';

        await sr.entities.StoreOrder.create({
          store_item_id: storeItemId,
          org_id: order.org_id,
          scope: 'org',
          item_type: 'gear',
          item_name: order.item_name || '',
          parent_name: order.parent_name || order.parent_email || '',
          amount_paid: order.amount_paid || 0,
          payment_status: (order.payment_status || 'pending').toLowerCase(),
          payment_date: order.paid_date || null,
        });
        results.orders_migrated++;
      } catch (e) {
        results.errors.push(`OrgStoreOrder ${order.id}: ${e.message}`);
      }
    }

    return Response.json({ success: true, ...results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});