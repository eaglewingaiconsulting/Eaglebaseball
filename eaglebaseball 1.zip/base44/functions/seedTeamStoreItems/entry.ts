import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const team = body?.data;
    const teamId = team?.id || body?.event?.entity_id;
    const orgId = team?.org_id;

    if (!teamId) {
      return Response.json({ error: 'Missing team id' }, { status: 400 });
    }

    // Fetch org store items if org exists
    let orgDuesPrice = 0;
    let uniformPrice = 0;

    if (orgId) {
      const orgItems = await base44.asServiceRole.entities.OrgStoreItem.filter({ org_id: orgId });
      const orgDues = orgItems.find(i => i.name === 'Organization Dues');
      const uniform = orgItems.find(i => i.name === 'Uniform Package');
      if (orgDues) orgDuesPrice = orgDues.price || 0;
      if (uniform) uniformPrice = uniform.price || 0;
    }

    await base44.asServiceRole.entities.TeamStoreItem.bulkCreate([
      { team_id: teamId, org_id: orgId || null, name: 'Organization Dues', price: orgDuesPrice, status: 'Unpublished', is_org_item: true },
      { team_id: teamId, org_id: orgId || null, name: 'Uniform Package', price: uniformPrice, status: 'Unpublished', is_org_item: true },
      { team_id: teamId, org_id: orgId || null, name: 'Team Dues', price: 0, status: 'Unpublished', is_org_item: false },
    ]);

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});